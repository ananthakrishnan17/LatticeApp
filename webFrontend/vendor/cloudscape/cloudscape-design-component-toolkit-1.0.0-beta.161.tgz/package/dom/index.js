"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.nodeBelongs = exports.nodeContains = exports.findUpUntil = void 0;
const tslib_1 = require("tslib");
var find_up_until_js_1 = require("./find-up-until.js");
Object.defineProperty(exports, "findUpUntil", { enumerable: true, get: function () { return tslib_1.__importDefault(find_up_until_js_1).default; } });
var node_contains_js_1 = require("./node-contains.js");
Object.defineProperty(exports, "nodeContains", { enumerable: true, get: function () { return tslib_1.__importDefault(node_contains_js_1).default; } });
var node_belongs_js_1 = require("./node-belongs.js");
Object.defineProperty(exports, "nodeBelongs", { enumerable: true, get: function () { return tslib_1.__importDefault(node_belongs_js_1).default; } });
