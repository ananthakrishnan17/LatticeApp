"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = nodeContains;
const element_types_js_1 = require("./element-types.js");
/**
 * Checks whether the given node is a parent of the other descendant node.
 * @param parent Parent node
 * @param descendant Node that is checked to be a descendant of the parent node
 */
function nodeContains(parent, descendant) {
    if (!parent || !descendant || !(0, element_types_js_1.isNode)(descendant)) {
        return false;
    }
    return parent.contains(descendant);
}
