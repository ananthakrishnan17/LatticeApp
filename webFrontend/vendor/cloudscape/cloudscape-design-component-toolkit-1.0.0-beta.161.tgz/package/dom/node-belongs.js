"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = nodeBelongs;
const index_js_1 = require("./index.js");
const element_types_js_1 = require("./element-types.js");
/**
 * Checks whether the given node (target) belongs to the container.
 * The function is similar to nodeContains but also accounts for dropdowns with expandToViewport=true.
 *
 * @param container Container node
 * @param target Node that is checked to be a descendant of the container
 */
function nodeBelongs(container, target) {
    var _a;
    if (!(0, element_types_js_1.isNode)(target)) {
        return false;
    }
    const portal = (0, index_js_1.findUpUntil)(target, node => node === container || ((0, element_types_js_1.isHTMLElement)(node) && !!node.dataset.awsuiReferrerId));
    if (portal && portal === container) {
        // We found the container as a direct ancestor without a portal
        return true;
    }
    const referrer = (0, element_types_js_1.isHTMLElement)(portal) ? document.getElementById((_a = portal.dataset.awsuiReferrerId) !== null && _a !== void 0 ? _a : '') : null;
    return referrer ? (0, index_js_1.nodeContains)(container, referrer) : (0, index_js_1.nodeContains)(container, target);
}
