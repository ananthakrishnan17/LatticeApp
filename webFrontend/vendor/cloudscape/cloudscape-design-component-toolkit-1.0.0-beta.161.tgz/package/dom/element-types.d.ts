export declare function isNode(target: unknown): target is Node;
export declare function isHTMLElement(target: unknown): target is HTMLElement;
export declare function isSVGElement(target: unknown): target is SVGElement;
