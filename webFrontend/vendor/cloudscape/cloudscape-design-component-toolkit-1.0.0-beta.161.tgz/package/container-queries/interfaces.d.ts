export { ContainerQueryEntry, ElementReference } from '../internal/container-queries/interfaces.js';
