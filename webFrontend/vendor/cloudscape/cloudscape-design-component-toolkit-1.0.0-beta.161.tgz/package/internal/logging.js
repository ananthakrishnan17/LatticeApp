"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.warnOnce = warnOnce;
exports.clearMessageCache = clearMessageCache;
const is_development_js_1 = require("./is-development.js");
const messageCache = new Set();
function warnOnce(component, message) {
    if (is_development_js_1.isDevelopment) {
        const warning = `[AwsUi] [${component}] ${message}`;
        if (!messageCache.has(warning)) {
            messageCache.add(warning);
            console.warn(warning);
        }
    }
}
function clearMessageCache() {
    messageCache.clear();
}
