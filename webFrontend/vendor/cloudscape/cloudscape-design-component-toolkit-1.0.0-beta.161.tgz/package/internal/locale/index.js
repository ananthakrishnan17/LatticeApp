"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeStartOfWeek = exports.normalizeLocale = exports.mergeLocales = void 0;
var merge_locales_js_1 = require("./merge-locales.js");
Object.defineProperty(exports, "mergeLocales", { enumerable: true, get: function () { return merge_locales_js_1.mergeLocales; } });
var normalize_locale_js_1 = require("./normalize-locale.js");
Object.defineProperty(exports, "normalizeLocale", { enumerable: true, get: function () { return normalize_locale_js_1.normalizeLocale; } });
var normalize_start_of_week_js_1 = require("./normalize-start-of-week.js");
Object.defineProperty(exports, "normalizeStartOfWeek", { enumerable: true, get: function () { return normalize_start_of_week_js_1.normalizeStartOfWeek; } });
