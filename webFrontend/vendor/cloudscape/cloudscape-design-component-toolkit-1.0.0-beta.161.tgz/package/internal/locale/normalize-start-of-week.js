"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeStartOfWeek = normalizeStartOfWeek;
const weekstart_1 = require("weekstart");
function normalizeStartOfWeek(startOfWeek, locale) {
    return (typeof startOfWeek === 'number' ? startOfWeek % 7 : (0, weekstart_1.getWeekStartByLocale)(locale));
}
