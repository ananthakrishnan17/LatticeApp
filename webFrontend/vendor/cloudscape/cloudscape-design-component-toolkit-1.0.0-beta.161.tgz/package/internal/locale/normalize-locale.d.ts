export declare function normalizeLocale(component: string, locale: string | null): string;
