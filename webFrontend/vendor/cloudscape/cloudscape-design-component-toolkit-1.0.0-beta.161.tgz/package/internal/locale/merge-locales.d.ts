export declare function mergeLocales(locale: string, fullLocale: string): string;
