"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.mergeLocales = mergeLocales;
function mergeLocales(locale, fullLocale) {
    const isShort = locale.length === 2;
    if (isShort && fullLocale.indexOf(locale) === 0) {
        return fullLocale;
    }
    return locale;
}
