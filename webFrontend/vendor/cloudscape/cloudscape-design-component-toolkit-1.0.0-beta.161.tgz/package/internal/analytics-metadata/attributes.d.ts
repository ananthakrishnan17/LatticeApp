import { GeneratedAnalyticsMetadataFragment } from './interfaces.js';
export declare const METADATA_DATA_ATTRIBUTE = "awsuiAnalytics";
export declare const METADATA_ATTRIBUTE = "data-awsui-analytics";
export declare const LABEL_DATA_ATTRIBUTE = "awsuiAnalyticsLabel";
export declare const REFERRER_DATA_ATTRIBUTE = "awsuiReferrerId";
export declare const REFERRER_ATTRIBUTE = "data-awsui-referrer-id";
export declare const activateAnalyticsMetadata: (active: boolean) => void;
export declare const getAnalyticsMetadataAttribute: (metadata: GeneratedAnalyticsMetadataFragment) => {
    "data-awsui-analytics": string;
} | {
    "data-awsui-analytics"?: undefined;
};
export declare const copyAnalyticsMetadataAttribute: (props: any) => {
    "data-awsui-analytics": any;
} | {
    "data-awsui-analytics"?: undefined;
};
export declare const getAnalyticsLabelAttribute: (labelIdentifierString: string) => {
    "data-awsui-analytics-label": string;
} | {
    "data-awsui-analytics-label"?: undefined;
};
