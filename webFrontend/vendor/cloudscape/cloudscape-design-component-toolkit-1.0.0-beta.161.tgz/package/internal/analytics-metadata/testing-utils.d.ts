import { GeneratedAnalyticsMetadataFragment } from './interfaces.js';
interface RawAnalyticsMetadata {
    metadata: Array<GeneratedAnalyticsMetadataFragment>;
    labelSelectors: Array<string>;
}
export declare const getRawAnalyticsMetadata: (target: HTMLElement | null) => RawAnalyticsMetadata;
export {};
