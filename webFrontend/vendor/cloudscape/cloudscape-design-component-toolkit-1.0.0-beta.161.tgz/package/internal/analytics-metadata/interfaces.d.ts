export interface GeneratedAnalyticsMetadata {
    action: string;
    detail: Record<string, string>;
    contexts: Array<GeneratedAnalyticsMetadataComponentContext>;
}
interface GeneratedAnalyticsMetadataComponent {
    name: string;
    label: string;
    instanceIdentifier?: string;
    properties?: Record<string, string | Array<string> | Array<Array<string>>>;
    innerContext?: Record<string, string>;
}
interface GeneratedAnalyticsMetadataComponentContext {
    type: 'component';
    detail: GeneratedAnalyticsMetadataComponent;
}
/**
 * Determines how elements are selected when extracting labels.
 * - 'single': Selects a single element matching the selector (default)
 * - 'multi': Selects all elements matching the selector and returns an array of labels
 */
export type LabelSelectionMode = 'single' | 'multi';
export interface LabelIdentifier {
    selector?: string | Array<string>;
    root?: 'component' | 'self' | 'body';
    rootSelector?: string;
}
export interface GeneratedAnalyticsMetadataFragment extends Omit<Partial<GeneratedAnalyticsMetadata>, 'detail'> {
    detail?: Record<string, string | LabelIdentifier>;
    component?: Omit<Partial<GeneratedAnalyticsMetadataComponent>, 'innerContext' | 'label' | 'properties'> & {
        label?: string | LabelIdentifier;
        innerContext?: Record<string, string | LabelIdentifier>;
        properties?: Record<string, string | Array<string> | Array<Array<string>> | LabelIdentifier>;
    };
}
export {};
