"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.isNodeComponent = exports.findLogicalParent = void 0;
exports.findComponentUpUntil = findComponentUpUntil;
exports.findSelectorUp = findSelectorUp;
const attributes_js_1 = require("./attributes.js");
const findLogicalParent = (node) => {
    try {
        const referrer = node.dataset[attributes_js_1.REFERRER_DATA_ATTRIBUTE];
        if (referrer) {
            return (node.ownerDocument || node).querySelector(`[id="${referrer}"]`);
        }
        return node.parentElement;
    }
    catch {
        return null;
    }
};
exports.findLogicalParent = findLogicalParent;
function findComponentUpUntil(node, until = document.body) {
    let firstComponentElement = node;
    while (firstComponentElement && firstComponentElement !== until && !(0, exports.isNodeComponent)(firstComponentElement)) {
        firstComponentElement = (0, exports.findLogicalParent)(firstComponentElement);
    }
    return firstComponentElement && (0, exports.isNodeComponent)(firstComponentElement) ? firstComponentElement : null;
}
const isNodeComponent = (node) => {
    const metadataString = node.dataset[attributes_js_1.METADATA_DATA_ATTRIBUTE];
    if (!metadataString) {
        return false;
    }
    try {
        const metadata = JSON.parse(metadataString);
        return !!metadata.component && !!metadata.component.name;
    }
    catch {
        return false;
    }
};
exports.isNodeComponent = isNodeComponent;
function findSelectorUp(node, selector) {
    let current = node;
    while (current && current.tagName !== 'body' && !current.matches(selector)) {
        current = (0, exports.findLogicalParent)(current);
    }
    return current && current.tagName !== 'body' ? current : null;
}
