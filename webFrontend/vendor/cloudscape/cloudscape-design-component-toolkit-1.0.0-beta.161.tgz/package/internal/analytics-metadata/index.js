"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.activateAnalyticsMetadata = exports.getAnalyticsLabelAttribute = exports.copyAnalyticsMetadataAttribute = exports.getAnalyticsMetadataAttribute = void 0;
var attributes_js_1 = require("./attributes.js");
Object.defineProperty(exports, "getAnalyticsMetadataAttribute", { enumerable: true, get: function () { return attributes_js_1.getAnalyticsMetadataAttribute; } });
Object.defineProperty(exports, "copyAnalyticsMetadataAttribute", { enumerable: true, get: function () { return attributes_js_1.copyAnalyticsMetadataAttribute; } });
Object.defineProperty(exports, "getAnalyticsLabelAttribute", { enumerable: true, get: function () { return attributes_js_1.getAnalyticsLabelAttribute; } });
Object.defineProperty(exports, "activateAnalyticsMetadata", { enumerable: true, get: function () { return attributes_js_1.activateAnalyticsMetadata; } });
