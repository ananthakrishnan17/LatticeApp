export { GeneratedAnalyticsMetadataFragment, GeneratedAnalyticsMetadata, LabelIdentifier } from './interfaces.js';
export { getAnalyticsMetadataAttribute, copyAnalyticsMetadataAttribute, getAnalyticsLabelAttribute, activateAnalyticsMetadata, } from './attributes.js';
