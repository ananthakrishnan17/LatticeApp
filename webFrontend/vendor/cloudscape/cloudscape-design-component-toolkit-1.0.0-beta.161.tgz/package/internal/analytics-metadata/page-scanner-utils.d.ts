interface GeneratedAnalyticsMetadataComponentTree {
    name: string;
    label: string;
    properties?: Record<string, string | Array<string> | Array<Array<string>>>;
    children?: Array<GeneratedAnalyticsMetadataComponentTree>;
}
export declare const getComponentsTree: (node?: HTMLElement | Document | null) => Array<GeneratedAnalyticsMetadataComponentTree>;
export {};
