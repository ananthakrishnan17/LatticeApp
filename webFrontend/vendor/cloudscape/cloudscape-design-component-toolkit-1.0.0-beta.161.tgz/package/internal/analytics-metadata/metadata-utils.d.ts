import { GeneratedAnalyticsMetadataFragment } from './interfaces.js';
export declare const mergeMetadata: (metadata: GeneratedAnalyticsMetadataFragment | null, localMetadata: GeneratedAnalyticsMetadataFragment | null) => any;
export declare const processMetadata: (node: HTMLElement | null, localMetadata: any) => GeneratedAnalyticsMetadataFragment;
export declare const merge: (inputTarget: any, inputSource: any) => any;
