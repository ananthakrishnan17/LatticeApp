"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.merge = exports.processMetadata = exports.mergeMetadata = void 0;
const labels_utils_js_1 = require("./labels-utils.js");
const mergeMetadata = (metadata, localMetadata) => {
    const output = (0, exports.merge)(metadata, localMetadata);
    if (output.component && output.component.name) {
        output.contexts = [...(output.contexts || []), { type: 'component', detail: output.component }];
        delete output.component;
    }
    return output;
};
exports.mergeMetadata = mergeMetadata;
const processMetadata = (node, localMetadata) => {
    return Object.keys(localMetadata).reduce((acc, key) => {
        if (key.toLowerCase().match(/labels$/)) {
            acc[key] = (0, labels_utils_js_1.processLabel)(node, localMetadata[key], 'multi');
        }
        else if (key.toLowerCase().match(/label$/)) {
            acc[key] = (0, labels_utils_js_1.processLabel)(node, localMetadata[key], 'single');
        }
        else if (typeof localMetadata[key] !== 'string' && !Array.isArray(localMetadata[key])) {
            acc[key] = (0, exports.processMetadata)(node, localMetadata[key]);
            if (key === 'properties' && localMetadata.name === 'awsui.Table') {
                const selectedItems = getTableSelectedItems(node);
                if (selectedItems.length) {
                    acc[key].selectedItemsLabels = selectedItems;
                }
                const columns = getTableColumns(node);
                if (columns.length) {
                    acc[key].columnLabels = columns;
                }
            }
        }
        else {
            acc[key] = localMetadata[key];
        }
        return acc;
    }, {});
};
exports.processMetadata = processMetadata;
const isNil = (value) => {
    return typeof value === 'undefined' || value === null;
};
const merge = (inputTarget, inputSource) => {
    const merged = {};
    const target = inputTarget || {};
    const source = inputSource || {};
    const targetKeys = Object.keys(target);
    const sourceKeys = Object.keys(source);
    const allKeys = new Set([...targetKeys, ...sourceKeys]);
    for (const key of allKeys) {
        if (target[key] && !source[key]) {
            merged[key] = target[key];
        }
        else if (!target[key] && !isNil(source[key])) {
            merged[key] = source[key];
        }
        else if (typeof target[key] === 'string' || Array.isArray(target[key])) {
            merged[key] = source[key];
        }
        else {
            merged[key] = (0, exports.merge)(target[key], source[key]);
        }
    }
    return JSON.parse(JSON.stringify(merged));
};
exports.merge = merge;
const getTableSelectedItems = (node) => {
    if (!node) {
        return [];
    }
    return Array.from(node.querySelectorAll('tr[data-selection-item="item"]'))
        .filter(row => row.querySelector('input:checked') || row.getAttribute('aria-selected') === 'true')
        .map(row => Array.from(row.querySelectorAll('td, th'))
        .filter(cell => !cell.querySelector('input'))
        .map(cell => { var _a; return ((_a = cell.textContent) === null || _a === void 0 ? void 0 : _a.trim()) || ''; })
        .filter(Boolean))
        .filter(row => row.length > 0);
};
const getTableColumns = (node) => {
    if (!node) {
        return [];
    }
    const headerRow = node.querySelector('thead tr, tr:first-child');
    return headerRow
        ? Array.from(headerRow.querySelectorAll('th, td'))
            .filter(cell => !cell.className.includes('selection-control'))
            .map(cell => { var _a; return ((_a = cell.textContent) === null || _a === void 0 ? void 0 : _a.trim()) || ''; })
            .filter(Boolean)
        : [];
};
