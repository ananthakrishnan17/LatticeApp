"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRawAnalyticsMetadata = void 0;
const attributes_js_1 = require("./attributes.js");
const dom_utils_js_1 = require("./dom-utils.js");
const getRawAnalyticsMetadata = (target) => {
    const output = {
        metadata: [],
        labelSelectors: [],
    };
    let currentNode = target;
    while (currentNode) {
        try {
            const currentMetadataString = currentNode.dataset[attributes_js_1.METADATA_DATA_ATTRIBUTE];
            if (currentMetadataString) {
                const currentMetadata = JSON.parse(currentMetadataString);
                output.metadata.push(currentMetadata);
                output.labelSelectors = [...output.labelSelectors, ...getLabelSelectors(currentMetadata)];
            }
        }
        catch {
            /* empty */
        }
        finally {
            currentNode = (0, dom_utils_js_1.findLogicalParent)(currentNode);
        }
    }
    return output;
};
exports.getRawAnalyticsMetadata = getRawAnalyticsMetadata;
const getLabelSelectors = (localMetadata) => {
    return Object.keys(localMetadata).reduce((acc, key) => {
        if (key.toLowerCase().match(/label$/)) {
            acc = [...acc, ...getLabelSelectorsFromLabelIdentifier(localMetadata[key])];
        }
        else if (typeof localMetadata[key] !== 'string') {
            acc = [...acc, ...getLabelSelectors(localMetadata[key])];
        }
        return acc;
    }, []);
};
const getLabelSelectorsFromLabelIdentifier = (label) => {
    let labels = [];
    if (typeof label === 'string') {
        labels.push(label);
    }
    else {
        if (label.selector) {
            if (typeof label.selector === 'string') {
                labels.push(label.selector);
            }
            else {
                labels = [...label.selector];
            }
        }
        if (label.rootSelector) {
            labels.push(label.rootSelector);
        }
    }
    return labels;
};
