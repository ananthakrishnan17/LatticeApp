"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabelFromElement = exports.processLabel = void 0;
const attributes_js_1 = require("./attributes.js");
const dom_utils_js_1 = require("./dom-utils.js");
const processLabel = (node, labelIdentifier, selectionMode = 'single') => {
    if (selectionMode === 'multi') {
        return processMultiLabels(node, labelIdentifier);
    }
    return processSingleLabel(node, labelIdentifier);
};
exports.processLabel = processLabel;
const processSingleLabel = (node, labelIdentifier) => {
    if (labelIdentifier === null) {
        return '';
    }
    const formattedLabelIdentifier = formatLabelIdentifier(labelIdentifier);
    const selector = formattedLabelIdentifier.selector;
    if (Array.isArray(selector)) {
        for (const labelSelector of selector) {
            const label = processSingleLabelInternal(node, labelSelector, formattedLabelIdentifier.root, formattedLabelIdentifier.rootSelector);
            if (label) {
                return label;
            }
        }
        return '';
    }
    return processSingleLabelInternal(node, selector, formattedLabelIdentifier.root, formattedLabelIdentifier.rootSelector);
};
const processMultiLabels = (node, labelIdentifier) => {
    if (labelIdentifier === null) {
        return [];
    }
    const formattedLabelIdentifier = formatLabelIdentifier(labelIdentifier);
    const selector = formattedLabelIdentifier.selector;
    if (Array.isArray(selector)) {
        for (const labelSelector of selector) {
            const labels = processMultiLabelsInternal(node, labelSelector, formattedLabelIdentifier.root, formattedLabelIdentifier.rootSelector);
            if (labels.length > 0) {
                return labels;
            }
        }
        return [];
    }
    return processMultiLabelsInternal(node, selector, formattedLabelIdentifier.root, formattedLabelIdentifier.rootSelector);
};
const formatLabelIdentifier = (labelIdentifier) => {
    if (typeof labelIdentifier === 'string') {
        return { selector: labelIdentifier };
    }
    return labelIdentifier;
};
const processSingleLabelInternal = (node, labelSelector, root = 'self', rootSelector) => {
    if (!node) {
        return '';
    }
    if (rootSelector) {
        return processSingleLabelInternal((0, dom_utils_js_1.findSelectorUp)(node, rootSelector), labelSelector);
    }
    if (root === 'component') {
        return processSingleLabelInternal((0, dom_utils_js_1.findComponentUpUntil)(node), labelSelector);
    }
    if (root === 'body') {
        return processSingleLabelInternal(node.ownerDocument.body, labelSelector);
    }
    let labelElement = node;
    if (labelSelector) {
        labelElement = labelElement.querySelector(labelSelector);
    }
    if (labelElement && labelElement.dataset[attributes_js_1.LABEL_DATA_ATTRIBUTE]) {
        return processSingleLabel(labelElement, labelElement.dataset[attributes_js_1.LABEL_DATA_ATTRIBUTE]);
    }
    return (0, exports.getLabelFromElement)(labelElement);
};
const processMultiLabelsInternal = (node, labelSelector, root = 'self', rootSelector) => {
    if (!node) {
        return [];
    }
    if (rootSelector) {
        return processMultiLabelsInternal((0, dom_utils_js_1.findSelectorUp)(node, rootSelector), labelSelector);
    }
    if (root === 'component') {
        return processMultiLabelsInternal((0, dom_utils_js_1.findComponentUpUntil)(node), labelSelector);
    }
    if (root === 'body') {
        return processMultiLabelsInternal(node.ownerDocument.body, labelSelector);
    }
    const elements = Array.from(node.querySelectorAll(labelSelector));
    return elements
        .map(el => {
        if (el.dataset[attributes_js_1.LABEL_DATA_ATTRIBUTE]) {
            return processMultiLabels(el, el.dataset[attributes_js_1.LABEL_DATA_ATTRIBUTE]);
        }
        return (0, exports.getLabelFromElement)(el);
    })
        .flat()
        .filter(label => label);
};
const getLabelFromElement = (element) => {
    if (!element) {
        return '';
    }
    const ariaLabel = element.getAttribute('aria-label');
    if (ariaLabel) {
        return ariaLabel.trim();
    }
    const ariaLabelledBy = element.getAttribute('aria-labelledby');
    if (ariaLabelledBy) {
        const elementWithLabel = document.querySelector(`[id="${ariaLabelledBy.split(' ')[0]}"]`);
        if (elementWithLabel !== element) {
            return (0, exports.getLabelFromElement)(elementWithLabel);
        }
    }
    return element.textContent ? element.textContent.trim() : '';
};
exports.getLabelFromElement = getLabelFromElement;
