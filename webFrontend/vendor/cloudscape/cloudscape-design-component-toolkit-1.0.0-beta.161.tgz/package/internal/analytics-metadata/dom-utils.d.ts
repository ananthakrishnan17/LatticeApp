export declare const findLogicalParent: (node: HTMLElement) => HTMLElement | null;
export declare function findComponentUpUntil(node: HTMLElement | null, until?: HTMLElement): HTMLElement | null;
export declare const isNodeComponent: (node: HTMLElement) => boolean;
export declare function findSelectorUp(node: HTMLElement | null, selector: string): HTMLElement | null;
