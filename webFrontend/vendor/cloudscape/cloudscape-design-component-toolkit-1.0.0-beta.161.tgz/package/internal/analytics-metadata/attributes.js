"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAnalyticsLabelAttribute = exports.copyAnalyticsMetadataAttribute = exports.getAnalyticsMetadataAttribute = exports.activateAnalyticsMetadata = exports.REFERRER_ATTRIBUTE = exports.REFERRER_DATA_ATTRIBUTE = exports.LABEL_DATA_ATTRIBUTE = exports.METADATA_ATTRIBUTE = exports.METADATA_DATA_ATTRIBUTE = void 0;
const index_js_1 = require("../global-flags/index.js");
exports.METADATA_DATA_ATTRIBUTE = 'awsuiAnalytics';
exports.METADATA_ATTRIBUTE = 'data-awsui-analytics';
exports.LABEL_DATA_ATTRIBUTE = 'awsuiAnalyticsLabel';
exports.REFERRER_DATA_ATTRIBUTE = 'awsuiReferrerId';
exports.REFERRER_ATTRIBUTE = 'data-awsui-referrer-id';
const LABEL_ATTRIBUTE = 'data-awsui-analytics-label';
let activated = (0, index_js_1.getGlobalFlag)('analyticsMetadata');
const activateAnalyticsMetadata = (active) => {
    activated = active;
};
exports.activateAnalyticsMetadata = activateAnalyticsMetadata;
const getAnalyticsMetadataAttribute = (metadata) => activated
    ? {
        [exports.METADATA_ATTRIBUTE]: JSON.stringify(metadata),
    }
    : {};
exports.getAnalyticsMetadataAttribute = getAnalyticsMetadataAttribute;
const copyAnalyticsMetadataAttribute = (props) => activated
    ? {
        [exports.METADATA_ATTRIBUTE]: props[exports.METADATA_ATTRIBUTE],
    }
    : {};
exports.copyAnalyticsMetadataAttribute = copyAnalyticsMetadataAttribute;
const getAnalyticsLabelAttribute = (labelIdentifierString) => activated
    ? {
        [LABEL_ATTRIBUTE]: labelIdentifierString,
    }
    : {};
exports.getAnalyticsLabelAttribute = getAnalyticsLabelAttribute;
