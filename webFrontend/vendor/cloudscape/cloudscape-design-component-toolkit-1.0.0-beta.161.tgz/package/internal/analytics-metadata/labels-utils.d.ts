import { LabelIdentifier, LabelSelectionMode } from './interfaces.js';
export declare const processLabel: (node: HTMLElement | null, labelIdentifier: string | LabelIdentifier | null, selectionMode?: LabelSelectionMode) => string | string[] | string[][];
export declare const getLabelFromElement: (element: HTMLElement | null) => string;
