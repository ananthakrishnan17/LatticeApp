"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGeneratedAnalyticsMetadata = exports.getComponentsTree = exports.getRawAnalyticsMetadata = void 0;
var testing_utils_js_1 = require("./testing-utils.js");
Object.defineProperty(exports, "getRawAnalyticsMetadata", { enumerable: true, get: function () { return testing_utils_js_1.getRawAnalyticsMetadata; } });
var page_scanner_utils_js_1 = require("./page-scanner-utils.js");
Object.defineProperty(exports, "getComponentsTree", { enumerable: true, get: function () { return page_scanner_utils_js_1.getComponentsTree; } });
const attributes_js_1 = require("./attributes.js");
const dom_utils_js_1 = require("./dom-utils.js");
const metadata_utils_js_1 = require("./metadata-utils.js");
const getGeneratedAnalyticsMetadata = (target) => {
    let metadata = {};
    let currentNode = target;
    while (currentNode) {
        try {
            const currentMetadataString = currentNode.dataset[attributes_js_1.METADATA_DATA_ATTRIBUTE];
            if (currentMetadataString) {
                const currentMetadata = JSON.parse(currentMetadataString);
                metadata = (0, metadata_utils_js_1.mergeMetadata)(metadata, (0, metadata_utils_js_1.processMetadata)(currentNode, currentMetadata));
            }
        }
        catch {
            /* empty */
        }
        finally {
            currentNode = (0, dom_utils_js_1.findLogicalParent)(currentNode);
        }
    }
    return metadata;
};
exports.getGeneratedAnalyticsMetadata = getGeneratedAnalyticsMetadata;
