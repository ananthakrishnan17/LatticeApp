"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.getComponentsTree = void 0;
const attributes_js_1 = require("./attributes.js");
const dom_utils_js_1 = require("./dom-utils.js");
const utils_js_1 = require("./utils.js");
const findPortalsOutsideOfNode = (node) => Array.from((node.ownerDocument || node).querySelectorAll(`[${attributes_js_1.REFERRER_ATTRIBUTE}]`)).filter(element => {
    const referrer = element.dataset[attributes_js_1.REFERRER_DATA_ATTRIBUTE];
    return !!node.querySelector(`[id="${referrer}"]`) && !node.querySelector(`[${attributes_js_1.REFERRER_ATTRIBUTE}="${referrer}"]`);
});
const findAccessibleIframes = (node) => Array.from(node.querySelectorAll('iframe')).filter(iframe => !!iframe.contentDocument);
const getComponentsArray = (node = document) => {
    const elementsWithMetadata = Array.from(node.querySelectorAll(`[${attributes_js_1.METADATA_ATTRIBUTE}]`));
    findPortalsOutsideOfNode(node).forEach(portal => {
        elementsWithMetadata.push(...getComponentsArray(portal));
    });
    return elementsWithMetadata.filter(dom_utils_js_1.isNodeComponent);
};
const buildComponentsMap = (node = document) => {
    const componentsArray = getComponentsArray(node);
    const map = {
        roots: [],
        parents: new Map(),
    };
    componentsArray.forEach(element => {
        var _a;
        const parent = element.parentElement ? (0, dom_utils_js_1.findComponentUpUntil)(element.parentElement, node) : null;
        if (!parent) {
            map.roots.push(element);
        }
        else {
            if (!map.parents.has(parent)) {
                map.parents.set(parent, []);
            }
            (_a = map.parents.get(parent)) === null || _a === void 0 ? void 0 : _a.push(element);
        }
    });
    findAccessibleIframes(node).forEach(iframe => iframe.contentDocument &&
        mergeComponentsMaps(map, (0, dom_utils_js_1.findComponentUpUntil)(iframe, node), buildComponentsMap(iframe.contentDocument)));
    return map;
};
const mergeComponentsMaps = (parentMap, parentComponent, childMap) => {
    parentMap.parents = new Map([...parentMap.parents, ...childMap.parents]);
    if (childMap.roots.length > 0) {
        if (parentComponent) {
            if (!parentMap.parents.has(parentComponent)) {
                parentMap.parents.set(parentComponent, []);
            }
            childMap.roots.forEach(root => { var _a; return (_a = parentMap.parents.get(parentComponent)) === null || _a === void 0 ? void 0 : _a.push(root); });
        }
        else {
            parentMap.roots = [...parentMap.roots, ...childMap.roots];
        }
    }
};
const getComponentsTreeRecursive = (componentNodes, parentsMap) => {
    const tree = [];
    componentNodes.forEach(componentNode => {
        const treeItem = {
            ...(0, utils_js_1.getGeneratedAnalyticsMetadata)(componentNode).contexts[0].detail,
        };
        const children = parentsMap.has(componentNode)
            ? getComponentsTreeRecursive(parentsMap.get(componentNode), parentsMap)
            : [];
        if (children.length > 0) {
            treeItem.children = children;
        }
        tree.push(treeItem);
    });
    return tree;
};
const getComponentsTree = (node = document) => {
    if (!node) {
        return [];
    }
    const { roots, parents } = buildComponentsMap(node);
    return getComponentsTreeRecursive(roots, parents);
};
exports.getComponentsTree = getComponentsTree;
