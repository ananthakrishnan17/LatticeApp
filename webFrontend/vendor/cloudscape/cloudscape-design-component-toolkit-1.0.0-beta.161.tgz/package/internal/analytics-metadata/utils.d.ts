export { getRawAnalyticsMetadata } from './testing-utils.js';
export { getComponentsTree } from './page-scanner-utils.js';
import { GeneratedAnalyticsMetadata } from './interfaces.js';
export declare const getGeneratedAnalyticsMetadata: (target: HTMLElement | null) => GeneratedAnalyticsMetadata;
