export type TrackBy<T> = string | ((item: T) => string);
export declare const getTrackableValue: <T>(trackBy: TrackBy<T> | undefined, item: T) => string | T;
