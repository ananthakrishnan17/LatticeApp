import { TrackBy } from '../track-by/index.js';
export interface GroupSelectionState<T> {
    inverted: boolean;
    toggledItems: readonly T[];
}
export interface SelectionTreeProps<T> {
    getChildren(item: T): readonly T[];
    isComplete?(item: null | T): boolean;
    trackBy?: TrackBy<T>;
}
export declare class SelectionTree<T> {
    private roots;
    private treeProps;
    private itemKeyToItem;
    private itemToggleState;
    private itemProjectedSelectionState;
    private itemProjectedParentSelectionState;
    private itemProjectedIndeterminateState;
    private itemKeyToSelectedCount;
    private selectedItems;
    constructor(roots: readonly T[], treeProps: SelectionTreeProps<T>, state: GroupSelectionState<T>);
    isItemSelected: (item: T) => boolean;
    isItemIndeterminate: (item: T) => boolean;
    isAllItemsSelected: () => boolean;
    isAllItemsIndeterminate: () => boolean;
    getSelectedItemsCount: (item: T) => number;
    getSelectedItems: () => T[];
    getState: () => GroupSelectionState<T>;
    toggleAll: () => SelectionTree<T>;
    toggleSome: (requestedItems: readonly T[]) => SelectionTree<T>;
    invertAll: () => SelectionTree<T>;
    invertOne: (item: T) => SelectionTree<T>;
    private computeState;
    private isGroup;
    private getKey;
    private getItemForKey;
    private toggleKey;
    private unselectDeep;
    private clone;
}
