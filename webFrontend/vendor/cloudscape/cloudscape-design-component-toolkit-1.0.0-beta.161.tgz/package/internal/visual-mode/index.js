"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.isMotionDisabled = isMotionDisabled;
exports.useCurrentMode = useCurrentMode;
exports.useDensityMode = useDensityMode;
exports.useReducedMotion = useReducedMotion;
exports.clearVisualRefreshState = clearVisualRefreshState;
exports.useRuntimeVisualRefresh = useRuntimeVisualRefresh;
const react_1 = require("react");
const index_js_1 = require("../../dom/index.js");
const index_js_2 = require("../singleton-handler/index.js");
const index_js_3 = require("../stable-callback/index.js");
const is_development_js_1 = require("../is-development.js");
const logging_js_1 = require("../logging.js");
const index_js_4 = require("../global-flags/index.js");
const safe_match_media_js_1 = require("../utils/safe-match-media.js");
function isMotionDisabled(element) {
    return (!!(0, index_js_1.findUpUntil)(element, node => node.classList.contains('awsui-motion-disabled')) ||
        (0, safe_match_media_js_1.safeMatchMedia)(element, '(prefers-reduced-motion: reduce)'));
}
// Generic hook for detecting mode changes via DOM mutation observation.
// Prevents unnecessary re-renders by only updating state when the value actually changes.
function useModeDetector(elementRef, detector, initialValue) {
    const [value, setValue] = (0, react_1.useState)(initialValue);
    useMutationObserver(elementRef, node => {
        const newValue = detector(node);
        /**
         * React has a behavior that triggers a re-render even if the same value is provided in the setState, while it does not
         * commit any changes to the DOM (commit phase) the function rerenders. This causes a false react act warnings in testing
         * and any component using the Transition component which in return uses this hook will possibly have false react warnings.
         *
         * To fix this, we manually stop setting the state ourselves if we see the same value.
         * References:  https://www.reddit.com/r/reactjs/comments/1ej505e/why_does_it_rerender_even_when_state_is_same/#:~:text=If%20the%20new%20value%20you,shouldn't%20affect%20your%20code
         */
        if (newValue !== value) {
            setValue(newValue);
        }
    });
    return value;
}
function detectCurrentMode(node) {
    const darkModeParent = (0, index_js_1.findUpUntil)(node, node => node.classList.contains('awsui-polaris-dark-mode') || node.classList.contains('awsui-dark-mode'));
    return darkModeParent ? 'dark' : 'light';
}
function detectDensityMode(node) {
    const compactModeParent = (0, index_js_1.findUpUntil)(node, node => node.classList.contains('awsui-polaris-compact-mode') || node.classList.contains('awsui-compact-mode'));
    return compactModeParent ? 'compact' : 'comfortable';
}
// Note that this hook doesn't take into consideration @media print (unlike the dark mode CSS),
// due to challenges with cross-browser implementations of media/print state change listeners.
// This means that components using this hook will render in dark mode even when printing.
function useCurrentMode(elementRef) {
    return useModeDetector(elementRef, detectCurrentMode, 'light');
}
function useDensityMode(elementRef) {
    return useModeDetector(elementRef, detectDensityMode, 'comfortable');
}
function useReducedMotion(elementRef) {
    return useModeDetector(elementRef, isMotionDisabled, false);
}
const useMutationSingleton = (0, index_js_2.createSingletonHandler)(handler => {
    const observer = new MutationObserver(() => handler());
    observer.observe(document.body, { attributes: true, subtree: true });
    return () => observer.disconnect();
});
function useMutationObserver(elementRef, onChange) {
    const handler = (0, index_js_3.useStableCallback)(() => {
        if (elementRef.current) {
            onChange(elementRef.current);
        }
    });
    useMutationSingleton(handler);
    (0, react_1.useEffect)(() => {
        handler();
    }, [handler]);
}
// We expect VR is to be set only once and before the application is rendered.
let visualRefreshState = undefined;
// for testing
function clearVisualRefreshState() {
    visualRefreshState = undefined;
    if (typeof document !== 'undefined') {
        document.body.classList.remove('awsui-visual-refresh');
    }
}
function detectVisualRefreshClassName() {
    return typeof document !== 'undefined' && !!document.querySelector('.awsui-visual-refresh');
}
function detectVisualRefreshFlag() {
    var _a, _b;
    const global = (0, index_js_4.getGlobal)();
    return (_b = (_a = global === null || global === void 0 ? void 0 : global[index_js_4.awsuiVisualRefreshFlag]) === null || _a === void 0 ? void 0 : _a.call(global)) !== null && _b !== void 0 ? _b : false;
}
function useRuntimeVisualRefresh() {
    if (visualRefreshState === undefined) {
        visualRefreshState = detectVisualRefreshClassName();
        if (!visualRefreshState) {
            if (detectVisualRefreshFlag()) {
                visualRefreshState = true;
                if (typeof document !== 'undefined') {
                    document.body.classList.add('awsui-visual-refresh');
                }
            }
        }
    }
    if (is_development_js_1.isDevelopment) {
        const newVisualRefreshState = detectVisualRefreshClassName() || detectVisualRefreshFlag();
        if (newVisualRefreshState !== visualRefreshState) {
            (0, logging_js_1.warnOnce)('Visual Refresh', 'Dynamic visual refresh change detected. This is not supported. ' +
                'Make sure `awsui-visual-refresh` is attached to the `<body>` element before initial React render');
        }
    }
    return visualRefreshState;
}
