import React from 'react';
export declare function isMotionDisabled(element: HTMLElement): boolean;
export declare function useCurrentMode(elementRef: React.RefObject<HTMLElement>): "dark" | "light";
export declare function useDensityMode(elementRef: React.RefObject<HTMLElement>): "compact" | "comfortable";
export declare function useReducedMotion(elementRef: React.RefObject<HTMLElement>): boolean;
export declare function clearVisualRefreshState(): void;
export declare function useRuntimeVisualRefresh(): boolean;
