"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSingletonHandler = createSingletonHandler;
exports.createSingletonState = createSingletonState;
const react_1 = require("react");
const react_dom_1 = require("react-dom");
function createSingletonHandler(factory) {
    // Using Set for O(1) add/delete operations instead of Array's O(n) indexOf + splice.
    // Sets maintain insertion order (ES2015+), preserving iteration consistency.
    const listeners = new Set();
    const callback = value => {
        (0, react_dom_1.unstable_batchedUpdates)(() => {
            for (const listener of listeners) {
                listener(value);
            }
        });
    };
    let cleanup;
    return function useSingleton(listener) {
        (0, react_1.useEffect)(() => {
            if (listeners.size === 0) {
                cleanup = factory(callback);
            }
            listeners.add(listener);
            return () => {
                listeners.delete(listener);
                if (listeners.size === 0) {
                    cleanup();
                    cleanup = undefined;
                }
            };
            // register handlers only on mount
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []);
    };
}
function createSingletonState({ factory, initialState }) {
    const useSingleton = createSingletonHandler(factory);
    return function useSingletonState() {
        const [state, setState] = (0, react_1.useState)(initialState);
        useSingleton(setState);
        return state;
    };
}
