export declare const awsuiVisualRefreshFlag: unique symbol;
export declare const awsuiGlobalFlagsSymbol: unique symbol;
interface GlobalFlags {
    appLayoutWidget?: boolean;
    appLayoutToolbar?: boolean;
    analyticsMetadata?: boolean;
}
export interface FlagsHolder {
    [awsuiVisualRefreshFlag]?: () => boolean;
    [awsuiGlobalFlagsSymbol]?: GlobalFlags;
}
export declare const getTopWindow: () => FlagsHolder | null;
export declare function getGlobal(): FlagsHolder | null;
export declare const getGlobalFlag: (flagName: keyof GlobalFlags) => GlobalFlags[keyof GlobalFlags] | undefined;
export declare const setGlobalFlag: <FlagName extends keyof GlobalFlags>(flagName: FlagName, value: GlobalFlags[FlagName] | undefined) => void;
export {};
