"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.setGlobalFlag = exports.getGlobalFlag = exports.getTopWindow = exports.awsuiGlobalFlagsSymbol = exports.awsuiVisualRefreshFlag = void 0;
exports.getGlobal = getGlobal;
exports.awsuiVisualRefreshFlag = Symbol.for('awsui-visual-refresh-flag');
exports.awsuiGlobalFlagsSymbol = Symbol.for('awsui-global-flags');
const getTopWindow = () => {
    return window.top;
};
exports.getTopWindow = getTopWindow;
function getGlobal() {
    return (typeof window !== 'undefined' ? window : globalThis);
}
function readFlag(holder, flagName) {
    var _a;
    return (_a = holder === null || holder === void 0 ? void 0 : holder[exports.awsuiGlobalFlagsSymbol]) === null || _a === void 0 ? void 0 : _a[flagName];
}
const getGlobalFlag = (flagName) => {
    try {
        const ownFlag = readFlag(getGlobal(), flagName);
        if (ownFlag !== undefined) {
            return ownFlag;
        }
        return readFlag((0, exports.getTopWindow)(), flagName);
    }
    catch {
        return undefined;
    }
};
exports.getGlobalFlag = getGlobalFlag;
const setGlobalFlag = (flagName, value) => {
    const holder = getGlobal();
    if (value === undefined) {
        const currentValue = readFlag(holder, flagName);
        if (currentValue !== undefined) {
            delete holder[exports.awsuiGlobalFlagsSymbol][flagName];
        }
    }
    else {
        holder[exports.awsuiGlobalFlagsSymbol] = holder[exports.awsuiGlobalFlagsSymbol] || {};
        holder[exports.awsuiGlobalFlagsSymbol][flagName] = value;
    }
};
exports.setGlobalFlag = setGlobalFlag;
