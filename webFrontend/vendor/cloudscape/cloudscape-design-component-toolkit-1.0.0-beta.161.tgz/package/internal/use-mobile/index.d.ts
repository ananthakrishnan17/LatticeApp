export declare const forceMobileModeSymbol: unique symbol;
export declare const useMobile: () => boolean;
