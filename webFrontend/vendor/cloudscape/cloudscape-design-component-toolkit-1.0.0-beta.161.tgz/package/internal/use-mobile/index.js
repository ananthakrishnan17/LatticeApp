"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.useMobile = exports.forceMobileModeSymbol = void 0;
const index_js_1 = require("../singleton-handler/index.js");
const breakpoints_js_1 = require("../breakpoints.js");
const safe_match_media_js_1 = require("../utils/safe-match-media.js");
exports.forceMobileModeSymbol = Symbol.for('awsui-force-mobile-mode');
function getIsMobile() {
    // allow overriding the mobile mode in tests
    // any is needed because of this https://github.com/microsoft/TypeScript/issues/36813
    const forceMobileMode = globalThis[exports.forceMobileModeSymbol];
    if (typeof forceMobileMode !== 'undefined') {
        return forceMobileMode;
    }
    if (typeof window === 'undefined') {
        // assume desktop in server-rendering
        return false;
    }
    /**
     * Some browsers include the scrollbar width in their media query calculations, but
     * some browsers don't. Thus we can't use `window.innerWidth` or
     * `document.documentElement.clientWidth` to get a very accurate result (since we
     * wouldn't know which one of them to use).
     * Instead, we use the media query here in JS too.
     */
    return (0, safe_match_media_js_1.safeMatchMedia)(document.body, `(max-width: ${breakpoints_js_1.mobileBreakpoint}px)`);
}
exports.useMobile = (0, index_js_1.createSingletonState)({
    initialState: () => getIsMobile(),
    factory: handler => {
        const listener = () => handler(getIsMobile());
        window.addEventListener('resize', listener);
        return () => {
            window.removeEventListener('resize', listener);
        };
    },
});
