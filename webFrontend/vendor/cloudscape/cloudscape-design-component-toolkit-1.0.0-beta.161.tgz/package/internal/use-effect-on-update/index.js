"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.useEffectOnUpdate = useEffectOnUpdate;
const react_1 = require("react");
// useEffect, which skips the initial render
function useEffectOnUpdate(callback, deps) {
    const isFirstRender = (0, react_1.useRef)(true);
    (0, react_1.useEffect)(() => {
        if (isFirstRender.current) {
            isFirstRender.current = false;
        }
        else {
            return callback();
        }
        // This is a useEffect extension, will be validated at the call site
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, deps);
}
