import { DependencyList, EffectCallback } from 'react';
export declare function useEffectOnUpdate(callback: EffectCallback, deps: DependencyList): void;
