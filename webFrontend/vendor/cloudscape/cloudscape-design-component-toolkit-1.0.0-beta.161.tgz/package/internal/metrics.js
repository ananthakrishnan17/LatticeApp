"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.Metrics = void 0;
var metrics_js_1 = require("./base-component/metrics/metrics.js");
Object.defineProperty(exports, "Metrics", { enumerable: true, get: function () { return metrics_js_1.Metrics; } });
