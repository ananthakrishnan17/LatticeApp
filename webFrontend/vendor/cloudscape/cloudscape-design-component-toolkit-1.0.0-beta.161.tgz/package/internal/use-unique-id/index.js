"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.useRandomId = void 0;
exports.useUniqueId = useUniqueId;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
let counter = 0;
const useRandomId = () => {
    const idRef = (0, react_1.useRef)(null);
    if (!idRef.current) {
        idRef.current = `${counter++}-${Date.now()}-${Math.round(Math.random() * 10000)}`;
    }
    return idRef.current;
};
exports.useRandomId = useRandomId;
const useId = (_a = react_1.default.useId) !== null && _a !== void 0 ? _a : exports.useRandomId;
function useUniqueId(prefix) {
    return `${prefix ? prefix : ''}` + useId();
}
