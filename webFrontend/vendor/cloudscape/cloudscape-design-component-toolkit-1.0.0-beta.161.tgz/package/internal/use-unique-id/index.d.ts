export declare const useRandomId: () => string;
export declare function useUniqueId(prefix?: string): string;
