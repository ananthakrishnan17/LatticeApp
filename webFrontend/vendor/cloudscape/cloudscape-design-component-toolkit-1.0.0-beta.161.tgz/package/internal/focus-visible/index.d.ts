import React from 'react';
export declare function useFocusVisible(componentRef?: React.RefObject<HTMLElement | null>): void;
