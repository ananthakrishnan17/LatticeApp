export declare function warnOnce(component: string, message: string): void;
export declare function clearMessageCache(): void;
