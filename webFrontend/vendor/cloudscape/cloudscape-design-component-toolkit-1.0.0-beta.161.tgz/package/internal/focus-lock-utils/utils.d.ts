export declare function isFocusable(element: HTMLElement): boolean;
export declare function getAllFocusables(container: HTMLElement): HTMLElement[];
export declare function getFirstFocusable(container: HTMLElement): null | HTMLElement;
export declare function getLastFocusable(container: HTMLElement): null | HTMLElement;
