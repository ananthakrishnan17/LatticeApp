"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.setTestSingleTabStopNavigationTarget = exports.TestSingleTabStopNavigationProvider = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const index_js_1 = require("../index.js");
const index_js_2 = require("../../use-unique-id/index.js");
const providerRegistry = new Map();
const TestSingleTabStopNavigationProvider = ({ children, navigationActive, }) => {
    const focusablesRef = (0, react_1.useRef)(new Set());
    const focusHandlersRef = (0, react_1.useRef)(new Map());
    const registerFocusable = (0, react_1.useCallback)((focusable, changeHandler) => {
        focusablesRef.current.add(focusable);
        focusHandlersRef.current.set(focusable, changeHandler);
        return () => {
            focusablesRef.current.delete(focusable);
            focusHandlersRef.current.delete(focusable);
        };
    }, []);
    const providerId = (0, index_js_2.useUniqueId)();
    providerRegistry.set(providerId, {
        setCurrentTarget: (focusTarget, suppressed = []) => {
            focusablesRef.current.forEach(focusable => {
                const handler = focusHandlersRef.current.get(focusable);
                handler(focusTarget === focusable || suppressed.includes(focusable));
            });
        },
    });
    (0, react_1.useEffect)(() => () => {
        providerRegistry.delete(providerId);
    }, [providerId]);
    return (react_1.default.createElement(index_js_1.SingleTabStopNavigationContext.Provider, { value: {
            navigationActive,
            registerFocusable,
            // The reset target feature is not needed in the test provider, and it is
            // already tested with the actual provider implementation instead.
            // istanbul ignore next
            resetFocusTarget: () => { },
        } }, children));
};
exports.TestSingleTabStopNavigationProvider = TestSingleTabStopNavigationProvider;
const setTestSingleTabStopNavigationTarget = (focusTarget, suppressed) => {
    Array.from(providerRegistry).forEach(([, provider]) => provider.setCurrentTarget(focusTarget, suppressed));
};
exports.setTestSingleTabStopNavigationTarget = setTestSingleTabStopNavigationTarget;
