import React from 'react';
type SetTarget = (focusTarget: null | Element, suppressed?: (null | Element)[]) => void;
export declare const TestSingleTabStopNavigationProvider: ({ children, navigationActive, }: {
    children: React.ReactNode;
    navigationActive: boolean;
}) => React.JSX.Element;
export declare const setTestSingleTabStopNavigationTarget: SetTarget;
export {};
