import { PointerEvent as ReactPointerEvent } from 'react';
export declare function getIsRtl(element: null | HTMLElement | SVGElement): boolean;
/**
 * The offsetLeft property is relative to the left of the offsetParent
 * regardless of the document direction. This function returns the
 * offsetLeft value or computes the Rtl equivalent of this value
 * from the right of the offsetParent.
 */
export declare function getOffsetInlineStart(element: HTMLElement): number;
/**
 * The scrollLeft value returned by the browser will be a negative number
 * if the direction is RTL. This function returns a positive value for direction
 * independent of scroll computations. Additionally, the scrollLeft value can be
 * a decimal value on systems using display scaling requiring the floor and ceiling calls.
 */
export declare function getScrollInlineStart(element: HTMLElement): number;
/**
 * The clientX value is computed from the top left corner of the document regardless
 * of the document diretion. This function returns the clientX value or computes the
 * Rtl equivalent relative to the top right corner of the document in order for
 * computations to yield the same result in both element directions.
 */
export declare function getLogicalClientX(event: PointerEvent | ReactPointerEvent<unknown>, IsRtl: boolean): number;
/**
 * The getBoundingClientRect() function returns values relative to the top left
 * corner of the document regardless of document direction. The left/right position
 * will be transformed to insetInlineStart based on element direction in order to
 * support direction agnostic position computation.
 */
export declare function getLogicalBoundingClientRect(element: HTMLElement | SVGElement): {
    blockSize: number;
    inlineSize: number;
    insetBlockStart: number;
    insetBlockEnd: number;
    insetInlineStart: number;
    insetInlineEnd: number;
};
/**
 * The pageX position needs to be converted so it is relative to the right of
 * the document in order for computations to yield the same result in both
 * element directions.
 */
export declare function getLogicalPageX(event: MouseEvent): number;
