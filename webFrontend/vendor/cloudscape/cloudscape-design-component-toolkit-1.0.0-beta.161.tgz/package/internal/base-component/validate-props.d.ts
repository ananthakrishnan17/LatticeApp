export declare function validateProps(componentName: string, props: Record<string, any>, excludedProps: Array<string>, allowedEnums: Record<string, Array<string>>, systemName: string): void;
