"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.useComponentMetrics = useComponentMetrics;
const react_1 = require("react");
const metrics_js_1 = require("./metrics/metrics.js");
function useComponentMetrics(componentName, settings, configuration = { props: {} }) {
    (0, react_1.useEffect)(() => {
        const metrics = new metrics_js_1.Metrics(settings);
        if (typeof window !== 'undefined') {
            metrics.sendOpsMetricValue('awsui-viewport-width', window.innerWidth || 0);
            metrics.sendOpsMetricValue('awsui-viewport-height', window.innerHeight || 0);
        }
        metrics.logComponentsLoaded();
        metrics.logComponentUsed(componentName.toLowerCase(), configuration);
        // Components do not change the name dynamically. Explicit empty array to prevent accidental double metrics
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
}
