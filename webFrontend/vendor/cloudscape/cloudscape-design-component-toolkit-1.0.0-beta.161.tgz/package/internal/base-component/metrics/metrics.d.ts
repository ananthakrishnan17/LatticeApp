import { MetricsV2EventItem } from './log-clients.js';
import { ComponentConfiguration, PackageSettings } from './interfaces.js';
export declare class Metrics {
    private readonly context;
    private readonly clog;
    private readonly panorama;
    constructor(packageSource: PackageSettings);
    constructor(packageSource: string, packageVersion: string);
    private sendComponentMetric;
    private sendMetricOnce;
    /**
     * Calls Console Platform's client v2 logging JS API with provided metric name and detail.
     * Does nothing if Console Platform client logging JS is not present in page.
     */
    sendPanoramaMetric(metric: MetricsV2EventItem): void;
    sendOpsMetricObject(metricName: string, detail: Record<string, string | number | boolean>): void;
    sendOpsMetricValue(metricName: string, value: number): void;
    logComponentsLoaded(): void;
    logComponentUsed(componentName: string, configuration: ComponentConfiguration): void;
}
export declare function clearOneTimeMetricsCache(): void;
