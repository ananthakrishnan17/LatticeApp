type JSONValue = string | number | boolean | null | undefined;
export interface JSONObject {
    [key: string]: JSONObject | JSONValue;
}
export interface PackageSettings {
    packageSource: string;
    packageVersion: string;
    theme: string;
}
export interface ComponentConfiguration {
    props: Record<string, JSONValue>;
    metadata?: Record<string, JSONValue>;
}
export type AnalyticsMetadata = JSONObject;
export interface ComponentMetricDetail {
    componentName: string;
    action: 'loaded' | 'used';
    configuration?: ComponentConfiguration;
    packageSource?: string;
}
export interface ComponentMetricMinified {
    o: string;
    s?: string;
    t: string;
    a?: string;
    f: string;
    v: string;
    c?: JSONObject;
    p?: string;
}
export {};
