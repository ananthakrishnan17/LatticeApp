export interface MetricsV2EventItem {
    eventContext?: string;
    eventDetail?: string | Record<string, string | number | boolean>;
    eventValue?: string | Record<string, string | number | boolean>;
    timestamp?: number;
}
/**
 * Console Platform's client logging JS API client.
 */
export declare class CLogClient {
    /**
     * Sends metric but only if Console Platform client logging JS API is present in the page.
     */
    sendMetric(metricName: string, value: number, detail?: string): void;
    private findAWSC;
}
/**
 * Console Platform's client v2 logging JS API client.
 */
export declare class PanoramaClient {
    /**
     * Sends metric but only if Console Platform client v2 logging JS API is present in the page.
     */
    sendMetric(metric: MetricsV2EventItem): boolean;
    private onMetricError;
    private findPanorama;
}
