"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.PanoramaClient = exports.CLogClient = void 0;
const AWSUI_EVENT = 'awsui';
function validateLength(value, maxLength) {
    return !value || value.length <= maxLength;
}
/**
 * Console Platform's client logging JS API client.
 */
class CLogClient {
    /**
     * Sends metric but only if Console Platform client logging JS API is present in the page.
     */
    sendMetric(metricName, value, detail) {
        if (!metricName || !/^[a-zA-Z0-9_-]+$/.test(metricName)) {
            console.error(`Invalid metric name: ${metricName}`);
            return;
        }
        if (!validateLength(metricName, 1000)) {
            console.error(`Metric name ${metricName} is too long`);
            return;
        }
        if (!validateLength(detail, 4000)) {
            console.error(`Detail for metric ${metricName} is too long: ${detail}`);
            return;
        }
        const wasSent = new PanoramaClient().sendMetric({
            eventContext: metricName,
            eventDetail: detail,
            eventValue: `${value}`,
            timestamp: Date.now(),
        });
        if (wasSent) {
            return;
        }
        const AWSC = this.findAWSC(window);
        if (typeof AWSC === 'object' && typeof AWSC.Clog === 'object' && typeof AWSC.Clog.log === 'function') {
            AWSC.Clog.log(metricName, value, detail);
        }
    }
    findAWSC(currentWindow) {
        try {
            if (typeof (currentWindow === null || currentWindow === void 0 ? void 0 : currentWindow.AWSC) === 'object') {
                return currentWindow === null || currentWindow === void 0 ? void 0 : currentWindow.AWSC;
            }
            if (!currentWindow || currentWindow.parent === currentWindow) {
                // When the window has no more parents, it references itself
                return undefined;
            }
            return this.findAWSC(currentWindow.parent);
        }
        catch {
            // Most likely a cross-origin access error
            return undefined;
        }
    }
}
exports.CLogClient = CLogClient;
/**
 * Console Platform's client v2 logging JS API client.
 */
class PanoramaClient {
    /**
     * Sends metric but only if Console Platform client v2 logging JS API is present in the page.
     */
    sendMetric(metric) {
        const panorama = this.findPanorama(window);
        if (!panorama) {
            return false;
        }
        const payload = {
            eventType: AWSUI_EVENT,
            timestamp: Date.now(),
            ...metric,
            eventDetail: typeof metric.eventDetail === 'object' ? JSON.stringify(metric.eventDetail) : metric.eventDetail,
            eventValue: typeof metric.eventValue === 'object' ? JSON.stringify(metric.eventValue) : metric.eventValue,
        };
        if (!validateLength(payload.eventDetail, 4000)) {
            this.onMetricError(`Event detail for metric is too long: ${payload.eventDetail}`);
            return true;
        }
        if (!validateLength(payload.eventValue, 4000)) {
            this.onMetricError(`Event value for metric is too long: ${payload.eventValue}`);
            return true;
        }
        if (!validateLength(payload.eventContext, 4000)) {
            this.onMetricError(`Event context for metric is too long: ${payload.eventContext}`);
            return true;
        }
        panorama('trackCustomEvent', payload);
        return true;
    }
    onMetricError(message) {
        console.error(message);
        const panorama = this.findPanorama(window);
        if (panorama) {
            panorama('trackCustomEvent', {
                eventType: AWSUI_EVENT,
                eventContext: 'awsui-metric-error',
                eventDetail: message.slice(0, 4000),
                timestamp: Date.now(),
            });
        }
    }
    findPanorama(currentWindow) {
        try {
            if (typeof (currentWindow === null || currentWindow === void 0 ? void 0 : currentWindow.panorama) === 'function') {
                return currentWindow === null || currentWindow === void 0 ? void 0 : currentWindow.panorama;
            }
            const panoramaSymbol = Symbol.for('panorama');
            const symbolProperty = currentWindow === null || currentWindow === void 0 ? void 0 : currentWindow[panoramaSymbol];
            if (typeof symbolProperty === 'function') {
                return symbolProperty;
            }
            if (!currentWindow || currentWindow.parent === currentWindow) {
                // When the window has no more parents, it references itself
                return undefined;
            }
            return this.findPanorama(currentWindow.parent);
        }
        catch {
            // Most likely a cross-origin access error
            return undefined;
        }
    }
}
exports.PanoramaClient = PanoramaClient;
