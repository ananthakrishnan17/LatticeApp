import { PackageSettings, ComponentMetricDetail, JSONObject } from './interfaces.js';
export declare function buildMetricDetail(detail: JSONObject, context: PackageSettings): string;
export declare function buildComponentMetricDetail({ componentName, action, configuration, packageSource }: ComponentMetricDetail, context: PackageSettings): string;
export declare function getMajorVersion(versionString: string): string;
