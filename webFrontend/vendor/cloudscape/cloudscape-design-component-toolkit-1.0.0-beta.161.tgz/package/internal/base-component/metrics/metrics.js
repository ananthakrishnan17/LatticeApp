"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.Metrics = void 0;
exports.clearOneTimeMetricsCache = clearOneTimeMetricsCache;
const log_clients_js_1 = require("./log-clients.js");
const formatters_js_1 = require("./formatters.js");
const oneTimeMetrics = new Set();
class Metrics {
    constructor(...args) {
        this.clog = new log_clients_js_1.CLogClient();
        this.panorama = new log_clients_js_1.PanoramaClient();
        if (args.length === 1) {
            this.context = args[0];
        }
        else {
            const [packageSource, packageVersion] = args;
            this.context = { packageSource, packageVersion, theme: 'unknown' };
        }
    }
    sendComponentMetric(metric) {
        this.sendMetricOnce(`awsui_${metric.componentName}_${this.context.theme.charAt(0)}${(0, formatters_js_1.getMajorVersion)(this.context.packageVersion)}`, 1, (0, formatters_js_1.buildComponentMetricDetail)(metric, this.context));
    }
    /*
     * Calls Console Platform's client logging only the first time the provided metricName is used.
     * Subsequent calls with the same metricName are ignored.
     */
    sendMetricOnce(metricName, value, detail) {
        const key = [metricName + value + detail].join('|');
        if (!oneTimeMetrics.has(key)) {
            this.clog.sendMetric(metricName, value, detail);
            oneTimeMetrics.add(key);
        }
    }
    /**
     * Calls Console Platform's client v2 logging JS API with provided metric name and detail.
     * Does nothing if Console Platform client logging JS is not present in page.
     */
    sendPanoramaMetric(metric) {
        this.panorama.sendMetric(metric);
    }
    sendOpsMetricObject(metricName, detail) {
        this.sendMetricOnce(metricName, 1, (0, formatters_js_1.buildMetricDetail)(detail, this.context));
    }
    sendOpsMetricValue(metricName, value) {
        this.sendMetricOnce(metricName, value);
    }
    /*
     * Reports a metric value 1 to Console Platform's client logging service to indicate that the
     * component was loaded. The component load event will only be reported as used to client logging
     * service once per page view.
     */
    logComponentsLoaded() {
        this.sendComponentMetric({ componentName: this.context.packageSource, action: 'loaded' });
    }
    /*
     * Reports a metric value 1 to Console Platform's client logging service to indicate that the
     * component was used in the page.  A component will only be reported as used to client logging
     * service once per page view.
     */
    logComponentUsed(componentName, configuration) {
        this.sendComponentMetric({
            action: 'used',
            componentName,
            configuration,
            packageSource: this.context.packageSource,
        });
    }
}
exports.Metrics = Metrics;
function clearOneTimeMetricsCache() {
    oneTimeMetrics.clear();
}
