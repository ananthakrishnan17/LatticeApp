import { AnalyticsMetadata } from './metrics/interfaces.js';
export declare const COMPONENT_METADATA_KEY = "__awsuiMetadata__";
interface PackageMetadata {
    packageName?: string;
    version: string;
    theme?: string;
}
export declare function useComponentMetadata<T = any>(componentName: string, packageMetadata: PackageMetadata | string, analyticsMetadata?: AnalyticsMetadata): import("react").RefObject<T>;
export {};
