"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateProps = validateProps;
const is_development_js_1 = require("../is-development.js");
function validateProps(componentName, props, excludedProps, allowedEnums, systemName) {
    if (!is_development_js_1.isDevelopment) {
        return;
    }
    for (const [prop, value] of Object.entries(props)) {
        if (excludedProps.includes(prop)) {
            throw new Error(`${componentName} does not support "${prop}" property when used in ${systemName} system`);
        }
        if (value && allowedEnums[prop] && !allowedEnums[prop].includes(value)) {
            throw new Error(`${componentName} does not support "${prop}" with value "${value}" when used in ${systemName} system`);
        }
    }
}
