"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMPONENT_METADATA_KEY = void 0;
exports.useComponentMetadata = useComponentMetadata;
const react_1 = require("react");
exports.COMPONENT_METADATA_KEY = '__awsuiMetadata__';
function useComponentMetadata(componentName, packageMetadata, analyticsMetadata) {
    const elementRef = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(() => {
        if (elementRef.current) {
            const pkgMetadata = typeof packageMetadata === 'string' ? { version: packageMetadata } : packageMetadata;
            const node = elementRef.current;
            const metadata = {
                ...pkgMetadata,
                name: componentName,
            };
            // Only add analytics property to metadata if analytics property is non-empty
            if (analyticsMetadata && Object.keys(analyticsMetadata).length > 0) {
                metadata.analytics = analyticsMetadata;
            }
            Object.freeze(metadata);
            Object.defineProperty(node, exports.COMPONENT_METADATA_KEY, { value: metadata, writable: false, configurable: true });
        }
    });
    return elementRef;
}
