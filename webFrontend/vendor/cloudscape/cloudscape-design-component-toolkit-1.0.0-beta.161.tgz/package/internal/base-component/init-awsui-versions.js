"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.initAwsUiVersions = initAwsUiVersions;
// expose version info, so it can be checked using the browser devtools
function initAwsUiVersions(source, packageVersion) {
    if (typeof window !== 'undefined') {
        if (!window.awsuiVersions) {
            window.awsuiVersions = {};
        }
        if (!window.awsuiVersions[source]) {
            window.awsuiVersions[source] = [];
        }
        window.awsuiVersions[source].push(packageVersion);
    }
}
