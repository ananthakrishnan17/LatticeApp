import { ComponentConfiguration, PackageSettings } from './metrics/interfaces.js';
export { ComponentConfiguration };
export declare function useComponentMetrics(componentName: string, settings: PackageSettings, configuration?: ComponentConfiguration): void;
