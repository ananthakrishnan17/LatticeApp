export declare function initAwsUiVersions(source: string, packageVersion: string): void;
