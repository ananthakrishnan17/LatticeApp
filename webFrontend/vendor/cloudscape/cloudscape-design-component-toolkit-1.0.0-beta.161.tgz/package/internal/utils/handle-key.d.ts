export declare function isEventLike(event: any): event is EventLike;
export interface EventLike {
    keyCode: number;
    currentTarget: HTMLElement | SVGElement;
}
export default function handleKey(event: EventLike, { onActivate, onBlockEnd, onBlockStart, onDefault, onEnd, onEscape, onHome, onInlineEnd, onInlineStart, onPageDown, onPageUp, }: {
    onActivate?: () => void;
    onBlockEnd?: () => void;
    onBlockStart?: () => void;
    onDefault?: () => void;
    onEnd?: () => void;
    onEscape?: () => void;
    onHome?: () => void;
    onInlineEnd?: () => void;
    onInlineStart?: () => void;
    onPageDown?: () => void;
    onPageUp?: () => void;
}): void;
