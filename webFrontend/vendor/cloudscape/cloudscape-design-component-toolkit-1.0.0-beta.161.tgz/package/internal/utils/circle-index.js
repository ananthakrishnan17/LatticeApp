"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = circleIndex;
// Returns given index if it is in range or the opposite range boundary otherwise.
function circleIndex(index, [from, to]) {
    if (index < from) {
        return to;
    }
    if (index > to) {
        return from;
    }
    return index;
}
