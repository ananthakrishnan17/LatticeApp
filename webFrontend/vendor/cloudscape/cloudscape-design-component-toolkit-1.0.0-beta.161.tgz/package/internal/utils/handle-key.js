"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
exports.isEventLike = isEventLike;
exports.default = handleKey;
const index_js_1 = require("../direction/index.js");
const keycode_js_1 = require("../keycode.js");
const element_types_js_1 = require("../../dom/element-types.js");
function isEventLike(event) {
    return (0, element_types_js_1.isHTMLElement)(event.currentTarget) || (0, element_types_js_1.isSVGElement)(event.currentTarget);
}
function handleKey(event, { onActivate, onBlockEnd, onBlockStart, onDefault, onEnd, onEscape, onHome, onInlineEnd, onInlineStart, onPageDown, onPageUp, }) {
    switch (event.keyCode) {
        case keycode_js_1.KeyCode.down:
            onBlockEnd === null || onBlockEnd === void 0 ? void 0 : onBlockEnd();
            break;
        case keycode_js_1.KeyCode.end:
            onEnd === null || onEnd === void 0 ? void 0 : onEnd();
            break;
        case keycode_js_1.KeyCode.enter:
        case keycode_js_1.KeyCode.space:
            onActivate === null || onActivate === void 0 ? void 0 : onActivate();
            break;
        case keycode_js_1.KeyCode.escape:
            onEscape === null || onEscape === void 0 ? void 0 : onEscape();
            break;
        case keycode_js_1.KeyCode.home:
            onHome === null || onHome === void 0 ? void 0 : onHome();
            break;
        case keycode_js_1.KeyCode.left:
            (0, index_js_1.getIsRtl)(event.currentTarget) ? onInlineEnd === null || onInlineEnd === void 0 ? void 0 : onInlineEnd() : onInlineStart === null || onInlineStart === void 0 ? void 0 : onInlineStart();
            break;
        case keycode_js_1.KeyCode.pageDown:
            onPageDown === null || onPageDown === void 0 ? void 0 : onPageDown();
            break;
        case keycode_js_1.KeyCode.pageUp:
            onPageUp === null || onPageUp === void 0 ? void 0 : onPageUp();
            break;
        case keycode_js_1.KeyCode.right:
            (0, index_js_1.getIsRtl)(event.currentTarget) ? onInlineStart === null || onInlineStart === void 0 ? void 0 : onInlineStart() : onInlineEnd === null || onInlineEnd === void 0 ? void 0 : onInlineEnd();
            break;
        case keycode_js_1.KeyCode.up:
            onBlockStart === null || onBlockStart === void 0 ? void 0 : onBlockStart();
            break;
        default:
            onDefault === null || onDefault === void 0 ? void 0 : onDefault();
            break;
    }
}
