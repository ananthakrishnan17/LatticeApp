export default function circleIndex(index: number, [from, to]: [number, number]): number;
