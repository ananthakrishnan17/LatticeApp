export declare function safeMatchMedia(element: HTMLElement, query: string): boolean;
