import React from 'react';
export interface PortalProps {
    container?: null | Element;
    getContainer?: (options: {
        abortSignal: AbortSignal;
    }) => Promise<HTMLElement>;
    removeContainer?: (container: HTMLElement | null) => void;
    children: React.ReactNode;
}
/**
 * A safe react portal component that renders to a provided node.
 * If a node isn't provided, it creates one under the owner document's body,
 * ensuring correct behavior inside iframes.
 */
export default function Portal({ container, getContainer, removeContainer, children, }: PortalProps): React.ReactPortal | React.ReactElement | null;
