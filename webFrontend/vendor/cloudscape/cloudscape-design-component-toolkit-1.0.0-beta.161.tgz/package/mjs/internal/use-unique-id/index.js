// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var _a;
import React, { useRef } from 'react';
let counter = 0;
export const useRandomId = () => {
    const idRef = useRef(null);
    if (!idRef.current) {
        idRef.current = `${counter++}-${Date.now()}-${Math.round(Math.random() * 10000)}`;
    }
    return idRef.current;
};
const useId = (_a = React.useId) !== null && _a !== void 0 ? _a : useRandomId;
export function useUniqueId(prefix) {
    return `${prefix ? prefix : ''}` + useId();
}
