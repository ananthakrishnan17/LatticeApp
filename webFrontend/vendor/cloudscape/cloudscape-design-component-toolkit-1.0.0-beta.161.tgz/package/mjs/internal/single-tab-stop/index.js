// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React, { createContext, forwardRef, useContext, useImperativeHandle, useLayoutEffect, useRef, useState, } from 'react';
import { useEffectOnUpdate } from '../use-effect-on-update/index.js';
import nodeBelongs from '../../dom/node-belongs.js';
const defaultValue = {
    navigationActive: false,
    registerFocusable: () => () => { },
    resetFocusTarget: () => { },
};
/**
 * Single tab stop navigation context is used together with keyboard navigation that requires a single tab stop.
 * It instructs interactive elements to override tab indices for just a single one to remain user-focusable.
 */
export const SingleTabStopNavigationContext = createContext(defaultValue);
export function useSingleTabStopNavigation(focusable, options) {
    var _a;
    const { navigationActive: contextNavigationActive, registerFocusable } = useContext(SingleTabStopNavigationContext);
    const [focusTargetActive, setFocusTargetActive] = useState(false);
    const navigationDisabled = (options === null || options === void 0 ? void 0 : options.tabIndex) && (options === null || options === void 0 ? void 0 : options.tabIndex) < 0;
    const navigationActive = contextNavigationActive && !navigationDisabled;
    useLayoutEffect(() => {
        if (navigationActive && focusable && focusable.current) {
            const unregister = registerFocusable(focusable.current, isFocusable => setFocusTargetActive(isFocusable));
            return () => unregister();
        }
    });
    let tabIndex = options === null || options === void 0 ? void 0 : options.tabIndex;
    if (navigationActive) {
        tabIndex = !focusTargetActive ? -1 : (_a = options === null || options === void 0 ? void 0 : options.tabIndex) !== null && _a !== void 0 ? _a : 0;
    }
    return { navigationActive, tabIndex };
}
export function SingleTabStopNavigationReset({ children }) {
    return (React.createElement(SingleTabStopNavigationContext.Provider, { value: defaultValue }, children));
}
export const SingleTabStopNavigationProvider = forwardRef(({ navigationActive, children, getNextFocusTarget, isElementSuppressed, onRegisterFocusable, onUnregisterActive, }, ref) => {
    // A set of registered focusable elements that can use keyboard navigation.
    const focusables = useRef(new Set());
    // A map of registered focusable element handlers to update the respective tab indices.
    const focusHandlers = useRef(new Map());
    // A map of focusable element states to avoid issuing unnecessary updates to registered elements.
    const focusablesState = useRef(new WeakMap());
    // A reference to the currently focused element.
    const focusTarget = useRef(null);
    function onUnregisterFocusable(focusableElement) {
        const isUnregisteringFocusedNode = nodeBelongs(focusableElement, document.activeElement);
        if (isUnregisteringFocusedNode) {
            // Wait for unmounted node to get removed from the DOM.
            setTimeout(() => onUnregisterActive === null || onUnregisterActive === void 0 ? void 0 : onUnregisterActive(focusableElement), 0);
        }
    }
    // Register a focusable element to allow navigating into it.
    // The focusable element tabIndex is only set to 0 if the element matches the focus target.
    function registerFocusable(focusableElement, changeHandler) {
        // In case the contexts are nested, we must that the components register to all of them,
        // so that switching between contexts dynamically is possible.
        const parentUnregister = parentContext.registerFocusable(focusableElement, changeHandler);
        focusables.current.add(focusableElement);
        focusHandlers.current.set(focusableElement, changeHandler);
        const isFocusable = !!focusablesState.current.get(focusableElement);
        const newIsFocusable = focusTarget.current === focusableElement || !!(isElementSuppressed === null || isElementSuppressed === void 0 ? void 0 : isElementSuppressed(focusableElement));
        if (newIsFocusable !== isFocusable) {
            focusablesState.current.set(focusableElement, newIsFocusable);
            changeHandler(newIsFocusable);
        }
        onRegisterFocusable === null || onRegisterFocusable === void 0 ? void 0 : onRegisterFocusable(focusableElement);
        return () => {
            parentUnregister();
            unregisterFocusable(focusableElement);
        };
    }
    function unregisterFocusable(focusableElement) {
        focusables.current.delete(focusableElement);
        focusHandlers.current.delete(focusableElement);
        onUnregisterFocusable === null || onUnregisterFocusable === void 0 ? void 0 : onUnregisterFocusable(focusableElement);
    }
    // Update focus target with next single focusable element and notify all registered focusables of a change.
    function updateFocusTarget(forceUpdate = false) {
        var _a;
        focusTarget.current = getNextFocusTarget();
        for (const focusableElement of focusables.current) {
            const isFocusable = (_a = focusablesState.current.get(focusableElement)) !== null && _a !== void 0 ? _a : false;
            const newIsFocusable = focusTarget.current === focusableElement || !!(isElementSuppressed === null || isElementSuppressed === void 0 ? void 0 : isElementSuppressed(focusableElement));
            if (newIsFocusable !== isFocusable || forceUpdate) {
                focusablesState.current.set(focusableElement, newIsFocusable);
                focusHandlers.current.get(focusableElement)(newIsFocusable);
            }
        }
    }
    function resetFocusTarget() {
        updateFocusTarget(true);
    }
    function getFocusTarget() {
        return focusTarget.current;
    }
    function isRegistered(element) {
        return focusables.current.has(element);
    }
    useImperativeHandle(ref, () => ({ updateFocusTarget, getFocusTarget, isRegistered }));
    // Only one STSN context should be active at a time.
    // The outer context is preferred over the inners. The components using STSN
    // must either work with either outer or inner context, or an explicit switch mechanism
    // needs to be implemented (that turns the outer context on and off based on user interaction).
    const parentContext = useContext(SingleTabStopNavigationContext);
    const value = parentContext.navigationActive
        ? parentContext
        : { navigationReset: false, navigationActive, registerFocusable, updateFocusTarget, resetFocusTarget };
    // When contexts switching occurs, it is essential that the now-active one updates the focus target
    // to ensure the tab indices are correctly set.
    useEffectOnUpdate(() => {
        if (parentContext.navigationActive) {
            parentContext.resetFocusTarget();
        }
        else {
            resetFocusTarget();
        }
        // The updateFocusTarget and its dependencies must be pure.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [parentContext.navigationActive]);
    return React.createElement(SingleTabStopNavigationContext.Provider, { value: value }, children);
});
