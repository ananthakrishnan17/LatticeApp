// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useCallback, useEffect, useRef } from 'react';
import { SingleTabStopNavigationContext } from '../index.js';
import { useUniqueId } from '../../use-unique-id/index.js';
const providerRegistry = new Map();
export const TestSingleTabStopNavigationProvider = ({ children, navigationActive, }) => {
    const focusablesRef = useRef(new Set());
    const focusHandlersRef = useRef(new Map());
    const registerFocusable = useCallback((focusable, changeHandler) => {
        focusablesRef.current.add(focusable);
        focusHandlersRef.current.set(focusable, changeHandler);
        return () => {
            focusablesRef.current.delete(focusable);
            focusHandlersRef.current.delete(focusable);
        };
    }, []);
    const providerId = useUniqueId();
    providerRegistry.set(providerId, {
        setCurrentTarget: (focusTarget, suppressed = []) => {
            focusablesRef.current.forEach(focusable => {
                const handler = focusHandlersRef.current.get(focusable);
                handler(focusTarget === focusable || suppressed.includes(focusable));
            });
        },
    });
    useEffect(() => () => {
        providerRegistry.delete(providerId);
    }, [providerId]);
    return (React.createElement(SingleTabStopNavigationContext.Provider, { value: {
            navigationActive,
            registerFocusable,
            // The reset target feature is not needed in the test provider, and it is
            // already tested with the actual provider implementation instead.
            // istanbul ignore next
            resetFocusTarget: () => { },
        } }, children));
};
export const setTestSingleTabStopNavigationTarget = (focusTarget, suppressed) => {
    Array.from(providerRegistry).forEach(([, provider]) => provider.setCurrentTarget(focusTarget, suppressed));
};
