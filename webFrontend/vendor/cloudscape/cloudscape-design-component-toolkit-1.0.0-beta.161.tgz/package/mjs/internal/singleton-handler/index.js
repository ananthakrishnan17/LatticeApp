// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useState } from 'react';
import { unstable_batchedUpdates } from 'react-dom';
export function createSingletonHandler(factory) {
    // Using Set for O(1) add/delete operations instead of Array's O(n) indexOf + splice.
    // Sets maintain insertion order (ES2015+), preserving iteration consistency.
    const listeners = new Set();
    const callback = value => {
        unstable_batchedUpdates(() => {
            for (const listener of listeners) {
                listener(value);
            }
        });
    };
    let cleanup;
    return function useSingleton(listener) {
        useEffect(() => {
            if (listeners.size === 0) {
                cleanup = factory(callback);
            }
            listeners.add(listener);
            return () => {
                listeners.delete(listener);
                if (listeners.size === 0) {
                    cleanup();
                    cleanup = undefined;
                }
            };
            // register handlers only on mount
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []);
    };
}
export function createSingletonState({ factory, initialState }) {
    const useSingleton = createSingletonHandler(factory);
    return function useSingletonState() {
        const [state, setState] = useState(initialState);
        useSingleton(setState);
        return state;
    };
}
