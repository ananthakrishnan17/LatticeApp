// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export function buildMetricDetail(detail, context) {
    const metricOrigin = typeof AWSUI_METRIC_ORIGIN !== 'undefined' ? AWSUI_METRIC_ORIGIN : 'main';
    const detailObject = {
        o: metricOrigin,
        t: context.theme,
        // React is the only framework we're using.
        f: 'react',
        // Remove spaces from the version string for compactness
        v: context.packageVersion.replace(/\s/g, ''),
        ...detail,
    };
    return jsonStringify(detailObject);
}
export function buildComponentMetricDetail({ componentName, action, configuration, packageSource }, context) {
    return buildMetricDetail({
        a: action,
        s: componentName,
        p: packageSource,
        c: configuration,
    }, context);
}
function jsonStringify(detailObject) {
    return JSON.stringify(detailObject, detailSerializer);
}
function detailSerializer(key, value) {
    // Report NaN and Infinity as strings instead of `null` (default behavior)
    if (typeof value === 'number' && !Number.isFinite(value)) {
        return `${value}`;
    }
    return value;
}
export function getMajorVersion(versionString) {
    const majorVersionMatch = versionString.match(/^(\d+\.\d+)/);
    return majorVersionMatch ? majorVersionMatch[1].replace('.', '') : '';
}
