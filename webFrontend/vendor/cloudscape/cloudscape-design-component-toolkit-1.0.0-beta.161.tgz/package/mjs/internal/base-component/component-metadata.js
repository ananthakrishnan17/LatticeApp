// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useRef } from 'react';
export const COMPONENT_METADATA_KEY = '__awsuiMetadata__';
export function useComponentMetadata(componentName, packageMetadata, analyticsMetadata) {
    const elementRef = useRef(null);
    useEffect(() => {
        if (elementRef.current) {
            const pkgMetadata = typeof packageMetadata === 'string' ? { version: packageMetadata } : packageMetadata;
            const node = elementRef.current;
            const metadata = {
                ...pkgMetadata,
                name: componentName,
            };
            // Only add analytics property to metadata if analytics property is non-empty
            if (analyticsMetadata && Object.keys(analyticsMetadata).length > 0) {
                metadata.analytics = analyticsMetadata;
            }
            Object.freeze(metadata);
            Object.defineProperty(node, COMPONENT_METADATA_KEY, { value: metadata, writable: false, configurable: true });
        }
    });
    return elementRef;
}
