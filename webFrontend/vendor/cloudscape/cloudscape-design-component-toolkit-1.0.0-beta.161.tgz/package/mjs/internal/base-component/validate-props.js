// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { isDevelopment } from '../is-development.js';
export function validateProps(componentName, props, excludedProps, allowedEnums, systemName) {
    if (!isDevelopment) {
        return;
    }
    for (const [prop, value] of Object.entries(props)) {
        if (excludedProps.includes(prop)) {
            throw new Error(`${componentName} does not support "${prop}" property when used in ${systemName} system`);
        }
        if (value && allowedEnums[prop] && !allowedEnums[prop].includes(value)) {
            throw new Error(`${componentName} does not support "${prop}" with value "${value}" when used in ${systemName} system`);
        }
    }
}
