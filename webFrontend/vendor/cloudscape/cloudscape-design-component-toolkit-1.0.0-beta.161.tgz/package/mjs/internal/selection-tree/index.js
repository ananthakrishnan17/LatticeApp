// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { getTrackableValue } from '../track-by/index.js';
const ROOT_KEY = Symbol('selection-tree-root');
export class SelectionTree {
    constructor(roots, treeProps, state) {
        this.itemKeyToItem = new Map();
        this.itemToggleState = new Set();
        this.itemProjectedSelectionState = new Set();
        this.itemProjectedParentSelectionState = new Set();
        this.itemProjectedIndeterminateState = new Set();
        this.itemKeyToSelectedCount = new Map();
        this.selectedItems = new Array();
        this.isItemSelected = (item) => this.itemProjectedSelectionState.has(this.getKey(item));
        this.isItemIndeterminate = (item) => this.itemProjectedIndeterminateState.has(this.getKey(item));
        this.isAllItemsSelected = () => this.itemProjectedSelectionState.has(ROOT_KEY) && !this.itemProjectedIndeterminateState.has(ROOT_KEY);
        this.isAllItemsIndeterminate = () => this.itemProjectedIndeterminateState.has(ROOT_KEY);
        this.getSelectedItemsCount = (item) => { var _a; return (_a = this.itemKeyToSelectedCount.get(this.getKey(item))) !== null && _a !== void 0 ? _a : 0; };
        this.getSelectedItems = () => this.selectedItems;
        this.getState = () => {
            const inverted = this.itemToggleState.has(ROOT_KEY);
            const toggledItems = [];
            for (const itemKey of Array.from(this.itemToggleState)) {
                const item = this.getItemForKey(itemKey);
                if (item) {
                    toggledItems.push(item);
                }
            }
            return { inverted, toggledItems };
        };
        this.toggleAll = () => {
            return this.isAllItemsSelected()
                ? new SelectionTree(this.roots, this.treeProps, { inverted: false, toggledItems: [] })
                : new SelectionTree(this.roots, this.treeProps, { inverted: true, toggledItems: [] });
        };
        this.toggleSome = (requestedItems) => {
            const clone = this.clone();
            const lastItemKey = clone.getKey(requestedItems[requestedItems.length - 1]);
            const isParentSelected = clone.itemProjectedParentSelectionState.has(lastItemKey);
            const isSelected = clone.itemProjectedSelectionState.has(lastItemKey);
            const isIndeterminate = clone.itemProjectedIndeterminateState.has(lastItemKey);
            const nextIsSelected = !(isSelected && !isIndeterminate);
            const nextIsSelfSelected = (isParentSelected && !nextIsSelected) || (!isParentSelected && nextIsSelected);
            for (const requested of requestedItems) {
                clone.unselectDeep(requested);
                if (nextIsSelfSelected) {
                    clone.itemToggleState.add(this.getKey(requested));
                }
            }
            clone.computeState();
            return clone;
        };
        this.invertAll = () => {
            const clone = this.clone();
            clone.toggleKey(ROOT_KEY);
            clone.roots.forEach(item => clone.toggleKey(clone.getKey(item)));
            clone.computeState();
            return clone;
        };
        this.invertOne = (item) => {
            const clone = this.clone();
            clone.toggleKey(clone.getKey(item));
            clone.treeProps.getChildren(item).forEach(child => clone.toggleKey(clone.getKey(child)));
            clone.computeState();
            return clone;
        };
        this.toggleKey = (key) => {
            if (this.itemToggleState.has(key)) {
                this.itemToggleState.delete(key);
            }
            else {
                this.itemToggleState.add(key);
            }
        };
        this.unselectDeep = (item) => {
            this.itemToggleState.delete(this.getKey(item));
            this.treeProps.getChildren(item).forEach(child => this.unselectDeep(child));
        };
        this.roots = roots;
        this.treeProps = treeProps;
        // Translate initial state into internal representation.
        if (state.inverted) {
            this.itemToggleState.add(ROOT_KEY);
        }
        for (const item of state.toggledItems) {
            this.itemToggleState.add(this.getKey(item));
        }
        // Populate item key to item mapping.
        const traverse = (item) => {
            this.itemKeyToItem.set(this.getKey(item), item);
            treeProps.getChildren(item).forEach(traverse);
        };
        roots.forEach(traverse);
        this.computeState();
    }
    computeState() {
        var _a, _b;
        this.itemProjectedSelectionState = new Set();
        this.itemProjectedIndeterminateState = new Set();
        this.itemProjectedParentSelectionState = new Set();
        this.itemKeyToSelectedCount = new Map();
        this.selectedItems = [];
        // Transform input items tree to selection buckets.
        // Selection buckets are organized in a map by level.
        // Each bucket has a parent element (index=0) and might have children elements (index>=1).
        const selectionBuckets = new Map();
        const createSelectionBuckets = (item, level) => {
            var _a;
            const itemKey = this.getKey(item);
            const levelBuckets = (_a = selectionBuckets.get(level)) !== null && _a !== void 0 ? _a : [];
            const children = this.treeProps.getChildren(item);
            const bucket = [itemKey];
            for (const child of children) {
                bucket.push(this.getKey(child));
                createSelectionBuckets(child, level + 1);
            }
            levelBuckets.push(bucket);
            selectionBuckets.set(level, levelBuckets);
        };
        // On level=0 there is a root bucket to hold the selection-inverted state.
        // On level>0 there are buckets that represent selection for every item.
        const rootBucket = [ROOT_KEY];
        for (const item of this.roots) {
            rootBucket.push(this.getKey(item));
            createSelectionBuckets(item, 1);
        }
        selectionBuckets.set(0, [rootBucket]);
        // Transform buckets map to an array of buckets where those with bigger levels come first.
        const selectionBucketEntries = Array.from(selectionBuckets.entries())
            .sort(([a], [b]) => b - a)
            .flatMap(([, v]) => v);
        // Normalize selection state.
        for (const bucket of selectionBucketEntries) {
            // Cannot normalize 1-element buckets.
            if (bucket.length === 1) {
                continue;
            }
            let selectedCount = 0;
            for (let i = bucket.length - 1; i >= 0; i--) {
                if (this.itemToggleState.has(bucket[i])) {
                    selectedCount++;
                }
                else {
                    break;
                }
            }
            // Cannot normalize incomplete buckets.
            if (((_b = (_a = this.treeProps).isComplete) === null || _b === void 0 ? void 0 : _b.call(_a, this.getItemForKey(bucket[0]))) === false) {
                continue;
            }
            // Normalize selection state when all children are selected but the parent is not.
            if (selectedCount === bucket.length - 1 && !this.itemToggleState.has(bucket[0])) {
                bucket.forEach(itemKey => this.itemToggleState.delete(itemKey));
                this.itemToggleState.add(bucket[0]);
            }
            // Normalize selection state when all children and the parent are selected.
            if (selectedCount === bucket.length) {
                bucket.forEach(itemKey => this.itemToggleState.delete(itemKey));
            }
        }
        // Compute projected selected state.
        // An item is selected either when it is present in selection state but its parent is not selected,
        // or when it is not present in selection state but its parent is selected.
        // An item can be selected and indeterminate at the same time.
        const setItemProjectedSelection = (item, inheritedSelected) => {
            const itemKey = this.getKey(item);
            const isSelfSelected = this.itemToggleState.has(itemKey);
            const isSelected = (isSelfSelected && !inheritedSelected) || (!isSelfSelected && inheritedSelected);
            if (isSelected) {
                this.itemProjectedSelectionState.add(itemKey);
            }
            if (inheritedSelected) {
                this.itemProjectedParentSelectionState.add(itemKey);
            }
            this.treeProps.getChildren(item).forEach(child => setItemProjectedSelection(child, isSelected));
        };
        // The projected selection computation starts from the root pseudo-item (selection inverted state).
        this.roots.forEach(item => {
            const isRootSelected = this.itemToggleState.has(ROOT_KEY);
            if (isRootSelected) {
                this.itemProjectedSelectionState.add(ROOT_KEY);
            }
            setItemProjectedSelection(item, isRootSelected);
        });
        // Compute projected indeterminate state.
        // The parent (bucket[0]) is indeterminate when any of its children (bucket[1+]) is selected or indeterminate.
        for (const bucket of selectionBucketEntries) {
            let indeterminate = false;
            for (let i = 1; i < bucket.length; i++) {
                if (this.itemToggleState.has(bucket[i]) || this.itemProjectedIndeterminateState.has(bucket[i])) {
                    indeterminate = true;
                    break;
                }
            }
            if (indeterminate) {
                this.itemProjectedIndeterminateState.add(bucket[0]);
            }
        }
        // Compute selected children count per item.
        const computeCounts = (item) => {
            const children = this.treeProps.getChildren(item);
            const selfCount = !this.isGroup(item) && this.isItemSelected(item) ? 1 : 0;
            const count = selfCount + children.reduce((acc, child) => acc + computeCounts(child), 0);
            if (selfCount) {
                this.selectedItems.push(item);
            }
            this.itemKeyToSelectedCount.set(this.getKey(item), count);
            return count;
        };
        for (const item of this.roots) {
            computeCounts(item);
        }
    }
    // Presently, the implementation treats all nodes with children as groups. Groups do not
    // contribute to the counters and are not returned as selected items - only the non-group nodes do.
    // This can be made configurable by exposing the isGroup as property.
    isGroup(item) {
        return this.treeProps.getChildren(item).length > 0;
    }
    getKey(item) {
        return getTrackableValue(this.treeProps.trackBy, item);
    }
    getItemForKey(itemKey) {
        if (itemKey === ROOT_KEY) {
            return null;
        }
        return this.itemKeyToItem.get(itemKey);
    }
    clone() {
        return new SelectionTree(this.roots, this.treeProps, this.getState());
    }
}
