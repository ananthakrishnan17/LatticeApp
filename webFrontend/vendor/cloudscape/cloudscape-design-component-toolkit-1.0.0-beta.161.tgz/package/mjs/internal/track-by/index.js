// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export const getTrackableValue = (trackBy, item) => {
    if (!trackBy) {
        return item;
    }
    if (typeof trackBy === 'function') {
        return trackBy(item);
    }
    return item[trackBy];
};
