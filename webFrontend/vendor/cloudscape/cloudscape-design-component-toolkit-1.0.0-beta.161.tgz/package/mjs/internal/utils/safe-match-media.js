// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export function safeMatchMedia(element, query) {
    var _a, _b, _c, _d;
    try {
        const targetWindow = (_b = (_a = element.ownerDocument) === null || _a === void 0 ? void 0 : _a.defaultView) !== null && _b !== void 0 ? _b : window;
        return (_d = (_c = targetWindow.matchMedia) === null || _c === void 0 ? void 0 : _c.call(targetWindow, query).matches) !== null && _d !== void 0 ? _d : false;
    }
    catch (error) {
        console.warn(error);
        return false;
    }
}
