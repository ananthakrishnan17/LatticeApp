// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect } from 'react';
import { isModifierKey } from '../keycode.js';
const frames = new Map();
function setIsKeyboard(active) {
    if (active) {
        for (const currentDocument of frames.keys()) {
            currentDocument.body.setAttribute('data-awsui-focus-visible', 'true');
        }
    }
    else {
        for (const currentDocument of frames.keys()) {
            currentDocument.body.removeAttribute('data-awsui-focus-visible');
        }
    }
}
function handleMousedown() {
    setIsKeyboard(false);
}
function handleKeydown(event) {
    if (!isModifierKey(event)) {
        setIsKeyboard(true);
    }
}
function addListeners(currentDocument) {
    const abortController = new AbortController();
    currentDocument.addEventListener('mousedown', handleMousedown, { signal: abortController.signal });
    currentDocument.addEventListener('keydown', handleKeydown, { signal: abortController.signal });
    return abortController;
}
export function useFocusVisible(componentRef) {
    useEffect(() => {
        var _a, _b;
        const currentDocument = (_b = (_a = componentRef === null || componentRef === void 0 ? void 0 : componentRef.current) === null || _a === void 0 ? void 0 : _a.ownerDocument) !== null && _b !== void 0 ? _b : document;
        let frame = frames.get(currentDocument);
        if (frame) {
            frame.componentsCount++;
        }
        else {
            const abortController = addListeners(currentDocument);
            frame = { componentsCount: 1, abortController };
            frames.set(currentDocument, frame);
        }
        return () => {
            frame.componentsCount--;
            if (frame.componentsCount === 0) {
                frame.abortController.abort();
                frames.delete(currentDocument);
            }
        };
    }, [componentRef]);
}
