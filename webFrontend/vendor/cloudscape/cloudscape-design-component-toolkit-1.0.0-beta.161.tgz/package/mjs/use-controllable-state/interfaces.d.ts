export interface PropertyDescriptions {
    componentName: string;
    changeHandlerName: string;
    propertyName: string;
}
