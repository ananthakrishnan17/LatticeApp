export declare function cloneDeep<T>(obj: T): T;
export declare function entries<T>(obj: Record<string, T>): [string, T][];
/**
 * This function mirrors the Object.fromEntries method.
 *
 * See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/fromEntries
 */
export declare function fromEntries<K extends string, V>(entries: [K, V][]): Record<K, V>;
/**
 * This function mirros the Object.values method.
 *
 * See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_objects/Object/values
 */
export declare function values<T>(some: Record<string, T>): T[];
/**
 * This function mirrors the String#includes and Array#includes methods.
 *
 * See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/includes
 * and https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/includes
 */
export declare function includes(subject: string, searchString: string): boolean;
export declare function includes<T>(subject: Array<T>, searchObject: T): boolean;
export declare function jsonToSass(json: Record<string, string | Record<string, string | Record<string, string>>>): string;
