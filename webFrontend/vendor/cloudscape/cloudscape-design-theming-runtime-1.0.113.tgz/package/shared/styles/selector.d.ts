export declare function increaseSpecificity(selector: string): string;
export declare const isIncreased: (selector: string) => boolean;
export declare const globalSelectors: string[];
export declare const isGlobalSelector: (selector: string) => boolean;
export declare function getFirstSelector(selector: string): string;
/**
 * Detects and repeats class names to increase specificity, otherwise
 * fall back to increase by id
 * @param selectors
 * @returns
 */
export declare function increaseSpecificityGradually(selectors: string): string;
