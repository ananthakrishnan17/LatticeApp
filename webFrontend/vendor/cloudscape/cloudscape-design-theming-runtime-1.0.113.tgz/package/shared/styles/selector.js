// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { includes } from '../utils';
// The idea to use a special :not(#\9) selector to increase CSS specificity came from:
// https://github.com/MadLittleMods/postcss-increase-specificity
var specificitySuffix = ':not(#\\9)';
export function increaseSpecificity(selector) {
    var _a = selector.split(':'), main = _a[0], pseudo = _a.slice(1);
    var pseudoSuffix = pseudo.length ? ':' + pseudo.join(':') : '';
    return "".concat(main).concat(specificitySuffix).concat(pseudoSuffix);
}
export var isIncreased = function (selector) { return includes(selector, specificitySuffix); };
export var globalSelectors = [':root', 'body', 'html'];
export var isGlobalSelector = function (selector) {
    return globalSelectors.indexOf(selector) > -1;
};
export function getFirstSelector(selector) {
    return selector.split(/[\s.:[\]]/)[0];
}
/**
 * Detects and repeats class names to increase specificity, otherwise
 * fall back to increase by id
 * @param selectors
 * @returns
 */
export function increaseSpecificityGradually(selectors) {
    var split = selectors.split(',').map(repeatClassNameOrAddID);
    return split.join(',');
}
function repeatClassNameOrAddID(selector) {
    var result = /[:.][\w_-]+/.exec(selector);
    // exec without g flag will return max one match
    if ((result === null || result === void 0 ? void 0 : result.length) === 1) {
        var match = result[0];
        var index = result.index;
        return "".concat(selector.substring(0, index)).concat(match).concat(selector.substring(index));
    }
    return increaseSpecificity(selector);
}
