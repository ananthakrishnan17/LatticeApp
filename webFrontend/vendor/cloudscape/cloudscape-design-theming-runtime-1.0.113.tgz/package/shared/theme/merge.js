import { __assign } from "tslib";
import { cloneDeep, entries } from '../utils';
import { getMode, isModeValue, isReference, isValue } from './utils';
/**
 * This function applies all tokens from the override to the theme.
 * It returns the resulting theme. The original theme object is modified.
 */
export function mergeInPlace(theme, override) {
    function withTokenApplied(originalValue, token, update) {
        var isGlobal = isValue(update) || isReference(update);
        var mode = getMode(theme, token);
        if (mode && isGlobal) {
            return Object.keys(mode.states).reduce(function (acc, state) {
                acc[state] = update;
                return acc;
            }, {});
        }
        else if ((isModeValue(originalValue) || originalValue === undefined) && isModeValue(update)) {
            return __assign(__assign({}, originalValue), update);
        }
        else if (isGlobal) {
            return update;
        }
        else {
            console.warn('The value for this token cannot be merged into the theme:', token);
        }
    }
    // Merge root-level tokens into the theme
    entries(override.tokens).forEach(function (_a) {
        var token = _a[0], update = _a[1];
        var newValue = withTokenApplied(theme.tokens[token], token, update);
        if (newValue) {
            theme.tokens[token] = newValue;
        }
    });
    // Merge context-specific tokens into each context
    if (override.contexts) {
        entries(override.contexts).forEach(function (_a) {
            var contextId = _a[0], context = _a[1];
            var themeContext = theme.contexts[contextId];
            if (!context || !themeContext) {
                return;
            }
            entries(context.tokens).forEach(function (_a) {
                var _b;
                var token = _a[0], update = _a[1];
                var originalValue = (_b = themeContext.tokens[token]) !== null && _b !== void 0 ? _b : theme.tokens[token];
                var newValue = withTokenApplied(originalValue, token, update);
                if (newValue) {
                    theme.contexts[contextId].tokens[token] = newValue;
                }
            });
        });
    }
    return theme;
}
/**
 * This function applies all tokens from the override to the theme.
 * It returns the resulting theme. The original theme object is not
 * modified.
 */
export function merge(theme, override) {
    var result = cloneDeep(theme);
    return mergeInPlace(result, override);
}
