import { Context, Mode } from '.';
import { Theme, Value } from './interfaces';
import type { PropertiesMap } from '../declaration/interfaces';
export type ModeTokenResolution = Record<string, Value>;
export type SpecificTokenResolution = Value;
interface ThemeResolution<TR> {
    [token: string]: TR;
}
type ModeTokenResolutionPath = Record<string, Array<string>>;
type SpecificTokenResolutionPath = Array<string>;
export type FullResolution = ThemeResolution<ModeTokenResolution | SpecificTokenResolution>;
export type SpecificResolution = ThemeResolution<SpecificTokenResolution>;
export type FullResolutionPaths = ThemeResolution<ModeTokenResolutionPath | SpecificTokenResolutionPath>;
interface FullResolutionWithPaths {
    resolvedTheme: FullResolution;
    resolutionPaths: FullResolutionPaths;
}
/**
 * If a base theme is provided, only keep tokens that are in the override theme or those that
 * have an overridden token in their resolution path
 */
export declare function resolveTheme(theme: Theme, baseTheme?: Theme, propertiesMap?: PropertiesMap): FullResolution;
export declare function resolveThemeWithPaths(theme: Theme, baseTheme?: Theme, propertiesMap?: PropertiesMap): FullResolutionWithPaths;
export declare function resolveContext(theme: Theme, context: Context, baseTheme?: Theme, themeResolution?: FullResolution, propertiesMap?: PropertiesMap): FullResolution;
type Reducer = (tokenResolution: ModeTokenResolution | SpecificTokenResolution, token: string, theme: Theme, baseTheme?: Theme) => SpecificTokenResolution | undefined;
export declare function reduce(resolution: FullResolution | SpecificResolution, theme: Theme, reducer: Reducer, baseTheme?: Theme): SpecificResolution;
export declare const defaultsReducer: () => (tokenResolution: ModeTokenResolution | SpecificTokenResolution, token: string, theme: Theme, baseTheme?: Theme) => string;
export declare const modeReducer: (mode: Mode, state: string) => (tokenResolution: ModeTokenResolution | SpecificTokenResolution, token: string, theme: Theme, baseTheme?: Theme) => string | undefined;
export declare function difference(base: SpecificResolution, other: SpecificResolution): SpecificResolution;
export declare function difference(base: FullResolution, other: FullResolution): FullResolution;
export declare function isModeTokenResolution(val: SpecificTokenResolution | ModeTokenResolution): val is ModeTokenResolution;
export declare function isSpecificTokenResolution(val: SpecificTokenResolution | ModeTokenResolution): val is SpecificTokenResolution;
export {};
