// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { __extends } from "tslib";
import { Hct } from './hct-utils';
import { PaletteSpecification } from './palette-spec';
var MIN_TONE = 3;
var MAX_TONE = 98;
var PrimaryPaletteSpecification = /** @class */ (function (_super) {
    __extends(PrimaryPaletteSpecification, _super);
    function PrimaryPaletteSpecification() {
        return _super.call(this, [
            {
                position: 50,
                chromaFraction: 0.2,
                minTone: 97,
                maxTone: MAX_TONE
            },
            {
                position: 100,
                chromaFraction: 0.3,
                minTone: 91,
                maxTone: 96
            },
            {
                position: 200,
                chromaFraction: 0.5,
                minTone: 84,
                maxTone: 91
            },
            {
                position: 300,
                chromaFraction: 0.7,
                minTone: 75,
                maxTone: 84
            },
            {
                position: 400,
                chromaFraction: 1.0,
                minTone: 65,
                maxTone: 75
            },
            {
                position: 500,
                chromaFraction: 1.0,
                minTone: 48,
                maxTone: 65
            },
            {
                position: 600,
                chromaFraction: 1.0,
                minTone: 44,
                maxTone: 47
            },
            {
                position: 700,
                chromaFraction: 1.1,
                minTone: 34,
                maxTone: 44
            },
            {
                position: 800,
                chromaFraction: 1.15,
                minTone: 25,
                maxTone: 34
            },
            {
                position: 900,
                chromaFraction: 1.2,
                minTone: 11,
                maxTone: 25
            },
            {
                position: 1000,
                chromaFraction: 1.25,
                minTone: MIN_TONE,
                maxTone: 5
            },
        ]) || this;
    }
    PrimaryPaletteSpecification.prototype.adjustSeedColor = function (hct, mode) {
        var tone = hct.tone;
        var position600 = this.colorSpecifications.find(function (s) { return s.position === 600; });
        var position400 = this.colorSpecifications.find(function (s) { return s.position === 400; });
        if (mode === 'light' && position600 && tone > position600.maxTone) {
            return Hct.from(hct.hue, hct.chroma, (position600.minTone + position600.maxTone) / 2);
        }
        if (mode === 'dark' && position400 && tone < position400.minTone) {
            return Hct.from(hct.hue, hct.chroma, (position400.minTone + position400.maxTone) / 2);
        }
        return hct;
    };
    PrimaryPaletteSpecification.prototype.getExactSeedPosition = function (hct, mode) {
        var tone = hct.tone;
        var position600 = this.colorSpecifications.find(function (s) { return s.position === 600; });
        var position400 = this.colorSpecifications.find(function (s) { return s.position === 400; });
        if (mode === 'light' && position600 && tone <= position600.maxTone) {
            return 600;
        }
        if (mode === 'dark' && position400 && tone >= position400.minTone) {
            return 400;
        }
        return undefined;
    };
    return PrimaryPaletteSpecification;
}(PaletteSpecification));
export { PrimaryPaletteSpecification };
