import { PaletteStep } from '../interfaces';
import { PaletteSpecification } from './palette-spec';
export declare class WarningPaletteSpecification extends PaletteSpecification<PaletteStep> {
    constructor();
}
