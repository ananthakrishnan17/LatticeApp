import { __assign } from "tslib";
import { createHct, hctToHex, hexToHct } from './hct-utils';
var PaletteSpecification = /** @class */ (function () {
    function PaletteSpecification(positionRequirements, maxChroma) {
        this.colorSpecifications = positionRequirements;
        this.maxChroma = maxChroma !== null && maxChroma !== void 0 ? maxChroma : 200; // High default for unrestricted palettes
    }
    PaletteSpecification.prototype.findColorSpecification = function (hctColor) {
        var tone = Math.round(hctColor.tone);
        for (var _i = 0, _a = this.colorSpecifications; _i < _a.length; _i++) {
            var position = _a[_i];
            if (tone <= position.maxTone && tone >= position.minTone) {
                return position;
            }
        }
        // No exact range match - find nearest valid tone
        var nearestTone = this.findNearestValidTone(tone);
        for (var _b = 0, _c = this.colorSpecifications; _b < _c.length; _b++) {
            var position = _c[_b];
            if (nearestTone <= position.maxTone && nearestTone >= position.minTone) {
                return position;
            }
        }
        return undefined;
    };
    PaletteSpecification.prototype.findNearestValidTone = function (inputTone) {
        var closestTone = inputTone;
        var minDistance = Infinity;
        var preferDarker = inputTone < 50;
        for (var _i = 0, _a = this.colorSpecifications; _i < _a.length; _i++) {
            var spec = _a[_i];
            var midTone = (spec.minTone + spec.maxTone) / 2;
            var distance = Math.abs(inputTone - midTone);
            if (distance < minDistance) {
                minDistance = distance;
                closestTone = midTone;
            }
            else if (distance === minDistance && preferDarker && midTone < closestTone) {
                closestTone = midTone;
            }
        }
        return Math.round(closestTone);
    };
    PaletteSpecification.prototype.getColorToneProportion = function (position, hctColor) {
        var proportion = (hctColor.tone - position.minTone) / (position.maxTone - position.minTone);
        return Math.max(0, Math.min(1, proportion));
    };
    PaletteSpecification.prototype.getColorToneForProportion = function (position, proportion) {
        var baseTone = position.minTone + (position.maxTone - position.minTone) * proportion;
        // Bias toward range edges to maximize contrast
        // Lower position numbers (50, 100, etc.) are light - bias toward maxTone (lighter)
        // Higher position numbers (700, 800, etc.) are dark - bias toward minTone (darker)
        var BIAS_STRENGTH = 0.5;
        var positionNum = Number(position.position);
        if (positionNum <= 500) {
            // Light half of palette - push toward maxTone (lighter)
            return baseTone + (position.maxTone - baseTone) * BIAS_STRENGTH;
        }
        else {
            // Dark half of palette - push toward minTone (darker)
            return baseTone - (baseTone - position.minTone) * BIAS_STRENGTH;
        }
    };
    PaletteSpecification.prototype.adjustSeedColor = function (hct, mode) {
        return hct;
    };
    PaletteSpecification.prototype.getExactSeedPosition = function (hct, mode) {
        return undefined;
    };
    PaletteSpecification.prototype.validateAndAdjustSeed = function (hexColor, mode) {
        var hct = hexToHct(hexColor);
        hct = this.adjustSeedColor(hct, mode);
        return hctToHex(hct);
    };
    PaletteSpecification.prototype.getPalette = function (hexBaseColor, autoAdjust, mode) {
        if (autoAdjust === void 0) { autoAdjust = true; }
        var adjustedSeed = this.prepareBaseSeed(hexBaseColor, autoAdjust, mode);
        var baseColorInfo = this.extractBaseColorInfo(adjustedSeed, mode);
        var colors = this.generatePaletteColors(baseColorInfo);
        return __assign({ seed: adjustedSeed.hex }, colors);
    };
    PaletteSpecification.prototype.prepareBaseSeed = function (hexColor, autoAdjust, mode) {
        var seedWasAdjusted = false;
        if (autoAdjust) {
            var original = hexColor;
            hexColor = this.validateAndAdjustSeed(hexColor, mode);
            seedWasAdjusted = original !== hexColor;
        }
        return { hex: hexColor, wasAdjusted: seedWasAdjusted };
    };
    PaletteSpecification.prototype.extractBaseColorInfo = function (seed, mode) {
        var hctBaseColor = hexToHct(seed.hex);
        var exactSeedPosition = this.getExactSeedPosition(hctBaseColor, mode);
        var baseColorPalettePosition = exactSeedPosition
            ? this.colorSpecifications.find(function (s) { return s.position === exactSeedPosition; })
            : this.findColorSpecification(hctBaseColor);
        if (!baseColorPalettePosition) {
            throw new Error("Seed color ".concat(seed.hex, " does not match any palette position specification"));
        }
        var baseColorToneRangePosition = exactSeedPosition
            ? 0.5
            : this.getColorToneProportion(baseColorPalettePosition, hctBaseColor);
        return {
            hue: hctBaseColor.hue,
            chroma: this.calculateBaseChroma(hctBaseColor.chroma, baseColorPalettePosition),
            basePosition: baseColorPalettePosition,
            toneRangePosition: baseColorToneRangePosition,
            seedHex: seed.hex,
            seedWasAdjusted: seed.wasAdjusted,
            exactSeedPosition: exactSeedPosition
        };
    };
    PaletteSpecification.prototype.calculateBaseChroma = function (seedChroma, position) {
        var useDirectChroma = this.maxChroma < 50;
        return useDirectChroma ? seedChroma : seedChroma / position.chromaFraction;
    };
    PaletteSpecification.prototype.generatePaletteColors = function (baseInfo) {
        var colors = {};
        for (var _i = 0, _a = this.colorSpecifications; _i < _a.length; _i++) {
            var color = _a[_i];
            var tone = this.getColorToneForProportion(color, baseInfo.toneRangePosition);
            var isPaletteBase = baseInfo.basePosition.position === color.position;
            var isExactSeedPosition = baseInfo.exactSeedPosition === color.position;
            var adjustedChroma = color.chromaFraction * baseInfo.chroma;
            if (adjustedChroma > this.maxChroma) {
                adjustedChroma = this.maxChroma;
            }
            var paletteColor = (isPaletteBase && !baseInfo.seedWasAdjusted) || isExactSeedPosition
                ? baseInfo.seedHex
                : hctToHex(createHct(baseInfo.hue, adjustedChroma, tone));
            colors[color.position] = paletteColor;
        }
        return colors;
    };
    return PaletteSpecification;
}());
export { PaletteSpecification };
