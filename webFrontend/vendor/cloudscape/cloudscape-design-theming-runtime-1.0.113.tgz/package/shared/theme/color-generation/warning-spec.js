// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { __extends } from "tslib";
import { PaletteSpecification } from './palette-spec';
var MIN_TONE = 5;
var MAX_TONE = 98;
var WarningPaletteSpecification = /** @class */ (function (_super) {
    __extends(WarningPaletteSpecification, _super);
    function WarningPaletteSpecification() {
        return _super.call(this, [
            {
                position: 50,
                chromaFraction: 0.5,
                minTone: 97,
                maxTone: MAX_TONE
            },
            {
                position: 100,
                chromaFraction: 0.5,
                minTone: 95,
                maxTone: 97
            },
            {
                position: 200,
                chromaFraction: 0.5,
                minTone: 90,
                maxTone: 95
            },
            {
                position: 300,
                chromaFraction: 0.75,
                minTone: 86,
                maxTone: 90
            },
            {
                position: 400,
                chromaFraction: 1.5,
                minTone: 82,
                maxTone: 86
            },
            {
                position: 500,
                chromaFraction: 1.5,
                minTone: 75,
                maxTone: 82
            },
            {
                position: 600,
                chromaFraction: 1.0,
                minTone: 65,
                maxTone: 75
            },
            {
                position: 700,
                chromaFraction: 1.1,
                minTone: 55,
                maxTone: 65
            },
            {
                position: 800,
                chromaFraction: 1.15,
                minTone: 47,
                maxTone: 55
            },
            {
                position: 900,
                chromaFraction: 1.2,
                minTone: 41,
                maxTone: 47
            },
            {
                position: 1000,
                chromaFraction: 1.25,
                minTone: MIN_TONE,
                maxTone: 15
            },
        ]) || this;
    }
    return WarningPaletteSpecification;
}(PaletteSpecification));
export { WarningPaletteSpecification };
