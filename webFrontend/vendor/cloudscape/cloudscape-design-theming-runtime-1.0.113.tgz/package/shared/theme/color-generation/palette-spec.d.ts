import { ReferencePaletteDefinition } from '../interfaces';
import { Hct } from './hct-utils';
interface ColorSpecification<PaletteKeys> {
    position: PaletteKeys;
    chromaFraction: number;
    minTone: number;
    maxTone: number;
}
export declare class PaletteSpecification<PaletteKeys> {
    maxChroma: number;
    colorSpecifications: ColorSpecification<PaletteKeys>[];
    constructor(positionRequirements: ColorSpecification<PaletteKeys>[], maxChroma?: number);
    private findColorSpecification;
    protected findNearestValidTone(inputTone: number): number;
    private getColorToneProportion;
    private getColorToneForProportion;
    protected adjustSeedColor(hct: Hct, mode?: string): Hct;
    protected getExactSeedPosition(hct: Hct, mode?: string): PaletteKeys | undefined;
    private validateAndAdjustSeed;
    getPalette(hexBaseColor: string, autoAdjust?: boolean, mode?: string): ReferencePaletteDefinition;
    private prepareBaseSeed;
    private extractBaseColorInfo;
    private calculateBaseChroma;
    private generatePaletteColors;
}
export {};
