// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { NeutralPaletteSpecification } from './neutral-spec';
import { PrimaryPaletteSpecification } from './primary-spec';
import { WarningPaletteSpecification } from './warning-spec';
// Memoization cache for palette generation
var paletteCache = new Map();
function getCacheKey(category, seed, autoAdjust, mode) {
    return "".concat(category, ":").concat(seed, ":").concat(autoAdjust, ":").concat(mode !== null && mode !== void 0 ? mode : 'none');
}
// Export for testing
export function clearPaletteCache() {
    paletteCache.clear();
}
export function generatePaletteFromSeed(category, seed, autoAdjust, mode) {
    if (autoAdjust === void 0) { autoAdjust = true; }
    var cacheKey = getCacheKey(category, seed, autoAdjust, mode);
    var cached = paletteCache.get(cacheKey);
    if (cached) {
        return cached;
    }
    var primaryPaletteSpec = new PrimaryPaletteSpecification();
    var neutralPaletteSpec = new NeutralPaletteSpecification();
    var warningPaletteSpec = new WarningPaletteSpecification();
    var paletteSpec;
    switch (category) {
        case 'neutral':
            paletteSpec = neutralPaletteSpec;
            break;
        case 'warning':
            paletteSpec = warningPaletteSpec;
            break;
        case 'primary':
        case 'error':
        case 'success':
        case 'info':
        default:
            paletteSpec = primaryPaletteSpec;
    }
    var generated = paletteSpec.getPalette(seed, autoAdjust, mode);
    paletteCache.set(cacheKey, generated);
    return generated;
}
