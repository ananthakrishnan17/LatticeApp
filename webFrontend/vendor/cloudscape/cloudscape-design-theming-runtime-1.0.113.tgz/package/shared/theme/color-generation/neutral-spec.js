import { __extends } from "tslib";
import { createHct } from './hct-utils';
import { PaletteSpecification } from './palette-spec';
var MIN_TONE = 1;
var MAX_TONE = 99;
var MAX_CHROMA = 15;
var NeutralPaletteSpecification = /** @class */ (function (_super) {
    __extends(NeutralPaletteSpecification, _super);
    function NeutralPaletteSpecification() {
        return _super.call(this, [
            // Near white - very light neutrals
            { position: 50, chromaFraction: 0.5, minTone: 98, maxTone: MAX_TONE },
            { position: 100, chromaFraction: 0.5, minTone: 97, maxTone: 98 },
            { position: 150, chromaFraction: 0.5, minTone: 96, maxTone: 97 },
            { position: 200, chromaFraction: 0.5, minTone: 96, maxTone: 96 },
            // Light neutrals
            { position: 250, chromaFraction: 0.5, minTone: 93, maxTone: 95 },
            { position: 300, chromaFraction: 0.5, minTone: 88, maxTone: 92 },
            { position: 350, chromaFraction: 0.5, minTone: 80, maxTone: 85 },
            // Medium neutrals
            { position: 400, chromaFraction: 0.75, minTone: 72, maxTone: 76 },
            { position: 450, chromaFraction: 0.75, minTone: 68, maxTone: 72 },
            { position: 500, chromaFraction: 0.75, minTone: 55, maxTone: 58 },
            { position: 550, chromaFraction: 0.75, minTone: 46, maxTone: 52 },
            { position: 600, chromaFraction: 0.75, minTone: 44, maxTone: 46 },
            // Dark neutrals
            { position: 650, chromaFraction: 0.75, minTone: 28, maxTone: 35 },
            { position: 700, chromaFraction: 0.75, minTone: 22, maxTone: 27 },
            { position: 750, chromaFraction: 0.75, minTone: 14, maxTone: 20 },
            { position: 800, chromaFraction: 0.75, minTone: 10, maxTone: 14 },
            // Very dark neutrals
            { position: 850, chromaFraction: 0.75, minTone: 5, maxTone: 7 },
            { position: 900, chromaFraction: 0.75, minTone: 3, maxTone: 5 },
            { position: 950, chromaFraction: 0.75, minTone: 2, maxTone: 3 },
            { position: 1000, chromaFraction: 0.75, minTone: MIN_TONE, maxTone: 2 }, // 2
        ], MAX_CHROMA) || this;
    }
    NeutralPaletteSpecification.prototype.adjustSeedColor = function (hct) {
        if (hct.chroma > MAX_CHROMA) {
            return createHct(hct.hue, MAX_CHROMA, this.findNearestValidTone(hct.tone));
        }
        return hct;
    };
    return NeutralPaletteSpecification;
}(PaletteSpecification));
export { NeutralPaletteSpecification };
