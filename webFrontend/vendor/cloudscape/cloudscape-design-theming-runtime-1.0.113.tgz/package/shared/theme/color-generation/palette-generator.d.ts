import { ColorReferenceTokens, ReferencePaletteDefinition } from '../interfaces';
export declare function clearPaletteCache(): void;
export declare function generatePaletteFromSeed(category: keyof ColorReferenceTokens, seed: string, autoAdjust?: boolean, mode?: string): ReferencePaletteDefinition;
