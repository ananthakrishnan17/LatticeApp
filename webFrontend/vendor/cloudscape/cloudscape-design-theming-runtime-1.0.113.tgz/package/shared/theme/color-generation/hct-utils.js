// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { argbFromHex, argbFromRgb, Hct, hexFromArgb } from '@material/material-color-utilities';
function isValidHex(hex) {
    return /^#?([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(hex);
}
/**
 * Parses CSS color formats and converts to ARGB.
 * Supports: #hex and rgb()/rgba()
 */
function parseColorToArgb(color) {
    var trimmed = color.trim();
    // Hex format
    if (trimmed.startsWith('#')) {
        if (!isValidHex(trimmed)) {
            throw new Error("Invalid hex color: ".concat(color));
        }
        return argbFromHex(trimmed);
    }
    // rgb() or rgba() format
    var rgbMatch = trimmed.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
    if (rgbMatch) {
        var r = parseInt(rgbMatch[1]);
        var g = parseInt(rgbMatch[2]);
        var b = parseInt(rgbMatch[3]);
        return argbFromRgb(r, g, b);
    }
    throw new Error("Unsupported color format: ".concat(color, ". Supported formats: #hex, rgb(), rgba()"));
}
export function hctToHex(hctColor) {
    return hexFromArgb(hctColor.toInt());
}
export function hexToHct(color) {
    var argb = parseColorToArgb(color);
    return Hct.fromInt(argb);
}
export function createHct(hue, chroma, tone) {
    return Hct.from(hue, chroma, tone);
}
export { hexFromArgb, argbFromHex, Hct };
