import { PaletteStep } from '../interfaces';
import { Hct } from './hct-utils';
import { PaletteSpecification } from './palette-spec';
export declare class NeutralPaletteSpecification extends PaletteSpecification<PaletteStep> {
    constructor();
    protected adjustSeedColor(hct: Hct): Hct;
}
