import { PaletteStep } from '../interfaces';
import { Hct } from './hct-utils';
import { PaletteSpecification } from './palette-spec';
export declare class PrimaryPaletteSpecification extends PaletteSpecification<PaletteStep> {
    constructor();
    protected adjustSeedColor(hct: Hct, mode?: string): Hct;
    protected getExactSeedPosition(hct: Hct, mode?: string): PaletteStep | undefined;
}
