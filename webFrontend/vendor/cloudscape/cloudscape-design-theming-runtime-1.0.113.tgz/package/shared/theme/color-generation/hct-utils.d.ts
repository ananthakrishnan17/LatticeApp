import { argbFromHex, Hct, hexFromArgb } from '@material/material-color-utilities';
export declare function hctToHex(hctColor: Hct): string;
export declare function hexToHct(color: string): Hct;
export declare function createHct(hue: number, chroma: number, tone: number): Hct;
export { hexFromArgb, argbFromHex, Hct };
