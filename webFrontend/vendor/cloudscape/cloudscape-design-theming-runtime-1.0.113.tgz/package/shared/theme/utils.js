import { __spreadArray } from "tslib";
export function isReferenceToken(category, theme, token) {
    var _a;
    var categoryTokens = (_a = theme.referenceTokens) === null || _a === void 0 ? void 0 : _a[category];
    if (!categoryTokens)
        return false;
    return Object.entries(categoryTokens).some(function (_a) {
        var type = _a[0], set = _a[1];
        if (!set)
            return false;
        return Object.keys(set).some(function (step) { return generateReferenceTokenName(category, type, step) === token; });
    });
}
export function flattenObject(obj, prefix) {
    if (prefix === void 0) { prefix = []; }
    var result = {};
    if (!obj || typeof obj !== 'object') {
        return result;
    }
    for (var _i = 0, _a = Object.entries(obj); _i < _a.length; _i++) {
        var _b = _a[_i], key = _b[0], value = _b[1];
        var path = __spreadArray(__spreadArray([], prefix, true), [key], false);
        if (typeof value === 'string') {
            result[generateCamelCaseName.apply(void 0, path)] = value;
        }
        else if (isModeValue(value)) {
            // Stop flattening at mode values - preserve them as Assignment
            result[generateCamelCaseName.apply(void 0, path)] = value;
        }
        else if (value && typeof value === 'object') {
            Object.assign(result, flattenObject(value, path));
        }
    }
    return result;
}
export function generateCamelCaseName() {
    var segments = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        segments[_i] = arguments[_i];
    }
    return segments.reduce(function (acc, segment, index) { return acc + (index === 0 ? segment : segment.charAt(0).toUpperCase() + segment.slice(1)); }, '');
}
export function flattenReferenceTokens(theme) {
    var _a;
    return ((_a = theme.referenceTokens) === null || _a === void 0 ? void 0 : _a.color) ? flattenObject(theme.referenceTokens.color, ['color']) : {};
}
export function generateReferenceTokenName(category, type, step) {
    return generateCamelCaseName(category, type, step);
}
export function isValue(val) {
    return typeof val === 'string' && !isReference(val);
}
export function isReference(val) {
    return typeof val === 'string' && val.charAt(0) === '{' && val.charAt(val.length - 1) === '}';
}
export function isModeValue(val) {
    return (typeof val === 'object' &&
        val !== null &&
        !Array.isArray(val) &&
        // Exclude objects with numeric keys (palette steps like '500', '900')
        !Object.keys(val).some(function (key) { return !isNaN(Number(key)); }) &&
        !Object.keys(val).some(function (state) { return !(isValue(val[state]) || isReference(val[state])); }));
}
export function areAssignmentsEqual(valueA, valueB) {
    return (valueA === valueB ||
        (typeof valueA === 'object' &&
            typeof valueB == 'object' &&
            Object.keys(valueA).length === Object.keys(valueB).length &&
            Object.keys(valueA).every(function (key) { return valueA[key] === valueB[key]; })));
}
export function isOptionalState(val) {
    return 'selector' in val;
}
export function getReference(reference) {
    return reference.slice(1, reference.length - 1);
}
export function collectReferencedTokens(theme, tokens) {
    var referenced = new Set();
    var visited = new Set();
    var addReferences = function (value) {
        if (isReference(value)) {
            referenced.add(getReference(value));
        }
        else if (isModeValue(value)) {
            Object.values(value).forEach(addReferences);
        }
    };
    var processToken = function (token) {
        if (visited.has(token))
            return;
        visited.add(token);
        var value = theme.tokens[token];
        if (value)
            addReferences(value);
        Object.values(theme.contexts).forEach(function (context) {
            var contextValue = context.tokens[token];
            if (contextValue)
                addReferences(contextValue);
        });
    };
    // Initial pass
    tokens.forEach(processToken);
    // Recursive passes until no new tokens found
    var previousSize = 0;
    var iterations = 0;
    while (referenced.size > previousSize && iterations < 10) {
        previousSize = referenced.size;
        var newTokens = Array.from(referenced).filter(function (t) { return !visited.has(t); });
        newTokens.forEach(processToken);
        iterations++;
    }
    return Array.from(referenced);
}
export function getMode(theme, token) {
    var _a;
    var modeId = theme.tokenModeMap[token];
    return (_a = theme.modes[modeId]) !== null && _a !== void 0 ? _a : null;
}
export function getDefaultState(mode) {
    var states = Object.keys(mode.states);
    for (var index = 0; index < states.length; index++) {
        var state = states[index];
        var option = mode.states[state];
        if (option && 'default' in option && option["default"]) {
            return state;
        }
    }
    throw new Error("Mode ".concat(JSON.stringify(mode), " does not have a default state"));
}
export function isValidPaletteStep(step) {
    return step >= 50 && step <= 1000 && step % 50 === 0;
}
