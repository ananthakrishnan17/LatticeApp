import { __assign } from "tslib";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { generatePaletteFromSeed } from './color-generation/palette-generator';
import { generateReferenceTokenName, isValidPaletteStep } from './utils';
export function processReferenceTokens(colorTokens) {
    var generatedTokens = {};
    Object.entries(colorTokens).forEach(function (_a) {
        var colorName = _a[0], paletteInput = _a[1];
        var palette = processColorPaletteInput(colorName, paletteInput);
        Object.entries(palette).forEach(function (_a) {
            var step = _a[0], value = _a[1];
            if (step !== 'seed') {
                var tokenName = generateReferenceTokenName('color', colorName, step);
                generatedTokens[tokenName] = value;
            }
        });
    });
    return generatedTokens;
}
function processSeedInput(category, seed) {
    if (!seed)
        return {};
    if (typeof seed === 'string') {
        return generatePaletteFromSeed(category, seed);
    }
    var palette = {};
    Object.entries(seed).forEach(function (_a) {
        var mode = _a[0], seedColor = _a[1];
        if (typeof seedColor !== 'string')
            return;
        var modePalette = generatePaletteFromSeed(category, seedColor, true, mode);
        Object.entries(modePalette).forEach(function (_a) {
            var _b, _c;
            var step = _a[0], value = _a[1];
            var paletteStep = Number(step);
            if (!isValidPaletteStep(paletteStep))
                return;
            var existing = palette[paletteStep];
            palette[paletteStep] = typeof existing === 'object' ? __assign(__assign({}, existing), (_b = {}, _b[mode] = value, _b)) : (_c = {}, _c[mode] = value, _c);
        });
    });
    return palette;
}
function mergeExplicitSteps(generated, input) {
    var result = __assign({}, generated);
    Object.entries(input).forEach(function (_a) {
        var step = _a[0], value = _a[1];
        if (step === 'seed') {
            result.seed = value;
            return;
        }
        var paletteStep = Number(step);
        if (!value || !isValidPaletteStep(paletteStep))
            return;
        var generatedValue = generated[paletteStep];
        // Merge mode objects, otherwise use explicit value
        result[paletteStep] =
            typeof generatedValue === 'object' && typeof value === 'object' ? __assign(__assign({}, generatedValue), value) : value;
    });
    return result;
}
export function processColorPaletteInput(category, input) {
    if (typeof input === 'string') {
        return generatePaletteFromSeed(category, input);
    }
    var generated = processSeedInput(category, input.seed);
    return mergeExplicitSteps(generated, input);
}
