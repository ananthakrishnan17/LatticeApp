import { Override, Theme, ThemePreset, Token } from './interfaces';
/**
 * This function compares the theme override against the list of tokens that are allowed
 * to be themed. Only those overrides that use allowed tokens are returned. Other tokens are
 * dropped and a warning is emitted to the console.
 * If the theme override contains visual-context-specific overrides, only those overrides
 * that specify known context IDs are returned. Other visual-context-specific overrides
 * are dropped and a warning is emitted to the console.
 */
export declare function validateOverride(override: Override, themeable: Token[], availableContexts: string[]): Override;
export declare function getContexts(preset: ThemePreset): string[];
export declare function getThemeFromPreset(preset: ThemePreset, baseThemeId?: string): Theme;
