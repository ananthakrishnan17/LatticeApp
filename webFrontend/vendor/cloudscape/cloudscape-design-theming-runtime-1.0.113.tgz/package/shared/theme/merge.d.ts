import { Theme, Override } from './interfaces';
/**
 * This function applies all tokens from the override to the theme.
 * It returns the resulting theme. The original theme object is modified.
 */
export declare function mergeInPlace(theme: Theme, override: Override): Theme;
/**
 * This function applies all tokens from the override to the theme.
 * It returns the resulting theme. The original theme object is not
 * modified.
 */
export declare function merge(theme: Theme, override: Override): Theme;
