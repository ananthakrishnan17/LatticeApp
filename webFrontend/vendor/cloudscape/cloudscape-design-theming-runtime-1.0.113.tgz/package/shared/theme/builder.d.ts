import { Theme, Context, Mode, ReferenceTokens } from './interfaces';
export type TokenCategory<T extends string, V> = Record<T, V>;
export declare class ThemeBuilder {
    theme: Theme;
    constructor(id: string, selector: string, modes: Mode[]);
    private addTokensToModeMap;
    addTokens<T extends string, V>(tokens: TokenCategory<T, V>, mode?: Mode): ThemeBuilder;
    addContext(context: Context): ThemeBuilder;
    addReferenceTokens(referenceTokens: ReferenceTokens, mode?: Mode): ThemeBuilder;
    build(): Theme;
}
