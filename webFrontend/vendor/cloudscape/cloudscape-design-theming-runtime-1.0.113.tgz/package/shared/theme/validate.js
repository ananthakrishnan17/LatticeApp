import { __assign, __spreadArray } from "tslib";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { entries, fromEntries, includes } from '../utils';
import { processReferenceTokens } from './process';
/**
 * This function compares the theme override against the list of tokens that are allowed
 * to be themed. Only those overrides that use allowed tokens are returned. Other tokens are
 * dropped and a warning is emitted to the console.
 * If the theme override contains visual-context-specific overrides, only those overrides
 * that specify known context IDs are returned. Other visual-context-specific overrides
 * are dropped and a warning is emitted to the console.
 */
export function validateOverride(override, themeable, availableContexts) {
    var _a;
    // The following two validations should not be possible, if customer uses
    // Typescript in their project. However, it might be easily overseen in a Javascript
    // project. Therefore, we supply additional hints beyond just types.
    if (typeof override.tokens !== 'object' || Array.isArray(override.tokens) || override.tokens === null) {
        throw new Error("Missing required \"tokens\" object field in ".concat(JSON.stringify(override)));
    }
    // This cache is used so that we emit only one warning per token name.
    var unthemeableTokenWarningCache = {};
    function isThemeable(token) {
        var isThemeable = includes(themeable, token);
        if (!isThemeable && !(token in unthemeableTokenWarningCache)) {
            console.warn("".concat(token, " is not themeable and will be ignored during theming"));
            unthemeableTokenWarningCache[token] = true;
        }
        return isThemeable;
    }
    function isValidContextId(contextId) {
        var isValid = includes(availableContexts, contextId);
        if (!isValid) {
            console.warn("".concat(contextId, " is not a valid ID of a visual context and will be ignored during theming."));
        }
        return isValid;
    }
    var tokensEntries = entries(override.tokens).filter(function (_a) {
        var token = _a[0];
        return isThemeable(token);
    });
    var contextEntries = (override.contexts
        ? entries(override.contexts).filter(function (_a) {
            var context = _a[1];
            return context !== undefined;
        })
        : [])
        .filter(function (_a) {
        var contextId = _a[0];
        return isValidContextId(contextId);
    })
        .map(function (_a) {
        var contextId = _a[0], context = _a[1];
        var filteredTokens = entries(context.tokens).filter(function (_a) {
            var token = _a[0];
            return isThemeable(token);
        });
        var from = fromEntries(filteredTokens);
        var newContext = __assign(__assign({}, context), { tokens: from });
        return [contextId, newContext];
    });
    var completeTokens = {};
    if ((_a = override.referenceTokens) === null || _a === void 0 ? void 0 : _a.color) {
        var generatedTokens = processReferenceTokens(override.referenceTokens.color);
        // Reference tokens should override existing tokens
        completeTokens = __assign(__assign({}, fromEntries(tokensEntries)), generatedTokens);
    }
    else {
        completeTokens = fromEntries(tokensEntries);
    }
    return {
        contexts: fromEntries(contextEntries),
        tokens: completeTokens,
        referenceTokens: override.referenceTokens
    };
}
export function getContexts(preset) {
    var _a;
    var themes = __spreadArray([preset.theme], ((_a = preset.secondary) !== null && _a !== void 0 ? _a : []), true);
    var contexts = [];
    for (var _i = 0, themes_1 = themes; _i < themes_1.length; _i++) {
        var theme = themes_1[_i];
        Object.keys(theme.contexts).forEach(function (contextName) {
            if (contexts.indexOf(contextName) === -1) {
                contexts.push(contextName);
            }
        });
    }
    return contexts;
}
export function getThemeFromPreset(preset, baseThemeId) {
    var _a;
    if (!baseThemeId) {
        return preset.theme;
    }
    var themesMap = __spreadArray([preset.theme], ((_a = preset.secondary) !== null && _a !== void 0 ? _a : []), true).reduce(function (accThemesMap, currentTheme) {
        accThemesMap[currentTheme.id] = currentTheme;
        return accThemesMap;
    }, {});
    if (!themesMap[baseThemeId]) {
        throw new Error("Specified baseThemeId '".concat(baseThemeId, "' is not available. Available values are ").concat(Object.keys(themesMap)
            .map(function (value) { return "'".concat(value, "'"); })
            .join(', '), "."));
    }
    return themesMap[baseThemeId];
}
