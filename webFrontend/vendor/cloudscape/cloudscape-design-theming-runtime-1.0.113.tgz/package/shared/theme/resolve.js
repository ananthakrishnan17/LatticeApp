import { __assign } from "tslib";
import { cloneDeep, values } from '../utils';
import { areAssignmentsEqual, getDefaultState, getMode, getReference, isModeValue, isReference, isReferenceToken, } from './utils';
/**
 * If a base theme is provided, only keep tokens that are in the override theme or those that
 * have an overridden token in their resolution path
 */
export function resolveTheme(theme, baseTheme, propertiesMap) {
    return resolveThemeWithPaths(theme, baseTheme, propertiesMap).resolvedTheme;
}
export function resolveThemeWithPaths(theme, baseTheme, propertiesMap) {
    var _a;
    var resolvedTheme = {};
    var resolutionPaths = {};
    Object.keys((_a = baseTheme === null || baseTheme === void 0 ? void 0 : baseTheme.tokens) !== null && _a !== void 0 ? _a : theme.tokens).forEach(function (token) {
        var mode = getMode(baseTheme !== null && baseTheme !== void 0 ? baseTheme : theme, token);
        if (mode) {
            var modeTokenResolutionPaths_1 = {};
            var resolvedToken = Object.keys(mode.states).reduce(function (acc, state) {
                modeTokenResolutionPaths_1[state] = [];
                acc[state] = resolveToken(theme, token, modeTokenResolutionPaths_1[state], state, baseTheme, propertiesMap);
                return acc;
            }, {});
            var tokenResolutionPathContainsOverriddenTokens = values(modeTokenResolutionPaths_1).some(function (tokenResolutionPath) {
                return tokenResolutionPath.some(function (pathToken) { return pathToken in theme.tokens; });
            });
            if (!baseTheme || tokenResolutionPathContainsOverriddenTokens) {
                resolutionPaths[token] = modeTokenResolutionPaths_1;
                resolvedTheme[token] = resolvedToken;
            }
        }
        else {
            var tokenResolutionPath = [];
            var resolvedToken = resolveToken(theme, token, tokenResolutionPath, undefined, baseTheme, propertiesMap);
            if (!baseTheme || tokenResolutionPath.some(function (pathToken) { return pathToken in theme.tokens; })) {
                resolutionPaths[token] = tokenResolutionPath;
                resolvedTheme[token] = resolvedToken;
            }
        }
    });
    return { resolvedTheme: resolvedTheme, resolutionPaths: resolutionPaths };
}
function resolveToken(theme, token, path, state, baseTheme, propertiesMap) {
    if (!theme.tokens[token] && !(baseTheme === null || baseTheme === void 0 ? void 0 : baseTheme.tokens[token])) {
        throw new Error("Token ".concat(token, " does not exist in the theme."));
    }
    if (path.includes(token)) {
        throw new Error("Token ".concat(token, " has a circular dependency."));
    }
    path.push(token);
    var assignment = getAssignment(theme, token, state, baseTheme);
    if (isReference(assignment)) {
        var ref = getReference(assignment);
        if ((propertiesMap === null || propertiesMap === void 0 ? void 0 : propertiesMap[ref]) && (theme.tokens[ref] || (baseTheme === null || baseTheme === void 0 ? void 0 : baseTheme.tokens[ref]))) {
            return "var(".concat(propertiesMap[ref], ")");
        }
        return resolveToken(theme, ref, path, state, baseTheme, propertiesMap);
    }
    return assignment;
}
function getAssignment(theme, token, state, baseTheme) {
    var assignment = theme.tokens[token] || (baseTheme === null || baseTheme === void 0 ? void 0 : baseTheme.tokens[token]);
    if (!assignment) {
        throw new Error("Empty assignment for token ".concat(token));
    }
    if (isModeValue(assignment)) {
        if (!state) {
            throw new Error("Mode resolution for token ".concat(token, " does not have any mode value. modes: ").concat(JSON.stringify(assignment)));
        }
        assignment = assignment[state];
    }
    return assignment;
}
export function resolveContext(theme, context, baseTheme, themeResolution, propertiesMap) {
    var tmp = cloneDeep(theme);
    if (context.defaultMode && theme.modes) {
        resolveModeReferenceTokens(tmp, context, baseTheme);
    }
    if (!baseTheme || !themeResolution) {
        tmp.tokens = __assign(__assign({}, tmp.tokens), context.tokens);
        return resolveTheme(tmp, baseTheme, propertiesMap);
    }
    tmp.tokens = applyContextPrecedenceRules(theme, context, baseTheme, themeResolution, propertiesMap);
    return resolveTheme(tmp, baseTheme, propertiesMap);
}
function resolveModeReferenceTokens(theme, context, baseTheme) {
    if (!context.defaultMode || !theme.modes)
        return;
    var defaultMode = context.defaultMode;
    var mode = Object.values(theme.modes).find(function (m) { return m.states[defaultMode]; });
    if (!mode)
        return;
    // Reference tokens must be resolved to their mode-specific values before path analysis
    // because resolveThemeWithPaths expects concrete values, not mode objects. Without this,
    // the resolution would fail when encountering reference tokens with mode values.
    Object.keys(theme.tokens).forEach(function (token) {
        if (isReferenceToken('color', theme, token)) {
            var tokenValue = theme.tokens[token];
            if (isModeValue(tokenValue)) {
                theme.tokens[token] = tokenValue[defaultMode];
            }
        }
    });
    // Merge theme tokens with context overrides to analyze full resolution paths
    var mergedTheme = __assign(__assign({}, theme), { tokens: __assign(__assign({}, theme.tokens), context.tokens) });
    var resolutionPaths = resolveThemeWithPaths(mergedTheme, baseTheme).resolutionPaths;
    // Add reference tokens to context
    collectReferenceTokens(theme, resolutionPaths).forEach(function (token) {
        context.tokens[token] = theme.tokens[token];
    });
    // Add parent tokens that depend on context-overridden tokens
    var contextTokens = new Set(Object.keys(context.tokens));
    Object.keys(theme.tokens).forEach(function (token) {
        if (!contextTokens.has(token) && resolutionPaths[token]) {
            var pathTokens = flattenResolutionPaths(resolutionPaths[token]);
            if (pathTokens.some(function (pathToken) { return contextTokens.has(pathToken); })) {
                context.tokens[token] = theme.tokens[token];
            }
        }
    });
}
function applyContextPrecedenceRules(theme, context, baseTheme, themeResolution, propertiesMap) {
    /**
     * The precedence of context tokens as specified by the API from highest to lowest is:
     * [override theme context] > [base theme context] > [override theme] > [base theme].
     *
     * The precedence of tokens as defined in the generated CSS follows this order.
     * However, tokens that are declared in both the base theme and base theme
     * context and share the same value are only included in the base theme css. This
     * results in override theme tokens incorrectly taking precedence over base theme
     * context.
     *
     * To counteract this we can re-baseline the override context using all keys used
     * in the override theme with their respective values from the base theme context
     */
    var baseContext = baseTheme.contexts[context.id];
    var baseResolution = resolveTheme(baseTheme, undefined, propertiesMap);
    var overrideResolution = resolveTheme(theme, baseTheme, propertiesMap);
    var rebaselined = Object.keys(themeResolution).reduce(function (acc, key) {
        var _a, _b;
        var shouldSkipReset = (!(key in baseContext.tokens) && !(key in theme.tokens)) ||
            areAssignmentsEqual(baseResolution[key], overrideResolution[key]);
        if (!shouldSkipReset) {
            acc[key] = (_b = (_a = baseContext.tokens[key]) !== null && _a !== void 0 ? _a : theme.tokens[key]) !== null && _b !== void 0 ? _b : baseTheme.tokens[key];
        }
        return acc;
    }, {});
    return __assign(__assign({}, rebaselined), context.tokens);
}
export function reduce(resolution, theme, reducer, baseTheme) {
    return Object.keys(resolution).reduce(function (acc, token) {
        var reduced = reducer(resolution[token], token, theme, baseTheme);
        if (reduced) {
            acc[token] = reduced;
        }
        return acc;
    }, {});
}
export var defaultsReducer = function () {
    return function (tokenResolution, token, theme, baseTheme) {
        var mode = getMode(baseTheme !== null && baseTheme !== void 0 ? baseTheme : theme, token);
        if (mode && isModeTokenResolution(tokenResolution)) {
            var defaultState = getDefaultState(mode);
            return tokenResolution[defaultState];
        }
        else if (isSpecificTokenResolution(tokenResolution)) {
            return tokenResolution;
        }
        else {
            throw new Error("Mismatch between resolution ".concat(JSON.stringify(tokenResolution), " and mode ").concat(mode));
        }
    };
};
export var modeReducer = function (mode, state) {
    return function (tokenResolution, token, theme, baseTheme) {
        var tokenMode = getMode(baseTheme !== null && baseTheme !== void 0 ? baseTheme : theme, token);
        if (tokenMode && tokenMode.id === mode.id && isModeTokenResolution(tokenResolution)) {
            return tokenResolution[state];
        }
        else if (isSpecificTokenResolution(tokenResolution)) {
            return tokenResolution;
        }
    };
};
export function difference(base, other) {
    var result = {};
    Object.keys(other).forEach(function (token) {
        var baseVal = base[token];
        var otherVal = other[token];
        if (isSpecificTokenResolution(baseVal) && isSpecificTokenResolution(otherVal) && baseVal !== otherVal) {
            result[token] = otherVal;
        }
        else if (isModeTokenResolution(baseVal) && isModeTokenResolution(otherVal)) {
            var resolved = Object.keys(otherVal).reduce(function (acc, state) {
                if (baseVal[state] !== otherVal[state]) {
                    acc[state] = otherVal[state];
                }
                return acc;
            }, {});
            if (!isEmpty(resolved)) {
                result[token] = resolved;
            }
        }
    });
    return result;
}
export function isModeTokenResolution(val) {
    return typeof val === 'object';
}
export function isSpecificTokenResolution(val) {
    return typeof val === 'string';
}
var isEmpty = function (obj) { return Object.keys(obj).length === 0; };
function flattenResolutionPaths(pathOrPaths) {
    var _a;
    return typeof pathOrPaths === 'object' && !Array.isArray(pathOrPaths)
        ? (_a = []).concat.apply(_a, Object.values(pathOrPaths)) : pathOrPaths;
}
function collectReferenceTokens(theme, resolutionPaths) {
    var referenceTokens = new Set();
    Object.values(resolutionPaths).forEach(function (pathOrPaths) {
        var allPaths = flattenResolutionPaths(pathOrPaths);
        allPaths.forEach(function (token) {
            if (isReferenceToken('color', theme, token)) {
                referenceTokens.add(token);
            }
        });
    });
    return referenceTokens;
}
