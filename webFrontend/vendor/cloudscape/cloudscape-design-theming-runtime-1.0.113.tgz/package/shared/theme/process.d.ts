import { ColorReferenceTokens, ColorPaletteInput, ReferencePaletteDefinition, Assignment } from './interfaces';
export type TokenCategory<T extends string, V> = Record<T, V>;
export declare function processReferenceTokens(colorTokens: ColorReferenceTokens): TokenCategory<string, Assignment>;
export declare function processColorPaletteInput(category: keyof ColorReferenceTokens, input: ColorPaletteInput): ReferencePaletteDefinition;
