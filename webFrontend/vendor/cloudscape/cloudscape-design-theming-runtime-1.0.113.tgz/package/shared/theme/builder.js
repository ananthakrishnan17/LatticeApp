import { __assign } from "tslib";
import { processReferenceTokens } from './process';
var ThemeBuilder = /** @class */ (function () {
    function ThemeBuilder(id, selector, modes) {
        this.theme = {
            id: id,
            selector: selector,
            modes: modes.reduce(function (acc, curr) {
                acc[curr.id] = curr;
                return acc;
            }, {}),
            tokens: {},
            contexts: {},
            tokenModeMap: {}
        };
    }
    ThemeBuilder.prototype.addTokensToModeMap = function (tokens, mode) {
        var modeMap = Object.keys(tokens).reduce(function (acc, token) {
            acc[token] = mode.id;
            return acc;
        }, {});
        this.theme.tokenModeMap = __assign(__assign({}, this.theme.tokenModeMap), modeMap);
    };
    ThemeBuilder.prototype.addTokens = function (tokens, mode) {
        this.theme.tokens = __assign(__assign({}, this.theme.tokens), tokens);
        if (mode) {
            this.addTokensToModeMap(tokens, mode);
        }
        return this;
    };
    ThemeBuilder.prototype.addContext = function (context) {
        this.theme.contexts[context.id] = context;
        return this;
    };
    ThemeBuilder.prototype.addReferenceTokens = function (referenceTokens, mode) {
        this.theme.referenceTokens = referenceTokens;
        if (referenceTokens.color) {
            var generatedTokens = processReferenceTokens(referenceTokens.color);
            this.theme.tokens = __assign(__assign({}, generatedTokens), this.theme.tokens);
            if (mode) {
                this.addTokensToModeMap(generatedTokens, mode);
            }
        }
        return this;
    };
    ThemeBuilder.prototype.build = function () {
        return this.theme;
    };
    return ThemeBuilder;
}());
export { ThemeBuilder };
