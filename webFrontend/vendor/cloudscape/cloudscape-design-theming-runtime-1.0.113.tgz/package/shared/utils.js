// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export function cloneDeep(obj) {
    return JSON.parse(JSON.stringify(obj));
}
/*
 * Replace those simple helpers with platform features when changing TS target
 */
export function entries(obj) {
    return Object.keys(obj).map(function (key) { return [key, obj[key]]; });
}
/**
 * This function mirrors the Object.fromEntries method.
 *
 * See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/fromEntries
 */
export function fromEntries(entries) {
    return entries.reduce(function (acc, _a) {
        var key = _a[0], value = _a[1];
        acc[key] = value;
        return acc;
    }, {});
}
/**
 * This function mirros the Object.values method.
 *
 * See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_objects/Object/values
 */
export function values(some) {
    return Object.keys(some).map(function (key) { return some[key]; });
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function includes(subject, search) {
    return subject.indexOf(search) > -1;
}
export function jsonToSass(json) {
    return "(\n    ".concat(Object.keys(json)
        .map(function (key) {
        return "'".concat(key, "': ").concat(typeof json[key] === 'string' ? "\"".concat(json[key], "\"") : jsonToSass(json[key]));
    })
        .join(',\n'), "\n  )");
}
