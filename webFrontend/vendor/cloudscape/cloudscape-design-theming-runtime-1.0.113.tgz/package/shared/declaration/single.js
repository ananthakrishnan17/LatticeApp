import { __extends } from "tslib";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { defaultsReducer, modeReducer, reduce, resolveContext, resolveTheme, } from '../theme';
import Stylesheet from './stylesheet';
import { AbstractCreator } from './abstract';
import { compact } from './utils';
var SingleThemeCreator = /** @class */ (function (_super) {
    __extends(SingleThemeCreator, _super);
    function SingleThemeCreator(theme, ruleCreator, baseTheme, propertiesMap) {
        var _this = _super.call(this) || this;
        _this.theme = theme;
        _this.baseTheme = baseTheme;
        _this.propertiesMap = propertiesMap;
        _this.resolution = resolveTheme(theme, _this.baseTheme, propertiesMap);
        _this.ruleCreator = ruleCreator;
        return _this;
    }
    SingleThemeCreator.prototype.create = function () {
        var _this = this;
        var stylesheet = new Stylesheet();
        var defaults = reduce(this.resolution, this.theme, defaultsReducer(), this.baseTheme);
        var rootRule = this.ruleCreator.create({ global: [this.theme.selector] }, defaults);
        SingleThemeCreator.appendRuleToStylesheet(stylesheet, rootRule, []);
        SingleThemeCreator.forEachOptionalModeState(this.theme, function (mode, state) {
            var modeResolution = reduce(_this.resolution, _this.theme, modeReducer(mode, state), _this.baseTheme);
            var stateDetails = mode.states[state];
            var modeRule = _this.ruleCreator.create({ global: [_this.theme.selector, stateDetails.selector], media: stateDetails.media }, modeResolution);
            SingleThemeCreator.appendRuleToStylesheet(stylesheet, modeRule, [rootRule]);
        });
        SingleThemeCreator.forEachContext(this.theme, function (context) {
            var contextResolution = reduce(resolveContext(_this.theme, context, _this.baseTheme, _this.resolution, _this.propertiesMap), _this.theme, defaultsReducer(), _this.baseTheme);
            var contextRule = _this.ruleCreator.create({ global: [_this.theme.selector], local: [context.selector] }, contextResolution);
            SingleThemeCreator.appendRuleToStylesheet(stylesheet, contextRule, [rootRule]);
            var contextRule2 = _this.ruleCreator.create({ global: [_this.theme.selector, context.selector] }, contextResolution);
            SingleThemeCreator.appendRuleToStylesheet(stylesheet, contextRule2, [rootRule]);
        });
        SingleThemeCreator.forEachContextWithinOptionalModeState(this.theme, function (context, mode, state) {
            var contextResolution = reduce(resolveContext(_this.theme, context, _this.baseTheme, _this.resolution, _this.propertiesMap), _this.theme, modeReducer(mode, state), _this.baseTheme);
            var stateDetails = mode.states[state];
            var contextAndModeRule = _this.ruleCreator.create({ global: [_this.theme.selector, stateDetails.selector], local: [context.selector], media: stateDetails.media }, contextResolution);
            var contextRule = stylesheet.findRule(_this.ruleCreator.selectorFor({ global: [_this.theme.selector], local: [context.selector] }));
            var contextRuleGlobal = stylesheet.findRule(_this.ruleCreator.selectorFor({ global: [_this.theme.selector, context.selector] }));
            var modeRule = stylesheet.findRule(_this.ruleCreator.selectorFor({
                global: [_this.theme.selector, mode.states[state].selector]
            }));
            SingleThemeCreator.appendRuleToStylesheet(stylesheet, contextAndModeRule, compact([contextRule, modeRule, rootRule]));
            var contextRuleAndModeRuleGlobal = _this.ruleCreator.create({ global: [_this.theme.selector, stateDetails.selector, context.selector], media: stateDetails.media }, contextResolution);
            SingleThemeCreator.appendRuleToStylesheet(stylesheet, contextRuleAndModeRuleGlobal, compact([contextRuleGlobal, modeRule, rootRule]));
        });
        return stylesheet;
    };
    return SingleThemeCreator;
}(AbstractCreator));
export { SingleThemeCreator };
