export declare function compact<T>(arr: (T | undefined)[]): T[];
/**
 * Extracts the CSS variable name from a var() reference.
 * @param value - Token value that may contain a var() reference
 * @returns The variable name (e.g., '--color-primary') or null if not a var() reference
 */
export declare function getReferencedVar(value: string): string | null;
