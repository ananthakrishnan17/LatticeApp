import { __spreadArray } from "tslib";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { mergeInPlace } from '../theme';
import { flattenReferenceTokens, collectReferencedTokens } from '../theme/utils';
import { RuleCreator } from './rule';
import { SingleThemeCreator } from './single';
import { MultiThemeCreator } from './multi';
import { Selector } from './selector';
import { UsedPropertyRegistry } from './registry';
import { MinimalTransformer } from './transformer';
import { cloneDeep, values } from '../utils';
function createMinimalTheme(base, override) {
    var minimalTheme = cloneDeep(base);
    var contextTokens = new Set();
    values(minimalTheme.contexts).forEach(function (context) {
        Object.keys(context.tokens).forEach(function (key) {
            var _a, _b, _c;
            var isInOverrideContext = key in ((_c = (_b = (_a = override === null || override === void 0 ? void 0 : override.contexts) === null || _a === void 0 ? void 0 : _a[context.id]) === null || _b === void 0 ? void 0 : _b.tokens) !== null && _c !== void 0 ? _c : {});
            if (!(key in override.tokens) && !isInOverrideContext) {
                delete context.tokens[key];
            }
            else {
                contextTokens.add(key);
            }
        });
    });
    Object.keys(minimalTheme.tokens).forEach(function (key) {
        if (!contextTokens.has(key) && !(key in override.tokens)) {
            delete minimalTheme.tokens[key];
        }
    });
    return mergeInPlace(minimalTheme, override);
}
function collectAllRequiredTokens(themes, initialTokens) {
    var referenceTokens = [];
    themes.forEach(function (theme) { return referenceTokens.push.apply(referenceTokens, Object.keys(flattenReferenceTokens(theme))); });
    var alreadyIncluded = new Set(__spreadArray(__spreadArray([], initialTokens, true), referenceTokens, true));
    var referencedTokens = [];
    themes.forEach(function (theme) {
        var referenced = collectReferencedTokens(theme, __spreadArray(__spreadArray([], initialTokens, true), referenceTokens, true));
        referenced.forEach(function (token) {
            if (!alreadyIncluded.has(token)) {
                referencedTokens.push(token);
                alreadyIncluded.add(token);
            }
        });
    });
    return { referenceTokens: referenceTokens, referencedTokens: referencedTokens };
}
function addMissingTokensToTheme(theme, tokens, sourceTheme) {
    tokens.forEach(function (token) {
        if (!(token in theme.tokens) && token in sourceTheme.tokens) {
            theme.tokens[token] = sourceTheme.tokens[token];
        }
    });
}
export function createOverrideDeclarations(base, override, propertiesMap, selectorCustomizer) {
    var minimalTheme = createMinimalTheme(base, override);
    var initialTokens = Object.keys(minimalTheme.tokens);
    var referencedTokens = collectAllRequiredTokens([base], initialTokens).referencedTokens;
    // Add referenced tokens to minimalTheme so they get output in root
    // The transformer will remove them from mode/context selectors since they're unchanged
    addMissingTokensToTheme(minimalTheme, referencedTokens, base);
    var usedTokens = __spreadArray(__spreadArray([], initialTokens, true), referencedTokens, true);
    var ruleCreator = new RuleCreator(new Selector(selectorCustomizer), new UsedPropertyRegistry(propertiesMap, usedTokens));
    var stylesheet = new SingleThemeCreator(minimalTheme, ruleCreator, base, propertiesMap).create();
    return new MinimalTransformer().transform(stylesheet).toString();
}
export function createBuildDeclarations(primary, secondary, propertiesMap, selectorCustomizer, used) {
    var themes = __spreadArray([primary], secondary, true);
    var _a = collectAllRequiredTokens(themes, used), referenceTokens = _a.referenceTokens, referencedTokens = _a.referencedTokens;
    var usedTokens = __spreadArray(__spreadArray(__spreadArray([], used, true), referenceTokens, true), referencedTokens, true);
    var ruleCreator = new RuleCreator(new Selector(selectorCustomizer), new UsedPropertyRegistry(propertiesMap, usedTokens));
    var stylesheet = new MultiThemeCreator(themes, ruleCreator, propertiesMap).create();
    return new MinimalTransformer().transform(stylesheet).toString('cloudscape-base-theme');
}
