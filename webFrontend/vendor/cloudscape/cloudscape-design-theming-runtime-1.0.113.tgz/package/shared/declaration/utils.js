// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export function compact(arr) {
    var result = [];
    for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
        var item = arr_1[_i];
        if (item !== undefined) {
            result.push(item);
        }
    }
    return result;
}
/**
 * Extracts the CSS variable name from a var() reference.
 * @param value - Token value that may contain a var() reference
 * @returns The variable name (e.g., '--color-primary') or null if not a var() reference
 */
export function getReferencedVar(value) {
    var match = value.match(/var\((--[^)]+)\)/);
    return match ? match[1] : null;
}
