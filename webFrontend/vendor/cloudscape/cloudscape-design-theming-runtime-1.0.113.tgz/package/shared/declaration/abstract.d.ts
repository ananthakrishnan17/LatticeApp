import type { Mode, Context, Theme } from '../theme';
import type Stylesheet from './stylesheet';
import type { Rule } from './stylesheet';
/**
 * Common used helpers by stylesheet creator
 */
export declare abstract class AbstractCreator {
    static forEachOptionalModeState(theme: Theme, func: (mode: Mode, stateKey: string) => void): void;
    static forEachContext(theme: Theme, func: (context: Context) => void): void;
    static forEachContextWithinOptionalModeState(theme: Theme, func: (context: Context, mode: Mode, stateName: string) => void): void;
    static appendRuleToStylesheet(stylesheet: Stylesheet, rule: Rule, path: Rule[]): void;
}
