import { isOptionalState } from '../theme/utils';
import { entries } from '../utils';
/**
 * Common used helpers by stylesheet creator
 */
var AbstractCreator = /** @class */ (function () {
    function AbstractCreator() {
    }
    AbstractCreator.forEachOptionalModeState = function (theme, func) {
        Object.keys(theme.modes).forEach(function (key) {
            var mode = theme.modes[key];
            entries(mode.states).forEach(function (_a) {
                var stateKey = _a[0], state = _a[1];
                if (isOptionalState(state)) {
                    func(mode, stateKey);
                }
            });
        });
    };
    AbstractCreator.forEachContext = function (theme, func) {
        Object.keys(theme.contexts).forEach(function (key) {
            var context = theme.contexts[key];
            func(context);
        });
    };
    AbstractCreator.forEachContextWithinOptionalModeState = function (theme, func) {
        AbstractCreator.forEachOptionalModeState(theme, function (mode, stateKey) {
            AbstractCreator.forEachContext(theme, function (context) {
                func(context, mode, stateKey);
            });
        });
    };
    AbstractCreator.appendRuleToStylesheet = function (stylesheet, rule, path) {
        if (rule.size()) {
            stylesheet.appendRuleWithPath(rule, path);
        }
    };
    return AbstractCreator;
}());
export { AbstractCreator };
