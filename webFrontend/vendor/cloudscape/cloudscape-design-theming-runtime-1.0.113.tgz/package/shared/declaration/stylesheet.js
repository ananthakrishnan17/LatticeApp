// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Allows building a stylesheet by appending selectors and declarations. A call of
 * `toString` will return CSS.
 */
var Stylesheet = /** @class */ (function () {
    function Stylesheet() {
        this.rulesMap = new Map();
        this.paths = new Map();
        this.counter = 0;
    }
    Stylesheet.prototype.appendRule = function (rule) {
        this.rulesMap.set(rule.selector, [rule, this.counter++]);
    };
    Stylesheet.prototype.appendRuleWithPath = function (rule, path) {
        // When a global theme (body/:root/html) has a context, the descendant form
        // { global: [body], local: [.ctx] } and the same-element form
        // { global: [body, .ctx] } both resolve to the same selector string because
        // the global selector is stripped. Silently skip the duplicate so that
        // rulesMap and paths stay in sync (one entry each per selector).
        if (this.rulesMap.has(rule.selector)) {
            return;
        }
        this.rulesMap.set(rule.selector, [rule, this.counter++]);
        this.paths.set(rule, path);
    };
    Stylesheet.prototype.removeRule = function (rule) {
        this.rulesMap["delete"](rule.selector);
        this.paths["delete"](rule);
    };
    Stylesheet.prototype.findRule = function (selector) {
        var ruleOrUndefined = this.rulesMap.get(selector);
        return ruleOrUndefined === null || ruleOrUndefined === void 0 ? void 0 : ruleOrUndefined[0];
    };
    Stylesheet.prototype.getPath = function (rule) {
        var path = this.paths.get(rule);
        if (!path) {
            throw new Error("No path for rule with selector: ".concat(rule.selector));
        }
        return path;
    };
    Stylesheet.prototype.getAllRules = function () {
        var rules = [];
        this.paths.forEach(function (_, key) { return rules.push(key); });
        return rules;
    };
    /**
     * @returns CSS
     */
    Stylesheet.prototype.toString = function (layer) {
        var result = asValuesArray(this.rulesMap).map(function (rule) { return rule.toString(); });
        return layer ? "@layer ".concat(layer, " {\n").concat(result.join('\n'), "\n}") : result.join('\n');
    };
    return Stylesheet;
}());
export default Stylesheet;
var Rule = /** @class */ (function () {
    function Rule(selector, media) {
        this.declarationsMap = new Map();
        this.counter = 0;
        this.selector = selector;
        this.media = media;
    }
    Rule.prototype.appendDeclaration = function (declaration) {
        this.declarationsMap.set(declaration.property, [declaration, this.counter++]);
    };
    Rule.prototype.clear = function () {
        this.declarationsMap = new Map();
        this.counter = 0;
    };
    Rule.prototype.getAllDeclarations = function () {
        return asValuesArray(this.declarationsMap);
    };
    Rule.prototype.printAllDeclarations = function () {
        return this.getAllDeclarations()
            .map(function (decl) { return decl.toString(); })
            .join('\n\t');
    };
    Rule.prototype.size = function () {
        return this.declarationsMap.size;
    };
    Rule.prototype.toString = function () {
        var rule = "".concat(this.selector, "{\n\t").concat(this.printAllDeclarations(), "\n}");
        if (this.media) {
            return "@media ".concat(this.media, " {").concat(rule, "}");
        }
        return rule;
    };
    Rule.prototype.isModeRule = function () {
        return !!this.media;
    };
    return Rule;
}());
export { Rule };
var Declaration = /** @class */ (function () {
    function Declaration(property, value) {
        this.property = property;
        this.value = value;
    }
    Declaration.prototype.toString = function () {
        return "".concat(this.property, ":").concat(this.value, ";");
    };
    return Declaration;
}());
export { Declaration };
function asValuesArray(map) {
    var tmp = [];
    map.forEach(function (_a) {
        var item = _a[0], position = _a[1];
        return tmp.push([item, position]);
    });
    tmp.sort(function (_a, _b) {
        var itemA = _a[0], posA = _a[1];
        var itemB = _b[0], posB = _b[1];
        return posA - posB;
    });
    return tmp.map(function (_a) {
        var item = _a[0];
        return item;
    });
}
