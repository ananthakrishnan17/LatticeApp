import type Stylesheet from './stylesheet';
export type PropertiesMap = Record<string, string>;
export type SelectorCustomizer = (selector: string) => string;
interface Creator<T> {
    create(): T;
}
export type StylesheetCreator = Creator<Stylesheet>;
export {};
