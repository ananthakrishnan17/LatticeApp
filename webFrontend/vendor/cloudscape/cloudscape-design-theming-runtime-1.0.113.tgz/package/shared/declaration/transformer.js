// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { entries } from '../utils';
import { Declaration } from './stylesheet';
import { getFirstSelector, isGlobalSelector } from '../styles/selector';
import { getReferencedVar } from './utils';
var MinimalTransformer = /** @class */ (function () {
    function MinimalTransformer() {
    }
    MinimalTransformer.prototype.transform = function (stylesheet) {
        var rules = stylesheet.getAllRules();
        var rulesWithPath = rules.map(function (rule) { return ({
            rule: rule,
            path: stylesheet.getPath(rule)
        }); });
        var sorted = rulesWithPath.sort(function (_a, _b) {
            var pathA = _a.path;
            var pathB = _b.path;
            return pathA.length - pathB.length;
        });
        sorted.forEach(function (_a) {
            var rule = _a.rule, path = _a.path;
            if (path.length === 0) {
                // Root rule nothing to see here.
                return;
            }
            var resolvedParent = {};
            for (var i = path.length - 1; i >= 0; i--) {
                var parent_1 = path[i];
                var declarations = parent_1.getAllDeclarations();
                declarations.forEach(function (decl) {
                    resolvedParent[decl.property] = decl.value;
                });
            }
            var ruleValue = rule.getAllDeclarations().reduce(function (acc, decl) {
                acc[decl.property] = decl.value;
                return acc;
            }, {});
            var diff = difference(resolvedParent, ruleValue);
            // CSS variables with nested var() references need special handling for non-global selectors.
            // Even if the selector doesn't explicitly show a descendant combinator (like `.navigation`),
            // it will be a descendant of `body` in the DOM. When a descendant overrides a token,
            // tokens that reference it must be re-output, otherwise they resolve in the parent context.
            //
            // However, for mode rules (which have media queries), we should skip tokens that have
            // identical values to their parent, even if referenced variables are overridden. These can inherit
            // properly via natural css variable cascade rules.
            var firstSelector = getFirstSelector(rule.selector);
            var isModeRule = rule.isModeRule();
            if (isGlobalSelector(firstSelector)) {
                rule.clear();
                entries(diff).forEach(function (_a) {
                    var property = _a[0], value = _a[1];
                    return rule.appendDeclaration(new Declaration(property, value));
                });
                if (rule.size() === 0) {
                    stylesheet.removeRule(rule);
                }
                return;
            }
            var isOverridden = function (varName, visited) {
                if (visited === void 0) { visited = new Set(); }
                if (visited.has(varName))
                    return false;
                visited.add(varName);
                var isDirectlyOverridden = varName in ruleValue && varName in resolvedParent && ruleValue[varName] !== resolvedParent[varName];
                if (isDirectlyOverridden)
                    return true;
                var referencedVar = varName in ruleValue ? getReferencedVar(ruleValue[varName]) : null;
                return referencedVar ? isOverridden(referencedVar, visited) : false;
            };
            Object.keys(ruleValue).forEach(function (property) {
                var referencedVar = getReferencedVar(ruleValue[property]);
                if (!referencedVar || !isOverridden(referencedVar))
                    return;
                // For mode rules, only output if value actually differs from resolved parent
                // For context rules, always output to ensure correct resolution
                var canInherit = isModeRule && ruleValue[property] === resolvedParent[property];
                if (canInherit)
                    return;
                if (!(property in diff)) {
                    diff[property] = ruleValue[property];
                }
            });
            rule.clear();
            entries(diff).forEach(function (_a) {
                var property = _a[0], value = _a[1];
                return rule.appendDeclaration(new Declaration(property, value));
            });
            if (rule.size() === 0) {
                stylesheet.removeRule(rule);
            }
        });
        return mergeSelectors(stylesheet);
    };
    return MinimalTransformer;
}());
export { MinimalTransformer };
/**
 * Merges adjacent rules with identical declarations into a single comma-separated selector.
 *
 * For example:
 * .a { --color-background: red; }
 * .b { --color-background: red; }
 *
 * becomes:
 * .a,
 * .b { --color-background: red; }
 */
function mergeSelectors(stylesheet) {
    var rules = stylesheet.getAllRules();
    var i = 1;
    while (i < rules.length) {
        var prev = rules[i - 1];
        var curr = rules[i];
        if (prev.media === curr.media && prev.printAllDeclarations() === curr.printAllDeclarations()) {
            prev.selector = "".concat(prev.selector, ",").concat(curr.selector);
            stylesheet.removeRule(curr);
            rules.splice(i, 1);
        }
        else {
            i++;
        }
    }
    return stylesheet;
}
function difference(mapA, mapB) {
    var diff = {};
    Object.keys(mapA).forEach(function (key) {
        if (mapA[key] !== mapB[key] && mapB[key] !== undefined) {
            diff[key] = mapB[key];
        }
    });
    Object.keys(mapB).forEach(function (key) {
        if (mapA[key] !== mapB[key] && mapB[key] !== undefined) {
            diff[key] = mapB[key];
        }
    });
    return diff;
}
