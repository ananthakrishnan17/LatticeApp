import type { PropertiesMap } from './interfaces';
export interface PropertyRegistry {
    get(token: string): string | undefined;
}
export declare class AllPropertyRegistry implements PropertyRegistry {
    map: Record<string, string>;
    constructor(propertiesMap: PropertiesMap);
    get(token: string): string;
}
export declare class UsedPropertyRegistry implements PropertyRegistry {
    map: Record<string, string>;
    used: string[];
    constructor(propertiesMap: PropertiesMap, used: string[]);
    get(token: string): string | undefined;
}
