var AllPropertyRegistry = /** @class */ (function () {
    function AllPropertyRegistry(propertiesMap) {
        this.map = propertiesMap;
    }
    AllPropertyRegistry.prototype.get = function (token) {
        var property = this.map[token];
        if (!property) {
            throw new Error("Token ".concat(token, " does not have a property"));
        }
        return property;
    };
    return AllPropertyRegistry;
}());
export { AllPropertyRegistry };
var UsedPropertyRegistry = /** @class */ (function () {
    function UsedPropertyRegistry(propertiesMap, used) {
        this.map = propertiesMap;
        this.used = used;
    }
    UsedPropertyRegistry.prototype.get = function (token) {
        if (this.used.indexOf(token) > -1) {
            return this.map[token];
        }
        return undefined;
    };
    return UsedPropertyRegistry;
}());
export { UsedPropertyRegistry };
