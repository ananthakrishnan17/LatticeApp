import { FullResolution, Theme } from '../theme';
import type { PropertiesMap } from './interfaces';
import Stylesheet from './stylesheet';
import { AbstractCreator } from './abstract';
import type { StylesheetCreator } from './interfaces';
import type { RuleCreator } from './rule';
export declare class SingleThemeCreator extends AbstractCreator implements StylesheetCreator {
    theme: Theme;
    baseTheme?: Theme;
    resolution: FullResolution;
    ruleCreator: RuleCreator;
    propertiesMap?: PropertiesMap;
    constructor(theme: Theme, ruleCreator: RuleCreator, baseTheme?: Theme, propertiesMap?: PropertiesMap);
    create(): Stylesheet;
}
