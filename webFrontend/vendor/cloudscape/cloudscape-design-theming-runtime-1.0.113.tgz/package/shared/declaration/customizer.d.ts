import type { SelectorCustomizer } from './interfaces';
export declare function createMultiThemeCustomizer(root: string): SelectorCustomizer;
export declare function singleThemeCustomizer(selector: string): string;
