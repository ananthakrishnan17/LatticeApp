/**
 * Allows building a stylesheet by appending selectors and declarations. A call of
 * `toString` will return CSS.
 */
export default class Stylesheet {
    rulesMap: Map<string, [Rule, number]>;
    paths: Map<Rule, Rule[]>;
    counter: number;
    appendRule(rule: Rule): void;
    appendRuleWithPath(rule: Rule, path: Rule[]): void;
    removeRule(rule: Rule): void;
    findRule(selector: string): Rule | undefined;
    getPath(rule: Rule): Rule[];
    getAllRules(): Rule[];
    /**
     * @returns CSS
     */
    toString(layer?: string): string;
}
export declare class Rule {
    selector: string;
    media?: string;
    declarationsMap: Map<string, [Declaration, number]>;
    counter: number;
    constructor(selector: string, media?: string);
    appendDeclaration(declaration: Declaration): void;
    clear(): void;
    getAllDeclarations(): Declaration[];
    printAllDeclarations(): string;
    size(): number;
    toString(): string;
    isModeRule(): boolean;
}
export declare class Declaration {
    property: string;
    value: string;
    constructor(property: string, value: string);
    toString(): string;
}
