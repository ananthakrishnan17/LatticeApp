import type Stylesheet from './stylesheet';
export interface Transformer {
    transform(stylesheet: Stylesheet): Stylesheet;
}
export declare class MinimalTransformer implements Transformer {
    transform(stylesheet: Stylesheet): Stylesheet;
}
