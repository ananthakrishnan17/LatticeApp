import { Selector } from './selector';
import type { PropertyRegistry } from './registry';
import { Rule } from './stylesheet';
import { SpecificResolution } from '../theme';
export interface SelectorConfig {
    global: string[];
    local?: string[];
    media?: string;
}
export declare class RuleCreator {
    selector: Selector;
    registry: PropertyRegistry;
    constructor(selector: Selector, registry: PropertyRegistry);
    create(config: SelectorConfig, resolution: SpecificResolution): Rule;
    selectorFor(config: SelectorConfig): string;
}
