import { isGlobalSelector } from '../styles/selector';
var Selector = /** @class */ (function () {
    function Selector(customizer) {
        this.customizer = customizer;
    }
    Selector.prototype["for"] = function (_a) {
        var global = _a.global, local = _a.local;
        if (global.length === 1 && !(local === null || local === void 0 ? void 0 : local.length) && isGlobalSelector(global[0])) {
            // Global selectors (:root, body, html) are only applied alone
            return this.customizer(global[0]);
        }
        var nonGlobalSelectors = global.filter(function (f) { return !isGlobalSelector(f); });
        var selector = this.toSelector(nonGlobalSelectors);
        if (local === null || local === void 0 ? void 0 : local.length) {
            selector += " ".concat(this.toSelector(local));
        }
        return this.customizer(selector.trim());
    };
    Selector.prototype.toSelector = function (individuals) {
        // Sort to guarantee a stable generation - element selectors first, then class selectors
        var isElement = function (selector) {
            return ['.', ':', '#'].indexOf(selector.charAt(0)) === -1;
        };
        return individuals
            .slice()
            .sort(function (a, b) {
            if (isElement(a) && !isElement(b))
                return -1;
            if (!isElement(a) && isElement(b))
                return 1;
            return a.localeCompare(b);
        })
            .join('');
    };
    return Selector;
}());
export { Selector };
