import { Theme } from '../theme';
import type { PropertiesMap } from './interfaces';
import { AbstractCreator } from './abstract';
import type { StylesheetCreator } from './interfaces';
import { RuleCreator } from './rule';
import Stylesheet from './stylesheet';
/**
 * Extends the single theme stylesheet creator by a secondary theme, which takes the existing theme as
 * base.
 */
export declare class MultiThemeCreator extends AbstractCreator implements StylesheetCreator {
    themes: Theme[];
    ruleCreator: RuleCreator;
    propertiesMap?: PropertiesMap;
    constructor(themes: Theme[], ruleCreator: RuleCreator, propertiesMap?: PropertiesMap);
    create(): Stylesheet;
    appendRulesForSecondary(stylesheet: Stylesheet, primary: Theme, secondary: Theme): Stylesheet;
    private findRule;
    private getThemesWithout;
}
