import { Override, Theme } from '../theme';
import type { PropertiesMap, SelectorCustomizer } from './interfaces';
export declare function createOverrideDeclarations(base: Theme, override: Override, propertiesMap: PropertiesMap, selectorCustomizer: SelectorCustomizer): string;
export declare function createBuildDeclarations(primary: Theme, secondary: Theme[], propertiesMap: PropertiesMap, selectorCustomizer: SelectorCustomizer, used: string[]): string;
