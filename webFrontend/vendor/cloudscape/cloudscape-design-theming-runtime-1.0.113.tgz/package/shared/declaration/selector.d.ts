import type { SelectorCustomizer } from './interfaces';
interface SelectorParams {
    global: string[];
    local?: string[];
}
export declare class Selector {
    customizer: SelectorCustomizer;
    constructor(customizer: SelectorCustomizer);
    for({ global, local }: SelectorParams): string;
    private toSelector;
}
export {};
