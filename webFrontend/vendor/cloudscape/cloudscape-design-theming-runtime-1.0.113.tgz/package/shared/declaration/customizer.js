import { increaseSpecificity, increaseSpecificityGradually, isIncreased } from '../styles/selector';
import { includes } from '../utils';
export function createMultiThemeCustomizer(root) {
    // non root selector receives an increased specificity at build time
    // as seen below
    return function (selector) {
        return selector === root
            ? increaseSpecificityGradually(selector)
            : increaseSpecificity(increaseSpecificityGradually(selector));
    };
}
export function singleThemeCustomizer(selector) {
    if (includes(selector, ':root') ||
        includes(selector, ':export') ||
        selector === 'html' ||
        selector === 'body' ||
        isIncreased(selector)) {
        return selector;
    }
    return increaseSpecificity(selector);
}
