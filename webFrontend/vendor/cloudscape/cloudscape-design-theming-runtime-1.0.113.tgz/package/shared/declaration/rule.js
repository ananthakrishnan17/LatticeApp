import { Rule, Declaration } from './stylesheet';
import { entries } from '../utils';
var RuleCreator = /** @class */ (function () {
    function RuleCreator(selector, registry) {
        this.selector = selector;
        this.registry = registry;
    }
    RuleCreator.prototype.create = function (config, resolution) {
        var _this = this;
        var rule = new Rule(this.selectorFor(config), config.media);
        entries(resolution).forEach(function (_a) {
            var token = _a[0], value = _a[1];
            var property = _this.registry.get(token);
            if (property) {
                rule.appendDeclaration(new Declaration(property, value));
            }
        });
        return rule;
    };
    RuleCreator.prototype.selectorFor = function (config) {
        return this.selector["for"](config);
    };
    return RuleCreator;
}());
export { RuleCreator };
