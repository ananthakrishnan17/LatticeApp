import { __extends, __spreadArray } from "tslib";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { isGlobalSelector } from '../styles/selector';
import { defaultsReducer, modeReducer, reduce, resolveContext, resolveTheme } from '../theme';
import { AbstractCreator } from './abstract';
import { SingleThemeCreator } from './single';
import Stylesheet from './stylesheet';
import { compact } from './utils';
/**
 * Extends the single theme stylesheet creator by a secondary theme, which takes the existing theme as
 * base.
 */
var MultiThemeCreator = /** @class */ (function (_super) {
    __extends(MultiThemeCreator, _super);
    function MultiThemeCreator(themes, ruleCreator, propertiesMap) {
        var _this = _super.call(this) || this;
        _this.themes = themes;
        _this.ruleCreator = ruleCreator;
        _this.propertiesMap = propertiesMap;
        return _this;
    }
    MultiThemeCreator.prototype.create = function () {
        var _this = this;
        var globalThemes = this.themes.filter(function (theme) { return isGlobalSelector(theme.selector); });
        if (globalThemes.length > 1) {
            throw new Error("Themes ".concat(globalThemes
                .map(function (_a) {
                var id = _a.id;
                return id;
            })
                .join(', '), " have a global selector. It is not supported to have more than one global theme. It produces unpredictable styling results."));
        }
        if (!globalThemes.length) {
            // If there is no root theme, all themes are scoped by their root selector. No interference.
            var stylesheets = this.themes.map(function (theme) {
                return new SingleThemeCreator(theme, _this.ruleCreator, undefined, _this.propertiesMap).create();
            });
            var result_1 = new Stylesheet();
            stylesheets.forEach(function (stylesheet) {
                stylesheet.getAllRules().map(function (rule) { var _a; return result_1.appendRuleWithPath(rule, (_a = stylesheet.getPath(rule)) !== null && _a !== void 0 ? _a : []); });
            });
            return result_1;
        }
        var globalTheme = globalThemes[0];
        var stylesheet = new SingleThemeCreator(globalTheme, this.ruleCreator, undefined, this.propertiesMap).create();
        var secondaries = this.getThemesWithout(globalTheme);
        secondaries.forEach(function (secondary) {
            _this.appendRulesForSecondary(stylesheet, globalTheme, secondary);
        });
        return stylesheet;
    };
    MultiThemeCreator.prototype.appendRulesForSecondary = function (stylesheet, primary, secondary) {
        var _this = this;
        var secondaryResolution = resolveTheme(secondary, undefined, this.propertiesMap);
        var defaults = reduce(secondaryResolution, secondary, defaultsReducer());
        var rootRule = this.ruleCreator.create({ global: [secondary.selector] }, defaults);
        var parentRule = this.findRule(stylesheet, { global: [primary.selector] });
        MultiThemeCreator.appendRuleToStylesheet(stylesheet, rootRule, compact([parentRule]));
        MultiThemeCreator.forEachOptionalModeState(secondary, function (mode, state) {
            var optionalState = mode.states[state];
            var modeResolution = reduce(secondaryResolution, secondary, modeReducer(mode, state));
            var modeRule = _this.ruleCreator.create({ global: [secondary.selector, optionalState.selector], media: optionalState.media }, modeResolution);
            var parentModeRule = stylesheet.findRule(_this.ruleCreator.selectorFor({
                global: [primary.selector, optionalState.selector]
            }));
            MultiThemeCreator.appendRuleToStylesheet(stylesheet, modeRule, compact([rootRule, parentModeRule, parentRule]));
        });
        MultiThemeCreator.forEachContext(secondary, function (context) {
            var contextResolution = reduce(resolveContext(secondary, context, undefined, undefined, _this.propertiesMap), secondary, defaultsReducer());
            var contextRule = _this.ruleCreator.create({ global: [secondary.selector], local: [context.selector] }, contextResolution);
            var parentContextRule = stylesheet.findRule(_this.ruleCreator.selectorFor({
                global: [primary.selector],
                local: [context.selector]
            }));
            MultiThemeCreator.appendRuleToStylesheet(stylesheet, contextRule, compact([parentContextRule, rootRule, parentRule]));
            var contextRuleGlobal = _this.ruleCreator.create({ global: [secondary.selector, context.selector] }, contextResolution);
            MultiThemeCreator.appendRuleToStylesheet(stylesheet, contextRuleGlobal, compact([rootRule, parentContextRule, parentRule]));
        });
        MultiThemeCreator.forEachContextWithinOptionalModeState(secondary, function (context, mode, state) {
            var optionalState = mode.states[state];
            var contextResolution = reduce(resolveContext(secondary, context, undefined, undefined, _this.propertiesMap), secondary, modeReducer(mode, state));
            var contextRule = _this.findRule(stylesheet, { global: [secondary.selector], local: [context.selector] });
            var contextRuleGlobal = _this.findRule(stylesheet, { global: [secondary.selector, context.selector] });
            var modeRule = _this.findRule(stylesheet, {
                global: [secondary.selector, optionalState.selector]
            });
            var contextAndModeRule = _this.ruleCreator.create({
                global: [secondary.selector, optionalState.selector],
                local: [context.selector],
                media: optionalState.media
            }, contextResolution);
            var parentContextRule = stylesheet.findRule(_this.ruleCreator.selectorFor({ global: [primary.selector], local: [context.selector] }));
            var parentModeRule = stylesheet.findRule(_this.ruleCreator.selectorFor({
                global: [primary.selector, optionalState.selector]
            }));
            var parentContextAndModeRule = stylesheet.findRule(_this.ruleCreator.selectorFor({
                global: [primary.selector, optionalState.selector],
                local: [context.selector]
            }));
            MultiThemeCreator.appendRuleToStylesheet(stylesheet, contextAndModeRule, compact([
                contextRule,
                parentContextAndModeRule,
                parentContextRule,
                modeRule,
                rootRule,
                parentModeRule,
                parentRule,
            ]));
            var contextAndModeRuleGlobal = _this.ruleCreator.create({
                global: [secondary.selector, optionalState.selector, context.selector],
                media: optionalState.media
            }, contextResolution);
            MultiThemeCreator.appendRuleToStylesheet(stylesheet, contextAndModeRuleGlobal, compact([
                contextRuleGlobal,
                parentContextAndModeRule,
                parentContextRule,
                modeRule,
                rootRule,
                parentModeRule,
                parentRule,
            ]));
        });
        return stylesheet;
    };
    MultiThemeCreator.prototype.findRule = function (stylesheet, config) {
        var rule = stylesheet.findRule(this.ruleCreator.selectorFor(config));
        if (!rule) {
            // Rules are creating in reverse order to dependency, which is why
            // we should always have a rule.
            throw new Error("No rule for selector ".concat(JSON.stringify(config), " found"));
        }
        return rule;
    };
    MultiThemeCreator.prototype.getThemesWithout = function (theme) {
        var idx = this.themes.indexOf(theme);
        return __spreadArray(__spreadArray([], this.themes.slice(0, idx), true), this.themes.slice(idx + 1), true);
    };
    return MultiThemeCreator;
}(AbstractCreator));
export { MultiThemeCreator };
