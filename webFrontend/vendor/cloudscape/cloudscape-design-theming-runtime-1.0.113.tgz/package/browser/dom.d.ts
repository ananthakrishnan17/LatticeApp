/**
 * Creates a style element from CSS String and an optional nonce value and returns it. The node
 * will have an extra attribute for identification.
 * @param content CSS string
 * @param nonce optional nonce to be added to the element
 * @returns style element with content
 */
export declare function createStyleNode(content: string, nonce?: string): HTMLStyleElement;
export declare function appendStyleNode(node: HTMLStyleElement, targetDocument?: Document): void;
/**
 * Parses meta tags to find name="nonce" and returns the value
 * @param targetDocument optional target HTML document to parse meta tags from. By default current document is used.
 * @returns nonce from meta tag
 */
export declare function getNonce(targetDocument?: Document): string | undefined;
