// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/**
 * Creates a style element from CSS String and an optional nonce value and returns it. The node
 * will have an extra attribute for identification.
 * @param content CSS string
 * @param nonce optional nonce to be added to the element
 * @returns style element with content
 */
export function createStyleNode(content, nonce) {
    var node = document.createElement('style');
    if (nonce) {
        node.setAttribute('nonce', nonce);
    }
    node.appendChild(document.createTextNode(content));
    return node;
}
export function appendStyleNode(node, targetDocument) {
    if (targetDocument === void 0) { targetDocument = document; }
    targetDocument.head.appendChild(node);
}
/**
 * Parses meta tags to find name="nonce" and returns the value
 * @param targetDocument optional target HTML document to parse meta tags from. By default current document is used.
 * @returns nonce from meta tag
 */
export function getNonce(targetDocument) {
    var _a;
    if (targetDocument === void 0) { targetDocument = document; }
    var metaTag = targetDocument.querySelector('meta[name="nonce"]');
    return (_a = metaTag === null || metaTag === void 0 ? void 0 : metaTag.content) !== null && _a !== void 0 ? _a : undefined;
}
