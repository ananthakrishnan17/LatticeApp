import { ThemePreset, Override } from '../shared/theme';
export interface GenerateThemeStylesheetParams {
    override: Override;
    preset: ThemePreset;
    baseThemeId?: string;
}
export declare function generateThemeStylesheet(params: GenerateThemeStylesheetParams): string;
export interface ApplyThemeParams {
    override: Override;
    preset: ThemePreset;
    baseThemeId?: string;
    targetDocument?: Document;
}
export interface ApplyThemeResult {
    reset: () => void;
}
export declare function applyTheme(params: ApplyThemeParams): ApplyThemeResult;
export { Theme, Override, ThemePreset, Value, GlobalValue, TypedModeValueOverride, ReferenceTokens, ColorReferenceTokens, ReferencePaletteDefinition, processColorPaletteInput, } from '../shared/theme';
