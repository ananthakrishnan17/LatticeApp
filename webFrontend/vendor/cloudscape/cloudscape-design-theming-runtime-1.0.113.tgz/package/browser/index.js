// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { validateOverride } from '../shared/theme';
import { createOverrideDeclarations } from '../shared/declaration';
import { getNonce, createStyleNode, appendStyleNode } from './dom';
import { createMultiThemeCustomizer } from '../shared/declaration/customizer';
import { getContexts, getThemeFromPreset } from '../shared/theme/validate';
export function generateThemeStylesheet(params) {
    var override = params.override, preset = params.preset, baseThemeId = params.baseThemeId;
    var availableContexts = getContexts(preset);
    var validated = validateOverride(override, preset.themeable, availableContexts);
    var theme = getThemeFromPreset(preset, baseThemeId);
    return createOverrideDeclarations(theme, validated, preset.propertiesMap, createMultiThemeCustomizer(preset.theme.selector));
}
export function applyTheme(params) {
    var targetDocument = params.targetDocument;
    var content = generateThemeStylesheet(params);
    var nonce = getNonce(targetDocument);
    var styleNode = createStyleNode(content, nonce);
    appendStyleNode(styleNode, targetDocument);
    return {
        reset: function () {
            styleNode.remove();
        }
    };
}
export { processColorPaletteInput, } from '../shared/theme';
