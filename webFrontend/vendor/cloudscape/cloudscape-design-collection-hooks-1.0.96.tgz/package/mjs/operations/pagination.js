// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const DEFAULT_PAGE_SIZE = 10;
export function createPageProps(pagination, currentPageIndex, items) {
    var _a;
    if (!pagination) {
        return null;
    }
    const pageSize = (_a = pagination.pageSize) !== null && _a !== void 0 ? _a : DEFAULT_PAGE_SIZE;
    const pagesCount = Math.ceil(items.length / pageSize);
    let pageIndex = currentPageIndex !== null && currentPageIndex !== void 0 ? currentPageIndex : 1;
    if (pageIndex < 1 || (pageIndex > pagesCount && !pagination.allowPageOutOfRange) || Number.isNaN(pageIndex)) {
        pageIndex = 1;
    }
    return { pageSize, pagesCount, pageIndex };
}
