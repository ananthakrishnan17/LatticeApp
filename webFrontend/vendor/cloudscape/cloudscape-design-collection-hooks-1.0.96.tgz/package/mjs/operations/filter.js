function defaultFilteringFunction(item, filteringText, filteringFields) {
    if (filteringText.length === 0) {
        return true;
    }
    filteringFields = filteringFields || Object.keys(item);
    const lowFilteringText = filteringText.toLowerCase();
    return filteringFields.some(key => {
        const value = item[key];
        if (value && typeof value === 'object') {
            return false;
        }
        return String(value).toLowerCase().indexOf(lowFilteringText) > -1;
    });
}
export function createFilterPredicate(filtering, filteringText = '') {
    var _a;
    if (!filtering) {
        return null;
    }
    const filteringFunction = (_a = filtering.filteringFunction) !== null && _a !== void 0 ? _a : defaultFilteringFunction;
    return item => filteringFunction(item, filteringText, filtering.fields);
}
