function getSorter(sortingField) {
    if (!sortingField) {
        return null;
    }
    return (row1, row2) => {
        var _a, _b;
        // Use empty string as a default value, because it works well to compare with both strings and numbers:
        // Every number can be casted to a string, but not every string can be casted to a meaningful number,
        // sometimes it is NaN.
        const value1 = (_a = row1[sortingField]) !== null && _a !== void 0 ? _a : '';
        const value2 = (_b = row2[sortingField]) !== null && _b !== void 0 ? _b : '';
        if (typeof value1 === 'string' && typeof value2 === 'string') {
            return value1.localeCompare(value2);
        }
        // use loose comparison to handle inconsistent data types
        // eslint-disable-next-line eqeqeq
        return value1 < value2 ? -1 : value1 == value2 ? 0 : 1;
    };
}
export function createComparator(sorting, state) {
    var _a;
    if (!sorting || !state) {
        return null;
    }
    const direction = state.isDescending ? -1 : 1;
    const comparator = (_a = state.sortingColumn.sortingComparator) !== null && _a !== void 0 ? _a : getSorter(state.sortingColumn.sortingField);
    return comparator ? (a, b) => comparator(a, b) * direction : null;
}
