import { compareDates, compareTimestamps } from '../date-utils/compare-dates.js';
import { warnOnce } from '../logging.js';
const filterUsingOperator = (itemValue, { tokenValue, operator: { operator, match, tokenType }, }) => {
    // For match="date" or match="datetime" we expect the value to be a Date object.
    // The token value is expected to be an ISO date- or datetime string, example:
    // match(operator="=", token="2020-01-01", value=new Date("2020-01-01")) == true
    if (match === 'date' || match === 'datetime') {
        return matchDateValue({ tokenValue, itemValue, operator, match });
    }
    // For custom match functions there is no expectation to value or token type: the function is supposed
    // to handle everything. It is recommended to treat both the token and the value as unknowns.
    else if (typeof match === 'function') {
        return match(itemValue, tokenValue);
    }
    else if (match) {
        throw new Error('Unsupported `operator.match` type given.');
    }
    // For default matching logic we expect the value to be a primitive type or an object that matches by reference.
    // The token can be an array (tokenType="enum") or a value (tokenType="value" or tokenType=undefined), examples:
    // match(operator="=", token="A", value="A") == true
    // match(operator="=", token=["A", "B"], value="A") == true
    return matchPrimitiveValue({ tokenValue, itemValue, operator, tokenType });
};
function matchDateValue({ tokenValue, itemValue, operator, match, }) {
    const comparator = match === 'date' ? compareDates : compareTimestamps;
    const comparisonResult = comparator(itemValue, tokenValue);
    switch (operator) {
        case '<':
            return comparisonResult < 0;
        case '<=':
            return comparisonResult <= 0;
        case '>':
            return comparisonResult > 0;
        case '>=':
            return comparisonResult >= 0;
        case '=':
            return comparisonResult === 0;
        case '!=':
            return comparisonResult !== 0;
        default:
            warnOnce(`Unsupported operator "${operator}" given for match="${match}".`);
            return false;
    }
}
function matchPrimitiveValue({ tokenValue, itemValue, operator, tokenType, }) {
    if (tokenType === 'enum') {
        if (!tokenValue || !Array.isArray(tokenValue)) {
            warnOnce('The token value must be an array when tokenType=="enum".');
            return false;
        }
        switch (operator) {
            case '=':
                return tokenValue && tokenValue.includes(itemValue);
            case '!=':
                return !tokenValue || !tokenValue.includes(itemValue);
            default:
                warnOnce(`Unsupported operator "${operator}" given for tokenType=="enum".`);
                return false;
        }
    }
    switch (operator) {
        case '<':
            return itemValue < tokenValue;
        case '<=':
            return itemValue <= tokenValue;
        case '>':
            return itemValue > tokenValue;
        case '>=':
            return itemValue >= tokenValue;
        case '=':
            // eslint-disable-next-line eqeqeq
            return itemValue == tokenValue;
        case '!=':
            // eslint-disable-next-line eqeqeq
            return itemValue != tokenValue;
        case ':':
            return (itemValue + '').toLowerCase().indexOf((tokenValue + '').toLowerCase()) > -1;
        case '!:':
            return (itemValue + '').toLowerCase().indexOf((tokenValue + '').toLowerCase()) === -1;
        case '^':
            return (itemValue + '').toLowerCase().startsWith((tokenValue + '').toLowerCase());
        case '!^':
            return !(itemValue + '').toLowerCase().startsWith((tokenValue + '').toLowerCase());
        // The unsupported operators result in an exception being thrown.
        // The exception can be avoided if using the match function.
        default:
            throw new Error('Unsupported operator given.');
    }
}
function freeTextFilter(tokenValue, item, operator, filteringPropertiesMap, freeTextMatchMap) {
    const customMatch = freeTextMatchMap[operator];
    if (customMatch) {
        return customMatch(item, tokenValue);
    }
    // If the operator is not a negation, we just need one property of the object to match.
    // If the operator is a negation, we want none of the properties of the object to match.
    const isNegation = operator.startsWith('!');
    return Object.keys(filteringPropertiesMap)[isNegation ? 'every' : 'some'](propertyKey => {
        const { operators } = filteringPropertiesMap[propertyKey];
        const propertyOperator = operators[operator];
        if (!propertyOperator) {
            return isNegation;
        }
        return filterUsingOperator(item[propertyKey], { tokenValue, operator: propertyOperator });
    });
}
function filterByToken(token, item, filteringPropertiesMap, freeTextMatchMap) {
    if (token.propertyKey) {
        // token refers to a unknown property or uses an unsupported operator
        if (!(token.propertyKey in filteringPropertiesMap) ||
            !(token.operator in filteringPropertiesMap[token.propertyKey].operators)) {
            return false;
        }
        const property = filteringPropertiesMap[token.propertyKey];
        const operator = property.operators[token.operator];
        const itemValue = (operator === null || operator === void 0 ? void 0 : operator.match)
            ? item[token.propertyKey]
            : fixupFalsyValues(item[token.propertyKey]);
        return filterUsingOperator(itemValue, {
            tokenValue: token.value,
            operator: operator !== null && operator !== void 0 ? operator : { operator: token.operator },
        });
    }
    return freeTextFilter(token.value, item, token.operator, filteringPropertiesMap, freeTextMatchMap);
}
function isPropertyFilterTokenGroup(t) {
    const key = 'operation';
    return key in t;
}
function defaultFilteringFunction({ filteringProperties, freeTextFiltering, }) {
    const evaluate = makeEvaluate(filteringProperties, freeTextFiltering);
    return (item, query) => {
        var _a;
        return evaluate(item, { operation: query.operation, tokens: (_a = query.tokenGroups) !== null && _a !== void 0 ? _a : query.tokens });
    };
}
export function makeEvaluate(filteringProperties, freeTextFiltering) {
    var _a;
    const filteringPropertiesMap = filteringProperties.reduce((acc, { key, operators, defaultOperator }) => {
        const operatorMap = { [defaultOperator !== null && defaultOperator !== void 0 ? defaultOperator : '=']: { operator: defaultOperator !== null && defaultOperator !== void 0 ? defaultOperator : '=' } };
        operators === null || operators === void 0 ? void 0 : operators.forEach(op => {
            if (typeof op === 'string') {
                operatorMap[op] = { operator: op };
            }
            else {
                operatorMap[op.operator] = { operator: op.operator, match: op.match, tokenType: op.tokenType };
            }
        });
        acc[key] = { operators: operatorMap };
        return acc;
    }, {});
    const freeTextMatchMap = {};
    (_a = freeTextFiltering === null || freeTextFiltering === void 0 ? void 0 : freeTextFiltering.operators) === null || _a === void 0 ? void 0 : _a.forEach(op => {
        if (typeof op !== 'string' && op.match) {
            freeTextMatchMap[op.operator] = op.match;
        }
    });
    return function evaluate(item, tokenOrGroup) {
        if (isPropertyFilterTokenGroup(tokenOrGroup)) {
            let result = tokenOrGroup.operation === 'and' ? true : !tokenOrGroup.tokens.length;
            for (const group of tokenOrGroup.tokens) {
                result = tokenOrGroup.operation === 'and' ? result && evaluate(item, group) : result || evaluate(item, group);
            }
            return result;
        }
        else {
            return filterByToken(tokenOrGroup, item, filteringPropertiesMap, freeTextMatchMap);
        }
    };
}
export function createPropertyFilterPredicate(propertyFiltering, query = { tokens: [], operation: 'and' }) {
    var _a;
    if (!propertyFiltering) {
        return null;
    }
    const filteringFunction = (_a = propertyFiltering.filteringFunction) !== null && _a !== void 0 ? _a : defaultFilteringFunction(propertyFiltering);
    return item => filteringFunction(item, query);
}
export const fixupFalsyValues = (value) => {
    if (typeof value === 'boolean') {
        return value + '';
    }
    if (value || value === 0) {
        return value;
    }
    return '';
};
