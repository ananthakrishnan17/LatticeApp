// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export function composeFilters(...predicates) {
    return predicates.some(Boolean)
        ? item => {
            for (const predicate of predicates) {
                if (predicate && !predicate(item)) {
                    return false;
                }
            }
            return true;
        }
        : null;
}
