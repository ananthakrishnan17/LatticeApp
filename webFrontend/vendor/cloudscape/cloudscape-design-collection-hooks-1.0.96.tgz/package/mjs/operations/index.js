import { createFilterPredicate } from './filter.js';
import { createPropertyFilterPredicate } from './property-filter.js';
import { createComparator } from './sort.js';
import { createPageProps } from './pagination.js';
import { composeFilters } from './compose-filters.js';
import { getTrackableValue, SelectionTree } from '@cloudscape-design/component-toolkit/internal';
import { computeFlatItems, computeTreeItems } from './items-tree.js';
export function processItems(allItems, state, { filtering, sorting, pagination, propertyFiltering, expandableRows, selection }) {
    var _a, _b, _c, _d;
    const filterPredicate = composeFilters(createPropertyFilterPredicate(propertyFiltering, state.propertyFilteringQuery), createFilterPredicate(filtering, state.filteringText));
    const sortingComparator = createComparator(sorting, state.sortingState);
    const { items, rootItemsCount, selectableItemsCount, getItemChildren, isItemExpandable, getItemsCount } = expandableRows
        ? computeTreeItems(allItems, expandableRows, filterPredicate, sortingComparator)
        : computeFlatItems(allItems, filterPredicate, sortingComparator);
    const filteredItemsCount = filterPredicate ? rootItemsCount : undefined;
    let getSelectedItemsCount = undefined;
    let selectedItems = undefined;
    if (selection && (expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.dataGrouping) && state.groupSelection && getItemChildren) {
        const trackBy = (_a = selection === null || selection === void 0 ? void 0 : selection.trackBy) !== null && _a !== void 0 ? _a : expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.getId;
        const selectionTreeProps = { getChildren: getItemChildren, trackBy };
        const selectionTree = new SelectionTree(items, selectionTreeProps, state.groupSelection);
        selectedItems = selectionTree.getSelectedItems();
        getSelectedItemsCount = selectionTree.getSelectedItemsCount;
    }
    const expandableRowsResult = getItemChildren && {
        getItemChildren,
        isItemExpandable,
        getItemsCount,
        totalItemsCount: selectableItemsCount,
        getSelectedItemsCount,
        totalSelectedItemsCount: (_d = (_b = selectedItems === null || selectedItems === void 0 ? void 0 : selectedItems.length) !== null && _b !== void 0 ? _b : (_c = state.selectedItems) === null || _c === void 0 ? void 0 : _c.length) !== null && _d !== void 0 ? _d : 0,
    };
    const pageProps = createPageProps(pagination, state.currentPageIndex, items);
    if (pageProps) {
        return {
            items: items.slice((pageProps.pageIndex - 1) * pageProps.pageSize, pageProps.pageIndex * pageProps.pageSize),
            allPageItems: items,
            totalItemsCount: rootItemsCount,
            filteredItemsCount,
            pagesCount: pageProps === null || pageProps === void 0 ? void 0 : pageProps.pagesCount,
            actualPageIndex: pageProps === null || pageProps === void 0 ? void 0 : pageProps.pageIndex,
            selectedItems,
            expandableRows: expandableRowsResult,
        };
    }
    return {
        items: items,
        allPageItems: items,
        totalItemsCount: rootItemsCount,
        filteredItemsCount,
        pagesCount: undefined,
        actualPageIndex: undefined,
        selectedItems,
        expandableRows: expandableRowsResult,
    };
}
export const processSelectedItems = (items, selectedItems, trackBy) => {
    const selectedSet = new Set();
    selectedItems.forEach(item => selectedSet.add(getTrackableValue(trackBy, item)));
    return items.filter(item => selectedSet.has(getTrackableValue(trackBy, item)));
};
export const itemsAreEqual = (items1, items2, trackBy) => {
    if (items1.length !== items2.length) {
        return false;
    }
    const set1 = new Set();
    items1.forEach(item => set1.add(getTrackableValue(trackBy, item)));
    return items2.every(item => set1.has(getTrackableValue(trackBy, item)));
};
