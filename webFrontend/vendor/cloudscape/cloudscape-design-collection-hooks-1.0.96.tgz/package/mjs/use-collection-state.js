// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useReducer, useMemo } from 'react';
import { createActions, collectionReducer } from './utils.js';
export function useCollectionState(options, collectionRef) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
    const [state, dispatch] = useReducer(collectionReducer, {
        selectedItems: (_b = (_a = options.selection) === null || _a === void 0 ? void 0 : _a.defaultSelectedItems) !== null && _b !== void 0 ? _b : [],
        expandedItems: (_d = (_c = options.expandableRows) === null || _c === void 0 ? void 0 : _c.defaultExpandedItems) !== null && _d !== void 0 ? _d : [],
        sortingState: (_e = options.sorting) === null || _e === void 0 ? void 0 : _e.defaultState,
        currentPageIndex: (_g = (_f = options.pagination) === null || _f === void 0 ? void 0 : _f.defaultPage) !== null && _g !== void 0 ? _g : 1,
        filteringText: (_j = (_h = options.filtering) === null || _h === void 0 ? void 0 : _h.defaultFilteringText) !== null && _j !== void 0 ? _j : '',
        propertyFilteringQuery: (_l = (_k = options.propertyFiltering) === null || _k === void 0 ? void 0 : _k.defaultQuery) !== null && _l !== void 0 ? _l : { tokens: [], operation: 'and' },
        groupSelection: { inverted: false, toggledItems: (_o = (_m = options.selection) === null || _m === void 0 ? void 0 : _m.defaultSelectedItems) !== null && _o !== void 0 ? _o : [] },
    });
    const actions = useMemo(() => createActions({ dispatch, collectionRef }), [dispatch, collectionRef]);
    return [state, actions];
}
