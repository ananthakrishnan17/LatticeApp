import { fixupFalsyValues } from './operations/property-filter.js';
export function computeFilteringOptions(allItems, filteringProperties) {
    if (!filteringProperties) {
        return [];
    }
    return filteringProperties.reduce((acc, property) => {
        const cache = new Set(['']);
        const addOption = (value) => {
            if (!cache.has(value)) {
                cache.add(value);
                acc.push({ propertyKey: property.key, value });
                return true;
            }
            return false;
        };
        for (const item of allItems) {
            addOption('' + fixupFalsyValues(item[property.key]));
        }
        return acc;
    }, []);
}
export function collectionReducer(state, action) {
    const newState = Object.assign({}, state);
    switch (action.type) {
        case 'selection':
            newState.selectedItems = action.selectedItems;
            break;
        case 'group-selection':
            newState.groupSelection = action.state;
            break;
        case 'expansion':
            newState.expandedItems = action.expandedItems;
            break;
        case 'filtering':
            newState.currentPageIndex = 1;
            newState.filteringText = action.filteringText;
            break;
        case 'sorting':
            newState.currentPageIndex = 1;
            newState.sortingState = action.sortingState;
            break;
        case 'pagination':
            newState.currentPageIndex = action.pageIndex;
            break;
        case 'property-filtering':
            newState.currentPageIndex = 1;
            newState.propertyFilteringQuery = action.query;
            break;
    }
    return newState;
}
export function createActions({ dispatch, collectionRef, }) {
    return {
        setFiltering(filteringText) {
            var _a;
            dispatch({ type: 'filtering', filteringText });
            (_a = collectionRef.current) === null || _a === void 0 ? void 0 : _a.scrollToTop();
        },
        setSorting(state) {
            var _a;
            dispatch({ type: 'sorting', sortingState: state });
            (_a = collectionRef.current) === null || _a === void 0 ? void 0 : _a.scrollToTop();
        },
        setCurrentPage(pageIndex) {
            var _a;
            dispatch({ type: 'pagination', pageIndex });
            (_a = collectionRef.current) === null || _a === void 0 ? void 0 : _a.scrollToTop();
        },
        setSelectedItems(selectedItems) {
            dispatch({ type: 'selection', selectedItems });
        },
        setPropertyFiltering(query) {
            var _a;
            dispatch({ type: 'property-filtering', query });
            (_a = collectionRef.current) === null || _a === void 0 ? void 0 : _a.scrollToTop();
        },
        setExpandedItems(expandedItems) {
            dispatch({ type: 'expansion', expandedItems });
        },
        setGroupSelection(groupSelection) {
            dispatch({ type: 'group-selection', state: groupSelection });
        },
    };
}
export function createSyncProps(options, { filteringText, sortingState, selectedItems, expandedItems, currentPageIndex, propertyFilteringQuery, groupSelection, }, actions, collectionRef, { pagesCount, actualPageIndex, allItems, totalItemsCount, expandableRows, filteringOptions, }) {
    var _a, _b, _c, _d, _e;
    let empty = options.filtering
        ? allItems.length
            ? options.filtering.noMatch
            : options.filtering.empty
        : null;
    empty = options.propertyFiltering
        ? allItems.length
            ? options.propertyFiltering.noMatch
            : options.propertyFiltering.empty
        : empty;
    return {
        collectionProps: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({ empty }, (options.sorting
            ? {
                onSortingChange: ({ detail }) => {
                    actions.setSorting(detail);
                },
                sortingColumn: sortingState === null || sortingState === void 0 ? void 0 : sortingState.sortingColumn,
                sortingDescending: sortingState === null || sortingState === void 0 ? void 0 : sortingState.isDescending,
            }
            : {})), (options.expandableRows && expandableRows
            ? {
                expandableRows: Object.assign(Object.assign({}, expandableRows), { expandedItems, onExpandableItemToggle: ({ detail: { item, expanded } }) => {
                        const getId = options.expandableRows.getId;
                        if (expanded) {
                            for (const stateItem of expandedItems) {
                                if (getId(stateItem) === getId(item)) {
                                    return;
                                }
                            }
                            actions.setExpandedItems([...expandedItems, item]);
                        }
                        else {
                            actions.setExpandedItems(expandedItems.filter(stateItem => getId(stateItem) !== getId(item)));
                        }
                    }, 
                    // The table component uses group selection when expandableRows.groupSelection is defined. Therefore,
                    // we only pass this property when selection and dataGrouping are configured in use-collection options.
                    groupSelection: options.selection && options.expandableRows.dataGrouping ? groupSelection : undefined, onGroupSelectionChange: ({ detail }) => actions.setGroupSelection(detail.groupSelection) }),
                // The trackBy property is used to match expanded items by ID and not by object reference.
                // The property can be overridden by the explicitly provided selection.trackBy.
                // If that is the case, we assume both selection.trackBy and expandableRows.getId have the same result.
                // If not, the expandable state won't be matched correctly by the table.
                trackBy: options.expandableRows.getId,
            }
            : {})), (options.selection
            ? {
                onSelectionChange: ({ detail: { selectedItems } }) => {
                    actions.setSelectedItems(selectedItems);
                },
                selectedItems,
                trackBy: (_a = options.selection.trackBy) !== null && _a !== void 0 ? _a : (_b = options.expandableRows) === null || _b === void 0 ? void 0 : _b.getId,
            }
            : {})), { ref: collectionRef, firstIndex: 1, totalItemsCount }), (((_c = options.pagination) === null || _c === void 0 ? void 0 : _c.pageSize)
            ? {
                firstIndex: ((actualPageIndex !== null && actualPageIndex !== void 0 ? actualPageIndex : currentPageIndex) - 1) * options.pagination.pageSize + 1,
            }
            : {})),
        filterProps: {
            filteringText,
            onChange: ({ detail: { filteringText } }) => {
                actions.setFiltering(filteringText);
            },
        },
        propertyFilterProps: {
            query: propertyFilteringQuery,
            onChange: ({ detail: query }) => {
                actions.setPropertyFiltering(query);
            },
            filteringProperties: ((_d = options.propertyFiltering) === null || _d === void 0 ? void 0 : _d.filteringProperties) || [],
            filteringOptions,
            freeTextFiltering: (_e = options.propertyFiltering) === null || _e === void 0 ? void 0 : _e.freeTextFiltering,
        },
        paginationProps: {
            currentPageIndex: actualPageIndex !== null && actualPageIndex !== void 0 ? actualPageIndex : currentPageIndex,
            // pagesCount is always calculated when options.pagination is present
            pagesCount: pagesCount,
            onChange: ({ detail: { currentPageIndex } }) => {
                actions.setCurrentPage(currentPageIndex);
            },
        },
    };
}
