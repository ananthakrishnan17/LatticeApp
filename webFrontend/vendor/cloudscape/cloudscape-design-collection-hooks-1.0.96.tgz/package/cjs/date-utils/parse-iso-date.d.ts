export declare function parseIsoDate(isoDate: string): Date;
