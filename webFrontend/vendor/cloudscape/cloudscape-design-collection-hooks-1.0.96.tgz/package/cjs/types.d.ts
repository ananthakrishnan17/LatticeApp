/**
 * subset of node.js types, safe to use in browser and bundlers
 * we do not use `lib.dom` types because they are not available in SSR environment
 */
declare global {
    const process: {
        env: {
            NODE_ENV?: string;
        };
    };
    const console: {
        warn: (...args: Array<any>) => void;
    };
    type AbortSignal = any;
}
export {};
