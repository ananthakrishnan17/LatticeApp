import { Dispatch, Reducer } from 'react';
import { UseCollectionOptions, CollectionState, SortingState, UseCollectionResult, CollectionRef, PropertyFilterQuery, PropertyFilterProperty, PropertyFilterOption, CollectionActions, GroupSelectionState, ExpandableRowsResultBase } from './interfaces';
export declare function computeFilteringOptions<T>(allItems: readonly T[], filteringProperties: readonly PropertyFilterProperty[] | undefined): PropertyFilterOption[];
interface SelectionAction<T> {
    type: 'selection';
    selectedItems: ReadonlyArray<T>;
}
interface GroupSelectionAction<T> {
    type: 'group-selection';
    state: GroupSelectionState<T>;
}
interface ExpansionAction<T> {
    type: 'expansion';
    expandedItems: ReadonlyArray<T>;
}
interface SortingAction<T> {
    type: 'sorting';
    sortingState: SortingState<T>;
}
interface PaginationAction {
    type: 'pagination';
    pageIndex: number;
}
interface FilteringAction {
    type: 'filtering';
    filteringText: string;
}
interface PropertyFilteringAction {
    type: 'property-filtering';
    query: PropertyFilterQuery;
}
type Action<T> = SelectionAction<T> | GroupSelectionAction<T> | ExpansionAction<T> | SortingAction<T> | PaginationAction | FilteringAction | PropertyFilteringAction;
export type CollectionReducer<T> = Reducer<CollectionState<T>, Action<T>>;
export declare function collectionReducer<T>(state: CollectionState<T>, action: Action<T>): CollectionState<T>;
export declare function createActions<T>({ dispatch, collectionRef, }: {
    dispatch: Dispatch<Action<T>>;
    collectionRef: React.RefObject<CollectionRef>;
}): CollectionActions<T>;
export declare function createSyncProps<T>(options: UseCollectionOptions<T>, { filteringText, sortingState, selectedItems, expandedItems, currentPageIndex, propertyFilteringQuery, groupSelection, }: CollectionState<T>, actions: CollectionActions<T>, collectionRef: React.RefObject<CollectionRef>, { pagesCount, actualPageIndex, allItems, totalItemsCount, expandableRows, filteringOptions, }: {
    pagesCount?: number;
    actualPageIndex?: number;
    allItems: readonly T[];
    totalItemsCount: number;
    expandableRows?: ExpandableRowsResultBase<T>;
    filteringOptions: PropertyFilterOption[];
}): Pick<UseCollectionResult<T>, 'collectionProps' | 'filterProps' | 'paginationProps' | 'propertyFilterProps'>;
export {};
