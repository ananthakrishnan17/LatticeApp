import { SortingState, UseCollectionOptions } from '../interfaces';
export declare function createComparator<T>(sorting: UseCollectionOptions<T>['sorting'], state: SortingState<T> | undefined): null | ((a: T, b: T) => number);
