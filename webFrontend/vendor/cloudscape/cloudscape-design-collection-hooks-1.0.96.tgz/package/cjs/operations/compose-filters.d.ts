export type Predicate<T> = (item: T) => boolean;
export declare function composeFilters<T>(...predicates: Array<null | Predicate<T>>): null | Predicate<T>;
