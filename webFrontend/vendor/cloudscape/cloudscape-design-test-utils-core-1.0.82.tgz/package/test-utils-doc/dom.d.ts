import { TestUtilsDefinition } from './interfaces';
  declare const definitions: TestUtilsDefinition;
  export = definitions;
  