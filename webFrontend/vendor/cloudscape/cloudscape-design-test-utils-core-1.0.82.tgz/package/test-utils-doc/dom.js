module.exports = { classes: [
  {
    "name": "AbstractWrapper",
    "methods": [
      {
        "name": "blur",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": []
      },
      {
        "name": "click",
        "description": "Performs a click by triggering a mouse event.\nNote that programmatic events ignore disabled attribute and will trigger listeners even if the element is disabled.",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "params",
            "typeName": "MouseEventInit",
            "flags": {
              "isOptional": true
            }
          }
        ]
      },
      {
        "name": "find",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findAll",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper<NewElementType>"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findAllByClassName",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper<NewElementType>"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findAllComponents",
        "description": "Returns the wrappers of all components that match the specified component type and the specified CSS selector.\nIf no CSS selector is specified, returns all of the components that match the specified component type.\nIf no matching component is found, returns an empty array.",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "Wrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": true
            }
          }
        ]
      },
      {
        "name": "findAny",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "selectors",
            "typeName": "Array<string>",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findByClassName",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findClosestComponent",
        "description": "Returns the closest ancestor element (or self) that matches the specified component type.\nIf no matching component is found, returns `null`.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findComponent",
        "description": "Returns the component wrapper matching the specified selector.\nIf the specified selector doesn't match any element, it returns `null`.\n\nNote: This function returns the specified component's wrapper even if the specified selector points to a different component type.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "ComponentClass",
            "typeName": "WrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "fireEvent",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "event",
            "typeName": "Event",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "focus",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": []
      },
      {
        "name": "getElement",
        "returnType": {
          "name": "ElementType",
          "isNullable": false
        },
        "parameters": []
      },
      {
        "name": "keydown",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "keydown",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "keypress",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "keypress",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "keyup",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "keyup",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "matches",
        "returnType": {
          "name": "this",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      }
    ]
  },
  {
    "name": "ElementWrapper",
    "methods": [
      {
        "name": "blur",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.blur"
        }
      },
      {
        "name": "click",
        "description": "Performs a click by triggering a mouse event.\nNote that programmatic events ignore disabled attribute and will trigger listeners even if the element is disabled.",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "params",
            "typeName": "MouseEventInit",
            "flags": {
              "isOptional": true
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.click"
        }
      },
      {
        "name": "find",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.find"
        }
      },
      {
        "name": "findAll",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper<NewElementType>"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAll"
        }
      },
      {
        "name": "findAllByClassName",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper<NewElementType>"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllByClassName"
        }
      },
      {
        "name": "findAllComponents",
        "description": "Returns the wrappers of all components that match the specified component type and the specified CSS selector.\nIf no CSS selector is specified, returns all of the components that match the specified component type.\nIf no matching component is found, returns an empty array.",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "Wrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": true
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllComponents"
        }
      },
      {
        "name": "findAny",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "selectors",
            "typeName": "Array<string>",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAny"
        }
      },
      {
        "name": "findByClassName",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findByClassName"
        }
      },
      {
        "name": "findClosestComponent",
        "description": "Returns the closest ancestor element (or self) that matches the specified component type.\nIf no matching component is found, returns `null`.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findClosestComponent"
        }
      },
      {
        "name": "findComponent",
        "description": "Returns the component wrapper matching the specified selector.\nIf the specified selector doesn't match any element, it returns `null`.\n\nNote: This function returns the specified component's wrapper even if the specified selector points to a different component type.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "ComponentClass",
            "typeName": "WrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findComponent"
        }
      },
      {
        "name": "fireEvent",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "event",
            "typeName": "Event",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.fireEvent"
        }
      },
      {
        "name": "focus",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.focus"
        }
      },
      {
        "name": "getElement",
        "returnType": {
          "name": "ElementType",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.getElement"
        }
      },
      {
        "name": "keydown",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keydown"
        }
      },
      {
        "name": "keydown",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keydown"
        }
      },
      {
        "name": "keypress",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keypress"
        }
      },
      {
        "name": "keypress",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keypress"
        }
      },
      {
        "name": "keyup",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keyup"
        }
      },
      {
        "name": "keyup",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keyup"
        }
      },
      {
        "name": "matches",
        "returnType": {
          "name": "this",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.matches"
        }
      }
    ]
  },
  {
    "name": "ComponentWrapper",
    "methods": [
      {
        "name": "blur",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.blur"
        }
      },
      {
        "name": "click",
        "description": "Performs a click by triggering a mouse event.\nNote that programmatic events ignore disabled attribute and will trigger listeners even if the element is disabled.",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "params",
            "typeName": "MouseEventInit",
            "flags": {
              "isOptional": true
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.click"
        }
      },
      {
        "name": "find",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.find"
        }
      },
      {
        "name": "findAll",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper<NewElementType>"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAll"
        }
      },
      {
        "name": "findAllByClassName",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper<NewElementType>"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllByClassName"
        }
      },
      {
        "name": "findAllComponents",
        "description": "Returns the wrappers of all components that match the specified component type and the specified CSS selector.\nIf no CSS selector is specified, returns all of the components that match the specified component type.\nIf no matching component is found, returns an empty array.",
        "returnType": {
          "name": "Array",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "Wrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": true
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllComponents"
        }
      },
      {
        "name": "findAny",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "selectors",
            "typeName": "Array<string>",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAny"
        }
      },
      {
        "name": "findByClassName",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": true,
          "typeArguments": [
            {
              "name": "NewElementType"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findByClassName"
        }
      },
      {
        "name": "findClosestComponent",
        "description": "Returns the closest ancestor element (or self) that matches the specified component type.\nIf no matching component is found, returns `null`.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findClosestComponent"
        }
      },
      {
        "name": "findComponent",
        "description": "Returns the component wrapper matching the specified selector.\nIf the specified selector doesn't match any element, it returns `null`.\n\nNote: This function returns the specified component's wrapper even if the specified selector points to a different component type.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "ComponentClass",
            "typeName": "WrapperClass<Wrapper, ElementType>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findComponent"
        }
      },
      {
        "name": "fireEvent",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "event",
            "typeName": "Event",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.fireEvent"
        }
      },
      {
        "name": "focus",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.focus"
        }
      },
      {
        "name": "getElement",
        "returnType": {
          "name": "ElementType",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.getElement"
        }
      },
      {
        "name": "keydown",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keydown"
        }
      },
      {
        "name": "keydown",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keydown"
        }
      },
      {
        "name": "keypress",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keypress"
        }
      },
      {
        "name": "keypress",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keypress"
        }
      },
      {
        "name": "keyup",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyCode",
            "typeName": "KeyCode",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keyup"
        }
      },
      {
        "name": "keyup",
        "returnType": {
          "name": "void",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "keyboardEventProps",
            "typeName": "KeyboardEventInit",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.keyup"
        }
      },
      {
        "name": "matches",
        "returnType": {
          "name": "this",
          "isNullable": true
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.matches"
        }
      }
    ]
  }
] };