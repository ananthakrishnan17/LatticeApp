module.exports = { classes: [
  {
    "name": "AbstractWrapper",
    "methods": [
      {
        "name": "find",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findAll",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findAllByClassName",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findAllComponents",
        "description": "Returns a multi-element wrapper that matches the specified component type with the specified CSS selector.\nIf no CSS selector is specified, returns a multi-element wrapper that matches the specified component type.",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "Wrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper>",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS Selector",
            "flags": {
              "isOptional": true
            }
          }
        ]
      },
      {
        "name": "findAny",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selectors",
            "typeName": "Array<string>",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findByClassName",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "findComponent",
        "description": "Returns a wrapper that matches the specified component type with the specified CSS selector.\n\nNote: This function returns the specified component's wrapper even if the specified selector points to a different component type.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "ComponentClass",
            "typeName": "WrapperClass<Wrapper>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "getElement",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": []
      },
      {
        "name": "matches",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "toSelector",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": []
      }
    ]
  },
  {
    "name": "ElementWrapper",
    "methods": [
      {
        "name": "find",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.find"
        }
      },
      {
        "name": "findAll",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAll"
        }
      },
      {
        "name": "findAllByClassName",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllByClassName"
        }
      },
      {
        "name": "findAllComponents",
        "description": "Returns a multi-element wrapper that matches the specified component type with the specified CSS selector.\nIf no CSS selector is specified, returns a multi-element wrapper that matches the specified component type.",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "Wrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper>",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS Selector",
            "flags": {
              "isOptional": true
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllComponents"
        }
      },
      {
        "name": "findAny",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selectors",
            "typeName": "Array<string>",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAny"
        }
      },
      {
        "name": "findByClassName",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findByClassName"
        }
      },
      {
        "name": "findComponent",
        "description": "Returns a wrapper that matches the specified component type with the specified CSS selector.\n\nNote: This function returns the specified component's wrapper even if the specified selector points to a different component type.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "ComponentClass",
            "typeName": "WrapperClass<Wrapper>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findComponent"
        }
      },
      {
        "name": "getElement",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.getElement"
        }
      },
      {
        "name": "matches",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.matches"
        }
      },
      {
        "name": "toSelector",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.toSelector"
        }
      }
    ]
  },
  {
    "name": "ComponentWrapper",
    "methods": [
      {
        "name": "find",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.find"
        }
      },
      {
        "name": "findAll",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAll"
        }
      },
      {
        "name": "findAllByClassName",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllByClassName"
        }
      },
      {
        "name": "findAllComponents",
        "description": "Returns a multi-element wrapper that matches the specified component type with the specified CSS selector.\nIf no CSS selector is specified, returns a multi-element wrapper that matches the specified component type.",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "Wrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper>",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS Selector",
            "flags": {
              "isOptional": true
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllComponents"
        }
      },
      {
        "name": "findAny",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selectors",
            "typeName": "Array<string>",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAny"
        }
      },
      {
        "name": "findByClassName",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findByClassName"
        }
      },
      {
        "name": "findComponent",
        "description": "Returns a wrapper that matches the specified component type with the specified CSS selector.\n\nNote: This function returns the specified component's wrapper even if the specified selector points to a different component type.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "ComponentClass",
            "typeName": "WrapperClass<Wrapper>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findComponent"
        }
      },
      {
        "name": "getElement",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.getElement"
        }
      },
      {
        "name": "matches",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.matches"
        }
      },
      {
        "name": "toSelector",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.toSelector"
        }
      }
    ]
  },
  {
    "name": "MultiElementWrapper",
    "methods": [
      {
        "name": "find",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.find"
        }
      },
      {
        "name": "findAll",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAll"
        }
      },
      {
        "name": "findAllByClassName",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "ElementWrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllByClassName"
        }
      },
      {
        "name": "findAllComponents",
        "description": "Returns a multi-element wrapper that matches the specified component type with the specified CSS selector.\nIf no CSS selector is specified, returns a multi-element wrapper that matches the specified component type.",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "Wrapper"
            }
          ]
        },
        "parameters": [
          {
            "name": "ComponentClass",
            "typeName": "ComponentWrapperClass<Wrapper>",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS Selector",
            "flags": {
              "isOptional": true
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAllComponents"
        }
      },
      {
        "name": "findAny",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selectors",
            "typeName": "Array<string>",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findAny"
        }
      },
      {
        "name": "findByClassName",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "className",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findByClassName"
        }
      },
      {
        "name": "findComponent",
        "description": "Returns a wrapper that matches the specified component type with the specified CSS selector.\n\nNote: This function returns the specified component's wrapper even if the specified selector points to a different component type.",
        "returnType": {
          "name": "Wrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "description": "CSS selector",
            "flags": {
              "isOptional": false
            }
          },
          {
            "name": "ComponentClass",
            "typeName": "WrapperClass<Wrapper>",
            "description": "Component's wrapper class",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.findComponent"
        }
      },
      {
        "name": "get",
        "description": "Index is one-based because the method uses the :nth-child() CSS pseudo-class.",
        "returnType": {
          "name": "T",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "index",
            "typeName": "number",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "getElement",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.getElement"
        }
      },
      {
        "name": "map",
        "returnType": {
          "name": "MultiElementWrapper",
          "isNullable": false,
          "typeArguments": [
            {
              "name": "T"
            }
          ]
        },
        "parameters": [
          {
            "name": "factory",
            "typeName": "(wrapper: ElementWrapper) => T",
            "flags": {
              "isOptional": false
            }
          }
        ]
      },
      {
        "name": "matches",
        "returnType": {
          "name": "ElementWrapper",
          "isNullable": false
        },
        "parameters": [
          {
            "name": "selector",
            "typeName": "string",
            "flags": {
              "isOptional": false
            }
          }
        ],
        "inheritedFrom": {
          "name": "AbstractWrapper.matches"
        }
      },
      {
        "name": "toSelector",
        "returnType": {
          "name": "string",
          "isNullable": false
        },
        "parameters": [],
        "inheritedFrom": {
          "name": "AbstractWrapper.toSelector"
        }
      }
    ]
  }
] };