// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalSegmentedControl from './internal';
export default function SegmentedControl(props) {
    var _a;
    const baseComponentProps = useBaseComponent('SegmentedControl', {
        props: {},
        metadata: {
            hasDisabledReasons: ((_a = props.options) !== null && _a !== void 0 ? _a : []).some(option => Boolean(option.disabledReason)),
        },
    });
    return React.createElement(InternalSegmentedControl, { ...props, ...baseComponentProps });
}
applyDisplayName(SegmentedControl, 'SegmentedControl');
//# sourceMappingURL=index.js.map