// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import { createWidgetizedComponent } from '../internal/widgets';
import CollapsibleFlashbar from './collapsible-flashbar';
import NonCollapsibleFlashbar from './non-collapsible-flashbar';
export function FlashbarImplementation(props) {
    if (props.stackItems) {
        return React.createElement(CollapsibleFlashbar, { ...props });
    }
    else {
        return React.createElement(NonCollapsibleFlashbar, { ...props });
    }
}
export const createWidgetizedFlashbar = createWidgetizedComponent(FlashbarImplementation);
//# sourceMappingURL=implementation.js.map