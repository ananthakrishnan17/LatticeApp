// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { InternalFlashbar } from './internal';
export default function Flashbar(props) {
    const { __internalRootRef } = useBaseComponent('Flashbar', {
        props: { stackItems: props.stackItems },
    });
    return React.createElement(InternalFlashbar, { __internalRootRef: __internalRootRef, ...props });
}
applyDisplayName(Flashbar, 'Flashbar');
//# sourceMappingURL=index.js.map