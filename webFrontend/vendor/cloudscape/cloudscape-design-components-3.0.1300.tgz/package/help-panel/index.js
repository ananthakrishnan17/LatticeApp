// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { InternalHelpPanel } from './internal';
export default function HelpPanel(props) {
    const internalProps = useBaseComponent('HelpPanel');
    return React.createElement(InternalHelpPanel, { ...props, ...internalProps });
}
applyDisplayName(HelpPanel, 'HelpPanel');
//# sourceMappingURL=index.js.map