// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import { useAppLayoutToolbarDesignEnabled } from '../app-layout/utils/feature-flags';
import { useInternalI18n } from '../i18n/context';
import { getBaseProps } from '../internal/base-component';
import { LinkDefaultVariantContext } from '../internal/context/link-default-variant-context';
import { createWidgetizedComponent } from '../internal/widgets';
import InternalLiveRegion from '../live-region/internal';
import InternalStatusIndicator from '../status-indicator/internal';
import styles from './styles.css.js';
export function HelpPanelImplementation({ header, footer, children, loading, loadingText, __internalRootRef, ...restProps }) {
    const baseProps = getBaseProps(restProps);
    const isToolbar = useAppLayoutToolbarDesignEnabled();
    const i18n = useInternalI18n('help-panel');
    const containerProps = {
        ...baseProps,
        className: clsx(baseProps.className, styles['help-panel'], isToolbar && styles['with-toolbar'], loading && styles.loading),
    };
    return loading ? (React.createElement("div", { ...containerProps, ref: __internalRootRef },
        React.createElement(InternalStatusIndicator, { type: "loading" },
            React.createElement(InternalLiveRegion, { tagName: "span" }, i18n('loadingText', loadingText))))) : (React.createElement("div", { ...containerProps, ref: __internalRootRef },
        header && React.createElement("div", { className: clsx(styles.header) }, header),
        React.createElement(LinkDefaultVariantContext.Provider, { value: { defaultVariant: 'primary' } },
            React.createElement("div", { className: styles.content }, children)),
        footer && (React.createElement("div", { className: styles.footer },
            React.createElement("hr", { role: "presentation" }),
            footer))));
}
export const createWidgetizedHelpPanel = createWidgetizedComponent(HelpPanelImplementation);
//# sourceMappingURL=implementation.js.map