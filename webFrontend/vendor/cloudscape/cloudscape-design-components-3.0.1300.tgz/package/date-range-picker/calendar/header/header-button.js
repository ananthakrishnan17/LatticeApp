// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import { InternalButton } from '../../../button/internal';
import testutilStyles from '../../test-classes/styles.css.js';
export function PrevPageButton({ ariaLabel, onChangePage }) {
    return (React.createElement(InternalButton, { iconName: "angle-left", ariaLabel: ariaLabel, variant: 'icon', onClick: () => onChangePage(-1), formAction: "none", className: clsx(testutilStyles[`calendar-prev-page-btn`], testutilStyles[`calendar-prev-month-btn`]) }));
}
export function NextPageButton({ ariaLabel, onChangePage }) {
    return (React.createElement(InternalButton, { iconName: "angle-right", ariaLabel: ariaLabel, variant: 'icon', onClick: () => onChangePage(1), formAction: "none", className: clsx(testutilStyles[`calendar-next-page-btn`], testutilStyles[`calendar-next-month-btn`]) }));
}
//# sourceMappingURL=header-button.js.map