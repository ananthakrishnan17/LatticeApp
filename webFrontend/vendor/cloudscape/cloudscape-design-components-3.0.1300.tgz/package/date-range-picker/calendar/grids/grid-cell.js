// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { forwardRef, useRef, useState } from 'react';
import { useMergeRefs } from '@cloudscape-design/component-toolkit/internal';
import useHiddenDescription from '../../../internal/hooks/use-hidden-description';
import { applyDisplayName } from '../../../internal/utils/apply-display-name';
import Tooltip from '../../../tooltip/internal.js';
import testutilStyles from '../../test-classes/styles.css.js';
export const GridCell = forwardRef((props, focusedDateRef) => {
    const { disabledReason, referrerId, ...rest } = props;
    const isDisabledWithReason = !!disabledReason;
    const { targetProps, descriptionEl } = useHiddenDescription(disabledReason);
    const ref = useRef(null);
    const [showTooltip, setShowTooltip] = useState(false);
    return (React.createElement("td", { ref: useMergeRefs(focusedDateRef, ref), ...rest, ...(isDisabledWithReason ? targetProps : {}), onFocus: event => {
            if (rest.onFocus) {
                rest.onFocus(event);
            }
            if (isDisabledWithReason) {
                setShowTooltip(true);
            }
        }, onBlur: event => {
            if (rest.onBlur) {
                rest.onBlur(event);
            }
            if (isDisabledWithReason) {
                setShowTooltip(false);
            }
        }, onMouseEnter: event => {
            if (rest.onMouseEnter) {
                rest.onMouseEnter(event);
            }
            if (isDisabledWithReason) {
                setShowTooltip(true);
            }
        }, onMouseLeave: event => {
            if (rest.onMouseLeave) {
                rest.onMouseLeave(event);
            }
            if (isDisabledWithReason) {
                setShowTooltip(false);
            }
        } },
        props.children,
        isDisabledWithReason && (React.createElement(React.Fragment, null,
            descriptionEl,
            showTooltip && (React.createElement(Tooltip, { className: testutilStyles['disabled-reason-tooltip'], getTrack: () => ref.current, content: disabledReason, onEscape: () => setShowTooltip(false), referrerId: referrerId }))))));
});
applyDisplayName(GridCell, 'GridCell');
//# sourceMappingURL=grid-cell.js.map