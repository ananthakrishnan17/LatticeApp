// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import styles from './styles.css.js';
export const Notifications = React.forwardRef(({ sticky, disableContentPaddings, ...props }, ref) => {
    var _a, _b;
    return sticky ? (React.createElement("div", { ref: ref, className: styles['notifications-sticky'], style: { top: props.topOffset } },
        React.createElement("div", { role: "region", className: clsx(props.testUtilsClassName, disableContentPaddings && styles['no-content-paddings']), "aria-label": (_a = props.labels) === null || _a === void 0 ? void 0 : _a.notifications }, props.children))) : (React.createElement("div", { role: "region", ref: ref, className: clsx(props.testUtilsClassName, styles.notifications, disableContentPaddings && styles['no-content-paddings']), "aria-label": (_b = props.labels) === null || _b === void 0 ? void 0 : _b.notifications }, props.children));
});
//# sourceMappingURL=index.js.map