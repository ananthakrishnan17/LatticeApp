// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useRef } from 'react';
import clsx from 'clsx';
import { useContainerQuery } from '@cloudscape-design/component-toolkit';
import { AppLayoutBuiltInErrorBoundary } from '../../../error-boundary/internal';
import { useMobile } from '../../../internal/hooks/use-mobile';
import { splitItems } from '../../drawer/drawers-helpers';
import OverflowMenu from '../../drawer/overflow-menu';
import { TOOLS_DRAWER_ID } from '../../utils/use-drawers';
import TriggerButton from './trigger-button';
import splitPanelTestUtilStyles from '../../../split-panel/test-classes/styles.css.js';
import testutilStyles from '../../test-classes/styles.css.js';
import styles from './styles.css.js';
export function DrawerTriggers({ ariaLabels, activeDrawerId, drawers, drawersFocusRef, onActiveDrawerChange, splitPanelOpen, splitPanelPosition = 'bottom', splitPanelFocusRef, splitPanelToggleProps, onSplitPanelToggle, disabled, activeGlobalDrawersIds, globalDrawers, globalDrawersFocusControl, onActiveGlobalDrawersChange, expandedDrawerId, setExpandedDrawerId, activeGlobalBottomDrawerId, onActiveGlobalBottomDrawerChange, bottomDrawersFocusRef, bottomDrawers, featureNotificationsProps, }) {
    var _a;
    const isMobile = useMobile();
    const hasMultipleTriggers = drawers.length > 1;
    const previousActiveLocalDrawerId = useRef(activeDrawerId);
    const previousActiveGlobalBottomDrawerId = useRef(activeGlobalBottomDrawerId);
    const previousActiveGlobalDrawersIds = useRef(activeGlobalDrawersIds);
    const [containerWidth, triggersContainerRef] = useContainerQuery(rect => rect.contentBoxWidth);
    const featureNotificationTriggerRef = useRef(null);
    if (!drawers.length && !globalDrawers.length && !(bottomDrawers === null || bottomDrawers === void 0 ? void 0 : bottomDrawers.length) && !splitPanelToggleProps) {
        return null;
    }
    if (activeDrawerId) {
        previousActiveLocalDrawerId.current = activeDrawerId;
    }
    if (activeGlobalDrawersIds.length) {
        previousActiveGlobalDrawersIds.current = activeGlobalDrawersIds;
    }
    if (activeGlobalBottomDrawerId) {
        previousActiveGlobalBottomDrawerId.current = activeGlobalBottomDrawerId;
    }
    const getIndexOfOverflowItem = () => {
        if (isMobile) {
            return 2;
        }
        if (containerWidth) {
            const ITEM_WIDTH = 50; // Roughly 34px + padding = 42px but added extra for safety
            const overflowSpot = containerWidth;
            const index = Math.floor(overflowSpot / ITEM_WIDTH);
            let splitPanelItem = 0;
            if (splitPanelToggleProps) {
                splitPanelItem = 1;
            }
            return index - splitPanelItem;
        }
        return 0;
    };
    const indexOfOverflowItem = getIndexOfOverflowItem();
    const { visibleItems, overflowItems } = splitItems([...drawers, ...globalDrawers, ...(bottomDrawers || [])], indexOfOverflowItem, activeDrawerId !== null && activeDrawerId !== void 0 ? activeDrawerId : null);
    const overflowMenuHasBadge = !!overflowItems.find(item => item.badge);
    const toolsOnlyMode = drawers.length === 1 && drawers[0].id === TOOLS_DRAWER_ID;
    const globalDrawersStartIndex = drawers.length;
    const hasOpenDrawer = !!activeDrawerId || (splitPanelPosition === 'side' && splitPanelOpen);
    const splitPanelResolvedPosition = splitPanelToggleProps === null || splitPanelToggleProps === void 0 ? void 0 : splitPanelToggleProps.position;
    const exitExpandedMode = () => {
        if (setExpandedDrawerId) {
            setExpandedDrawerId(null);
        }
    };
    return (React.createElement("aside", { className: styles[`drawers-${isMobile ? 'mobile' : 'desktop'}-triggers-container`], "aria-label": ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.drawers, ref: triggersContainerRef, role: "region" }, (_a = featureNotificationsProps === null || featureNotificationsProps === void 0 ? void 0 : featureNotificationsProps.renderLatestFeaturePrompt) === null || _a === void 0 ? void 0 :
        _a.call(featureNotificationsProps, { triggerRef: featureNotificationTriggerRef }),
        React.createElement("div", { className: styles['drawers-trigger-content'], "aria-label": ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.drawers, role: "toolbar", "aria-orientation": "horizontal" },
            splitPanelToggleProps && (React.createElement(React.Fragment, null,
                React.createElement(TriggerButton, { ariaLabel: splitPanelToggleProps.ariaLabel, ariaControls: splitPanelToggleProps.controlId, ariaExpanded: !expandedDrawerId && splitPanelToggleProps.active, className: clsx(styles['drawers-trigger'], testutilStyles['drawers-trigger'], splitPanelTestUtilStyles['open-button']), iconName: splitPanelResolvedPosition === 'side' ? 'view-vertical' : 'view-horizontal', onClick: () => {
                        exitExpandedMode();
                        if (!!expandedDrawerId && splitPanelToggleProps.active) {
                            return;
                        }
                        onSplitPanelToggle === null || onSplitPanelToggle === void 0 ? void 0 : onSplitPanelToggle();
                    }, selected: !expandedDrawerId && splitPanelToggleProps.active, ref: splitPanelResolvedPosition === 'side' ? splitPanelFocusRef : undefined, hasTooltip: true, isMobile: isMobile, isForSplitPanel: true, disabled: disabled }),
                hasMultipleTriggers ? React.createElement("div", { className: styles['group-divider'] }) : null)),
            visibleItems.slice(0, globalDrawersStartIndex).map(item => {
                var _a, _b, _c;
                const isForPreviousActiveDrawer = (previousActiveLocalDrawerId === null || previousActiveLocalDrawerId === void 0 ? void 0 : previousActiveLocalDrawerId.current) === item.id;
                const selected = !expandedDrawerId && item.id === activeDrawerId;
                const isFeatureNotificationsDrawer = ((_a = featureNotificationsProps === null || featureNotificationsProps === void 0 ? void 0 : featureNotificationsProps.drawer) === null || _a === void 0 ? void 0 : _a.id) === item.id;
                return (React.createElement(AppLayoutBuiltInErrorBoundary, { key: item.id },
                    React.createElement(TriggerButton, { ariaLabel: (_b = item.ariaLabels) === null || _b === void 0 ? void 0 : _b.triggerButton, ariaExpanded: selected, ariaControls: activeDrawerId === item.id ? item.id : undefined, className: clsx(styles['drawers-trigger'], !toolsOnlyMode && testutilStyles['drawers-trigger'], item.id === TOOLS_DRAWER_ID && testutilStyles['tools-toggle']), iconName: item.trigger.iconName, iconSvg: item.trigger.iconSvg, key: item.id, onClick: () => {
                            exitExpandedMode();
                            if (!!expandedDrawerId && activeDrawerId === item.id) {
                                return;
                            }
                            onActiveDrawerChange === null || onActiveDrawerChange === void 0 ? void 0 : onActiveDrawerChange(activeDrawerId !== item.id ? item.id : null, { initiatedByUserAction: true });
                        }, ref: item.id === previousActiveLocalDrawerId.current
                            ? drawersFocusRef
                            : isFeatureNotificationsDrawer
                                ? featureNotificationTriggerRef
                                : null, selected: selected, badge: item.badge, testId: `awsui-app-layout-trigger-${item.id}`, hasTooltip: true, hasOpenDrawer: hasOpenDrawer, tooltipText: (_c = item.ariaLabels) === null || _c === void 0 ? void 0 : _c.drawerName, isForPreviousActiveDrawer: isForPreviousActiveDrawer, isMobile: isMobile, disabled: disabled })));
            }),
            globalDrawersStartIndex > 0 && visibleItems.length > globalDrawersStartIndex && (React.createElement("div", { className: styles['group-divider'] })),
            visibleItems.slice(globalDrawersStartIndex).map(item => {
                var _a, _b, _c;
                let isForPreviousActiveDrawer = previousActiveGlobalDrawersIds === null || previousActiveGlobalDrawersIds === void 0 ? void 0 : previousActiveGlobalDrawersIds.current.includes(item.id);
                const isBottom = item.position === 'bottom';
                let selected = activeGlobalDrawersIds.includes(item.id) && (!expandedDrawerId || item.id === expandedDrawerId);
                if (isBottom) {
                    selected = item.id === activeGlobalBottomDrawerId && (!expandedDrawerId || item.id === expandedDrawerId);
                    isForPreviousActiveDrawer = previousActiveGlobalBottomDrawerId.current === item.id;
                }
                return (React.createElement(AppLayoutBuiltInErrorBoundary, { key: item.id },
                    React.createElement(TriggerButton, { ariaLabel: (_a = item.ariaLabels) === null || _a === void 0 ? void 0 : _a.triggerButton, ariaExpanded: selected, ariaControls: selected ? item.id : undefined, className: clsx(styles['drawers-trigger'], testutilStyles['drawers-trigger'], testutilStyles['drawers-trigger-global']), iconName: item.trigger.iconName, iconSvg: item.trigger.iconSvg, key: item.id, onClick: () => {
                            exitExpandedMode();
                            if (!!expandedDrawerId && item.id !== expandedDrawerId && activeGlobalDrawersIds.includes(item.id)) {
                                return;
                            }
                            if (isBottom) {
                                onActiveGlobalBottomDrawerChange === null || onActiveGlobalBottomDrawerChange === void 0 ? void 0 : onActiveGlobalBottomDrawerChange(selected ? null : item.id, { initiatedByUserAction: true });
                                return;
                            }
                            onActiveGlobalDrawersChange === null || onActiveGlobalDrawersChange === void 0 ? void 0 : onActiveGlobalDrawersChange(item.id, { initiatedByUserAction: true });
                        }, ref: isBottom ? bottomDrawersFocusRef : (_b = globalDrawersFocusControl === null || globalDrawersFocusControl === void 0 ? void 0 : globalDrawersFocusControl.refs[item.id]) === null || _b === void 0 ? void 0 : _b.toggle, selected: selected, badge: item.badge, testId: `awsui-app-layout-trigger-${item.id}`, hasTooltip: true, hasOpenDrawer: hasOpenDrawer, tooltipText: (_c = item.ariaLabels) === null || _c === void 0 ? void 0 : _c.drawerName, isForPreviousActiveDrawer: isForPreviousActiveDrawer, isMobile: isMobile, disabled: disabled })));
            }),
            overflowItems.length > 0 && (React.createElement(AppLayoutBuiltInErrorBoundary, null,
                React.createElement(OverflowMenu, { items: overflowItems.map(item => {
                        const isBottom = (item === null || item === void 0 ? void 0 : item.position) === 'bottom';
                        let active = activeGlobalDrawersIds.includes(item.id) && (!expandedDrawerId || item.id === expandedDrawerId);
                        if (isBottom) {
                            active =
                                item.id === activeGlobalBottomDrawerId && (!expandedDrawerId || item.id === expandedDrawerId);
                        }
                        return {
                            ...item,
                            active,
                        };
                    }), ariaLabel: overflowMenuHasBadge ? ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.drawersOverflowWithBadge : ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.drawersOverflow, customTriggerBuilder: ({ onClick, triggerRef, ariaLabel, ariaExpanded, testUtilsClass }) => {
                        return (React.createElement(TriggerButton, { ref: triggerRef, ariaLabel: ariaLabel, ariaExpanded: ariaExpanded, badge: overflowMenuHasBadge, className: clsx(styles['drawers-trigger'], testutilStyles['drawers-trigger'], testutilStyles['drawers-trigger-global'], testUtilsClass), iconName: "ellipsis", onClick: onClick, disabled: disabled }));
                    }, onItemClick: event => {
                        const id = event.detail.id;
                        exitExpandedMode();
                        const item = overflowItems.find(item => item.id === id);
                        const isBottom = (item === null || item === void 0 ? void 0 : item.position) === 'bottom';
                        if (isBottom) {
                            const selected = item.id === activeGlobalBottomDrawerId && (!expandedDrawerId || item.id === expandedDrawerId);
                            onActiveGlobalBottomDrawerChange === null || onActiveGlobalBottomDrawerChange === void 0 ? void 0 : onActiveGlobalBottomDrawerChange(selected ? null : item.id, { initiatedByUserAction: true });
                            return;
                        }
                        if (globalDrawers.find(drawer => drawer.id === id)) {
                            if (!!expandedDrawerId && id !== expandedDrawerId && activeGlobalDrawersIds.includes(id)) {
                                return;
                            }
                            onActiveGlobalDrawersChange === null || onActiveGlobalDrawersChange === void 0 ? void 0 : onActiveGlobalDrawersChange(id, { initiatedByUserAction: true });
                        }
                        else {
                            onActiveDrawerChange === null || onActiveDrawerChange === void 0 ? void 0 : onActiveDrawerChange(event.detail.id, { initiatedByUserAction: true });
                        }
                    }, globalDrawersStartIndex: globalDrawersStartIndex - indexOfOverflowItem }))))));
}
//# sourceMappingURL=drawer-triggers.js.map