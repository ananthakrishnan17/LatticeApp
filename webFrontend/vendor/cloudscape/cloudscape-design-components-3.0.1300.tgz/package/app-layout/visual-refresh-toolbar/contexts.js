// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import { awsuiPluginsInternal } from '../../internal/plugins/api';
export const BreadcrumbsSlotContext = awsuiPluginsInternal.sharedReactContexts.createContext(React, 'BreadcrumbsSlotContext');
export const AppLayoutVisibilityContext = awsuiPluginsInternal.sharedReactContexts.createContext(React, 'AppLayoutVisibilityContext');
export const AppLayoutToolbarPublicContext = awsuiPluginsInternal.sharedReactContexts.createContext(React, 'AppLayoutToolbarPublicContext');
//# sourceMappingURL=contexts.js.map