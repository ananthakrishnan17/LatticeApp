// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useLayoutEffect, useState } from 'react';
import { AppLayoutBuiltInErrorBoundary } from '../../../error-boundary/internal';
import { createWidgetizedComponent } from '../../../internal/widgets';
import { getPropsToMerge, mergeProps } from './props-merger';
import { useAppLayout } from './use-app-layout';
import { useSkeletonSlotsAttributes } from './use-skeleton-slots-attributes';
export const AppLayoutStateProviderInternal = ({ appLayoutProps, stateManager, forwardRef }) => {
    var _a;
    const [hasToolbar, setHasToolbar] = useState((_a = stateManager.current.hasToolbar) !== null && _a !== void 0 ? _a : false);
    const appLayoutState = useAppLayout(hasToolbar, appLayoutProps, forwardRef);
    const skeletonSlotsAttributes = useSkeletonSlotsAttributes(hasToolbar, appLayoutProps, appLayoutState);
    useLayoutEffect(() => {
        var _a;
        if (!((_a = stateManager.current) === null || _a === void 0 ? void 0 : _a.setState)) {
            console.warn('AppLayout state manager is not found');
            return;
        }
        stateManager.current.setState(appLayoutState, skeletonSlotsAttributes, getPropsToMerge(appLayoutProps, appLayoutState), mergeProps);
    });
    useLayoutEffect(() => {
        stateManager.current.setToolbar = setHasToolbar;
    }, [stateManager]);
    return React.createElement(React.Fragment, null);
};
export const AppLayoutStateProvider = (props) => {
    return (React.createElement(AppLayoutBuiltInErrorBoundary, null,
        React.createElement(AppLayoutStateProviderInternal, { ...props })));
};
export const createWidgetizedAppLayoutState = createWidgetizedComponent(AppLayoutStateProvider);
//# sourceMappingURL=index.js.map