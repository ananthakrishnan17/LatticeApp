// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useRef } from 'react';
import { Transition } from 'react-transition-group';
import clsx from 'clsx';
import ButtonGroup from '../../../button-group/internal';
import { AppLayoutBuiltInErrorBoundary } from '../../../error-boundary/internal';
import PanelResizeHandle from '../../../internal/components/panel-resize-handle';
import customCssProps from '../../../internal/generated/custom-css-properties';
import { usePrevious } from '../../../internal/hooks/use-previous';
import { getLimitedValue } from '../../../split-panel/utils/size-utils';
import { getDrawerStyles } from '../compute-layout';
import { useResize } from './use-resize';
import sharedStyles from '../../resize/styles.css.js';
import testutilStyles from '../../test-classes/styles.css.js';
import styles from './styles.css.js';
function AppLayoutGlobalDrawerImplementation({ appLayoutInternals, show, activeGlobalDrawer, }) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j;
    const { ariaLabels, globalDrawersFocusControl, isMobile, placement, onActiveGlobalDrawersChange, onActiveDrawerResize, minGlobalDrawersSizes, maxGlobalDrawersSizes, activeGlobalDrawersSizes, activeGlobalDrawers, verticalOffsets, drawersOpenQueue, expandedDrawerId, setExpandedDrawerId, activeAiDrawer, } = appLayoutInternals;
    const drawerRef = useRef(null);
    const activeDrawerId = (_a = activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.id) !== null && _a !== void 0 ? _a : '';
    const computedAriaLabels = {
        closeButton: activeGlobalDrawer ? (_b = activeGlobalDrawer.ariaLabels) === null || _b === void 0 ? void 0 : _b.closeButton : ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.toolsClose,
        content: activeGlobalDrawer ? (_c = activeGlobalDrawer.ariaLabels) === null || _c === void 0 ? void 0 : _c.drawerName : ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.tools,
    };
    const { drawerTopOffset, drawerHeight } = getDrawerStyles(verticalOffsets, isMobile, placement);
    const activeDrawerSize = (_d = (activeDrawerId ? activeGlobalDrawersSizes[activeDrawerId] : 0)) !== null && _d !== void 0 ? _d : 0;
    const minDrawerSize = (_e = (activeDrawerId ? minGlobalDrawersSizes[activeDrawerId] : 0)) !== null && _e !== void 0 ? _e : 0;
    const maxDrawerSize = (_f = (activeDrawerId ? maxGlobalDrawersSizes[activeDrawerId] : 0)) !== null && _f !== void 0 ? _f : 0;
    const refs = globalDrawersFocusControl.refs[activeDrawerId];
    const resizeProps = useResize({
        currentWidth: activeDrawerSize,
        minWidth: minDrawerSize,
        maxWidth: maxDrawerSize,
        panelRef: drawerRef,
        handleRef: refs === null || refs === void 0 ? void 0 : refs.slider,
        onResize: size => onActiveDrawerResize({ id: activeDrawerId, size }),
    });
    const size = getLimitedValue(minDrawerSize, activeDrawerSize, maxDrawerSize);
    const lastOpenedDrawerId = drawersOpenQueue.length ? drawersOpenQueue[0] : null;
    const hasTriggerButton = !!(activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.trigger);
    const isExpanded = (activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.isExpandable) && expandedDrawerId === activeDrawerId;
    const wasExpanded = usePrevious(isExpanded);
    const animationDisabled = ((activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.defaultActive) && !drawersOpenQueue.includes(activeGlobalDrawer.id)) ||
        (wasExpanded && !isExpanded);
    let drawerActions = [
        {
            type: 'icon-button',
            id: 'close',
            iconName: isMobile ? 'close' : 'angle-right',
            text: (_g = computedAriaLabels.closeButton) !== null && _g !== void 0 ? _g : '',
            analyticsAction: 'close',
        },
    ];
    if (!isMobile && (activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.isExpandable)) {
        drawerActions = [
            {
                type: 'icon-button',
                id: 'expand',
                iconName: isExpanded ? 'shrink' : 'expand',
                text: (_j = (_h = activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.ariaLabels) === null || _h === void 0 ? void 0 : _h.expandedModeButton) !== null && _j !== void 0 ? _j : '',
                analyticsAction: isExpanded ? 'expand' : 'collapse',
            },
            ...drawerActions,
        ];
    }
    if (activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.headerActions) {
        drawerActions = [
            {
                type: 'group',
                text: 'Actions',
                items: activeGlobalDrawer.headerActions,
            },
            ...drawerActions,
        ];
    }
    return (React.createElement(AppLayoutBuiltInErrorBoundary, null,
        React.createElement(Transition, { nodeRef: drawerRef, in: show || isExpanded, appear: show || isExpanded, timeout: 0 }, state => {
            var _a, _b;
            return (React.createElement("aside", { id: activeDrawerId, "aria-hidden": !show, "aria-label": computedAriaLabels.content, className: clsx(styles.drawer, styles['drawer-global'], styles[state], !animationDisabled && sharedStyles['with-motion-horizontal'], !animationDisabled && isExpanded && styles['with-expanded-motion'], {
                    [styles['drawer-hidden']]: !show,
                    [styles['last-opened']]: (!activeAiDrawer && lastOpenedDrawerId === activeDrawerId) || isExpanded,
                    [testutilStyles['active-drawer']]: show,
                    [styles['drawer-expanded']]: isExpanded,
                    [styles['has-next-siblings']]: activeGlobalDrawers.findIndex(drawer => drawer.id === activeDrawerId) + 1 <
                        activeGlobalDrawers.length,
                }), ref: drawerRef, onBlur: e => {
                    // Drawers with trigger buttons follow this restore focus logic:
                    // If a previously focused element exists, restore focus on it; otherwise, focus on the associated trigger button.
                    // This function resets the previously focused element.
                    // If the drawer has no trigger button and loses focus on the previously focused element, it defaults to document.body,
                    // which ideally should never happen.
                    if (!hasTriggerButton) {
                        return;
                    }
                    if (!e.relatedTarget || !e.currentTarget.contains(e.relatedTarget)) {
                        globalDrawersFocusControl.loseFocus();
                    }
                }, style: {
                    blockSize: drawerHeight,
                    insetBlockStart: drawerTopOffset,
                    ...(!isMobile && {
                        [customCssProps.drawerSize]: `${['entering', 'entered'].includes(state) ? (isExpanded ? '100%' : size + 'px') : 0}`,
                    }),
                }, "data-testid": `awsui-app-layout-drawer-${activeDrawerId}` },
                React.createElement("div", { className: clsx(styles['global-drawer-wrapper']) },
                    !isMobile && React.createElement("div", { className: styles['drawer-gap'] }),
                    !isMobile && (activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.resizable) && !isExpanded && (React.createElement("div", { className: styles['drawer-slider'] },
                        React.createElement(PanelResizeHandle, { ref: refs === null || refs === void 0 ? void 0 : refs.slider, position: "side", className: testutilStyles['drawers-slider'], ariaLabel: (_a = activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.ariaLabels) === null || _a === void 0 ? void 0 : _a.resizeHandle, tooltipText: (_b = activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.ariaLabels) === null || _b === void 0 ? void 0 : _b.resizeHandleTooltipText, ariaValuenow: resizeProps.relativeSize, onKeyDown: resizeProps.onKeyDown, onDirectionClick: resizeProps.onDirectionClick, onPointerDown: resizeProps.onPointerDown }))),
                    React.createElement("div", { className: clsx(styles['drawer-content-container'], sharedStyles['with-motion-horizontal']), "data-testid": `awsui-app-layout-drawer-content-${activeDrawerId}` },
                        React.createElement("div", { className: styles['drawer-actions'] },
                            React.createElement(ButtonGroup, { dropdownExpandToViewport: false, variant: "icon", onItemClick: event => {
                                    var _a;
                                    switch (event.detail.id) {
                                        case 'close':
                                            onActiveGlobalDrawersChange(activeDrawerId, { initiatedByUserAction: true });
                                            break;
                                        case 'expand':
                                            setExpandedDrawerId(isExpanded ? null : activeDrawerId);
                                            break;
                                        default:
                                            (_a = activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.onHeaderActionClick) === null || _a === void 0 ? void 0 : _a.call(activeGlobalDrawer, event);
                                    }
                                }, ariaLabel: "Global panel actions", items: drawerActions, __internalRootRef: (root) => {
                                    if (!root) {
                                        return;
                                    }
                                    refs.close = { current: root.querySelector('[data-itemid="close"]') };
                                } })),
                        React.createElement("div", { className: styles['drawer-content'], style: { blockSize: drawerHeight } }, activeGlobalDrawer === null || activeGlobalDrawer === void 0 ? void 0 : activeGlobalDrawer.content)))));
        })));
}
export default AppLayoutGlobalDrawerImplementation;
//# sourceMappingURL=global-drawer.js.map