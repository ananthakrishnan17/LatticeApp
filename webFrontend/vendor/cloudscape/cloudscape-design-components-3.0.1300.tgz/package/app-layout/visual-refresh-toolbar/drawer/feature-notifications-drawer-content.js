// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useRef } from 'react';
import Box from '../../../box/internal';
import { InternalDrawer } from '../../../drawer/internal';
import { useInternalI18n } from '../../../i18n/context';
import { formatDate } from '../../../internal/utils/date-time';
import Link from '../../../link/internal';
import List from '../../../list/internal';
import SpaceBetween from '../../../space-between/internal';
import styles from './styles.css.js';
export function RuntimeContentPart({ content, mountContent }) {
    const ref = useRef(null);
    useEffect(() => {
        if (!(mountContent && ref.current)) {
            return;
        }
        const container = ref.current;
        const destructor = mountContent(container, content);
        return () => {
            destructor === null || destructor === void 0 ? void 0 : destructor();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return mountContent ? React.createElement("div", { ref: ref }) : React.createElement(React.Fragment, null, content);
}
export default function RuntimeFeaturesNotificationDrawer({ features, mountItem, featuresPageLink, i18nStrings, }) {
    const i18n = useInternalI18n('features-notification-drawer');
    return (React.createElement(InternalDrawer, { header: i18n('i18nStrings.title', i18nStrings === null || i18nStrings === void 0 ? void 0 : i18nStrings.titleText), disableContentPaddings: true },
        React.createElement("div", { className: styles['runtime-feature-notifications-drawer-content'] },
            React.createElement(Box, { padding: { top: 'm', left: 'xl', right: 'xl', bottom: 'm' } },
                React.createElement(List, { items: features, renderItem: item => ({
                        id: item.id,
                        content: (React.createElement(Box, { variant: "h3" },
                            React.createElement(RuntimeContentPart, { mountContent: mountItem, content: item.header }))),
                        secondaryContent: (React.createElement(SpaceBetween, { size: "xs", direction: "vertical" },
                            React.createElement(Box, { fontSize: "body-s", color: "text-body-secondary" }, formatDate(item.releaseDate)),
                            !!item.contentCategory && (React.createElement(Box, null,
                                React.createElement(RuntimeContentPart, { mountContent: mountItem, content: item.contentCategory }))),
                            React.createElement(Box, null,
                                React.createElement(RuntimeContentPart, { mountContent: mountItem, content: item.content })))),
                    }) }),
                !!featuresPageLink && (React.createElement("footer", { className: styles['runtime-feature-notifications-footer'] },
                    React.createElement(Box, { padding: { top: 's' } },
                        React.createElement(Link, { href: featuresPageLink }, i18n('i18nStrings.viewAll', i18nStrings === null || i18nStrings === void 0 ? void 0 : i18nStrings.viewAllText)))))))));
}
//# sourceMappingURL=feature-notifications-drawer-content.js.map