// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useRef } from 'react';
import AppLayoutGlobalDrawer from './global-drawer';
export function AppLayoutGlobalDrawersImplementation({ appLayoutInternals, }) {
    const { globalDrawers, activeGlobalDrawersIds, expandedDrawerId } = appLayoutInternals;
    const openDrawersHistory = useRef(new Set());
    if (!globalDrawers.length) {
        return React.createElement(React.Fragment, null);
    }
    return (React.createElement(React.Fragment, null, globalDrawers
        .filter(drawer => (drawer.position !== 'bottom' && activeGlobalDrawersIds.includes(drawer.id)) ||
        (drawer.preserveInactiveContent && openDrawersHistory.current.has(drawer.id)))
        .map(drawer => {
        openDrawersHistory.current.add(drawer.id);
        return (React.createElement(AppLayoutGlobalDrawer, { key: drawer.id, show: activeGlobalDrawersIds.includes(drawer.id) && (!expandedDrawerId || drawer.id === expandedDrawerId), activeGlobalDrawer: drawer, appLayoutInternals: appLayoutInternals }));
    })));
}
//# sourceMappingURL=global-drawers.js.map