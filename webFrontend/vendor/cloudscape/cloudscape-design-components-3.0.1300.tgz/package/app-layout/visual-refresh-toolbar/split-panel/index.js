// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import { SplitPanelProvider } from '../../split-panel';
import { getDrawerStyles } from '../compute-layout';
import styles from './styles.css.js';
export function AppLayoutSplitPanelDrawerSideImplementation({ children, appLayoutInternals, splitPanelInternals, bottomDrawerReportedSize, }) {
    const { splitPanelControlId, placement, verticalOffsets, isMobile, splitPanelAnimationDisabled } = appLayoutInternals;
    const { drawerTopOffset, drawerHeight } = getDrawerStyles(verticalOffsets, isMobile, placement, isMobile ? 0 : (bottomDrawerReportedSize !== null && bottomDrawerReportedSize !== void 0 ? bottomDrawerReportedSize : 0));
    return (React.createElement(SplitPanelProvider, { ...splitPanelInternals, animationDisabled: splitPanelAnimationDisabled },
        React.createElement("section", { id: splitPanelControlId, className: styles['split-panel-side'], style: {
                blockSize: drawerHeight,
                insetBlockStart: drawerTopOffset,
            } }, children)));
}
export function AppLayoutSplitPanelDrawerBottomImplementation({ children, splitPanelInternals, appLayoutInternals, }) {
    const { splitPanelControlId, splitPanelAnimationDisabled } = appLayoutInternals;
    return (React.createElement(SplitPanelProvider, { ...splitPanelInternals, animationDisabled: splitPanelAnimationDisabled },
        React.createElement("section", { id: splitPanelControlId }, children)));
}
//# sourceMappingURL=index.js.map