// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { unstable_batchedUpdates } from 'react-dom';
import { AppLayoutBuiltInErrorBoundary } from '../../error-boundary/internal';
import RemoteI18nProvider from '../../i18n/providers/remote-provider';
import ScreenreaderOnly from '../../internal/components/screenreader-only';
import { useAriaLabels } from '../utils/use-aria-labels';
import { AppLayoutVisibilityContext } from './contexts';
import { AppLayoutWidgetizedState, loadFormatter } from './internal';
import { SkeletonLayout } from './skeleton';
import { useMultiAppLayout } from './skeleton/multi-layout';
import { getPropsToMerge, mergeProps } from './state/props-merger';
const AppLayoutStateProvider = ({ forceDeduplicationType, appLayoutProps, stateManager, children }) => {
    const [appLayoutState, setAppLayoutState] = useState({ isIntersecting: true });
    const [skeletonAttributes, setSkeletonAttributes] = useState({});
    // use { fn: } object wrapper to avoid confusion with callback form of setState
    const [deduplicator, setDeduplicator] = useState({ fn: mergeProps });
    const [deduplicationProps, setDeduplicationProps] = useState(undefined);
    const { registered, toolbarProps } = useMultiAppLayout(forceDeduplicationType, appLayoutState.isIntersecting, deduplicationProps !== null && deduplicationProps !== void 0 ? deduplicationProps : getPropsToMerge(appLayoutProps, appLayoutState), deduplicator.fn);
    useLayoutEffect(() => {
        stateManager.current.setState = (appLayoutState, skeletonAttributes, deduplicationProps, mergeProps) => {
            unstable_batchedUpdates(() => {
                setAppLayoutState(appLayoutState);
                setSkeletonAttributes(skeletonAttributes);
                setDeduplicationProps(deduplicationProps);
                setDeduplicator({ fn: mergeProps });
            });
        };
    }, [stateManager]);
    const hasToolbar = !!toolbarProps;
    useEffect(() => {
        var _a, _b;
        stateManager.current.hasToolbar = hasToolbar;
        (_b = (_a = stateManager.current).setToolbar) === null || _b === void 0 ? void 0 : _b.call(_a, hasToolbar);
    }, [stateManager, hasToolbar]);
    return React.createElement(React.Fragment, null, children(registered, appLayoutState, toolbarProps, skeletonAttributes));
};
const AppLayoutVisualRefreshToolbar = React.forwardRef((props, forwardRef) => {
    const stateManagerRef = useRef({ setState: undefined, hasToolbar: false, setToolbar: undefined });
    return (React.createElement(RemoteI18nProvider, { loadFormatter: loadFormatter },
        React.createElement(AppLayoutVisualRefreshToolbarWithI18n, { appLayoutRef: forwardRef, stateManagerRef: stateManagerRef, appLayoutProps: props })));
});
function AppLayoutVisualRefreshToolbarWithI18n({ appLayoutRef, stateManagerRef, appLayoutProps, }) {
    const { __forceDeduplicationType: forceDeduplicationType, __embeddedViewMode: embeddedViewMode } = appLayoutProps;
    const ariaLabels = useAriaLabels(appLayoutProps.ariaLabels);
    const appLayoutPropsWithI18n = { ...appLayoutProps, ariaLabels };
    return (React.createElement(React.Fragment, null,
        React.createElement(AppLayoutStateProvider, { forceDeduplicationType: forceDeduplicationType, appLayoutProps: appLayoutPropsWithI18n, stateManager: stateManagerRef }, (registered, appLayoutState, toolbarProps, skeletonAttributes) => (React.createElement(AppLayoutVisibilityContext.Provider, { value: appLayoutState.isIntersecting },
            (embeddedViewMode || !toolbarProps) && appLayoutPropsWithI18n.breadcrumbs ? (React.createElement(AppLayoutBuiltInErrorBoundary, null,
                React.createElement(ScreenreaderOnly, null, appLayoutPropsWithI18n.breadcrumbs))) : null,
            React.createElement(SkeletonLayout, { registered: registered, toolbarProps: toolbarProps, appLayoutProps: appLayoutPropsWithI18n, appLayoutState: appLayoutState, skeletonSlotsAttributes: skeletonAttributes })))),
        React.createElement(AppLayoutWidgetizedState, { forwardRef: appLayoutRef, appLayoutProps: appLayoutPropsWithI18n, stateManager: stateManagerRef })));
}
export default AppLayoutVisualRefreshToolbar;
//# sourceMappingURL=index.js.map