// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import { AppLayoutBuiltInErrorBoundary } from '../../../error-boundary/internal';
import { createWidgetizedComponent } from '../../../internal/widgets';
import { AppLayoutSplitPanelDrawerBottomImplementation as AppLayoutSplitPanelBottom } from '../split-panel';
import { isWidgetReady } from '../state/invariants';
import sharedStyles from '../../resize/styles.css.js';
import styles from '../skeleton/styles.css.js';
export const BottomContentSlotImplementationInternal = ({ appLayoutState, appLayoutProps }) => {
    if (!isWidgetReady(appLayoutState)) {
        return null;
    }
    const { splitPanelPosition, placement, activeGlobalBottomDrawerId, bottomDrawerReportedSize, isMobile } = appLayoutState.widgetizedState;
    return (React.createElement(React.Fragment, null, splitPanelPosition === 'bottom' && (React.createElement("div", { className: clsx(styles['split-panel-bottom'], sharedStyles['with-motion-vertical']), style: {
            insetBlockEnd: placement.insetBlockEnd + (activeGlobalBottomDrawerId && !isMobile ? bottomDrawerReportedSize : 0),
        } },
        React.createElement(AppLayoutSplitPanelBottom, { appLayoutInternals: appLayoutState.appLayoutInternals, splitPanelInternals: appLayoutState.splitPanelInternals }, appLayoutProps.splitPanel)))));
};
export const BottomContentSlotImplementation = (props) => {
    return (React.createElement(AppLayoutBuiltInErrorBoundary, null,
        React.createElement(BottomContentSlotImplementationInternal, { ...props })));
};
export const createWidgetizedAppLayoutBottomContentSlot = createWidgetizedComponent(BottomContentSlotImplementation);
//# sourceMappingURL=bottom-content-slot.js.map