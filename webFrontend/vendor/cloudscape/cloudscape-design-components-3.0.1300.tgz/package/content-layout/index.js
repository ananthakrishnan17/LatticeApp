// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalContentLayout from './internal';
export default function ContentLayout(props) {
    const baseComponentProps = useBaseComponent('ContentLayout', {
        props: { disableOverlap: props.disableOverlap },
    });
    return React.createElement(InternalContentLayout, { ...props, ...baseComponentProps });
}
applyDisplayName(ContentLayout, 'ContentLayout');
//# sourceMappingURL=index.js.map