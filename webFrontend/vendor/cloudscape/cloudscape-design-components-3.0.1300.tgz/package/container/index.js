// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import { AnalyticsFunnelSubStep } from '../internal/analytics/components/analytics-funnel';
import { getAnalyticsMetadataProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { getExternalProps } from '../internal/utils/external-props';
import { InternalContainerAsSubstep } from './internal';
export default function Container({ variant = 'default', disableHeaderPaddings = false, disableContentPaddings = false, fitHeight = false, ...props }) {
    const analyticsMetadata = getAnalyticsMetadataProps(props);
    const baseComponentProps = useBaseComponent('Container', {
        props: {
            disableContentPaddings,
            disableHeaderPaddings,
            fitHeight,
            variant,
        },
        metadata: {
            hasInstanceIdentifier: Boolean(analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.instanceIdentifier),
        },
    }, analyticsMetadata);
    const externalProps = getExternalProps(props);
    const analyticsComponentMetadata = {
        name: 'awsui.Container',
        label: { root: 'self' },
    };
    return (React.createElement(AnalyticsFunnelSubStep, { subStepIdentifier: analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.instanceIdentifier, subStepErrorContext: analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.errorContext },
        React.createElement(InternalContainerAsSubstep, { variant: variant, disableContentPaddings: disableContentPaddings, disableHeaderPaddings: disableHeaderPaddings, fitHeight: fitHeight, ...props, ...externalProps, ...baseComponentProps, ...getAnalyticsMetadataAttribute({ component: analyticsComponentMetadata }) })));
}
applyDisplayName(Container, 'Container');
//# sourceMappingURL=index.js.map