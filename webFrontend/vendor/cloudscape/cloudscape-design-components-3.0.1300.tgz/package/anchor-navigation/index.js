// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalAnchorNavigation from './internal';
export default function AnchorNavigation({ scrollSpyOffset = 0, ...props }) {
    const baseComponentProps = useBaseComponent('AnchorNavigation');
    return React.createElement(InternalAnchorNavigation, { scrollSpyOffset: scrollSpyOffset, ...props, ...baseComponentProps });
}
applyDisplayName(AnchorNavigation, 'AnchorNavigation');
//# sourceMappingURL=index.js.map