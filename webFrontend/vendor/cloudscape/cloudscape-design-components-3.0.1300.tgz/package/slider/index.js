// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalSlider from './internal';
export default function Slider({ tickMarks, hideFillLine, style, ...props }) {
    const baseComponentProps = useBaseComponent('Slider', {
        props: { tickMarks, hideFillLine, readOnly: props.readOnly },
    });
    return (React.createElement(InternalSlider, { tickMarks: tickMarks, hideFillLine: hideFillLine, style: style, ...props, ...baseComponentProps }));
}
applyDisplayName(Slider, 'Slider');
//# sourceMappingURL=index.js.map