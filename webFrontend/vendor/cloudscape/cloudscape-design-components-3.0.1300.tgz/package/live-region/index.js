// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalLiveRegion from './internal';
function LiveRegion({ assertive = false, hidden = false, tagName = 'div', ...restProps }) {
    const baseComponentProps = useBaseComponent('LiveRegion', { props: { assertive, hidden } });
    return (React.createElement(InternalLiveRegion, { assertive: assertive, hidden: hidden, tagName: tagName, ...baseComponentProps, ...restProps }));
}
applyDisplayName(LiveRegion, 'LiveRegion');
export default LiveRegion;
//# sourceMappingURL=index.js.map