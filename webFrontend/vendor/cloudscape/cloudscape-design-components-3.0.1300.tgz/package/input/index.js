// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React, { useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalInput from './internal';
import styles from './styles.css.js';
const Input = React.forwardRef(({ value, type = 'text', step, inputMode, autoComplete = true, spellcheck, disabled, readOnly, disableBrowserAutocorrect, onKeyDown, onKeyUp, onChange, onBlur, onFocus, ariaRequired, name, placeholder, autoFocus, ariaLabel, ariaLabelledby, ariaDescribedby, invalid, warning, controlId, clearAriaLabel, nativeInputAttributes, style, ...rest }, ref) => {
    const baseComponentProps = useBaseComponent('Input', {
        props: { autoComplete, autoFocus, disableBrowserAutocorrect, inputMode, readOnly, spellcheck, type },
    });
    const baseProps = getBaseProps(rest);
    const inputRef = useRef(null);
    useImperativeHandle(ref, () => ({
        focus(...args) {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus(...args);
        },
        select() {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.select();
        },
    }), [inputRef]);
    return (React.createElement(InternalInput, { ref: inputRef, ...baseProps,
        ...baseComponentProps,
        autoComplete,
        ariaLabel,
        ariaRequired,
        autoFocus,
        disabled,
        disableBrowserAutocorrect,
        name,
        onKeyDown,
        onKeyUp,
        onChange,
        onBlur,
        onFocus,
        placeholder,
        readOnly,
        type,
        step,
        inputMode,
        spellcheck,
        value,
        ariaDescribedby,
        ariaLabelledby,
        invalid,
        warning,
        controlId,
        clearAriaLabel,
        nativeInputAttributes,
        style, className: clsx(styles.root, baseProps.className), __inheritFormFieldProps: true, __injectAnalyticsComponentMetadata: true }));
});
applyDisplayName(Input, 'Input');
export default Input;
//# sourceMappingURL=index.js.map