// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import clsx from 'clsx';
import InternalRadioButton from '../internal/components/radio-button';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import styles from './styles.css.js';
const RadioButton = React.forwardRef((props, ref) => {
    const baseComponentProps = useBaseComponent('RadioButton', {
        props: { readOnly: Boolean(props.readOnly), disabled: Boolean(props.disabled) },
    });
    return (React.createElement(InternalRadioButton, { ...props, ...baseComponentProps, className: clsx(props.className, styles['radio-button']), ref: ref }));
});
applyDisplayName(RadioButton, 'RadioButton');
/**
 * @awsuiSystem core
 */
export default RadioButton;
//# sourceMappingURL=index.js.map