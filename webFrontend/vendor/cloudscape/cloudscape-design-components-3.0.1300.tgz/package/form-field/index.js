// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import { getAnalyticsMetadataProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalFormField from './internal';
import analyticsSelectors from './analytics-metadata/styles.css.js';
export default function FormField({ stretch = false, ...props }) {
    const analyticsMetadata = getAnalyticsMetadataProps(props);
    const baseComponentProps = useBaseComponent('FormField', {
        props: {
            stretch,
        },
        metadata: {
            hasInstanceIdentifier: Boolean(analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.instanceIdentifier),
            hasErrorContext: Boolean(analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.errorContext),
        },
    }, analyticsMetadata);
    return (React.createElement(InternalFormField, { stretch: stretch, ...props, __hideLabel: false, __analyticsMetadata: analyticsMetadata, ...baseComponentProps, ...getAnalyticsMetadataAttribute({
            component: {
                name: 'awsui.FormField',
                label: `.${analyticsSelectors.label}`,
            },
        }) }));
}
applyDisplayName(FormField, 'FormField');
//# sourceMappingURL=index.js.map