// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import OptionComponent from '../internal/components/option';
import { getTestOptionIndexes } from '../internal/components/options-list/utils/test-indexes';
import SelectableItem from '../internal/components/selectable-item';
import styles from './styles.css.js';
const toAutosuggestOptionGroupItem = (props) => {
    var _a;
    return {
        type: 'group',
        index: (_a = props.virtualIndex) !== null && _a !== void 0 ? _a : props.index,
        option: props.option.option,
        disabled: props.disabled,
    };
};
const toAutosuggestOptionItem = (props) => {
    var _a;
    return {
        type: 'item',
        index: (_a = props.virtualIndex) !== null && _a !== void 0 ? _a : props.index,
        option: props.option.option,
        selected: props.selected,
        highlighted: props.highlighted,
        disabled: props.disabled,
        parent: props.parentProps
            ? toAutosuggestOptionGroupItem({
                index: props.parentProps.index,
                virtualIndex: props.parentProps.virtualIndex,
                option: props.parentProps.option,
                disabled: props.disabled,
            })
            : null,
    };
};
const toAutosuggestUseEnteredItem = (props) => {
    return {
        type: 'entered-text',
        option: props.option.option,
        highlighted: props.highlighted,
    };
};
const AutosuggestOption = ({ index, virtualIndex, nativeAttributes = {}, highlightText, option, highlighted, highlightType, current, virtualPosition, padBottom, screenReaderContent, ariaSetsize, ariaPosinset, renderOption, parentProps, ...rest }, ref) => {
    const baseProps = getBaseProps(rest);
    const useEntered = (option === null || option === void 0 ? void 0 : option.type) === 'use-entered';
    const isParent = (option === null || option === void 0 ? void 0 : option.type) === 'parent';
    const isChild = (option === null || option === void 0 ? void 0 : option.type) === 'child';
    const { throughIndex, inGroupIndex, groupIndex } = getTestOptionIndexes(option) || {};
    const getAutosuggestItemProps = (option) => {
        if (option.type === 'parent') {
            return toAutosuggestOptionGroupItem({
                option: option,
                index: index,
                virtualIndex: virtualIndex,
                disabled: !!option.disabled,
            });
        }
        else if (option.type === 'use-entered') {
            return toAutosuggestUseEnteredItem({
                option: option,
                highlighted: highlighted,
            });
        }
        else {
            return toAutosuggestOptionItem({
                option: option,
                index: index,
                virtualIndex: virtualIndex,
                disabled: !!option.disabled,
                highlighted: highlighted,
                selected: current,
                parentProps: parentProps,
            });
        }
    };
    const renderOptionWrapper = (option) => {
        if (!renderOption) {
            return null;
        }
        return renderOption({ item: getAutosuggestItemProps(option), filterText: highlightText });
    };
    const renderResult = renderOptionWrapper(option);
    let optionContent;
    if (useEntered) {
        optionContent = renderResult !== null && renderResult !== void 0 ? renderResult : option.label;
        // we don't want fancy generated content for screenreader for the "Use..." option,
        // just the visible text is fine
        screenReaderContent = undefined;
    }
    else if (isParent) {
        optionContent = renderResult !== null && renderResult !== void 0 ? renderResult : option.label;
    }
    else {
        const a11yProperties = {};
        if (nativeAttributes['aria-label']) {
            a11yProperties['aria-label'] = nativeAttributes['aria-label'];
        }
        optionContent = (React.createElement("div", { ...a11yProperties },
            React.createElement(OptionComponent, { customContent: renderResult, option: option, highlightedOption: highlighted, highlightText: highlightText })));
    }
    return (React.createElement(SelectableItem, { ...baseProps, disableContentStyling: !!renderResult, className: styles.option, ariaSelected: current, highlighted: highlighted, disabled: option.disabled, hasBackground: useEntered, isParent: isParent, isChild: isChild, virtualPosition: virtualPosition, "data-test-index": throughIndex, "data-in-group-index": inGroupIndex, "data-group-index": groupIndex, ref: ref, padBottom: padBottom, screenReaderContent: screenReaderContent, ariaSetsize: ariaSetsize, ariaPosinset: ariaPosinset, highlightType: highlightType.type, value: option.value }, optionContent));
};
export default React.memo(React.forwardRef(AutosuggestOption));
//# sourceMappingURL=autosuggest-option.js.map