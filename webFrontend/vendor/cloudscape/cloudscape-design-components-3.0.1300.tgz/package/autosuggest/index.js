// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { getExternalProps } from '../internal/utils/external-props';
import InternalAutosuggest from './internal';
const Autosuggest = React.forwardRef(({ filteringType = 'auto', statusType = 'finished', disableBrowserAutocorrect = false, hideEnteredTextOption = false, renderOption, ...props }, ref) => {
    const baseComponentProps = useBaseComponent('Autosuggest', {
        props: {
            autoFocus: props.autoFocus,
            disableBrowserAutocorrect,
            expandToViewport: props.expandToViewport,
            filteringType,
            readOnly: props.readOnly,
            virtualScroll: props.virtualScroll,
            hideEnteredTextOption,
        },
    });
    const componentAnalyticsMetadata = {
        name: 'awsui.Autosuggest',
        label: 'input',
        properties: {
            disabled: `${!!props.disabled}`,
            value: props.value || '',
        },
    };
    const externalProps = getExternalProps(props);
    return (React.createElement(InternalAutosuggest, { renderOption: renderOption, filteringType: filteringType, statusType: statusType, disableBrowserAutocorrect: disableBrowserAutocorrect, hideEnteredTextOption: hideEnteredTextOption, ...externalProps, ...baseComponentProps, ref: ref, ...getAnalyticsMetadataAttribute({ component: componentAnalyticsMetadata }) }));
});
applyDisplayName(Autosuggest, 'Autosuggest');
export default Autosuggest;
//# sourceMappingURL=index.js.map