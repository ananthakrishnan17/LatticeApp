// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { getExternalProps } from '../internal/utils/external-props';
import InternalSteps from './internal';
const Steps = ({ steps, ...props }) => {
    const baseProps = getBaseProps(props);
    const baseComponentProps = useBaseComponent('Steps');
    const externalProps = getExternalProps(props);
    return React.createElement(InternalSteps, { ...baseProps, ...baseComponentProps, ...externalProps, steps: steps });
};
applyDisplayName(Steps, 'Steps');
export default Steps;
//# sourceMappingURL=index.js.map