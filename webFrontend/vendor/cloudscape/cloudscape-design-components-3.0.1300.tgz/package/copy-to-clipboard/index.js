// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { getExternalProps } from '../internal/utils/external-props';
import InternalCopyToClipboard from './internal';
export default function CopyToClipboard({ variant = 'button', popoverRenderWithPortal = false, wrapText = true, ...restProps }) {
    const baseProps = useBaseComponent('CopyToClipboard', {
        props: { variant },
    });
    const filteredProps = getExternalProps(restProps);
    return (React.createElement(InternalCopyToClipboard, { variant: variant, popoverRenderWithPortal: popoverRenderWithPortal, wrapText: wrapText, ...baseProps, ...filteredProps }));
}
applyDisplayName(CopyToClipboard, 'CopyToClipboard');
//# sourceMappingURL=index.js.map