// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export function filterOptions(options, searchText = '') {
    if (!searchText) {
        return options;
    }
    const filtered = [];
    for (const option of options) {
        if (isGroup(option)) {
            const childOptions = filterOptions(option.options, searchText);
            if (childOptions.length > 0) {
                filtered.push({ ...option, options: childOptions });
            }
        }
        else if (matchSingleOption(option, searchText)) {
            filtered.push(option);
        }
    }
    return filtered;
}
function isGroup(optionOrGroup) {
    const key = 'options';
    return key in optionOrGroup;
}
function matchSingleOption(option, searchText) {
    var _a, _b, _c, _d, _e, _f;
    searchText = searchText.toLowerCase();
    const label = ((_a = option.label) !== null && _a !== void 0 ? _a : '').toLowerCase();
    const labelPrefix = (_b = option.__labelPrefix) !== null && _b !== void 0 ? _b : '';
    const value = (option.value ? option.value.slice(labelPrefix.length) : '').toLowerCase();
    const matchesLabelOrValue = label.indexOf(searchText) !== -1 || value.indexOf(searchText) !== -1;
    const matchesTags = (_d = (_c = option.tags) === null || _c === void 0 ? void 0 : _c.some(tag => tag.toLowerCase().indexOf(searchText) !== -1)) !== null && _d !== void 0 ? _d : false;
    const matchesFilteringTags = (_f = (_e = option.filteringTags) === null || _e === void 0 ? void 0 : _e.some(tag => tag.toLowerCase().indexOf(searchText) !== -1)) !== null && _f !== void 0 ? _f : false;
    return matchesLabelOrValue || matchesTags || matchesFilteringTags;
}
//# sourceMappingURL=filter-options.js.map