// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';

import CoreComponent from './internal-do-not-use-core';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { validateProps } from '@cloudscape-design/component-toolkit/internal';



const Alert = React.forwardRef((props, ref) => {
    validateProps('Alert', props, ["persistenceConfig"], {}, 'core');
    return React.createElement(CoreComponent, {ref,...props});
});


applyDisplayName(Alert, 'Alert');
export default Alert;
