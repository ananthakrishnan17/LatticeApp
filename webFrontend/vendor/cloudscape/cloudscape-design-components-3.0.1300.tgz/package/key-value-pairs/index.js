// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalKeyValuePairs from './internal';
export default function KeyValuePairs({ columns = 1, items, ariaLabel, ariaLabelledby, minColumnWidth = 150, ...rest }) {
    const { __internalRootRef } = useBaseComponent('KeyValuePairs', {
        props: { columns },
    });
    const baseProps = getBaseProps(rest);
    return (React.createElement(InternalKeyValuePairs, { columns: columns, items: items, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, minColumnWidth: minColumnWidth, ...baseProps, ref: __internalRootRef }));
}
applyDisplayName(KeyValuePairs, 'KeyValuePairs');
//# sourceMappingURL=index.js.map