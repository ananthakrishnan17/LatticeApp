// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { forwardRef, useState } from 'react';
import InternalFileInput from '../file-input/internal.js';
import { fireCancelableEvent } from '../internal/events/index.js';
import Tooltip from '../tooltip/internal.js';
import testUtilStyles from './test-classes/styles.css.js';
const FileInputItem = forwardRef(({ item, showTooltip, onTooltipDismiss, onFilesChange }, ref) => {
    const [files, setFiles] = useState([]);
    const containerRef = React.useRef(null);
    const canShowTooltip = Boolean(showTooltip);
    return (React.createElement("div", { ref: containerRef },
        React.createElement(InternalFileInput, { className: testUtilStyles['button-group-item'], ref: ref, variant: "icon", ariaLabel: item.text, accept: item.accept, multiple: item.multiple, value: files, onChange: event => {
                fireCancelableEvent(onFilesChange, { id: item.id, files: event.detail.value });
                setFiles(event.detail.value);
            }, "data-testid": item.id, __inputNativeAttributes: {
                'data-itemid': item.id,
            }, __inputClassName: testUtilStyles.item }),
        canShowTooltip && (React.createElement(Tooltip, { className: testUtilStyles['button-group-tooltip'], getTrack: () => containerRef.current, content: item.text, onEscape: onTooltipDismiss }))));
});
export default FileInputItem;
//# sourceMappingURL=file-input-item.js.map