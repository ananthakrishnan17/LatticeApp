// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useRef } from 'react';
import { useSingleTabStopNavigation } from '@cloudscape-design/component-toolkit/internal';
import styles from './styles.css.js';
export default function FocusTarget({ ariaLabel }) {
    const divRef = useRef(null);
    const { tabIndex } = useSingleTabStopNavigation(divRef);
    return (React.createElement("div", { role: "group", ref: divRef, tabIndex: tabIndex, "aria-label": ariaLabel, className: styles['tree-item-focus-target'] }, null));
}
//# sourceMappingURL=focus-target.js.map