// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalDivider from './internal';
export default function Divider({ orientation = 'horizontal', children, nativeAttributes, ...rest }) {
    const baseComponentProps = useBaseComponent('Divider', { props: { orientation } });
    const baseProps = getBaseProps(rest);
    return (React.createElement(InternalDivider, { ...baseProps, ...baseComponentProps, orientation: orientation, nativeAttributes: nativeAttributes }, children));
}
applyDisplayName(Divider, 'Divider');
//# sourceMappingURL=index.js.map