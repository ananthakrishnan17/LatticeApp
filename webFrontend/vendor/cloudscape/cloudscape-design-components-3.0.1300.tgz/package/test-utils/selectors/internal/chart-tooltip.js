"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const selectors_1 = require("@cloudscape-design/test-utils-core/selectors");
const button_1 = require("../button");
const styles_selectors_js_1 = require("../../../internal/components/chart-popover/styles.selectors.js");
const styles_selectors_js_2 = require("../../../internal/components/chart-popover/test-classes/styles.selectors.js");
const styles_selectors_js_3 = require("../../../popover/styles.selectors.js");
class ChartTooltipWrapper extends selectors_1.ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles_selectors_js_2.default.header);
    }
    findBody() {
        return this.findByClassName(styles_selectors_js_2.default.body);
    }
    findFooter() {
        return this.findByClassName(styles_selectors_js_2.default.footer);
    }
    findDismissButton() {
        return this.findComponent(`.${styles_selectors_js_3.default['dismiss-control']}`, button_1.default);
    }
}
ChartTooltipWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = ChartTooltipWrapper;
//# sourceMappingURL=chart-tooltip.js.map