"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const selectors_1 = require("@cloudscape-design/test-utils-core/selectors");
const styles_selectors_js_1 = require("../../../internal/components/drag-handle/test-classes/styles.selectors.js");
const styles_selectors_js_2 = require("../../../internal/components/drag-handle-wrapper/test-classes/styles.selectors.js");
class DragHandleWrapper extends selectors_1.ComponentWrapper {
    findAllVisibleDirectionButtons() {
        return (0, selectors_1.createWrapper)().findAll(`.${styles_selectors_js_2.default['direction-button-visible']}`);
    }
    findVisibleDirectionButtonBlockStart() {
        return (0, selectors_1.createWrapper)().find(`.${styles_selectors_js_2.default['direction-button-block-start']}.${styles_selectors_js_2.default['direction-button-visible']}`);
    }
    findVisibleDirectionButtonBlockEnd() {
        return (0, selectors_1.createWrapper)().find(`.${styles_selectors_js_2.default['direction-button-block-end']}.${styles_selectors_js_2.default['direction-button-visible']}`);
    }
    findVisibleDirectionButtonInlineStart() {
        return (0, selectors_1.createWrapper)().find(`.${styles_selectors_js_2.default['direction-button-inline-start']}.${styles_selectors_js_2.default['direction-button-visible']}`);
    }
    findVisibleDirectionButtonInlineEnd() {
        return (0, selectors_1.createWrapper)().find(`.${styles_selectors_js_2.default['direction-button-inline-end']}.${styles_selectors_js_2.default['direction-button-visible']}`);
    }
}
DragHandleWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = DragHandleWrapper;
//# sourceMappingURL=drag-handle.js.map