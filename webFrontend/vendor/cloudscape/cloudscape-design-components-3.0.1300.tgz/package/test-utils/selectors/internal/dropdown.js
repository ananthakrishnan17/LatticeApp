"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const selectors_1 = require("@cloudscape-design/test-utils-core/selectors");
const styles_selectors_js_1 = require("../../../dropdown/styles.selectors.js");
const styles_selectors_js_2 = require("../../../dropdown/test-classes/styles.selectors.js");
class DropdownWrapper extends selectors_1.ElementWrapper {
    findTrigger() {
        return this.findByClassName(styles_selectors_js_2.default.trigger);
    }
    findOpenDropdown() {
        return this.find(`.${styles_selectors_js_1.default.dropdown}[data-open=true]`);
    }
}
DropdownWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = DropdownWrapper;
//# sourceMappingURL=dropdown.js.map