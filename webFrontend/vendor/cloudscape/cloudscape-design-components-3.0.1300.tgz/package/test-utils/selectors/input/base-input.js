"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
const selectors_1 = require("@cloudscape-design/test-utils-core/selectors");
const styles_selectors_js_1 = require("../../../input/styles.selectors.js");
class BaseInputWrapper extends selectors_1.ComponentWrapper {
    findNativeInput() {
        // Input component always have native input
        return this.find(`.${styles_selectors_js_1.default.input}`);
    }
}
exports.default = BaseInputWrapper;
//# sourceMappingURL=base-input.js.map