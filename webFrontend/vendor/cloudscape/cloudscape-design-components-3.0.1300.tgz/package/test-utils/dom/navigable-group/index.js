"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../navigable-group/test-classes/styles.selectors.js");
class NavigableGroupWrapper extends dom_1.ComponentWrapper {
    findContent() {
        return new dom_1.ElementWrapper(this.getElement());
    }
}
NavigableGroupWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = NavigableGroupWrapper;
//# sourceMappingURL=index.js.map