"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalendarDateWrapper = void 0;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const button_1 = require("../button");
const styles_selectors_js_1 = require("../../../calendar/styles.selectors.js");
class CalendarDateWrapper extends dom_1.ComponentWrapper {
    findDisabledReason() {
        return (0, dom_1.createWrapper)().find(`.${styles_selectors_js_1.default['disabled-reason-tooltip']}`);
    }
}
exports.CalendarDateWrapper = CalendarDateWrapper;
class CalendarWrapper extends dom_1.ComponentWrapper {
    /**
     * Returns a date container on the calendar.
     *
     * @param row 1-based row index of the day or month.
     * @param column 1-based column index of the day or month.
     */
    findDateAt(row, column) {
        return this.findComponent(`.${styles_selectors_js_1.default['calendar-row']}:nth-child(${row}) .${styles_selectors_js_1.default['calendar-date']}:nth-child(${column})`, CalendarDateWrapper);
    }
    findHeader() {
        return this.findByClassName(styles_selectors_js_1.default['calendar-header']);
    }
    /**
     * Alias for findPreviousButton for compatibility with previous versions
     * @deprecated
     */
    findPreviousMonthButton() {
        return this.findPreviousButton();
    }
    /**
     * Alias for findNextButton for compatibility with previous versions
     * @deprecated
     */
    findNextMonthButton() {
        return this.findNextButton();
    }
    findPreviousButton() {
        return this.findComponent(`.${styles_selectors_js_1.default['calendar-prev-btn']}`, button_1.default);
    }
    findNextButton() {
        return this.findComponent(`.${styles_selectors_js_1.default['calendar-next-btn']}`, button_1.default);
    }
    findSelectedDate() {
        return this.find(`.${styles_selectors_js_1.default['calendar-date-selected']}`);
    }
}
CalendarWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = CalendarWrapper;
//# sourceMappingURL=index.js.map