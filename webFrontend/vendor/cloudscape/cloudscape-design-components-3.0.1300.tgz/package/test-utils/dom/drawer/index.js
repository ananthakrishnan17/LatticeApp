"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../drawer/styles.selectors.js");
const styles_selectors_js_2 = require("../../../drawer/test-classes/styles.selectors.js");
class DrawerWrapper extends dom_1.ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles_selectors_js_1.default.header);
    }
    findFooter() {
        return this.findByClassName(styles_selectors_js_1.default.footer);
    }
    findHeaderActions() {
        return this.findByClassName(styles_selectors_js_1.default['header-actions']);
    }
    findContent() {
        return this.findByClassName(styles_selectors_js_1.default['test-utils-drawer-content']);
    }
    findBackdrop() {
        return this.findByClassName(styles_selectors_js_2.default.backdrop);
    }
    findCloseAction() {
        return this.findByClassName(styles_selectors_js_2.default['close-action']);
    }
}
DrawerWrapper.rootSelector = styles_selectors_js_2.default.root;
exports.default = DrawerWrapper;
//# sourceMappingURL=index.js.map