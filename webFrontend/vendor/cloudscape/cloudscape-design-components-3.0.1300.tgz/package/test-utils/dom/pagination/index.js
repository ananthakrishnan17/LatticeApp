"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const button_1 = require("../button");
const input_1 = require("../input");
const popover_1 = require("../popover");
const styles_selectors_js_1 = require("../../../pagination/styles.selectors.js");
class PaginationWrapper extends dom_1.ComponentWrapper {
    findCurrentPage() {
        return this.findByClassName(styles_selectors_js_1.default['button-current']);
    }
    findPageNumbers() {
        return this.findAllByClassName(styles_selectors_js_1.default['page-number']);
    }
    /**
     * Returns a page number for a given index.
     *
     * @param index 1-based index of the page number to return.
     */
    findPageNumberByIndex(index) {
        // we need to skip the "previous page" button
        const pageIndex = index + 1;
        return this.find(`li:nth-child(${pageIndex}) .${styles_selectors_js_1.default.button}`);
    }
    findPreviousPageButton() {
        return this.find(`li:first-child .${styles_selectors_js_1.default.button}`);
    }
    findNextPageButton() {
        return this.find(`li:last-child .${styles_selectors_js_1.default.button}`);
    }
    /**
     * Returns the jump to page input field.
     */
    findJumpToPageInput() {
        return this.findComponent(`.${styles_selectors_js_1.default['jump-to-page-input']}`, input_1.default);
    }
    /**
     * Returns the jump to page submit button.
     */
    findJumpToPageButton() {
        const jumpToPageContainer = this.findByClassName(styles_selectors_js_1.default['jump-to-page']);
        return jumpToPageContainer ? jumpToPageContainer.findComponent('button', button_1.default) : null;
    }
    /**
     * Returns the error popover for jump to page.
     */
    findJumpToPagePopover() {
        return this.findComponent(`.${popover_1.default.rootSelector}`, popover_1.default);
    }
    isDisabled() {
        return this.element.classList.contains(styles_selectors_js_1.default['root-disabled']);
    }
}
PaginationWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = PaginationWrapper;
__decorate([
    dom_1.usesDom
], PaginationWrapper.prototype, "isDisabled", null);
//# sourceMappingURL=index.js.map