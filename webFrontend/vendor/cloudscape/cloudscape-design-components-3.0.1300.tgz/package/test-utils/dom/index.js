"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LineChartWrapper = exports.KeyValuePairsWrapper = exports.ItemCardWrapper = exports.InputWrapper = exports.IconWrapper = exports.HotspotWrapper = exports.HelpPanelWrapper = exports.HeaderWrapper = exports.GridWrapper = exports.FormFieldWrapper = exports.FormWrapper = exports.FlashbarWrapper = exports.FileUploadWrapper = exports.FileTokenGroupWrapper = exports.FileInputWrapper = exports.FileDropzoneWrapper = exports.ExpandableSectionWrapper = exports.ErrorBoundaryWrapper = exports.DropdownWrapper = exports.DrawerWrapper = exports.DividerWrapper = exports.DateRangePickerWrapper = exports.DatePickerWrapper = exports.DateInputWrapper = exports.CopyToClipboardWrapper = exports.ContentLayoutWrapper = exports.ContainerWrapper = exports.ColumnLayoutWrapper = exports.CollectionPreferencesWrapper = exports.CodeEditorWrapper = exports.CheckboxWrapper = exports.CardsWrapper = exports.CalendarWrapper = exports.ButtonGroupWrapper = exports.ButtonDropdownWrapper = exports.ButtonWrapper = exports.BreadcrumbGroupWrapper = exports.BoxWrapper = exports.BarChartWrapper = exports.BadgeWrapper = exports.AutosuggestWrapper = exports.AttributeEditorWrapper = exports.AreaChartWrapper = exports.AppLayoutToolbarWrapper = exports.AppLayoutWrapper = exports.AnnotationWrapper = exports.AnchorNavigationWrapper = exports.AlertWrapper = exports.ActionCardWrapper = exports.ElementWrapper = void 0;
exports.WizardWrapper = exports.TutorialPanelWrapper = exports.TreeViewWrapper = exports.TopNavigationWrapper = exports.TooltipWrapper = exports.TokenGroupWrapper = exports.TokenWrapper = exports.ToggleButtonWrapper = exports.ToggleWrapper = exports.TimeInputWrapper = exports.TilesWrapper = exports.TextareaWrapper = exports.TextFilterWrapper = exports.TextContentWrapper = exports.TagEditorWrapper = exports.TabsWrapper = exports.TableWrapper = exports.StepsWrapper = exports.StatusIndicatorWrapper = exports.SplitPanelWrapper = exports.SpinnerWrapper = exports.SpaceBetweenWrapper = exports.SliderWrapper = exports.SkeletonWrapper = exports.SideNavigationWrapper = exports.SelectWrapper = exports.SegmentedControlWrapper = exports.S3ResourceSelectorWrapper = exports.RadioGroupWrapper = exports.RadioButtonWrapper = exports.PropertyFilterWrapper = exports.PromptInputWrapper = exports.ProgressBarWrapper = exports.PopoverWrapper = exports.PieChartWrapper = exports.PanelLayoutWrapper = exports.PaginationWrapper = exports.NavigableGroupWrapper = exports.MultiselectWrapper = exports.ModalWrapper = exports.MixedLineBarChartWrapper = exports.LiveRegionWrapper = exports.ListWrapper = exports.LinkWrapper = void 0;
exports.default = wrapper;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
Object.defineProperty(exports, "ElementWrapper", { enumerable: true, get: function () { return dom_1.ElementWrapper; } });
const utils_1 = require("@cloudscape-design/test-utils-core/utils");
const action_card_1 = require("./action-card");
exports.ActionCardWrapper = action_card_1.default;
const alert_1 = require("./alert");
exports.AlertWrapper = alert_1.default;
const anchor_navigation_1 = require("./anchor-navigation");
exports.AnchorNavigationWrapper = anchor_navigation_1.default;
const annotation_1 = require("./annotation");
exports.AnnotationWrapper = annotation_1.default;
const app_layout_1 = require("./app-layout");
exports.AppLayoutWrapper = app_layout_1.default;
const app_layout_toolbar_1 = require("./app-layout-toolbar");
exports.AppLayoutToolbarWrapper = app_layout_toolbar_1.default;
const area_chart_1 = require("./area-chart");
exports.AreaChartWrapper = area_chart_1.default;
const attribute_editor_1 = require("./attribute-editor");
exports.AttributeEditorWrapper = attribute_editor_1.default;
const autosuggest_1 = require("./autosuggest");
exports.AutosuggestWrapper = autosuggest_1.default;
const badge_1 = require("./badge");
exports.BadgeWrapper = badge_1.default;
const bar_chart_1 = require("./bar-chart");
exports.BarChartWrapper = bar_chart_1.default;
const box_1 = require("./box");
exports.BoxWrapper = box_1.default;
const breadcrumb_group_1 = require("./breadcrumb-group");
exports.BreadcrumbGroupWrapper = breadcrumb_group_1.default;
const button_1 = require("./button");
exports.ButtonWrapper = button_1.default;
const button_dropdown_1 = require("./button-dropdown");
exports.ButtonDropdownWrapper = button_dropdown_1.default;
const button_group_1 = require("./button-group");
exports.ButtonGroupWrapper = button_group_1.default;
const calendar_1 = require("./calendar");
exports.CalendarWrapper = calendar_1.default;
const cards_1 = require("./cards");
exports.CardsWrapper = cards_1.default;
const checkbox_1 = require("./checkbox");
exports.CheckboxWrapper = checkbox_1.default;
const code_editor_1 = require("./code-editor");
exports.CodeEditorWrapper = code_editor_1.default;
const collection_preferences_1 = require("./collection-preferences");
exports.CollectionPreferencesWrapper = collection_preferences_1.default;
const column_layout_1 = require("./column-layout");
exports.ColumnLayoutWrapper = column_layout_1.default;
const container_1 = require("./container");
exports.ContainerWrapper = container_1.default;
const content_layout_1 = require("./content-layout");
exports.ContentLayoutWrapper = content_layout_1.default;
const copy_to_clipboard_1 = require("./copy-to-clipboard");
exports.CopyToClipboardWrapper = copy_to_clipboard_1.default;
const date_input_1 = require("./date-input");
exports.DateInputWrapper = date_input_1.default;
const date_picker_1 = require("./date-picker");
exports.DatePickerWrapper = date_picker_1.default;
const date_range_picker_1 = require("./date-range-picker");
exports.DateRangePickerWrapper = date_range_picker_1.default;
const divider_1 = require("./divider");
exports.DividerWrapper = divider_1.default;
const drawer_1 = require("./drawer");
exports.DrawerWrapper = drawer_1.default;
const dropdown_1 = require("./dropdown");
exports.DropdownWrapper = dropdown_1.default;
const error_boundary_1 = require("./error-boundary");
exports.ErrorBoundaryWrapper = error_boundary_1.default;
const expandable_section_1 = require("./expandable-section");
exports.ExpandableSectionWrapper = expandable_section_1.default;
const file_dropzone_1 = require("./file-dropzone");
exports.FileDropzoneWrapper = file_dropzone_1.default;
const file_input_1 = require("./file-input");
exports.FileInputWrapper = file_input_1.default;
const file_token_group_1 = require("./file-token-group");
exports.FileTokenGroupWrapper = file_token_group_1.default;
const file_upload_1 = require("./file-upload");
exports.FileUploadWrapper = file_upload_1.default;
const flashbar_1 = require("./flashbar");
exports.FlashbarWrapper = flashbar_1.default;
const form_1 = require("./form");
exports.FormWrapper = form_1.default;
const form_field_1 = require("./form-field");
exports.FormFieldWrapper = form_field_1.default;
const grid_1 = require("./grid");
exports.GridWrapper = grid_1.default;
const header_1 = require("./header");
exports.HeaderWrapper = header_1.default;
const help_panel_1 = require("./help-panel");
exports.HelpPanelWrapper = help_panel_1.default;
const hotspot_1 = require("./hotspot");
exports.HotspotWrapper = hotspot_1.default;
const icon_1 = require("./icon");
exports.IconWrapper = icon_1.default;
const input_1 = require("./input");
exports.InputWrapper = input_1.default;
const item_card_1 = require("./item-card");
exports.ItemCardWrapper = item_card_1.default;
const key_value_pairs_1 = require("./key-value-pairs");
exports.KeyValuePairsWrapper = key_value_pairs_1.default;
const line_chart_1 = require("./line-chart");
exports.LineChartWrapper = line_chart_1.default;
const link_1 = require("./link");
exports.LinkWrapper = link_1.default;
const list_1 = require("./list");
exports.ListWrapper = list_1.default;
const live_region_1 = require("./live-region");
exports.LiveRegionWrapper = live_region_1.default;
const mixed_line_bar_chart_1 = require("./mixed-line-bar-chart");
exports.MixedLineBarChartWrapper = mixed_line_bar_chart_1.default;
const modal_1 = require("./modal");
exports.ModalWrapper = modal_1.default;
const multiselect_1 = require("./multiselect");
exports.MultiselectWrapper = multiselect_1.default;
const navigable_group_1 = require("./navigable-group");
exports.NavigableGroupWrapper = navigable_group_1.default;
const pagination_1 = require("./pagination");
exports.PaginationWrapper = pagination_1.default;
const panel_layout_1 = require("./panel-layout");
exports.PanelLayoutWrapper = panel_layout_1.default;
const pie_chart_1 = require("./pie-chart");
exports.PieChartWrapper = pie_chart_1.default;
const popover_1 = require("./popover");
exports.PopoverWrapper = popover_1.default;
const progress_bar_1 = require("./progress-bar");
exports.ProgressBarWrapper = progress_bar_1.default;
const prompt_input_1 = require("./prompt-input");
exports.PromptInputWrapper = prompt_input_1.default;
const property_filter_1 = require("./property-filter");
exports.PropertyFilterWrapper = property_filter_1.default;
const radio_button_1 = require("./radio-button");
exports.RadioButtonWrapper = radio_button_1.default;
const radio_group_1 = require("./radio-group");
exports.RadioGroupWrapper = radio_group_1.default;
const s3_resource_selector_1 = require("./s3-resource-selector");
exports.S3ResourceSelectorWrapper = s3_resource_selector_1.default;
const segmented_control_1 = require("./segmented-control");
exports.SegmentedControlWrapper = segmented_control_1.default;
const select_1 = require("./select");
exports.SelectWrapper = select_1.default;
const side_navigation_1 = require("./side-navigation");
exports.SideNavigationWrapper = side_navigation_1.default;
const skeleton_1 = require("./skeleton");
exports.SkeletonWrapper = skeleton_1.default;
const slider_1 = require("./slider");
exports.SliderWrapper = slider_1.default;
const space_between_1 = require("./space-between");
exports.SpaceBetweenWrapper = space_between_1.default;
const spinner_1 = require("./spinner");
exports.SpinnerWrapper = spinner_1.default;
const split_panel_1 = require("./split-panel");
exports.SplitPanelWrapper = split_panel_1.default;
const status_indicator_1 = require("./status-indicator");
exports.StatusIndicatorWrapper = status_indicator_1.default;
const steps_1 = require("./steps");
exports.StepsWrapper = steps_1.default;
const table_1 = require("./table");
exports.TableWrapper = table_1.default;
const tabs_1 = require("./tabs");
exports.TabsWrapper = tabs_1.default;
const tag_editor_1 = require("./tag-editor");
exports.TagEditorWrapper = tag_editor_1.default;
const text_content_1 = require("./text-content");
exports.TextContentWrapper = text_content_1.default;
const text_filter_1 = require("./text-filter");
exports.TextFilterWrapper = text_filter_1.default;
const textarea_1 = require("./textarea");
exports.TextareaWrapper = textarea_1.default;
const tiles_1 = require("./tiles");
exports.TilesWrapper = tiles_1.default;
const time_input_1 = require("./time-input");
exports.TimeInputWrapper = time_input_1.default;
const toggle_1 = require("./toggle");
exports.ToggleWrapper = toggle_1.default;
const toggle_button_1 = require("./toggle-button");
exports.ToggleButtonWrapper = toggle_button_1.default;
const token_1 = require("./token");
exports.TokenWrapper = token_1.default;
const token_group_1 = require("./token-group");
exports.TokenGroupWrapper = token_group_1.default;
const tooltip_1 = require("./tooltip");
exports.TooltipWrapper = tooltip_1.default;
const top_navigation_1 = require("./top-navigation");
exports.TopNavigationWrapper = top_navigation_1.default;
const tree_view_1 = require("./tree-view");
exports.TreeViewWrapper = tree_view_1.default;
const tutorial_panel_1 = require("./tutorial-panel");
exports.TutorialPanelWrapper = tutorial_panel_1.default;
const wizard_1 = require("./wizard");
exports.WizardWrapper = wizard_1.default;
dom_1.ElementWrapper.prototype.findActionCard = function (selector) {
    let rootSelector = `.${action_card_1.default.rootSelector}`;
    if ("legacyRootSelector" in action_card_1.default && action_card_1.default.legacyRootSelector) {
        rootSelector = `:is(.${action_card_1.default.rootSelector}, .${action_card_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, action_card_1.default);
};
dom_1.ElementWrapper.prototype.findAllActionCards = function (selector) {
    return this.findAllComponents(action_card_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAlert = function (selector) {
    let rootSelector = `.${alert_1.default.rootSelector}`;
    if ("legacyRootSelector" in alert_1.default && alert_1.default.legacyRootSelector) {
        rootSelector = `:is(.${alert_1.default.rootSelector}, .${alert_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, alert_1.default);
};
dom_1.ElementWrapper.prototype.findAllAlerts = function (selector) {
    return this.findAllComponents(alert_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAnchorNavigation = function (selector) {
    let rootSelector = `.${anchor_navigation_1.default.rootSelector}`;
    if ("legacyRootSelector" in anchor_navigation_1.default && anchor_navigation_1.default.legacyRootSelector) {
        rootSelector = `:is(.${anchor_navigation_1.default.rootSelector}, .${anchor_navigation_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, anchor_navigation_1.default);
};
dom_1.ElementWrapper.prototype.findAllAnchorNavigations = function (selector) {
    return this.findAllComponents(anchor_navigation_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAnnotation = function (selector) {
    let rootSelector = `.${annotation_1.default.rootSelector}`;
    if ("legacyRootSelector" in annotation_1.default && annotation_1.default.legacyRootSelector) {
        rootSelector = `:is(.${annotation_1.default.rootSelector}, .${annotation_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, annotation_1.default);
};
dom_1.ElementWrapper.prototype.findAllAnnotations = function (selector) {
    return this.findAllComponents(annotation_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAppLayout = function (selector) {
    let rootSelector = `.${app_layout_1.default.rootSelector}`;
    if ("legacyRootSelector" in app_layout_1.default && app_layout_1.default.legacyRootSelector) {
        rootSelector = `:is(.${app_layout_1.default.rootSelector}, .${app_layout_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, app_layout_1.default);
};
dom_1.ElementWrapper.prototype.findAllAppLayouts = function (selector) {
    return this.findAllComponents(app_layout_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAppLayoutToolbar = function (selector) {
    let rootSelector = `.${app_layout_toolbar_1.default.rootSelector}`;
    if ("legacyRootSelector" in app_layout_toolbar_1.default && app_layout_toolbar_1.default.legacyRootSelector) {
        rootSelector = `:is(.${app_layout_toolbar_1.default.rootSelector}, .${app_layout_toolbar_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, app_layout_toolbar_1.default);
};
dom_1.ElementWrapper.prototype.findAllAppLayoutToolbars = function (selector) {
    return this.findAllComponents(app_layout_toolbar_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAreaChart = function (selector) {
    let rootSelector = `.${area_chart_1.default.rootSelector}`;
    if ("legacyRootSelector" in area_chart_1.default && area_chart_1.default.legacyRootSelector) {
        rootSelector = `:is(.${area_chart_1.default.rootSelector}, .${area_chart_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, area_chart_1.default);
};
dom_1.ElementWrapper.prototype.findAllAreaCharts = function (selector) {
    return this.findAllComponents(area_chart_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAttributeEditor = function (selector) {
    let rootSelector = `.${attribute_editor_1.default.rootSelector}`;
    if ("legacyRootSelector" in attribute_editor_1.default && attribute_editor_1.default.legacyRootSelector) {
        rootSelector = `:is(.${attribute_editor_1.default.rootSelector}, .${attribute_editor_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, attribute_editor_1.default);
};
dom_1.ElementWrapper.prototype.findAllAttributeEditors = function (selector) {
    return this.findAllComponents(attribute_editor_1.default, selector);
};
dom_1.ElementWrapper.prototype.findAutosuggest = function (selector) {
    let rootSelector = `.${autosuggest_1.default.rootSelector}`;
    if ("legacyRootSelector" in autosuggest_1.default && autosuggest_1.default.legacyRootSelector) {
        rootSelector = `:is(.${autosuggest_1.default.rootSelector}, .${autosuggest_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, autosuggest_1.default);
};
dom_1.ElementWrapper.prototype.findAllAutosuggests = function (selector) {
    return this.findAllComponents(autosuggest_1.default, selector);
};
dom_1.ElementWrapper.prototype.findBadge = function (selector) {
    let rootSelector = `.${badge_1.default.rootSelector}`;
    if ("legacyRootSelector" in badge_1.default && badge_1.default.legacyRootSelector) {
        rootSelector = `:is(.${badge_1.default.rootSelector}, .${badge_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, badge_1.default);
};
dom_1.ElementWrapper.prototype.findAllBadges = function (selector) {
    return this.findAllComponents(badge_1.default, selector);
};
dom_1.ElementWrapper.prototype.findBarChart = function (selector) {
    let rootSelector = `.${bar_chart_1.default.rootSelector}`;
    if ("legacyRootSelector" in bar_chart_1.default && bar_chart_1.default.legacyRootSelector) {
        rootSelector = `:is(.${bar_chart_1.default.rootSelector}, .${bar_chart_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, bar_chart_1.default);
};
dom_1.ElementWrapper.prototype.findAllBarCharts = function (selector) {
    return this.findAllComponents(bar_chart_1.default, selector);
};
dom_1.ElementWrapper.prototype.findBox = function (selector) {
    let rootSelector = `.${box_1.default.rootSelector}`;
    if ("legacyRootSelector" in box_1.default && box_1.default.legacyRootSelector) {
        rootSelector = `:is(.${box_1.default.rootSelector}, .${box_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, box_1.default);
};
dom_1.ElementWrapper.prototype.findAllBoxes = function (selector) {
    return this.findAllComponents(box_1.default, selector);
};
dom_1.ElementWrapper.prototype.findBreadcrumbGroup = function (selector) {
    let rootSelector = `.${breadcrumb_group_1.default.rootSelector}`;
    if ("legacyRootSelector" in breadcrumb_group_1.default && breadcrumb_group_1.default.legacyRootSelector) {
        rootSelector = `:is(.${breadcrumb_group_1.default.rootSelector}, .${breadcrumb_group_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, breadcrumb_group_1.default);
};
dom_1.ElementWrapper.prototype.findAllBreadcrumbGroups = function (selector) {
    return this.findAllComponents(breadcrumb_group_1.default, selector);
};
dom_1.ElementWrapper.prototype.findButton = function (selector) {
    let rootSelector = `.${button_1.default.rootSelector}`;
    if ("legacyRootSelector" in button_1.default && button_1.default.legacyRootSelector) {
        rootSelector = `:is(.${button_1.default.rootSelector}, .${button_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, button_1.default);
};
dom_1.ElementWrapper.prototype.findAllButtons = function (selector) {
    return this.findAllComponents(button_1.default, selector);
};
dom_1.ElementWrapper.prototype.findButtonDropdown = function (selector) {
    let rootSelector = `.${button_dropdown_1.default.rootSelector}`;
    if ("legacyRootSelector" in button_dropdown_1.default && button_dropdown_1.default.legacyRootSelector) {
        rootSelector = `:is(.${button_dropdown_1.default.rootSelector}, .${button_dropdown_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, button_dropdown_1.default);
};
dom_1.ElementWrapper.prototype.findAllButtonDropdowns = function (selector) {
    return this.findAllComponents(button_dropdown_1.default, selector);
};
dom_1.ElementWrapper.prototype.findButtonGroup = function (selector) {
    let rootSelector = `.${button_group_1.default.rootSelector}`;
    if ("legacyRootSelector" in button_group_1.default && button_group_1.default.legacyRootSelector) {
        rootSelector = `:is(.${button_group_1.default.rootSelector}, .${button_group_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, button_group_1.default);
};
dom_1.ElementWrapper.prototype.findAllButtonGroups = function (selector) {
    return this.findAllComponents(button_group_1.default, selector);
};
dom_1.ElementWrapper.prototype.findCalendar = function (selector) {
    let rootSelector = `.${calendar_1.default.rootSelector}`;
    if ("legacyRootSelector" in calendar_1.default && calendar_1.default.legacyRootSelector) {
        rootSelector = `:is(.${calendar_1.default.rootSelector}, .${calendar_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, calendar_1.default);
};
dom_1.ElementWrapper.prototype.findAllCalendars = function (selector) {
    return this.findAllComponents(calendar_1.default, selector);
};
dom_1.ElementWrapper.prototype.findCards = function (selector) {
    let rootSelector = `.${cards_1.default.rootSelector}`;
    if ("legacyRootSelector" in cards_1.default && cards_1.default.legacyRootSelector) {
        rootSelector = `:is(.${cards_1.default.rootSelector}, .${cards_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, cards_1.default);
};
dom_1.ElementWrapper.prototype.findAllCards = function (selector) {
    return this.findAllComponents(cards_1.default, selector);
};
dom_1.ElementWrapper.prototype.findCheckbox = function (selector) {
    let rootSelector = `.${checkbox_1.default.rootSelector}`;
    if ("legacyRootSelector" in checkbox_1.default && checkbox_1.default.legacyRootSelector) {
        rootSelector = `:is(.${checkbox_1.default.rootSelector}, .${checkbox_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, checkbox_1.default);
};
dom_1.ElementWrapper.prototype.findAllCheckboxes = function (selector) {
    return this.findAllComponents(checkbox_1.default, selector);
};
dom_1.ElementWrapper.prototype.findCodeEditor = function (selector) {
    let rootSelector = `.${code_editor_1.default.rootSelector}`;
    if ("legacyRootSelector" in code_editor_1.default && code_editor_1.default.legacyRootSelector) {
        rootSelector = `:is(.${code_editor_1.default.rootSelector}, .${code_editor_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, code_editor_1.default);
};
dom_1.ElementWrapper.prototype.findAllCodeEditors = function (selector) {
    return this.findAllComponents(code_editor_1.default, selector);
};
dom_1.ElementWrapper.prototype.findCollectionPreferences = function (selector) {
    let rootSelector = `.${collection_preferences_1.default.rootSelector}`;
    if ("legacyRootSelector" in collection_preferences_1.default && collection_preferences_1.default.legacyRootSelector) {
        rootSelector = `:is(.${collection_preferences_1.default.rootSelector}, .${collection_preferences_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, collection_preferences_1.default);
};
dom_1.ElementWrapper.prototype.findAllCollectionPreferences = function (selector) {
    return this.findAllComponents(collection_preferences_1.default, selector);
};
dom_1.ElementWrapper.prototype.findColumnLayout = function (selector) {
    let rootSelector = `.${column_layout_1.default.rootSelector}`;
    if ("legacyRootSelector" in column_layout_1.default && column_layout_1.default.legacyRootSelector) {
        rootSelector = `:is(.${column_layout_1.default.rootSelector}, .${column_layout_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, column_layout_1.default);
};
dom_1.ElementWrapper.prototype.findAllColumnLayouts = function (selector) {
    return this.findAllComponents(column_layout_1.default, selector);
};
dom_1.ElementWrapper.prototype.findContainer = function (selector) {
    let rootSelector = `.${container_1.default.rootSelector}`;
    if ("legacyRootSelector" in container_1.default && container_1.default.legacyRootSelector) {
        rootSelector = `:is(.${container_1.default.rootSelector}, .${container_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, container_1.default);
};
dom_1.ElementWrapper.prototype.findAllContainers = function (selector) {
    return this.findAllComponents(container_1.default, selector);
};
dom_1.ElementWrapper.prototype.findContentLayout = function (selector) {
    let rootSelector = `.${content_layout_1.default.rootSelector}`;
    if ("legacyRootSelector" in content_layout_1.default && content_layout_1.default.legacyRootSelector) {
        rootSelector = `:is(.${content_layout_1.default.rootSelector}, .${content_layout_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, content_layout_1.default);
};
dom_1.ElementWrapper.prototype.findAllContentLayouts = function (selector) {
    return this.findAllComponents(content_layout_1.default, selector);
};
dom_1.ElementWrapper.prototype.findCopyToClipboard = function (selector) {
    let rootSelector = `.${copy_to_clipboard_1.default.rootSelector}`;
    if ("legacyRootSelector" in copy_to_clipboard_1.default && copy_to_clipboard_1.default.legacyRootSelector) {
        rootSelector = `:is(.${copy_to_clipboard_1.default.rootSelector}, .${copy_to_clipboard_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, copy_to_clipboard_1.default);
};
dom_1.ElementWrapper.prototype.findAllCopyToClipboards = function (selector) {
    return this.findAllComponents(copy_to_clipboard_1.default, selector);
};
dom_1.ElementWrapper.prototype.findDateInput = function (selector) {
    let rootSelector = `.${date_input_1.default.rootSelector}`;
    if ("legacyRootSelector" in date_input_1.default && date_input_1.default.legacyRootSelector) {
        rootSelector = `:is(.${date_input_1.default.rootSelector}, .${date_input_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, date_input_1.default);
};
dom_1.ElementWrapper.prototype.findAllDateInputs = function (selector) {
    return this.findAllComponents(date_input_1.default, selector);
};
dom_1.ElementWrapper.prototype.findDatePicker = function (selector) {
    let rootSelector = `.${date_picker_1.default.rootSelector}`;
    if ("legacyRootSelector" in date_picker_1.default && date_picker_1.default.legacyRootSelector) {
        rootSelector = `:is(.${date_picker_1.default.rootSelector}, .${date_picker_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, date_picker_1.default);
};
dom_1.ElementWrapper.prototype.findAllDatePickers = function (selector) {
    return this.findAllComponents(date_picker_1.default, selector);
};
dom_1.ElementWrapper.prototype.findDateRangePicker = function (selector) {
    let rootSelector = `.${date_range_picker_1.default.rootSelector}`;
    if ("legacyRootSelector" in date_range_picker_1.default && date_range_picker_1.default.legacyRootSelector) {
        rootSelector = `:is(.${date_range_picker_1.default.rootSelector}, .${date_range_picker_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, date_range_picker_1.default);
};
dom_1.ElementWrapper.prototype.findAllDateRangePickers = function (selector) {
    return this.findAllComponents(date_range_picker_1.default, selector);
};
dom_1.ElementWrapper.prototype.findDivider = function (selector) {
    let rootSelector = `.${divider_1.default.rootSelector}`;
    if ("legacyRootSelector" in divider_1.default && divider_1.default.legacyRootSelector) {
        rootSelector = `:is(.${divider_1.default.rootSelector}, .${divider_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, divider_1.default);
};
dom_1.ElementWrapper.prototype.findAllDividers = function (selector) {
    return this.findAllComponents(divider_1.default, selector);
};
dom_1.ElementWrapper.prototype.findDrawer = function (selector) {
    let rootSelector = `.${drawer_1.default.rootSelector}`;
    if ("legacyRootSelector" in drawer_1.default && drawer_1.default.legacyRootSelector) {
        rootSelector = `:is(.${drawer_1.default.rootSelector}, .${drawer_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, drawer_1.default);
};
dom_1.ElementWrapper.prototype.findAllDrawers = function (selector) {
    return this.findAllComponents(drawer_1.default, selector);
};
dom_1.ElementWrapper.prototype.findDropdown = function (selector) {
    let rootSelector = `.${dropdown_1.default.rootSelector}`;
    if ("legacyRootSelector" in dropdown_1.default && dropdown_1.default.legacyRootSelector) {
        rootSelector = `:is(.${dropdown_1.default.rootSelector}, .${dropdown_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, dropdown_1.default);
};
dom_1.ElementWrapper.prototype.findAllDropdowns = function (selector) {
    return this.findAllComponents(dropdown_1.default, selector);
};
dom_1.ElementWrapper.prototype.findErrorBoundary = function (selector) {
    let rootSelector = `.${error_boundary_1.default.rootSelector}`;
    if ("legacyRootSelector" in error_boundary_1.default && error_boundary_1.default.legacyRootSelector) {
        rootSelector = `:is(.${error_boundary_1.default.rootSelector}, .${error_boundary_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, error_boundary_1.default);
};
dom_1.ElementWrapper.prototype.findAllErrorBoundaries = function (selector) {
    return this.findAllComponents(error_boundary_1.default, selector);
};
dom_1.ElementWrapper.prototype.findExpandableSection = function (selector) {
    let rootSelector = `.${expandable_section_1.default.rootSelector}`;
    if ("legacyRootSelector" in expandable_section_1.default && expandable_section_1.default.legacyRootSelector) {
        rootSelector = `:is(.${expandable_section_1.default.rootSelector}, .${expandable_section_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, expandable_section_1.default);
};
dom_1.ElementWrapper.prototype.findAllExpandableSections = function (selector) {
    return this.findAllComponents(expandable_section_1.default, selector);
};
dom_1.ElementWrapper.prototype.findFileDropzone = function (selector) {
    let rootSelector = `.${file_dropzone_1.default.rootSelector}`;
    if ("legacyRootSelector" in file_dropzone_1.default && file_dropzone_1.default.legacyRootSelector) {
        rootSelector = `:is(.${file_dropzone_1.default.rootSelector}, .${file_dropzone_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, file_dropzone_1.default);
};
dom_1.ElementWrapper.prototype.findAllFileDropzones = function (selector) {
    return this.findAllComponents(file_dropzone_1.default, selector);
};
dom_1.ElementWrapper.prototype.findFileInput = function (selector) {
    let rootSelector = `.${file_input_1.default.rootSelector}`;
    if ("legacyRootSelector" in file_input_1.default && file_input_1.default.legacyRootSelector) {
        rootSelector = `:is(.${file_input_1.default.rootSelector}, .${file_input_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, file_input_1.default);
};
dom_1.ElementWrapper.prototype.findAllFileInputs = function (selector) {
    return this.findAllComponents(file_input_1.default, selector);
};
dom_1.ElementWrapper.prototype.findFileTokenGroup = function (selector) {
    let rootSelector = `.${file_token_group_1.default.rootSelector}`;
    if ("legacyRootSelector" in file_token_group_1.default && file_token_group_1.default.legacyRootSelector) {
        rootSelector = `:is(.${file_token_group_1.default.rootSelector}, .${file_token_group_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, file_token_group_1.default);
};
dom_1.ElementWrapper.prototype.findAllFileTokenGroups = function (selector) {
    return this.findAllComponents(file_token_group_1.default, selector);
};
dom_1.ElementWrapper.prototype.findFileUpload = function (selector) {
    let rootSelector = `.${file_upload_1.default.rootSelector}`;
    if ("legacyRootSelector" in file_upload_1.default && file_upload_1.default.legacyRootSelector) {
        rootSelector = `:is(.${file_upload_1.default.rootSelector}, .${file_upload_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, file_upload_1.default);
};
dom_1.ElementWrapper.prototype.findAllFileUploads = function (selector) {
    return this.findAllComponents(file_upload_1.default, selector);
};
dom_1.ElementWrapper.prototype.findFlashbar = function (selector) {
    let rootSelector = `.${flashbar_1.default.rootSelector}`;
    if ("legacyRootSelector" in flashbar_1.default && flashbar_1.default.legacyRootSelector) {
        rootSelector = `:is(.${flashbar_1.default.rootSelector}, .${flashbar_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, flashbar_1.default);
};
dom_1.ElementWrapper.prototype.findAllFlashbars = function (selector) {
    return this.findAllComponents(flashbar_1.default, selector);
};
dom_1.ElementWrapper.prototype.findForm = function (selector) {
    let rootSelector = `.${form_1.default.rootSelector}`;
    if ("legacyRootSelector" in form_1.default && form_1.default.legacyRootSelector) {
        rootSelector = `:is(.${form_1.default.rootSelector}, .${form_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, form_1.default);
};
dom_1.ElementWrapper.prototype.findAllForms = function (selector) {
    return this.findAllComponents(form_1.default, selector);
};
dom_1.ElementWrapper.prototype.findFormField = function (selector) {
    let rootSelector = `.${form_field_1.default.rootSelector}`;
    if ("legacyRootSelector" in form_field_1.default && form_field_1.default.legacyRootSelector) {
        rootSelector = `:is(.${form_field_1.default.rootSelector}, .${form_field_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, form_field_1.default);
};
dom_1.ElementWrapper.prototype.findAllFormFields = function (selector) {
    return this.findAllComponents(form_field_1.default, selector);
};
dom_1.ElementWrapper.prototype.findGrid = function (selector) {
    let rootSelector = `.${grid_1.default.rootSelector}`;
    if ("legacyRootSelector" in grid_1.default && grid_1.default.legacyRootSelector) {
        rootSelector = `:is(.${grid_1.default.rootSelector}, .${grid_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, grid_1.default);
};
dom_1.ElementWrapper.prototype.findAllGrids = function (selector) {
    return this.findAllComponents(grid_1.default, selector);
};
dom_1.ElementWrapper.prototype.findHeader = function (selector) {
    let rootSelector = `.${header_1.default.rootSelector}`;
    if ("legacyRootSelector" in header_1.default && header_1.default.legacyRootSelector) {
        rootSelector = `:is(.${header_1.default.rootSelector}, .${header_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, header_1.default);
};
dom_1.ElementWrapper.prototype.findAllHeaders = function (selector) {
    return this.findAllComponents(header_1.default, selector);
};
dom_1.ElementWrapper.prototype.findHelpPanel = function (selector) {
    let rootSelector = `.${help_panel_1.default.rootSelector}`;
    if ("legacyRootSelector" in help_panel_1.default && help_panel_1.default.legacyRootSelector) {
        rootSelector = `:is(.${help_panel_1.default.rootSelector}, .${help_panel_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, help_panel_1.default);
};
dom_1.ElementWrapper.prototype.findAllHelpPanels = function (selector) {
    return this.findAllComponents(help_panel_1.default, selector);
};
dom_1.ElementWrapper.prototype.findHotspot = function (selector) {
    let rootSelector = `.${hotspot_1.default.rootSelector}`;
    if ("legacyRootSelector" in hotspot_1.default && hotspot_1.default.legacyRootSelector) {
        rootSelector = `:is(.${hotspot_1.default.rootSelector}, .${hotspot_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, hotspot_1.default);
};
dom_1.ElementWrapper.prototype.findAllHotspots = function (selector) {
    return this.findAllComponents(hotspot_1.default, selector);
};
dom_1.ElementWrapper.prototype.findIcon = function (selector) {
    let rootSelector = `.${icon_1.default.rootSelector}`;
    if ("legacyRootSelector" in icon_1.default && icon_1.default.legacyRootSelector) {
        rootSelector = `:is(.${icon_1.default.rootSelector}, .${icon_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, icon_1.default);
};
dom_1.ElementWrapper.prototype.findAllIcons = function (selector) {
    return this.findAllComponents(icon_1.default, selector);
};
dom_1.ElementWrapper.prototype.findInput = function (selector) {
    let rootSelector = `.${input_1.default.rootSelector}`;
    if ("legacyRootSelector" in input_1.default && input_1.default.legacyRootSelector) {
        rootSelector = `:is(.${input_1.default.rootSelector}, .${input_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, input_1.default);
};
dom_1.ElementWrapper.prototype.findAllInputs = function (selector) {
    return this.findAllComponents(input_1.default, selector);
};
dom_1.ElementWrapper.prototype.findItemCard = function (selector) {
    let rootSelector = `.${item_card_1.default.rootSelector}`;
    if ("legacyRootSelector" in item_card_1.default && item_card_1.default.legacyRootSelector) {
        rootSelector = `:is(.${item_card_1.default.rootSelector}, .${item_card_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, item_card_1.default);
};
dom_1.ElementWrapper.prototype.findAllItemCards = function (selector) {
    return this.findAllComponents(item_card_1.default, selector);
};
dom_1.ElementWrapper.prototype.findKeyValuePairs = function (selector) {
    let rootSelector = `.${key_value_pairs_1.default.rootSelector}`;
    if ("legacyRootSelector" in key_value_pairs_1.default && key_value_pairs_1.default.legacyRootSelector) {
        rootSelector = `:is(.${key_value_pairs_1.default.rootSelector}, .${key_value_pairs_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, key_value_pairs_1.default);
};
dom_1.ElementWrapper.prototype.findAllKeyValuePairs = function (selector) {
    return this.findAllComponents(key_value_pairs_1.default, selector);
};
dom_1.ElementWrapper.prototype.findLineChart = function (selector) {
    let rootSelector = `.${line_chart_1.default.rootSelector}`;
    if ("legacyRootSelector" in line_chart_1.default && line_chart_1.default.legacyRootSelector) {
        rootSelector = `:is(.${line_chart_1.default.rootSelector}, .${line_chart_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, line_chart_1.default);
};
dom_1.ElementWrapper.prototype.findAllLineCharts = function (selector) {
    return this.findAllComponents(line_chart_1.default, selector);
};
dom_1.ElementWrapper.prototype.findLink = function (selector) {
    let rootSelector = `.${link_1.default.rootSelector}`;
    if ("legacyRootSelector" in link_1.default && link_1.default.legacyRootSelector) {
        rootSelector = `:is(.${link_1.default.rootSelector}, .${link_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, link_1.default);
};
dom_1.ElementWrapper.prototype.findAllLinks = function (selector) {
    return this.findAllComponents(link_1.default, selector);
};
dom_1.ElementWrapper.prototype.findList = function (selector) {
    let rootSelector = `.${list_1.default.rootSelector}`;
    if ("legacyRootSelector" in list_1.default && list_1.default.legacyRootSelector) {
        rootSelector = `:is(.${list_1.default.rootSelector}, .${list_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, list_1.default);
};
dom_1.ElementWrapper.prototype.findAllLists = function (selector) {
    return this.findAllComponents(list_1.default, selector);
};
dom_1.ElementWrapper.prototype.findLiveRegion = function (selector) {
    let rootSelector = `.${live_region_1.default.rootSelector}`;
    if ("legacyRootSelector" in live_region_1.default && live_region_1.default.legacyRootSelector) {
        rootSelector = `:is(.${live_region_1.default.rootSelector}, .${live_region_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, live_region_1.default);
};
dom_1.ElementWrapper.prototype.findAllLiveRegions = function (selector) {
    return this.findAllComponents(live_region_1.default, selector);
};
dom_1.ElementWrapper.prototype.findMixedLineBarChart = function (selector) {
    let rootSelector = `.${mixed_line_bar_chart_1.default.rootSelector}`;
    if ("legacyRootSelector" in mixed_line_bar_chart_1.default && mixed_line_bar_chart_1.default.legacyRootSelector) {
        rootSelector = `:is(.${mixed_line_bar_chart_1.default.rootSelector}, .${mixed_line_bar_chart_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, mixed_line_bar_chart_1.default);
};
dom_1.ElementWrapper.prototype.findAllMixedLineBarCharts = function (selector) {
    return this.findAllComponents(mixed_line_bar_chart_1.default, selector);
};
dom_1.ElementWrapper.prototype.findModal = function (selector) {
    let rootSelector = `.${modal_1.default.rootSelector}`;
    if ("legacyRootSelector" in modal_1.default && modal_1.default.legacyRootSelector) {
        rootSelector = `:is(.${modal_1.default.rootSelector}, .${modal_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, modal_1.default);
};
dom_1.ElementWrapper.prototype.findAllModals = function (selector) {
    return this.findAllComponents(modal_1.default, selector);
};
dom_1.ElementWrapper.prototype.findMultiselect = function (selector) {
    let rootSelector = `.${multiselect_1.default.rootSelector}`;
    if ("legacyRootSelector" in multiselect_1.default && multiselect_1.default.legacyRootSelector) {
        rootSelector = `:is(.${multiselect_1.default.rootSelector}, .${multiselect_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, multiselect_1.default);
};
dom_1.ElementWrapper.prototype.findAllMultiselects = function (selector) {
    return this.findAllComponents(multiselect_1.default, selector);
};
dom_1.ElementWrapper.prototype.findNavigableGroup = function (selector) {
    let rootSelector = `.${navigable_group_1.default.rootSelector}`;
    if ("legacyRootSelector" in navigable_group_1.default && navigable_group_1.default.legacyRootSelector) {
        rootSelector = `:is(.${navigable_group_1.default.rootSelector}, .${navigable_group_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, navigable_group_1.default);
};
dom_1.ElementWrapper.prototype.findAllNavigableGroups = function (selector) {
    return this.findAllComponents(navigable_group_1.default, selector);
};
dom_1.ElementWrapper.prototype.findPagination = function (selector) {
    let rootSelector = `.${pagination_1.default.rootSelector}`;
    if ("legacyRootSelector" in pagination_1.default && pagination_1.default.legacyRootSelector) {
        rootSelector = `:is(.${pagination_1.default.rootSelector}, .${pagination_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, pagination_1.default);
};
dom_1.ElementWrapper.prototype.findAllPaginations = function (selector) {
    return this.findAllComponents(pagination_1.default, selector);
};
dom_1.ElementWrapper.prototype.findPanelLayout = function (selector) {
    let rootSelector = `.${panel_layout_1.default.rootSelector}`;
    if ("legacyRootSelector" in panel_layout_1.default && panel_layout_1.default.legacyRootSelector) {
        rootSelector = `:is(.${panel_layout_1.default.rootSelector}, .${panel_layout_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, panel_layout_1.default);
};
dom_1.ElementWrapper.prototype.findAllPanelLayouts = function (selector) {
    return this.findAllComponents(panel_layout_1.default, selector);
};
dom_1.ElementWrapper.prototype.findPieChart = function (selector) {
    let rootSelector = `.${pie_chart_1.default.rootSelector}`;
    if ("legacyRootSelector" in pie_chart_1.default && pie_chart_1.default.legacyRootSelector) {
        rootSelector = `:is(.${pie_chart_1.default.rootSelector}, .${pie_chart_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, pie_chart_1.default);
};
dom_1.ElementWrapper.prototype.findAllPieCharts = function (selector) {
    return this.findAllComponents(pie_chart_1.default, selector);
};
dom_1.ElementWrapper.prototype.findPopover = function (selector) {
    let rootSelector = `.${popover_1.default.rootSelector}`;
    if ("legacyRootSelector" in popover_1.default && popover_1.default.legacyRootSelector) {
        rootSelector = `:is(.${popover_1.default.rootSelector}, .${popover_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, popover_1.default);
};
dom_1.ElementWrapper.prototype.findAllPopovers = function (selector) {
    return this.findAllComponents(popover_1.default, selector);
};
dom_1.ElementWrapper.prototype.findProgressBar = function (selector) {
    let rootSelector = `.${progress_bar_1.default.rootSelector}`;
    if ("legacyRootSelector" in progress_bar_1.default && progress_bar_1.default.legacyRootSelector) {
        rootSelector = `:is(.${progress_bar_1.default.rootSelector}, .${progress_bar_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, progress_bar_1.default);
};
dom_1.ElementWrapper.prototype.findAllProgressBars = function (selector) {
    return this.findAllComponents(progress_bar_1.default, selector);
};
dom_1.ElementWrapper.prototype.findPromptInput = function (selector) {
    let rootSelector = `.${prompt_input_1.default.rootSelector}`;
    if ("legacyRootSelector" in prompt_input_1.default && prompt_input_1.default.legacyRootSelector) {
        rootSelector = `:is(.${prompt_input_1.default.rootSelector}, .${prompt_input_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, prompt_input_1.default);
};
dom_1.ElementWrapper.prototype.findAllPromptInputs = function (selector) {
    return this.findAllComponents(prompt_input_1.default, selector);
};
dom_1.ElementWrapper.prototype.findPropertyFilter = function (selector) {
    let rootSelector = `.${property_filter_1.default.rootSelector}`;
    if ("legacyRootSelector" in property_filter_1.default && property_filter_1.default.legacyRootSelector) {
        rootSelector = `:is(.${property_filter_1.default.rootSelector}, .${property_filter_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, property_filter_1.default);
};
dom_1.ElementWrapper.prototype.findAllPropertyFilters = function (selector) {
    return this.findAllComponents(property_filter_1.default, selector);
};
dom_1.ElementWrapper.prototype.findRadioButton = function (selector) {
    let rootSelector = `.${radio_button_1.default.rootSelector}`;
    if ("legacyRootSelector" in radio_button_1.default && radio_button_1.default.legacyRootSelector) {
        rootSelector = `:is(.${radio_button_1.default.rootSelector}, .${radio_button_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, radio_button_1.default);
};
dom_1.ElementWrapper.prototype.findAllRadioButtons = function (selector) {
    return this.findAllComponents(radio_button_1.default, selector);
};
dom_1.ElementWrapper.prototype.findRadioGroup = function (selector) {
    let rootSelector = `.${radio_group_1.default.rootSelector}`;
    if ("legacyRootSelector" in radio_group_1.default && radio_group_1.default.legacyRootSelector) {
        rootSelector = `:is(.${radio_group_1.default.rootSelector}, .${radio_group_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, radio_group_1.default);
};
dom_1.ElementWrapper.prototype.findAllRadioGroups = function (selector) {
    return this.findAllComponents(radio_group_1.default, selector);
};
dom_1.ElementWrapper.prototype.findS3ResourceSelector = function (selector) {
    let rootSelector = `.${s3_resource_selector_1.default.rootSelector}`;
    if ("legacyRootSelector" in s3_resource_selector_1.default && s3_resource_selector_1.default.legacyRootSelector) {
        rootSelector = `:is(.${s3_resource_selector_1.default.rootSelector}, .${s3_resource_selector_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, s3_resource_selector_1.default);
};
dom_1.ElementWrapper.prototype.findAllS3ResourceSelectors = function (selector) {
    return this.findAllComponents(s3_resource_selector_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSegmentedControl = function (selector) {
    let rootSelector = `.${segmented_control_1.default.rootSelector}`;
    if ("legacyRootSelector" in segmented_control_1.default && segmented_control_1.default.legacyRootSelector) {
        rootSelector = `:is(.${segmented_control_1.default.rootSelector}, .${segmented_control_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, segmented_control_1.default);
};
dom_1.ElementWrapper.prototype.findAllSegmentedControls = function (selector) {
    return this.findAllComponents(segmented_control_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSelect = function (selector) {
    let rootSelector = `.${select_1.default.rootSelector}`;
    if ("legacyRootSelector" in select_1.default && select_1.default.legacyRootSelector) {
        rootSelector = `:is(.${select_1.default.rootSelector}, .${select_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, select_1.default);
};
dom_1.ElementWrapper.prototype.findAllSelects = function (selector) {
    return this.findAllComponents(select_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSideNavigation = function (selector) {
    let rootSelector = `.${side_navigation_1.default.rootSelector}`;
    if ("legacyRootSelector" in side_navigation_1.default && side_navigation_1.default.legacyRootSelector) {
        rootSelector = `:is(.${side_navigation_1.default.rootSelector}, .${side_navigation_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, side_navigation_1.default);
};
dom_1.ElementWrapper.prototype.findAllSideNavigations = function (selector) {
    return this.findAllComponents(side_navigation_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSkeleton = function (selector) {
    let rootSelector = `.${skeleton_1.default.rootSelector}`;
    if ("legacyRootSelector" in skeleton_1.default && skeleton_1.default.legacyRootSelector) {
        rootSelector = `:is(.${skeleton_1.default.rootSelector}, .${skeleton_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, skeleton_1.default);
};
dom_1.ElementWrapper.prototype.findAllSkeletons = function (selector) {
    return this.findAllComponents(skeleton_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSlider = function (selector) {
    let rootSelector = `.${slider_1.default.rootSelector}`;
    if ("legacyRootSelector" in slider_1.default && slider_1.default.legacyRootSelector) {
        rootSelector = `:is(.${slider_1.default.rootSelector}, .${slider_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, slider_1.default);
};
dom_1.ElementWrapper.prototype.findAllSliders = function (selector) {
    return this.findAllComponents(slider_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSpaceBetween = function (selector) {
    let rootSelector = `.${space_between_1.default.rootSelector}`;
    if ("legacyRootSelector" in space_between_1.default && space_between_1.default.legacyRootSelector) {
        rootSelector = `:is(.${space_between_1.default.rootSelector}, .${space_between_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, space_between_1.default);
};
dom_1.ElementWrapper.prototype.findAllSpaceBetweens = function (selector) {
    return this.findAllComponents(space_between_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSpinner = function (selector) {
    let rootSelector = `.${spinner_1.default.rootSelector}`;
    if ("legacyRootSelector" in spinner_1.default && spinner_1.default.legacyRootSelector) {
        rootSelector = `:is(.${spinner_1.default.rootSelector}, .${spinner_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, spinner_1.default);
};
dom_1.ElementWrapper.prototype.findAllSpinners = function (selector) {
    return this.findAllComponents(spinner_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSplitPanel = function (selector) {
    let rootSelector = `.${split_panel_1.default.rootSelector}`;
    if ("legacyRootSelector" in split_panel_1.default && split_panel_1.default.legacyRootSelector) {
        rootSelector = `:is(.${split_panel_1.default.rootSelector}, .${split_panel_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, split_panel_1.default);
};
dom_1.ElementWrapper.prototype.findAllSplitPanels = function (selector) {
    return this.findAllComponents(split_panel_1.default, selector);
};
dom_1.ElementWrapper.prototype.findStatusIndicator = function (selector) {
    let rootSelector = `.${status_indicator_1.default.rootSelector}`;
    if ("legacyRootSelector" in status_indicator_1.default && status_indicator_1.default.legacyRootSelector) {
        rootSelector = `:is(.${status_indicator_1.default.rootSelector}, .${status_indicator_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, status_indicator_1.default);
};
dom_1.ElementWrapper.prototype.findAllStatusIndicators = function (selector) {
    return this.findAllComponents(status_indicator_1.default, selector);
};
dom_1.ElementWrapper.prototype.findSteps = function (selector) {
    let rootSelector = `.${steps_1.default.rootSelector}`;
    if ("legacyRootSelector" in steps_1.default && steps_1.default.legacyRootSelector) {
        rootSelector = `:is(.${steps_1.default.rootSelector}, .${steps_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, steps_1.default);
};
dom_1.ElementWrapper.prototype.findAllSteps = function (selector) {
    return this.findAllComponents(steps_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTable = function (selector) {
    let rootSelector = `.${table_1.default.rootSelector}`;
    if ("legacyRootSelector" in table_1.default && table_1.default.legacyRootSelector) {
        rootSelector = `:is(.${table_1.default.rootSelector}, .${table_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, table_1.default);
};
dom_1.ElementWrapper.prototype.findAllTables = function (selector) {
    return this.findAllComponents(table_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTabs = function (selector) {
    let rootSelector = `.${tabs_1.default.rootSelector}`;
    if ("legacyRootSelector" in tabs_1.default && tabs_1.default.legacyRootSelector) {
        rootSelector = `:is(.${tabs_1.default.rootSelector}, .${tabs_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, tabs_1.default);
};
dom_1.ElementWrapper.prototype.findAllTabs = function (selector) {
    return this.findAllComponents(tabs_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTagEditor = function (selector) {
    let rootSelector = `.${tag_editor_1.default.rootSelector}`;
    if ("legacyRootSelector" in tag_editor_1.default && tag_editor_1.default.legacyRootSelector) {
        rootSelector = `:is(.${tag_editor_1.default.rootSelector}, .${tag_editor_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, tag_editor_1.default);
};
dom_1.ElementWrapper.prototype.findAllTagEditors = function (selector) {
    return this.findAllComponents(tag_editor_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTextContent = function (selector) {
    let rootSelector = `.${text_content_1.default.rootSelector}`;
    if ("legacyRootSelector" in text_content_1.default && text_content_1.default.legacyRootSelector) {
        rootSelector = `:is(.${text_content_1.default.rootSelector}, .${text_content_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, text_content_1.default);
};
dom_1.ElementWrapper.prototype.findAllTextContents = function (selector) {
    return this.findAllComponents(text_content_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTextFilter = function (selector) {
    let rootSelector = `.${text_filter_1.default.rootSelector}`;
    if ("legacyRootSelector" in text_filter_1.default && text_filter_1.default.legacyRootSelector) {
        rootSelector = `:is(.${text_filter_1.default.rootSelector}, .${text_filter_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, text_filter_1.default);
};
dom_1.ElementWrapper.prototype.findAllTextFilters = function (selector) {
    return this.findAllComponents(text_filter_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTextarea = function (selector) {
    let rootSelector = `.${textarea_1.default.rootSelector}`;
    if ("legacyRootSelector" in textarea_1.default && textarea_1.default.legacyRootSelector) {
        rootSelector = `:is(.${textarea_1.default.rootSelector}, .${textarea_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, textarea_1.default);
};
dom_1.ElementWrapper.prototype.findAllTextareas = function (selector) {
    return this.findAllComponents(textarea_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTiles = function (selector) {
    let rootSelector = `.${tiles_1.default.rootSelector}`;
    if ("legacyRootSelector" in tiles_1.default && tiles_1.default.legacyRootSelector) {
        rootSelector = `:is(.${tiles_1.default.rootSelector}, .${tiles_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, tiles_1.default);
};
dom_1.ElementWrapper.prototype.findAllTiles = function (selector) {
    return this.findAllComponents(tiles_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTimeInput = function (selector) {
    let rootSelector = `.${time_input_1.default.rootSelector}`;
    if ("legacyRootSelector" in time_input_1.default && time_input_1.default.legacyRootSelector) {
        rootSelector = `:is(.${time_input_1.default.rootSelector}, .${time_input_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, time_input_1.default);
};
dom_1.ElementWrapper.prototype.findAllTimeInputs = function (selector) {
    return this.findAllComponents(time_input_1.default, selector);
};
dom_1.ElementWrapper.prototype.findToggle = function (selector) {
    let rootSelector = `.${toggle_1.default.rootSelector}`;
    if ("legacyRootSelector" in toggle_1.default && toggle_1.default.legacyRootSelector) {
        rootSelector = `:is(.${toggle_1.default.rootSelector}, .${toggle_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, toggle_1.default);
};
dom_1.ElementWrapper.prototype.findAllToggles = function (selector) {
    return this.findAllComponents(toggle_1.default, selector);
};
dom_1.ElementWrapper.prototype.findToggleButton = function (selector) {
    let rootSelector = `.${toggle_button_1.default.rootSelector}`;
    if ("legacyRootSelector" in toggle_button_1.default && toggle_button_1.default.legacyRootSelector) {
        rootSelector = `:is(.${toggle_button_1.default.rootSelector}, .${toggle_button_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, toggle_button_1.default);
};
dom_1.ElementWrapper.prototype.findAllToggleButtons = function (selector) {
    return this.findAllComponents(toggle_button_1.default, selector);
};
dom_1.ElementWrapper.prototype.findToken = function (selector) {
    let rootSelector = `.${token_1.default.rootSelector}`;
    if ("legacyRootSelector" in token_1.default && token_1.default.legacyRootSelector) {
        rootSelector = `:is(.${token_1.default.rootSelector}, .${token_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, token_1.default);
};
dom_1.ElementWrapper.prototype.findAllTokens = function (selector) {
    return this.findAllComponents(token_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTokenGroup = function (selector) {
    let rootSelector = `.${token_group_1.default.rootSelector}`;
    if ("legacyRootSelector" in token_group_1.default && token_group_1.default.legacyRootSelector) {
        rootSelector = `:is(.${token_group_1.default.rootSelector}, .${token_group_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, token_group_1.default);
};
dom_1.ElementWrapper.prototype.findAllTokenGroups = function (selector) {
    return this.findAllComponents(token_group_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTooltip = function (selector) {
    let rootSelector = `.${tooltip_1.default.rootSelector}`;
    if ("legacyRootSelector" in tooltip_1.default && tooltip_1.default.legacyRootSelector) {
        rootSelector = `:is(.${tooltip_1.default.rootSelector}, .${tooltip_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, tooltip_1.default);
};
dom_1.ElementWrapper.prototype.findAllTooltips = function (selector) {
    return this.findAllComponents(tooltip_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTopNavigation = function (selector) {
    let rootSelector = `.${top_navigation_1.default.rootSelector}`;
    if ("legacyRootSelector" in top_navigation_1.default && top_navigation_1.default.legacyRootSelector) {
        rootSelector = `:is(.${top_navigation_1.default.rootSelector}, .${top_navigation_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, top_navigation_1.default);
};
dom_1.ElementWrapper.prototype.findAllTopNavigations = function (selector) {
    return this.findAllComponents(top_navigation_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTreeView = function (selector) {
    let rootSelector = `.${tree_view_1.default.rootSelector}`;
    if ("legacyRootSelector" in tree_view_1.default && tree_view_1.default.legacyRootSelector) {
        rootSelector = `:is(.${tree_view_1.default.rootSelector}, .${tree_view_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, tree_view_1.default);
};
dom_1.ElementWrapper.prototype.findAllTreeViews = function (selector) {
    return this.findAllComponents(tree_view_1.default, selector);
};
dom_1.ElementWrapper.prototype.findTutorialPanel = function (selector) {
    let rootSelector = `.${tutorial_panel_1.default.rootSelector}`;
    if ("legacyRootSelector" in tutorial_panel_1.default && tutorial_panel_1.default.legacyRootSelector) {
        rootSelector = `:is(.${tutorial_panel_1.default.rootSelector}, .${tutorial_panel_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, tutorial_panel_1.default);
};
dom_1.ElementWrapper.prototype.findAllTutorialPanels = function (selector) {
    return this.findAllComponents(tutorial_panel_1.default, selector);
};
dom_1.ElementWrapper.prototype.findWizard = function (selector) {
    let rootSelector = `.${wizard_1.default.rootSelector}`;
    if ("legacyRootSelector" in wizard_1.default && wizard_1.default.legacyRootSelector) {
        rootSelector = `:is(.${wizard_1.default.rootSelector}, .${wizard_1.default.legacyRootSelector})`;
    }
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findComponent(selector ? (0, utils_1.appendSelector)(selector, rootSelector) : rootSelector, wizard_1.default);
};
dom_1.ElementWrapper.prototype.findAllWizards = function (selector) {
    return this.findAllComponents(wizard_1.default, selector);
};
dom_1.ElementWrapper.prototype.findClosestActionCard = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(action_card_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAlert = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(alert_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAnchorNavigation = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(anchor_navigation_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAnnotation = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(annotation_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAppLayout = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(app_layout_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAppLayoutToolbar = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(app_layout_toolbar_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAreaChart = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(area_chart_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAttributeEditor = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(attribute_editor_1.default);
};
dom_1.ElementWrapper.prototype.findClosestAutosuggest = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(autosuggest_1.default);
};
dom_1.ElementWrapper.prototype.findClosestBadge = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(badge_1.default);
};
dom_1.ElementWrapper.prototype.findClosestBarChart = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(bar_chart_1.default);
};
dom_1.ElementWrapper.prototype.findClosestBox = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(box_1.default);
};
dom_1.ElementWrapper.prototype.findClosestBreadcrumbGroup = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(breadcrumb_group_1.default);
};
dom_1.ElementWrapper.prototype.findClosestButton = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(button_1.default);
};
dom_1.ElementWrapper.prototype.findClosestButtonDropdown = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(button_dropdown_1.default);
};
dom_1.ElementWrapper.prototype.findClosestButtonGroup = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(button_group_1.default);
};
dom_1.ElementWrapper.prototype.findClosestCalendar = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(calendar_1.default);
};
dom_1.ElementWrapper.prototype.findClosestCards = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(cards_1.default);
};
dom_1.ElementWrapper.prototype.findClosestCheckbox = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(checkbox_1.default);
};
dom_1.ElementWrapper.prototype.findClosestCodeEditor = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(code_editor_1.default);
};
dom_1.ElementWrapper.prototype.findClosestCollectionPreferences = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(collection_preferences_1.default);
};
dom_1.ElementWrapper.prototype.findClosestColumnLayout = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(column_layout_1.default);
};
dom_1.ElementWrapper.prototype.findClosestContainer = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(container_1.default);
};
dom_1.ElementWrapper.prototype.findClosestContentLayout = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(content_layout_1.default);
};
dom_1.ElementWrapper.prototype.findClosestCopyToClipboard = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(copy_to_clipboard_1.default);
};
dom_1.ElementWrapper.prototype.findClosestDateInput = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(date_input_1.default);
};
dom_1.ElementWrapper.prototype.findClosestDatePicker = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(date_picker_1.default);
};
dom_1.ElementWrapper.prototype.findClosestDateRangePicker = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(date_range_picker_1.default);
};
dom_1.ElementWrapper.prototype.findClosestDivider = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(divider_1.default);
};
dom_1.ElementWrapper.prototype.findClosestDrawer = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(drawer_1.default);
};
dom_1.ElementWrapper.prototype.findClosestDropdown = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(dropdown_1.default);
};
dom_1.ElementWrapper.prototype.findClosestErrorBoundary = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(error_boundary_1.default);
};
dom_1.ElementWrapper.prototype.findClosestExpandableSection = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(expandable_section_1.default);
};
dom_1.ElementWrapper.prototype.findClosestFileDropzone = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(file_dropzone_1.default);
};
dom_1.ElementWrapper.prototype.findClosestFileInput = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(file_input_1.default);
};
dom_1.ElementWrapper.prototype.findClosestFileTokenGroup = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(file_token_group_1.default);
};
dom_1.ElementWrapper.prototype.findClosestFileUpload = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(file_upload_1.default);
};
dom_1.ElementWrapper.prototype.findClosestFlashbar = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(flashbar_1.default);
};
dom_1.ElementWrapper.prototype.findClosestForm = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(form_1.default);
};
dom_1.ElementWrapper.prototype.findClosestFormField = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(form_field_1.default);
};
dom_1.ElementWrapper.prototype.findClosestGrid = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(grid_1.default);
};
dom_1.ElementWrapper.prototype.findClosestHeader = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(header_1.default);
};
dom_1.ElementWrapper.prototype.findClosestHelpPanel = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(help_panel_1.default);
};
dom_1.ElementWrapper.prototype.findClosestHotspot = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(hotspot_1.default);
};
dom_1.ElementWrapper.prototype.findClosestIcon = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(icon_1.default);
};
dom_1.ElementWrapper.prototype.findClosestInput = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(input_1.default);
};
dom_1.ElementWrapper.prototype.findClosestItemCard = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(item_card_1.default);
};
dom_1.ElementWrapper.prototype.findClosestKeyValuePairs = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(key_value_pairs_1.default);
};
dom_1.ElementWrapper.prototype.findClosestLineChart = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(line_chart_1.default);
};
dom_1.ElementWrapper.prototype.findClosestLink = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(link_1.default);
};
dom_1.ElementWrapper.prototype.findClosestList = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(list_1.default);
};
dom_1.ElementWrapper.prototype.findClosestLiveRegion = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(live_region_1.default);
};
dom_1.ElementWrapper.prototype.findClosestMixedLineBarChart = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(mixed_line_bar_chart_1.default);
};
dom_1.ElementWrapper.prototype.findClosestModal = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(modal_1.default);
};
dom_1.ElementWrapper.prototype.findClosestMultiselect = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(multiselect_1.default);
};
dom_1.ElementWrapper.prototype.findClosestNavigableGroup = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(navigable_group_1.default);
};
dom_1.ElementWrapper.prototype.findClosestPagination = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(pagination_1.default);
};
dom_1.ElementWrapper.prototype.findClosestPanelLayout = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(panel_layout_1.default);
};
dom_1.ElementWrapper.prototype.findClosestPieChart = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(pie_chart_1.default);
};
dom_1.ElementWrapper.prototype.findClosestPopover = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(popover_1.default);
};
dom_1.ElementWrapper.prototype.findClosestProgressBar = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(progress_bar_1.default);
};
dom_1.ElementWrapper.prototype.findClosestPromptInput = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(prompt_input_1.default);
};
dom_1.ElementWrapper.prototype.findClosestPropertyFilter = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(property_filter_1.default);
};
dom_1.ElementWrapper.prototype.findClosestRadioButton = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(radio_button_1.default);
};
dom_1.ElementWrapper.prototype.findClosestRadioGroup = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(radio_group_1.default);
};
dom_1.ElementWrapper.prototype.findClosestS3ResourceSelector = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(s3_resource_selector_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSegmentedControl = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(segmented_control_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSelect = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(select_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSideNavigation = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(side_navigation_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSkeleton = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(skeleton_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSlider = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(slider_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSpaceBetween = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(space_between_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSpinner = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(spinner_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSplitPanel = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(split_panel_1.default);
};
dom_1.ElementWrapper.prototype.findClosestStatusIndicator = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(status_indicator_1.default);
};
dom_1.ElementWrapper.prototype.findClosestSteps = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(steps_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTable = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(table_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTabs = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(tabs_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTagEditor = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(tag_editor_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTextContent = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(text_content_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTextFilter = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(text_filter_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTextarea = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(textarea_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTiles = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(tiles_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTimeInput = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(time_input_1.default);
};
dom_1.ElementWrapper.prototype.findClosestToggle = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(toggle_1.default);
};
dom_1.ElementWrapper.prototype.findClosestToggleButton = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(toggle_button_1.default);
};
dom_1.ElementWrapper.prototype.findClosestToken = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(token_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTokenGroup = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(token_group_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTooltip = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(tooltip_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTopNavigation = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(top_navigation_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTreeView = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(tree_view_1.default);
};
dom_1.ElementWrapper.prototype.findClosestTutorialPanel = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(tutorial_panel_1.default);
};
dom_1.ElementWrapper.prototype.findClosestWizard = function () {
    // casting to 'any' is needed to avoid this issue with generics
    // https://github.com/microsoft/TypeScript/issues/29132
    return this.findClosestComponent(wizard_1.default);
};
function wrapper(root = document.body) {
    if (document && document.body && !document.body.contains(root)) {
        console.warn('[AwsUi] [test-utils] provided element is not part of the document body, interactions may work incorrectly');
    }
    ;
    return new dom_1.ElementWrapper(root);
}
//# sourceMappingURL=index.js.map