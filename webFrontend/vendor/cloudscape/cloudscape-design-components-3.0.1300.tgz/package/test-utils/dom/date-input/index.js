"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const base_input_1 = require("../input/base-input");
const styles_selectors_js_1 = require("../../../date-input/styles.selectors.js");
class DateInputWrapper extends base_input_1.default {
    /**
     * Sets the value of the component and calls the `onChange` handler.
     * The value needs to use the "YYYY/MM/DD" format,
     * but the subsequent `onChange` handler will contain the value in the "YYYY-MM-DD" format.
     *
     * @param value The value the input is set to, using the "YYYY/MM/DD" format.
     */
    setInputValue(value) {
        return super.setInputValue(value);
    }
}
DateInputWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = DateInputWrapper;
__decorate([
    dom_1.usesDom
], DateInputWrapper.prototype, "setInputValue", null);
//# sourceMappingURL=index.js.map