"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../icon/styles.selectors.js");
class IconWrapper extends dom_1.ComponentWrapper {
}
IconWrapper.rootSelector = styles_selectors_js_1.default.icon;
exports.default = IconWrapper;
//# sourceMappingURL=index.js.map