"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const abstract_switch_1 = require("../internal/abstract-switch");
const styles_selectors_js_1 = require("../../../checkbox/styles.selectors.js");
class CheckboxWrapper extends dom_1.ComponentWrapper {
    findAbstractSwitch() {
        return new abstract_switch_1.default(this.getElement());
    }
    findLabel() {
        return this.findAbstractSwitch().findLabel();
    }
    findNativeInput() {
        return this.findAbstractSwitch().findNativeInput();
    }
    findDescription() {
        return this.findAbstractSwitch().findDescription();
    }
}
CheckboxWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = CheckboxWrapper;
//# sourceMappingURL=index.js.map