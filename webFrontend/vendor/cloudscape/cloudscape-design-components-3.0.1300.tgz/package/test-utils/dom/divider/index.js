"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../divider/styles.selectors.js");
class DividerWrapper extends dom_1.ComponentWrapper {
    /** Returns the label element, or `null` if no label is set. */
    findLabel() {
        return this.findByClassName(styles_selectors_js_1.default['divider-label']);
    }
}
DividerWrapper.rootSelector = styles_selectors_js_1.default.divider;
exports.default = DividerWrapper;
//# sourceMappingURL=index.js.map