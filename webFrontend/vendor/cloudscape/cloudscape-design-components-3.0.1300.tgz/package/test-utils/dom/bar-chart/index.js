"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const mixed_line_bar_chart_1 = require("../mixed-line-bar-chart");
const styles_selectors_js_1 = require("../../../bar-chart/styles.selectors.js");
class BarChartWrapper extends mixed_line_bar_chart_1.default {
}
BarChartWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = BarChartWrapper;
//# sourceMappingURL=index.js.map