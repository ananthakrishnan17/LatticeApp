"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileTokenWrapper = void 0;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../file-token-group/styles.selectors.js");
const styles_selectors_js_2 = require("../../../file-token-group/test-classes/styles.selectors.js");
const styles_selectors_js_3 = require("../../../form-field/styles.selectors.js");
const styles_selectors_js_4 = require("../../../token/test-classes/styles.selectors.js");
class FileTokenGroupWrapper extends dom_1.ComponentWrapper {
    findFileTokens() {
        return this.findAllByClassName(styles_selectors_js_1.default.token).map(tokenElement => new FileTokenWrapper(tokenElement.getElement()));
    }
    /**
     * Returns a file token from for a given index.
     *
     * @param tokenIndex 1-based index of the file token to return.
     */
    findFileToken(fileTokenIndex) {
        return this.findComponent(`.${styles_selectors_js_1.default.token}[data-index="${fileTokenIndex - 1}"]`, FileTokenWrapper);
    }
}
FileTokenGroupWrapper.rootSelector = styles_selectors_js_2.default.root;
exports.default = FileTokenGroupWrapper;
class FileTokenWrapper extends dom_1.ComponentWrapper {
    findFileName() {
        return this.findByClassName(styles_selectors_js_1.default['file-option-name']);
    }
    findFileSize() {
        return this.findByClassName(styles_selectors_js_1.default['file-option-size']);
    }
    findFileLastModified() {
        return this.findByClassName(styles_selectors_js_1.default['file-option-last-modified']);
    }
    findFileThumbnail() {
        return this.findByClassName(styles_selectors_js_1.default['file-option-thumbnail']);
    }
    findFileError() {
        return this.find(`.${styles_selectors_js_3.default.error} .${styles_selectors_js_3.default.error__message}`);
    }
    findFileWarning() {
        return this.find(`.${styles_selectors_js_3.default.warning} .${styles_selectors_js_3.default.warning__message}`);
    }
    findRemoveButton() {
        return this.findByClassName(styles_selectors_js_4.default['dismiss-button']);
    }
}
exports.FileTokenWrapper = FileTokenWrapper;
FileTokenWrapper.rootSelector = styles_selectors_js_1.default.token;
//# sourceMappingURL=index.js.map