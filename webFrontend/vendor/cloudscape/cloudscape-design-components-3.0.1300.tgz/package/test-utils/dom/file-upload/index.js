"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const button_1 = require("../button");
const file_token_group_1 = require("../file-token-group");
const styles_selectors_js_1 = require("../../../file-input/styles.selectors.js");
const styles_selectors_js_2 = require("../../../file-token-group/styles.selectors.js");
const styles_selectors_js_3 = require("../../../file-upload/styles.selectors.js");
const styles_selectors_js_4 = require("../../../form-field/styles.selectors.js");
const styles_selectors_js_5 = require("../../../internal/components/token-list/styles.selectors.js");
class FileUploadWrapper extends dom_1.ComponentWrapper {
    findUploadButton() {
        return this.findComponent(`.${styles_selectors_js_1.default['file-input-button']}`, button_1.default);
    }
    findNativeInput() {
        return this.findByClassName(styles_selectors_js_1.default['file-input']);
    }
    findFileTokens() {
        return this.findAllByClassName(styles_selectors_js_2.default.token).map(tokenElement => new file_token_group_1.FileTokenWrapper(tokenElement.getElement()));
    }
    /**
     * Returns a file token from for a given index.
     *
     * @param tokenIndex 1-based index of the file token to return.
     */
    findFileToken(fileTokenIndex) {
        return this.findComponent(`.${styles_selectors_js_2.default.token}[data-index="${fileTokenIndex - 1}"]`, file_token_group_1.FileTokenWrapper);
    }
    /**
     * Returns the token toggle button.
     */
    findTokenToggle() {
        return this.findByClassName(styles_selectors_js_5.default.toggle);
    }
    findConstraint() {
        return this.find(`.${styles_selectors_js_3.default.hints} .${styles_selectors_js_4.default.constraint}`);
    }
    findError() {
        return this.find(`.${styles_selectors_js_3.default.hints} .${styles_selectors_js_4.default.error} .${styles_selectors_js_4.default.error__message}`);
    }
    findWarning() {
        return this.find(`.${styles_selectors_js_3.default.hints} .${styles_selectors_js_4.default.warning} .${styles_selectors_js_4.default.warning__message}`);
    }
}
FileUploadWrapper.rootSelector = styles_selectors_js_3.default.root;
exports.default = FileUploadWrapper;
//# sourceMappingURL=index.js.map