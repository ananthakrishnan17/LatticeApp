"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListItemWrapper = void 0;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const structured_item_js_1 = require("../internal/structured-item.js");
const styles_selectors_js_1 = require("../../../internal/components/drag-handle/test-classes/styles.selectors.js");
const styles_selectors_js_2 = require("../../../list/test-classes/styles.selectors.js");
class ListItemWrapper extends structured_item_js_1.default {
    findDragHandle() {
        return this.findByClassName(styles_selectors_js_1.default.root);
    }
}
exports.ListItemWrapper = ListItemWrapper;
class ListWrapper extends dom_1.ComponentWrapper {
    /**
     * Returns all list items.
     */
    findItems() {
        return this.findAllByClassName(styles_selectors_js_2.default.item).map(wrapper => new ListItemWrapper(wrapper.getElement()));
    }
    /**
     * Returns an item for a given index.
     *
     * @param index 1-based index of the item to return.
     */
    findItemByIndex(index) {
        return this.findComponent(`.${styles_selectors_js_2.default.item}:nth-child(${index})`, ListItemWrapper);
    }
    /**
     * Returns an item for a given id.
     *
     */
    findItemById(id) {
        return this.findComponent(`.${styles_selectors_js_2.default.item}[data-testid="${id}"]`, ListItemWrapper);
    }
}
ListWrapper.rootSelector = styles_selectors_js_2.default.root;
exports.default = ListWrapper;
//# sourceMappingURL=index.js.map