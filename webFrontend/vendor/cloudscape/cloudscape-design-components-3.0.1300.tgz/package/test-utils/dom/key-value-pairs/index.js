"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const box_1 = require("../box");
const styles_selectors_js_1 = require("../../../column-layout/flexible-column-layout/styles.selectors.js");
const styles_selectors_js_2 = require("../../../key-value-pairs/styles.selectors.js");
class KeyValuePairsPairWrapper extends dom_1.ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles_selectors_js_2.default['key-label']);
    }
    findValue() {
        return this.findByClassName(styles_selectors_js_2.default.detail);
    }
    findInfo() {
        return this.findByClassName(styles_selectors_js_2.default.info);
    }
}
class KeyValuePairsItemWrapper extends KeyValuePairsPairWrapper {
    findGroupTitle() {
        return this.findComponent(`.${box_1.default.rootSelector}`, dom_1.ElementWrapper);
    }
    findGroupPairs() {
        return this.findAllByClassName(styles_selectors_js_2.default['group-list-item']).map(i => new KeyValuePairsPairWrapper(i.getElement()));
    }
}
class KeyValuePairsWrapper extends dom_1.ComponentWrapper {
    findItems() {
        return this.findAllByClassName(styles_selectors_js_1.default.item).map(i => new KeyValuePairsItemWrapper(i.getElement()));
    }
}
KeyValuePairsWrapper.rootSelector = styles_selectors_js_2.default['key-value-pairs'];
exports.default = KeyValuePairsWrapper;
//# sourceMappingURL=index.js.map