"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const index_js_1 = require("../button/index.js");
const index_js_2 = require("../button-dropdown/index.js");
const index_js_3 = require("../file-input/index.js");
const index_js_4 = require("../index.js");
const index_js_5 = require("../toggle-button/index.js");
const styles_selectors_js_1 = require("../../../button-group/test-classes/styles.selectors.js");
class ButtonGroupWrapper extends dom_1.ComponentWrapper {
    /**
     * Finds all button and menu items.
     */
    findItems() {
        return this.findAllByClassName(styles_selectors_js_1.default['button-group-item']);
    }
    /**
     * Finds a button item by its id.
     */
    findButtonById(id) {
        const inlineItemSelector = `.${styles_selectors_js_1.default['button-group-item']}[data-testid="${CSS.escape(id)}"]`;
        const wrapper = this.find(inlineItemSelector);
        return wrapper && new index_js_1.default(wrapper.getElement());
    }
    /**
     * Finds a toggle button item by its id.
     */
    findToggleButtonById(id) {
        const inlineItemSelector = `.${styles_selectors_js_1.default['button-group-item']}[data-testid="${CSS.escape(id)}"]`;
        const wrapper = this.find(inlineItemSelector);
        return wrapper && new index_js_5.default(wrapper.getElement());
    }
    /**
     * Finds a file input item by its id.
     */
    findFileInputById(id) {
        const inlineItemSelector = `.${styles_selectors_js_1.default['button-group-item']}[data-testid="${CSS.escape(id)}"]`;
        const wrapper = this.find(inlineItemSelector);
        return wrapper && new index_js_3.default(wrapper.getElement());
    }
    /**
     * Finds a menu item by its id.
     */
    findMenuById(id) {
        const inlineItemSelector = `.${styles_selectors_js_1.default['button-group-item']}[data-testid="${CSS.escape(id)}"]`;
        const wrapper = this.find(inlineItemSelector);
        return wrapper && new index_js_2.default(wrapper.getElement());
    }
    /**
     * Finds the currently opened tooltip.
     */
    findTooltip() {
        return (0, index_js_4.default)().findByClassName(styles_selectors_js_1.default['button-group-tooltip']);
    }
}
ButtonGroupWrapper.rootSelector = styles_selectors_js_1.default['button-group'];
exports.default = ButtonGroupWrapper;
//# sourceMappingURL=index.js.map