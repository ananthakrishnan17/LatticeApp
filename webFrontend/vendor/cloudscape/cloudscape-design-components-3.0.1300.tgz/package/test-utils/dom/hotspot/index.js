"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const annotation_1 = require("../annotation");
const styles_selectors_js_1 = require("../../../annotation-context/annotation/styles.selectors.js");
const styles_selectors_js_2 = require("../../../hotspot/styles.selectors.js");
class HotspotWrapper extends dom_1.ComponentWrapper {
    findTrigger() {
        return this.findByClassName(styles_selectors_js_1.default.hotspot);
    }
    findAnnotation() {
        return (0, dom_1.createWrapper)().findComponent(`.${styles_selectors_js_1.default.annotation}`, annotation_1.default);
    }
}
HotspotWrapper.rootSelector = styles_selectors_js_2.default.root;
exports.default = HotspotWrapper;
//# sourceMappingURL=index.js.map