"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../action-card/styles.selectors.js");
const styles_selectors_js_2 = require("../../../action-card/test-classes/styles.selectors.js");
class ActionCardWrapper extends dom_1.ComponentWrapper {
    /**
     * Returns the header element of the action card.
     */
    findHeader() {
        return this.findByClassName(styles_selectors_js_2.default.header);
    }
    /**
     * Returns the description element of the action card.
     */
    findDescription() {
        return this.findByClassName(styles_selectors_js_2.default.description);
    }
    /**
     * Returns the content element of the action card.
     */
    findContent() {
        return this.findByClassName(styles_selectors_js_2.default.body);
    }
    /**
     * Finds the icon slot of the action card.
     */
    findIcon() {
        return this.findByClassName(styles_selectors_js_2.default.icon);
    }
    /**
     * Returns whether the action card is disabled.
     */
    isDisabled() {
        return this.element.classList.contains(styles_selectors_js_2.default.disabled);
    }
    /**
     * Performs a click by triggering a mouse event on the internal button.
     * Note that programmatic events ignore disabled attribute and will trigger listeners even if the element is disabled.
     */
    click() {
        const button = this.findByClassName(styles_selectors_js_2.default.button);
        if (button) {
            button.click();
        }
    }
}
ActionCardWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = ActionCardWrapper;
__decorate([
    dom_1.usesDom
], ActionCardWrapper.prototype, "isDisabled", null);
__decorate([
    dom_1.usesDom
], ActionCardWrapper.prototype, "click", null);
//# sourceMappingURL=index.js.map