"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const app_layout_1 = require("../app-layout");
const styles_selectors_js_1 = require("../../../app-layout/test-classes/styles.selectors.js");
class AppLayoutToolbarWrapper extends app_layout_1.default {
}
AppLayoutToolbarWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = AppLayoutToolbarWrapper;
//# sourceMappingURL=index.js.map