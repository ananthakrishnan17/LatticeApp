"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const popover_1 = require("../popover");
const styles_selectors_js_1 = require("../../../internal/do-not-use/feature-prompt/styles.selectors.js");
class FeaturePromptWrapper extends popover_1.default {
    findHeader() {
        return super.findHeader({ renderWithPortal: true });
    }
    findContent() {
        return super.findContent({ renderWithPortal: true });
    }
    findDismissButton() {
        return super.findDismissButton({ renderWithPortal: true });
    }
}
FeaturePromptWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = FeaturePromptWrapper;
//# sourceMappingURL=feature-prompt.js.map