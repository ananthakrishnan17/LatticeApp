"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const input_1 = require("../input");
const dropdown_js_1 = require("./dropdown.js");
const styles_selectors_js_1 = require("../../../dropdown/styles.selectors.js");
const styles_selectors_js_2 = require("../../../input/styles.selectors.js");
const styles_selectors_js_3 = require("../../../internal/components/autosuggest-input/styles.selectors.js");
class AutosuggestInputWrapper extends dom_1.ComponentWrapper {
    findInput() {
        return this.findComponent(`.${styles_selectors_js_2.default['input-container']}`, input_1.default);
    }
    findDropdown() {
        return this.findComponent(`.${styles_selectors_js_1.default.root}`, dropdown_js_1.default);
    }
}
AutosuggestInputWrapper.rootSelector = styles_selectors_js_3.default.root;
exports.default = AutosuggestInputWrapper;
//# sourceMappingURL=autosuggest-input.js.map