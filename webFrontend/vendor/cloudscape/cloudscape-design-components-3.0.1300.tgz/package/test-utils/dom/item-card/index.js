"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../internal/components/structured-item/test-classes/styles.selectors.js");
const styles_selectors_js_2 = require("../../../item-card/styles.selectors.js");
const styles_selectors_js_3 = require("../../../item-card/test-classes/styles.selectors.js");
class ItemCardWrapper extends dom_1.ComponentWrapper {
    /**
     * Finds the action slot of the item card.
     */
    findActions() {
        return this.findByClassName(styles_selectors_js_1.default.actions);
    }
    /**
     * Finds the content slot of the item card.
     */
    findContent() {
        return this.findByClassName(styles_selectors_js_3.default.body);
    }
    /**
     * Finds the description slot of the item card.
     */
    findDescription() {
        return this.findByClassName(styles_selectors_js_3.default.description);
    }
    /**
     * Finds the header slot of the item card.
     */
    findHeader() {
        return this.findByClassName(styles_selectors_js_3.default.header);
    }
    /**
     * Finds the footer slot of the item card.
     */
    findFooter() {
        return this.findByClassName(styles_selectors_js_3.default.footer);
    }
    /**
     * Finds the icon slot of the item card.
     */
    findIcon() {
        return this.findByClassName(styles_selectors_js_3.default.icon);
    }
}
ItemCardWrapper.rootSelector = styles_selectors_js_2.default.root;
exports.default = ItemCardWrapper;
//# sourceMappingURL=index.js.map