"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
Object.defineProperty(exports, "__esModule", { value: true });
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../error-boundary/test-classes/styles.selectors.js");
class ErrorBoundaryWrapper extends dom_1.ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles_selectors_js_1.default.header);
    }
    findDescription() {
        return this.findByClassName(styles_selectors_js_1.default.description);
    }
    findAction() {
        return this.findByClassName(styles_selectors_js_1.default.action);
    }
    findFeedbackAction() {
        return this.findByClassName(styles_selectors_js_1.default['feedback-action']);
    }
    findRefreshAction() {
        return this.findByClassName(styles_selectors_js_1.default['refresh-action']);
    }
}
ErrorBoundaryWrapper.rootSelector = styles_selectors_js_1.default.fallback;
exports.default = ErrorBoundaryWrapper;
//# sourceMappingURL=index.js.map