"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DropdownContentWrapper = void 0;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../dropdown/styles.selectors.js");
const styles_selectors_js_2 = require("../../../dropdown/test-classes/styles.selectors.js");
class DropdownContentWrapper extends dom_1.ComponentWrapper {
    /**
     * Returns the dropdown content.
     */
    findContent() {
        return this.findByClassName(styles_selectors_js_1.default['dropdown-content']);
    }
    /**
     * Returns the dropdown header.
     */
    findHeader() {
        return this.findByClassName(styles_selectors_js_2.default.header);
    }
    /**
     * Returns the dropdown footer.
     */
    findFooter() {
        return this.findByClassName(styles_selectors_js_2.default.footer);
    }
}
exports.DropdownContentWrapper = DropdownContentWrapper;
class DropdownWrapper extends dom_1.ComponentWrapper {
    /**
     * Returns the trigger element.
     */
    findTrigger() {
        return this.findByClassName(styles_selectors_js_2.default.trigger);
    }
    /**
     * Returns the open dropdown wrapper, or null if the dropdown is closed.
     *
     * @param options
     * * expandToViewport (boolean) - Use this when the component under test is rendered with an `expandToViewport` flag.
     */
    findOpenDropdown(options = { expandToViewport: false }) {
        const dropdown = options.expandToViewport
            ? (0, dom_1.createWrapper)().find(`.${styles_selectors_js_1.default.dropdown}[data-open=true]`)
            : this.find(`.${styles_selectors_js_1.default.dropdown}[data-open=true]`);
        return dropdown ? new DropdownContentWrapper(dropdown.getElement()) : null;
    }
    /**
     * Returns whether the dropdown is open.
     *
     * @param options
     * * expandToViewport (boolean) - Use this when the component under test is rendered with an `expandToViewport` flag.
     */
    isOpen(options = { expandToViewport: false }) {
        return options.expandToViewport
            ? (0, dom_1.createWrapper)().find(`.${styles_selectors_js_1.default.dropdown}[data-open=true]`) !== null
            : this.find(`.${styles_selectors_js_1.default.dropdown}[data-open=true]`) !== null;
    }
}
DropdownWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = DropdownWrapper;
//# sourceMappingURL=index.js.map