"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../live-region/test-classes/styles.selectors.js");
class LiveRegionWrapper extends dom_1.ComponentWrapper {
}
LiveRegionWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = LiveRegionWrapper;
//# sourceMappingURL=index.js.map