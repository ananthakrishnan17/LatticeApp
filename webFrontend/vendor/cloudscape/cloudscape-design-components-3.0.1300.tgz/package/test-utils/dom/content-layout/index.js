"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const styles_selectors_js_1 = require("../../../content-layout/styles.selectors.js");
const styles_selectors_js_2 = require("../../../content-layout/test-classes/styles.selectors.js");
class ContentLayoutWrapper extends dom_1.ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles_selectors_js_2.default.header);
    }
    findContent() {
        return this.findByClassName(styles_selectors_js_1.default.content);
    }
    findNotifications() {
        return this.findByClassName(styles_selectors_js_2.default.notifications);
    }
    findBreadcrumbs() {
        return this.findByClassName(styles_selectors_js_2.default.breadcrumbs);
    }
    findSecondaryHeader() {
        return this.findByClassName(styles_selectors_js_2.default['secondary-header']);
    }
}
ContentLayoutWrapper.rootSelector = styles_selectors_js_1.default.layout;
exports.default = ContentLayoutWrapper;
//# sourceMappingURL=index.js.map