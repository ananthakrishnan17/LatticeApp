"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const button_dropdown_1 = require("../button-dropdown");
const split_panel_1 = require("../split-panel");
const styles_selectors_js_1 = require("../../../app-layout/test-classes/styles.selectors.js");
const styles_selectors_js_2 = require("../../../split-panel/test-classes/styles.selectors.js");
class AppLayoutWrapper extends dom_1.ComponentWrapper {
    findNavigation() {
        return this.findByClassName(styles_selectors_js_1.default.navigation);
    }
    findOpenNavigationPanel() {
        const navigation = this.findNavigation();
        if (!navigation) {
            throw new Error('App Layout does not have navigation content');
        }
        return navigation.matches(`:not(.${styles_selectors_js_1.default['drawer-closed']})`);
    }
    findNavigationToggle() {
        return this.findByClassName(styles_selectors_js_1.default['navigation-toggle']);
    }
    findNavigationClose() {
        return this.findByClassName(styles_selectors_js_1.default['navigation-close']);
    }
    findContentRegion() {
        return this.findByClassName(styles_selectors_js_1.default.content);
    }
    findNotifications() {
        return this.findByClassName(styles_selectors_js_1.default.notifications);
    }
    findBreadcrumbs() {
        return this.findByClassName(styles_selectors_js_1.default.breadcrumbs);
    }
    findTools() {
        return this.findByClassName(styles_selectors_js_1.default.tools);
    }
    findOpenToolsPanel() {
        const tools = this.findTools();
        if (!tools) {
            throw new Error('App Layout does not have tools content');
        }
        return tools.matches(`:not(.${styles_selectors_js_1.default['drawer-closed']})`);
    }
    findToolsClose() {
        return this.findByClassName(styles_selectors_js_1.default['tools-close']);
    }
    findToolsToggle() {
        return this.findByClassName(styles_selectors_js_1.default['tools-toggle']);
    }
    findSplitPanel() {
        return this.findComponent(`.${split_panel_1.default.rootSelector}`, split_panel_1.default);
    }
    findSplitPanelOpenButton() {
        return this.findByClassName(styles_selectors_js_2.default['open-button']);
    }
    findActiveDrawer() {
        return this.findByClassName(styles_selectors_js_1.default['active-drawer']);
    }
    findActiveDrawerCloseButton() {
        return this.findByClassName(styles_selectors_js_1.default['active-drawer-close-button']);
    }
    findDrawersTriggers() {
        return this.findAllByClassName(styles_selectors_js_1.default['drawers-trigger']);
    }
    /**
     * Finds a drawer trigger by the given id.
     *
     * @param id id of the trigger to find
     * @param options
     * * hasBadge (boolean) - If provided, only finds drawers with the badge or without badge respectively
     */
    findDrawerTriggerById(id, options = {}) {
        const trigger = this.find(`.${styles_selectors_js_1.default['drawers-trigger']}[data-testid="awsui-app-layout-trigger-${id}"]`);
        if (!trigger || options.hasBadge === undefined) {
            return trigger;
        }
        const badgeSelector = `.${styles_selectors_js_1.default['drawers-trigger-with-badge']}`;
        return trigger.matches(options.hasBadge ? badgeSelector : `:not(${badgeSelector})`);
    }
    findDrawersOverflowTrigger() {
        return this.findComponent(`.${styles_selectors_js_1.default['overflow-menu']}`, button_dropdown_1.default);
    }
    findActiveDrawerResizeHandle() {
        return this.findByClassName(styles_selectors_js_1.default['drawers-slider']);
    }
    findToolbar() {
        return this.findByClassName(styles_selectors_js_1.default.toolbar);
    }
    findDrawerTriggerTooltip() {
        return (0, dom_1.createWrapper)().findByClassName(styles_selectors_js_1.default['trigger-tooltip']);
    }
}
AppLayoutWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = AppLayoutWrapper;
//# sourceMappingURL=index.js.map