"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentDisplayOptionWrapper = void 0;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const list_1 = require("../list");
const text_filter_1 = require("../text-filter");
const toggle_1 = require("../toggle");
const styles_selectors_js_1 = require("../../../collection-preferences/styles.selectors.js");
const getClassName = (suffix) => styles_selectors_js_1.default[`content-display-${suffix}`];
class ContentDisplayOptionWrapper extends dom_1.ComponentWrapper {
    getListItem() {
        return new list_1.ListItemWrapper(this.getElement());
    }
    /**
     * Returns the drag handle for the option item.
     */
    findDragHandle() {
        return this.getListItem().findDragHandle();
    }
    /**
     * Returns the text label displayed in the option item.
     */
    findLabel() {
        return this.getListItem().findContent().findByClassName(styles_selectors_js_1.default['content-display-option-label']);
    }
    /**
     * Returns the visibility toggle for the option item.
     */
    findVisibilityToggle() {
        return this.getListItem()
            .findContent()
            .findComponent(`.${styles_selectors_js_1.default['content-display-option-toggle']}`, toggle_1.default);
    }
}
exports.ContentDisplayOptionWrapper = ContentDisplayOptionWrapper;
class ContentDisplayPreferenceWrapper extends dom_1.ComponentWrapper {
    /**
     * Returns the title.
     */
    findTitle() {
        return this.findByClassName(getClassName('title'));
    }
    /**
     * Returns the preference description displayed below the title.
     */
    findDescription() {
        return this.findByClassName(getClassName('description'));
    }
    getList() {
        return new list_1.default(this.getElement());
    }
    /**
     * Returns an option for a given index.
     *
     * @param index 1-based index of the option to return.
     */
    findOptionByIndex(index) {
        const item = this.getList().findItemByIndex(index);
        return item && new ContentDisplayOptionWrapper(item.getElement());
    }
    /**
     * Returns options that the user can reorder.
     */
    findOptions() {
        return this.getList()
            .findItems()
            .map(wrapper => new ContentDisplayOptionWrapper(wrapper.getElement()));
    }
    /**
     * Returns the text filter input.
     */
    findTextFilter() {
        return this.findComponent(`.${styles_selectors_js_1.default['content-display-text-filter']}`, text_filter_1.default);
    }
    /**
     * Returns no match with the clear filter button.
     */
    findNoMatch() {
        return this.findByClassName(styles_selectors_js_1.default['content-display-no-match']);
    }
}
ContentDisplayPreferenceWrapper.rootSelector = styles_selectors_js_1.default['content-display'];
exports.default = ContentDisplayPreferenceWrapper;
//# sourceMappingURL=content-display-preference.js.map