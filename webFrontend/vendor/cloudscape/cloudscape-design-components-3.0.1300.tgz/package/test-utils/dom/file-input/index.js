"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const dom_1 = require("@cloudscape-design/test-utils-core/dom");
const button_1 = require("../button");
const styles_selectors_js_1 = require("../../../file-input/styles.selectors.js");
class FileInputWrapper extends dom_1.ComponentWrapper {
    findTrigger() {
        return this.findComponent(`.${styles_selectors_js_1.default['file-input-button']}`, button_1.default);
    }
    findNativeInput() {
        return this.findByClassName(styles_selectors_js_1.default['file-input']);
    }
}
FileInputWrapper.rootSelector = styles_selectors_js_1.default.root;
exports.default = FileInputWrapper;
//# sourceMappingURL=index.js.map