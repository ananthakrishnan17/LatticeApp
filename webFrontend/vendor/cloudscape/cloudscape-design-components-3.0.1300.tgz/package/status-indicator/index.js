// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalStatusIndicator from './internal';
export default function StatusIndicator({ type = 'success', wrapText = true, ...props }) {
    const baseComponentProps = useBaseComponent('StatusIndicator', {
        props: { colorOverride: props.colorOverride, type, wrapText },
    });
    return React.createElement(InternalStatusIndicator, { type: type, wrapText: wrapText, ...props, ...baseComponentProps });
}
applyDisplayName(StatusIndicator, 'StatusIndicator');
//# sourceMappingURL=index.js.map