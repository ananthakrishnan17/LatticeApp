// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalBox from './internal';
export default function Box({ variant = 'div', margin = {}, padding = {}, ...props }) {
    const baseComponentProps = useBaseComponent('Box', {
        props: {
            color: props.color,
            display: props.display,
            float: props.float,
            fontSize: props.fontSize,
            fontWeight: props.fontWeight,
            textAlign: props.textAlign,
            variant,
        },
    });
    return React.createElement(InternalBox, { variant: variant, margin: margin, padding: padding, ...props, ...baseComponentProps });
}
applyDisplayName(Box, 'Box');
//# sourceMappingURL=index.js.map