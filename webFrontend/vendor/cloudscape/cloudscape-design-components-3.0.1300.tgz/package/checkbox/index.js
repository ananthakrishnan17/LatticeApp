// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalCheckbox from './internal';
const Checkbox = React.forwardRef(({ ...props }, ref) => {
    const baseComponentProps = useBaseComponent('Checkbox', {
        props: { readOnly: props.readOnly },
    });
    return React.createElement(InternalCheckbox, { ...props, ...baseComponentProps, ref: ref, __injectAnalyticsComponentMetadata: true });
});
applyDisplayName(Checkbox, 'Checkbox');
export default Checkbox;
//# sourceMappingURL=index.js.map