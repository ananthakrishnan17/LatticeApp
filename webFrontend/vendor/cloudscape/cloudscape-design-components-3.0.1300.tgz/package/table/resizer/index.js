// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useCallback, useEffect, useRef, useState } from 'react';
import clsx from 'clsx';
import { useStableCallback, useUniqueId } from '@cloudscape-design/component-toolkit/internal';
import { getIsRtl, getLogicalBoundingClientRect, getLogicalPageX } from '@cloudscape-design/component-toolkit/internal';
import { useSingleTabStopNavigation } from '@cloudscape-design/component-toolkit/internal';
import DragHandleWrapper from '../../internal/components/drag-handle-wrapper';
import { useThrottleCallback } from '../../internal/hooks/use-throttle-callback';
import { useVisualRefresh } from '../../internal/hooks/use-visual-mode';
import { KeyCode } from '../../internal/keycode';
import handleKey, { isEventLike } from '../../internal/utils/handle-key';
import { scrollElementIntoView } from '../../internal/utils/scrollable-containers';
import { DEFAULT_COLUMN_WIDTH } from '../use-column-widths';
import { getHeaderWidth, getResizerElements } from './resizer-lookup';
import styles from './styles.css.js';
const RESIZE_THROTTLE = 25;
const AUTO_GROW_START_TIME = 10;
const AUTO_GROW_INTERVAL = 10;
const AUTO_GROW_INCREMENT = 5;
export function Divider({ className }) {
    return React.createElement("span", { className: clsx(styles.divider, styles['divider-disabled'], className) });
}
export function Resizer({ onWidthUpdate, onWidthUpdateCommit, ariaLabelledby, minWidth = DEFAULT_COLUMN_WIDTH, tabIndex, showFocusRing, focusId, roleDescription, tooltipText, isBorderless, }) {
    onWidthUpdate = useStableCallback(onWidthUpdate);
    onWidthUpdateCommit = useStableCallback(onWidthUpdateCommit);
    const isVisualRefresh = useVisualRefresh();
    const separatorId = useUniqueId();
    const positioningWrapperRef = useRef(null);
    const resizerToggleRef = useRef(null);
    const resizerSeparatorRef = useRef(null);
    const [isPointerDown, setIsPointerDown] = useState(false);
    const [isDragging, setIsDragging] = useState(false);
    const [showUapButtons, setShowUapButtons] = useState(false);
    const [resizerObscured, setResizerObscured] = useState(false);
    const [isKeyboardDragging, setIsKeyboardDragging] = useState(false);
    const autoGrowTimeout = useRef();
    const [resizerHasFocus, setResizerHasFocus] = useState(false);
    const [headerCellWidth, setHeaderCellWidth] = useState(0);
    // Read header width after mounting for it to be available in the element's ARIA label before it gets focused.
    useEffect(() => {
        setHeaderCellWidth(getHeaderWidth(resizerToggleRef.current));
    }, []);
    const isObscured = useCallback(() => {
        const elements = getResizerElements(resizerToggleRef.current);
        if (!elements || !positioningWrapperRef.current) {
            return false;
        }
        let scrollPaddingInlineStart = 0;
        let scrollPaddingInlineEnd = 0;
        // Calculate size of the headers at the exact moment of the call to deal
        // with auto-width columns and cached sticky column state.
        elements.allHeaders.forEach(header => {
            const { inlineSize } = getLogicalBoundingClientRect(header);
            if (header.style.insetInlineStart) {
                scrollPaddingInlineStart += inlineSize;
            }
            if (header.style.insetInlineEnd) {
                scrollPaddingInlineEnd += inlineSize;
            }
        });
        const { insetInlineStart: scrollParentInsetInlineStart, insetInlineEnd: scrollParentInsetInlineEnd } = getLogicalBoundingClientRect(elements.scrollParent);
        const { insetInlineStart, insetInlineEnd, inlineSize } = getLogicalBoundingClientRect(elements.header);
        const relativeInsetInlineStart = insetInlineStart - scrollParentInsetInlineStart;
        const relativeInsetInlineEnd = scrollParentInsetInlineEnd - insetInlineEnd;
        const isSticky = !!elements.header.style.insetInlineStart || !!elements.header.style.insetInlineEnd;
        return (
        // Is positioningWrapper obscured behind the left edge of scrollParent?
        Math.ceil(relativeInsetInlineStart + inlineSize) < (isSticky ? 0 : scrollPaddingInlineStart) ||
            // Is positioningWrapper obscured behind the right edge of scrollParent?
            Math.ceil(relativeInsetInlineEnd) < (isSticky ? 0 : scrollPaddingInlineEnd));
    }, []);
    const scrollIntoViewIfNeeded = useCallback(() => {
        if (resizerSeparatorRef.current && isObscured()) {
            scrollElementIntoView(resizerSeparatorRef.current);
        }
    }, [isObscured]);
    useEffect(() => {
        if (!showUapButtons) {
            setResizerObscured(false);
            return;
        }
        const elements = getResizerElements(resizerToggleRef.current);
        if (!elements) {
            return;
        }
        const onScroll = () => setResizerObscured(isObscured());
        elements.scrollParent.addEventListener('scroll', onScroll);
        return () => elements.scrollParent.removeEventListener('scroll', onScroll);
    }, [isObscured, showUapButtons]);
    useEffect(() => {
        if (showUapButtons) {
            setResizerObscured(isObscured());
        }
    }, [headerCellWidth, isObscured, showUapButtons]);
    const updateTrackerPosition = useCallback((newOffset) => {
        const elements = getResizerElements(resizerToggleRef.current);
        if (!elements) {
            return;
        }
        const { insetInlineStart: scrollParentInsetInlineStart } = getLogicalBoundingClientRect(elements.table);
        elements.tracker.style.insetBlockStart = getLogicalBoundingClientRect(elements.header).blockSize + 'px';
        // minus one pixel to offset the cell border
        elements.tracker.style.insetInlineStart = newOffset - scrollParentInsetInlineStart - 1 + 'px';
    }, []);
    const updateColumnWidth = useCallback((newWidth) => {
        const elements = getResizerElements(resizerToggleRef.current);
        if (!elements) {
            return;
        }
        const { insetInlineEnd, inlineSize } = getLogicalBoundingClientRect(elements.header);
        const updatedWidth = newWidth < minWidth ? minWidth : newWidth;
        updateTrackerPosition(insetInlineEnd + updatedWidth - inlineSize);
        setHeaderCellWidth(updatedWidth);
        // callbacks must be the last calls in the handler, because they may cause an extra update
        onWidthUpdate(newWidth);
    }, [minWidth, onWidthUpdate, updateTrackerPosition]);
    const resizeColumn = useThrottleCallback((offset) => {
        const elements = getResizerElements(resizerToggleRef.current);
        if (!elements) {
            return;
        }
        const { insetInlineStart: inlineStartEdge } = getLogicalBoundingClientRect(elements.scrollParent);
        if (offset > inlineStartEdge) {
            const cellLeft = getLogicalBoundingClientRect(elements.header).insetInlineStart;
            const newWidth = offset - cellLeft;
            // callbacks must be the last calls in the handler, because they may cause an extra update
            updateColumnWidth(newWidth);
        }
    }, RESIZE_THROTTLE, [updateColumnWidth]);
    useEffect(() => {
        var _a, _b;
        const elements = getResizerElements(resizerToggleRef.current);
        const document = (_b = (_a = resizerToggleRef.current) === null || _a === void 0 ? void 0 : _a.ownerDocument) !== null && _b !== void 0 ? _b : window.document;
        if ((!isPointerDown && !resizerHasFocus) || !elements) {
            return;
        }
        const { insetInlineEnd: inlineEndEdge } = getLogicalBoundingClientRect(elements.scrollParent);
        const onAutoGrow = () => {
            const inlineSize = getLogicalBoundingClientRect(elements.header).inlineSize;
            autoGrowTimeout.current = setTimeout(onAutoGrow, AUTO_GROW_INTERVAL);
            // callbacks must be the last calls in the handler, because they may cause an extra update
            updateColumnWidth(inlineSize + AUTO_GROW_INCREMENT);
            elements.scrollParent.scrollLeft += AUTO_GROW_INCREMENT * (getIsRtl(elements.scrollParent) ? -1 : 1);
        };
        const onPointerMove = (event) => {
            setIsDragging(true);
            clearTimeout(autoGrowTimeout.current);
            const offset = getLogicalPageX(event);
            if (offset > inlineEndEdge) {
                autoGrowTimeout.current = setTimeout(onAutoGrow, AUTO_GROW_START_TIME);
            }
            else {
                resizeColumn(offset);
            }
        };
        const onPointerUp = (event) => {
            setIsPointerDown(false);
            if (isDragging) {
                setIsDragging(false);
                resizeColumn(getLogicalPageX(event));
            }
            else {
                setShowUapButtons(true);
            }
            onWidthUpdateCommit();
            clearTimeout(autoGrowTimeout.current);
        };
        const onKeyDown = (event) => {
            if (isKeyboardDragging) {
                const keys = [KeyCode.left, KeyCode.right, KeyCode.enter, KeyCode.space, KeyCode.escape];
                if (keys.indexOf(event.keyCode) !== -1) {
                    event.preventDefault();
                    if (isEventLike(event)) {
                        handleKey(event, {
                            onActivate: () => {
                                var _a;
                                setIsKeyboardDragging(false);
                                setShowUapButtons(false);
                                (_a = resizerToggleRef.current) === null || _a === void 0 ? void 0 : _a.focus();
                            },
                            onEscape: () => {
                                var _a;
                                setIsKeyboardDragging(false);
                                setShowUapButtons(false);
                                (_a = resizerToggleRef.current) === null || _a === void 0 ? void 0 : _a.focus();
                            },
                            onInlineStart: () => {
                                updateColumnWidth(getLogicalBoundingClientRect(elements.header).inlineSize - 10);
                                scrollIntoViewIfNeeded();
                            },
                            onInlineEnd: () => {
                                updateColumnWidth(getLogicalBoundingClientRect(elements.header).inlineSize + 10);
                                scrollIntoViewIfNeeded();
                            },
                        });
                    }
                }
            }
            else {
                if (event.keyCode === KeyCode.enter || event.keyCode === KeyCode.space) {
                    // Enter keyboard dragging mode
                    event.preventDefault();
                    if (isEventLike(event)) {
                        handleKey(event, {
                            onActivate: () => {
                                var _a;
                                setShowUapButtons(true);
                                setIsKeyboardDragging(true);
                                (_a = resizerSeparatorRef.current) === null || _a === void 0 ? void 0 : _a.focus();
                            },
                        });
                    }
                }
                else {
                    // Showing the UAP buttons when the button is only focused and not activated
                    // gives a false impression that you can resize with the arrow keys.
                    setShowUapButtons(false);
                }
            }
        };
        updateTrackerPosition(getLogicalBoundingClientRect(elements.header).insetInlineEnd);
        const controller = new AbortController();
        if (isPointerDown) {
            document.body.classList.add(styles['resize-active']);
            document.addEventListener('pointermove', onPointerMove, { signal: controller.signal });
            document.addEventListener('pointerup', onPointerUp, { signal: controller.signal });
        }
        else if (resizerHasFocus) {
            document.body.classList.add(styles['resize-active-with-focus']);
            elements.header.addEventListener('keydown', onKeyDown, { signal: controller.signal });
        }
        if (isKeyboardDragging) {
            document.body.classList.add(styles['resize-active']);
        }
        return () => {
            document.body.classList.remove(styles['resize-active']);
            document.body.classList.remove(styles['resize-active-with-focus']);
            controller.abort();
        };
    }, [
        isDragging,
        isKeyboardDragging,
        isPointerDown,
        resizerHasFocus,
        scrollIntoViewIfNeeded,
        onWidthUpdateCommit,
        resizeColumn,
        updateColumnWidth,
        updateTrackerPosition,
    ]);
    useEffect(() => {
        if (isDragging) {
            return () => clearTimeout(autoGrowTimeout.current);
        }
    }, [isDragging]);
    const { tabIndex: resizerTabIndex } = useSingleTabStopNavigation(resizerToggleRef, { tabIndex });
    return (React.createElement("div", { 
        // When the table is borderless (works in visual refresh tables only), the last resize handle must not
        // exceed table's edges, as it causes an unintended overflow otherwise.
        className: clsx(styles['resizer-wrapper'], isVisualRefresh && styles['visual-refresh'], (!isVisualRefresh || isBorderless) && styles['is-borderless']), ref: positioningWrapperRef },
        React.createElement(DragHandleWrapper, { clickDragThreshold: 3, hideButtonsOnDrag: false, directions: {
                'inline-start': resizerObscured ? undefined : headerCellWidth > minWidth ? 'active' : 'disabled',
                'inline-end': resizerObscured ? undefined : 'active',
            }, triggerMode: "controlled", controlledShowButtons: showUapButtons && !resizerObscured, wrapperClassName: styles['resizer-button-wrapper'], tooltipText: tooltipText, "data-obscured": resizerObscured, onDirectionClick: direction => {
                const elements = getResizerElements(resizerToggleRef.current);
                if (!elements) {
                    return;
                }
                if (direction === 'inline-start') {
                    updateColumnWidth(getLogicalBoundingClientRect(elements.header).inlineSize - 20);
                    requestAnimationFrame(() => {
                        onWidthUpdateCommit();
                        scrollIntoViewIfNeeded();
                    });
                }
                else if (direction === 'inline-end') {
                    updateColumnWidth(getLogicalBoundingClientRect(elements.header).inlineSize + 20);
                    requestAnimationFrame(() => {
                        onWidthUpdateCommit();
                        scrollIntoViewIfNeeded();
                    });
                }
            } },
            React.createElement("button", { type: "button", ref: resizerToggleRef, className: clsx(styles.resizer, (resizerHasFocus || showFocusRing || isKeyboardDragging) && styles['has-focus']), onPointerDown: event => {
                    if (event.pointerType === 'mouse' && event.button !== 0) {
                        return;
                    }
                    setIsPointerDown(true);
                }, onClick: () => {
                    var _a;
                    // Prevent mouse drag activation and activate keyboard dragging for VO+Space click.
                    setIsPointerDown(false);
                    setIsDragging(false);
                    setShowUapButtons(true);
                    setResizerHasFocus(true);
                    setIsKeyboardDragging(true);
                    (_a = resizerSeparatorRef.current) === null || _a === void 0 ? void 0 : _a.focus();
                }, onFocus: () => {
                    setHeaderCellWidth(getHeaderWidth(resizerToggleRef.current));
                    setResizerHasFocus(true);
                }, onBlur: event => {
                    // Ignoring blur event when focus moves to the resizer separator element.
                    // (This focus transition is done programmatically when the resizer button is clicked).
                    if (event.relatedTarget !== resizerSeparatorRef.current) {
                        setResizerHasFocus(false);
                        setShowUapButtons(false);
                        return;
                    }
                }, "aria-roledescription": roleDescription, "aria-labelledby": ariaLabelledby, tabIndex: resizerTabIndex, "data-focus-id": focusId }),
            React.createElement("span", { className: clsx(styles['divider-interactive'], (isPointerDown || isDragging) && styles['divider-active']), "data-awsui-table-suppress-navigation": true, ref: resizerSeparatorRef, id: separatorId, role: "slider", tabIndex: -1, "aria-labelledby": ariaLabelledby, "aria-hidden": !isKeyboardDragging, "aria-valuemin": minWidth, "aria-valuemax": Number.MAX_SAFE_INTEGER, "aria-valuenow": headerCellWidth, "data-focus-id": focusId, onBlur: event => {
                    setIsKeyboardDragging(false);
                    if (event.relatedTarget !== resizerToggleRef.current) {
                        setResizerHasFocus(false);
                        setShowUapButtons(false);
                    }
                    onWidthUpdateCommit();
                } }))));
}
export function ResizeTracker() {
    return React.createElement("span", { className: styles.tracker });
}
//# sourceMappingURL=index.js.map