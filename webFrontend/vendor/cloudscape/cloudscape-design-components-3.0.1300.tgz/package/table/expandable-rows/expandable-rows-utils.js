// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useInternalI18n } from '../../i18n/context';
import { fireNonCancelableEvent } from '../../internal/events';
import { ItemSet } from '../selection/utils';
export function useExpandableTableProps({ items, expandableRows, trackBy, ariaLabels, }) {
    var _a, _b;
    const i18n = useInternalI18n('table');
    const isExpandable = !!expandableRows;
    const expandedSet = new ItemSet(trackBy, (_a = expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.expandedItems) !== null && _a !== void 0 ? _a : []);
    let allItems = items;
    const itemToDetail = new Map();
    const getItemLevel = (item) => { var _a, _b; return (_b = (_a = itemToDetail.get(item)) === null || _a === void 0 ? void 0 : _a.level) !== null && _b !== void 0 ? _b : 0; };
    if (isExpandable) {
        const visibleItems = new Array();
        const traverse = (item, detail, visible) => {
            const children = expandableRows.getItemChildren(item);
            itemToDetail.set(item, { ...detail, children });
            if (visible) {
                visibleItems.push(item);
                children.forEach((child, index) => traverse(child, { level: detail.level + 1, setSize: children.length, posInSet: index + 1, parent: item }, expandedSet.has(item)));
            }
        };
        items.forEach((item, index) => traverse(item, { level: 1, setSize: items.length, posInSet: index + 1, parent: null }, true));
        for (let index = 0; index < visibleItems.length; index++) {
            const item = visibleItems[index];
            if (expandedSet.has(item)) {
                let insertionIndex = index + 1;
                for (insertionIndex; insertionIndex < visibleItems.length; insertionIndex++) {
                    const insertionItem = visibleItems[insertionIndex];
                    if (getItemLevel(item) >= getItemLevel(insertionItem)) {
                        break;
                    }
                }
                insertionIndex--;
            }
        }
        allItems = visibleItems;
    }
    const getExpandableItemProps = (item) => {
        var _a, _b, _c, _d, _e, _f;
        const { level = 1, setSize = 1, posInSet = 1, parent = null, children = [] } = (_a = itemToDetail.get(item)) !== null && _a !== void 0 ? _a : {};
        return {
            level,
            setSize,
            posInSet,
            isExpandable: (_b = expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.isItemExpandable(item)) !== null && _b !== void 0 ? _b : true,
            isExpanded: expandedSet.has(item),
            onExpandableItemToggle: () => fireNonCancelableEvent(expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.onExpandableItemToggle, { item, expanded: !expandedSet.has(item) }),
            expandButtonLabel: i18n('ariaLabels.expandButtonLabel', (_c = ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.expandButtonLabel) === null || _c === void 0 ? void 0 : _c.call(ariaLabels, item)),
            collapseButtonLabel: i18n('ariaLabels.collapseButtonLabel', (_d = ariaLabels === null || ariaLabels === void 0 ? void 0 : ariaLabels.collapseButtonLabel) === null || _d === void 0 ? void 0 : _d.call(ariaLabels, item)),
            parent,
            children,
            itemsCount: (_e = expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.getItemsCount) === null || _e === void 0 ? void 0 : _e.call(expandableRows, item),
            selectedItemsCount: (_f = expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.getSelectedItemsCount) === null || _f === void 0 ? void 0 : _f.call(expandableRows, item),
        };
    };
    return {
        isExpandable,
        allItems,
        getExpandableItemProps,
        hasGroupSelection: !!(expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.groupSelection),
        groupSelection: (_b = expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.groupSelection) !== null && _b !== void 0 ? _b : { inverted: false, toggledItems: [] },
        onGroupSelectionChange: expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.onGroupSelectionChange,
        totalItemsCount: expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.totalItemsCount,
        totalSelectedItemsCount: expandableRows === null || expandableRows === void 0 ? void 0 : expandableRows.totalSelectedItemsCount,
    };
}
//# sourceMappingURL=expandable-rows-utils.js.map