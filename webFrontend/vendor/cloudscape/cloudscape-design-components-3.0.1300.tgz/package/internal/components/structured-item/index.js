// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import styles from './styles.css.js';
import testClasses from './test-classes/styles.css.js';
export default function InternalStructuredItem({ content, icon, actions, secondaryContent, disablePaddings, wrapActions = true, className, }) {
    return (React.createElement("div", { className: clsx(styles.root, testClasses.root, disablePaddings && styles['disable-paddings'], className) },
        icon && React.createElement("div", { className: clsx(styles.icon, testClasses.icon) }, icon),
        React.createElement("div", { className: clsx(styles.main) },
            React.createElement("div", { className: clsx(styles['content-wrap'], wrapActions && styles['wrap-actions']) },
                React.createElement("div", { className: clsx(styles.content, testClasses.content) }, content),
                actions && React.createElement("div", { className: clsx(styles.actions, testClasses.actions) }, actions)),
            secondaryContent && React.createElement("div", { className: clsx(styles.secondary, testClasses.secondary) }, secondaryContent))));
}
//# sourceMappingURL=index.js.map