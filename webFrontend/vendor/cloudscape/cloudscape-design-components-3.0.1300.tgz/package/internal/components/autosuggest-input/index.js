// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useImperativeHandle, useRef, useState } from 'react';
import clsx from 'clsx';
import { useResizeObserver } from '@cloudscape-design/component-toolkit/internal';
import InternalDropdown from '../../../dropdown/internal';
import InternalInput from '../../../input/internal';
import { getBaseProps } from '../../base-component';
import { getBreakpointValue } from '../../breakpoints';
import { useFormFieldContext } from '../../context/form-field-context';
import { fireCancelableEvent, fireNonCancelableEvent } from '../../events';
import { useIMEComposition } from '../../hooks/use-ime-composition';
import { KeyCode } from '../../keycode';
import { getDropdownMinWidth } from '../../utils/get-dropdown-min-width';
import { nodeBelongs } from '../../utils/node-belongs';
import { processAttributes } from '../../utils/with-native-attributes';
import styles from './styles.css.js';
const AutosuggestInput = React.forwardRef(({ value, onChange, onBlur, onFocus, onKeyUp, onKeyDown, name, placeholder, disabled, readOnly, autoFocus, ariaLabel, ariaRequired, disableBrowserAutocorrect = false, expandToViewport, ariaControls, ariaActivedescendant, clearAriaLabel, dropdownExpanded = true, dropdownContentKey, dropdownContentFocusable = false, dropdownContent = null, dropdownFooter = null, dropdownWidth, loopFocus, nativeInputAttributes, onCloseDropdown, onDelayedInput, onPressArrowDown, onPressArrowUp, onPressEnter, style, __internalRootRef, ...restProps }, ref) => {
    const baseProps = getBaseProps(restProps);
    const formFieldContext = useFormFieldContext(restProps);
    const inputRef = useRef(null);
    const dropdownContentRef = useRef(null);
    const dropdownFooterRef = useRef(null);
    const preventOpenOnFocusRef = useRef(false);
    const preventCloseOnBlurRef = useRef(false);
    const [triggerWidth, setTriggerWidth] = useState(null);
    useResizeObserver(() => inputRef.current, entry => entry.borderBoxWidth > 0 && setTriggerWidth(entry.borderBoxWidth));
    const [open, setOpen] = useState(false);
    const openDropdown = () => !readOnly && setOpen(true);
    const closeDropdown = () => {
        setOpen(false);
        fireNonCancelableEvent(onCloseDropdown, null);
    };
    const { isComposing } = useIMEComposition(inputRef);
    useImperativeHandle(ref, () => ({
        focus(options) {
            var _a;
            if (options === null || options === void 0 ? void 0 : options.preventDropdown) {
                preventOpenOnFocusRef.current = true;
            }
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        },
        select() {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.select();
        },
        open: openDropdown,
        close: closeDropdown,
    }));
    const handleBlur = () => {
        if (!preventCloseOnBlurRef.current) {
            closeDropdown();
            fireNonCancelableEvent(onBlur, null);
        }
    };
    const handleFocus = () => {
        if (!preventOpenOnFocusRef.current) {
            openDropdown();
            fireNonCancelableEvent(onFocus, null);
        }
        preventOpenOnFocusRef.current = false;
    };
    const fireKeydown = (event) => fireCancelableEvent(onKeyDown, event.detail, event);
    // Shared ESC key handler logic for both input and dropdown elements
    // When returnFocus is true (from dropdown elements), focus returns to input after closing
    const handleEscapeKey = (returnFocus) => {
        var _a;
        if (open) {
            closeDropdown();
            if (returnFocus) {
                // Return focus to input when closing from dropdown elements (e.g., recovery button)
                (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
            }
        }
        else if (value) {
            fireNonCancelableEvent(onChange, { value: '' });
        }
    };
    const handleKeyDown = (event) => {
        switch (event.detail.keyCode) {
            case KeyCode.down: {
                onPressArrowDown === null || onPressArrowDown === void 0 ? void 0 : onPressArrowDown();
                openDropdown();
                event.preventDefault();
                break;
            }
            case KeyCode.up: {
                onPressArrowUp === null || onPressArrowUp === void 0 ? void 0 : onPressArrowUp();
                openDropdown();
                event.preventDefault();
                break;
            }
            case KeyCode.enter: {
                if (isComposing()) {
                    event.preventDefault();
                    return;
                }
                if (open) {
                    if (!(onPressEnter === null || onPressEnter === void 0 ? void 0 : onPressEnter())) {
                        closeDropdown();
                    }
                    event.preventDefault();
                }
                fireKeydown(event);
                break;
            }
            case KeyCode.escape: {
                // Use shared ESC handler, without focus restoration since ESC came from input
                handleEscapeKey(false);
                if (open || value) {
                    event.stopPropagation();
                }
                event.preventDefault();
                fireKeydown(event);
                break;
            }
            default: {
                fireKeydown(event);
            }
        }
    };
    const handleChange = (value) => {
        openDropdown();
        fireNonCancelableEvent(onChange, { value });
    };
    const handleDelayedInput = (value) => {
        fireNonCancelableEvent(onDelayedInput, { value });
    };
    const handleDropdownMouseDown = event => {
        // Prevent currently focused element from losing focus.
        if (!dropdownContentFocusable) {
            event.preventDefault();
        }
        // Prevent closing dropdown on click inside.
        else {
            preventCloseOnBlurRef.current = true;
            requestAnimationFrame(() => {
                preventCloseOnBlurRef.current = false;
            });
        }
    };
    const expanded = open && dropdownExpanded;
    const nativeAttributes = {
        name,
        placeholder,
        autoFocus,
        onClick: openDropdown,
        role: 'combobox',
        'aria-autocomplete': 'list',
        'aria-expanded': expanded,
        'aria-controls': open ? ariaControls : undefined,
        // 'aria-owns' needed for safari+vo to announce activedescendant content
        'aria-owns': open ? ariaControls : undefined,
        'aria-label': ariaLabel,
        'aria-activedescendant': ariaActivedescendant,
    };
    // Closes dropdown when outside click is detected.
    // Similar to the internal dropdown implementation but includes the target as well.
    useEffect(() => {
        if (!open) {
            return;
        }
        const clickListener = (event) => {
            if (!nodeBelongs(inputRef.current, event.target) &&
                !nodeBelongs(dropdownContentRef.current, event.target) &&
                !nodeBelongs(dropdownFooterRef.current, event.target)) {
                closeDropdown();
            }
        };
        window.addEventListener('mousedown', clickListener);
        return () => {
            window.removeEventListener('mousedown', clickListener);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open]);
    const handleDropdownKeyDown = event => {
        // Handle ESC key from focusable elements inside the dropdown (e.g., recovery button)
        // but NOT from the input itself (that's handled by handleKeyDown)
        const isFromInput = event.target === inputRef.current || nodeBelongs(inputRef.current, event.target);
        if (event.key === 'Escape' && !isFromInput) {
            event.stopPropagation();
            event.preventDefault();
            // Use shared ESC handler with focus restoration since ESC came from dropdown element
            handleEscapeKey(true);
        }
    };
    return (React.createElement("div", { ...baseProps, className: clsx(baseProps.className, styles.root), ref: __internalRootRef },
        React.createElement(InternalDropdown, { minWidth: getDropdownMinWidth({ expandToViewport, triggerWidth, dropdownWidth }), maxWidth: getBreakpointValue('xxs'), contentKey: dropdownContentKey, onFocus: handleFocus, onBlur: handleBlur, trigger: React.createElement(InternalInput, { type: "visualSearch", value: value, onChange: event => handleChange(event.detail.value), __onDelayedInput: event => handleDelayedInput(event.detail.value), onKeyDown: handleKeyDown, onKeyUp: onKeyUp, disabled: disabled, disableBrowserAutocorrect: disableBrowserAutocorrect, readOnly: readOnly, ariaRequired: ariaRequired, clearAriaLabel: clearAriaLabel, ref: inputRef, autoComplete: false, nativeInputAttributes: processAttributes(nativeAttributes, nativeInputAttributes, 'Autosuggest'), __skipNativeAttributesWarnings: Object.keys(nativeAttributes), style: style, ...formFieldContext }), onMouseDown: handleDropdownMouseDown, open: open && (!!dropdownContent || !!dropdownFooter), footer: dropdownFooterRef && (React.createElement("div", { ref: dropdownFooterRef, className: styles['dropdown-footer'], onKeyDown: handleDropdownKeyDown }, open && dropdownFooter ? dropdownFooter : null)), expandToViewport: expandToViewport, loopFocus: loopFocus, content: open && dropdownContent ? (React.createElement("div", { ref: dropdownContentRef, className: styles['dropdown-content'] }, dropdownContent)) : null })));
});
export default AutosuggestInput;
//# sourceMappingURL=index.js.map