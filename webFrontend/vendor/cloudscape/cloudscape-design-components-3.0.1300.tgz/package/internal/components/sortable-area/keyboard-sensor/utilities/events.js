// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export var EventName;
(function (EventName) {
    EventName["Blur"] = "blur";
    EventName["Keydown"] = "keydown";
    EventName["Resize"] = "resize";
    EventName["VisibilityChange"] = "visibilitychange";
    EventName["CustomDown"] = "custom-movedown";
    EventName["CustomUp"] = "custom-moveup";
})(EventName || (EventName = {}));
//# sourceMappingURL=events.js.map