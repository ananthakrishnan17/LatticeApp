// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import styles from './styles.css.js';
const splitOnFiltering = (str, highlightText) => {
    // We match by creating a regex using user-provided strings, so we skip
    // highlighting if the generated regex would be too memory intensive.
    if (highlightText.length > 10000) {
        return { noMatches: [str], matches: null };
    }
    // Filtering needs to be case insensitive
    const filteringPattern = highlightText.replace(/[-[\]/{}()*+?.\\^$|]/g, '\\$&');
    const regexp = new RegExp(filteringPattern, 'gi');
    const noMatches = str.split(regexp);
    const matches = str.match(regexp);
    return { noMatches, matches };
};
function Highlight({ str, labelRef }) {
    return (React.createElement("mark", { ref: labelRef, className: styles['filtering-match-highlight'] }, str));
}
export default function HighlightMatch({ str, highlightText, labelRef }) {
    if (!str || !highlightText) {
        return React.createElement("span", { ref: labelRef }, str);
    }
    if (str === highlightText) {
        return React.createElement(Highlight, { labelRef: labelRef, str: str });
    }
    const { noMatches, matches } = splitOnFiltering(str, highlightText);
    const highlighted = [];
    noMatches.forEach((noMatch, idx) => {
        highlighted.push(React.createElement("span", { key: `noMatch-${idx}` }, noMatch));
        if (matches && idx < matches.length) {
            highlighted.push(React.createElement(Highlight, { key: `match-${idx}`, str: matches[idx] }));
        }
    });
    return React.createElement("span", { ref: labelRef }, highlighted);
}
//# sourceMappingURL=highlight-match.js.map