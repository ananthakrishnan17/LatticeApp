// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useRef } from 'react';
import clsx from 'clsx';
import { findUpUntil } from '@cloudscape-design/component-toolkit/dom';
import { useMergeRefs, useStableCallback } from '@cloudscape-design/component-toolkit/internal';
import { getBaseProps } from '../../base-component';
import { fireKeyboardEvent, fireNonCancelableEvent, } from '../../events';
import styles from './styles.css.js';
const BOTTOM_TRIGGER_OFFSET = 80;
const getItemIndex = (containerRef, event) => {
    const target = findUpUntil(event.target, element => element === containerRef.current || !!element.dataset.mouseTarget);
    const mouseTarget = target === null || target === void 0 ? void 0 : target.dataset.mouseTarget;
    return mouseTarget ? parseInt(mouseTarget) : -1;
};
const OptionsList = ({ open, statusType, children, nativeAttributes = {}, onKeyDown, onBlur, onFocus, onLoadMore, onMouseUp, onMouseMove, position = 'relative', role = 'listbox', tagOverride: Tag = 'div', decreaseBlockMargin = false, ariaLabel, ariaLabelledby, ariaDescribedby, ariaRequired, embedded, stickyItemBlockSize, isMultiSelect, ...restProps }, ref) => {
    const baseProps = getBaseProps(restProps);
    const menuRef = useRef(null);
    const handleScroll = useStableCallback(() => {
        const scrollContainer = menuRef === null || menuRef === void 0 ? void 0 : menuRef.current;
        if (scrollContainer) {
            const bottomEdgePosition = scrollContainer.scrollTop + scrollContainer.clientHeight;
            const remainingScrollHeight = scrollContainer.scrollHeight - bottomEdgePosition;
            if (remainingScrollHeight < BOTTOM_TRIGGER_OFFSET) {
                fireNonCancelableEvent(onLoadMore);
            }
        }
    });
    useEffect(() => {
        if (open && statusType === 'pending') {
            handleScroll();
        }
    }, [open, statusType, handleScroll]);
    const className = clsx(styles['options-list'], {
        [styles['decrease-block-margin']]: decreaseBlockMargin,
        [styles['options-list-embedded']]: embedded,
    });
    const mergedRef = useMergeRefs(ref, menuRef);
    return (React.createElement(Tag, { ...baseProps, ...nativeAttributes, className: className, ref: mergedRef, style: { position, scrollPaddingBlockStart: stickyItemBlockSize !== null && stickyItemBlockSize !== void 0 ? stickyItemBlockSize : undefined }, role: role, onScroll: handleScroll, onKeyDown: event => fireKeyboardEvent(onKeyDown, event), onMouseMove: event => onMouseMove === null || onMouseMove === void 0 ? void 0 : onMouseMove(getItemIndex(menuRef, event)), onMouseUp: event => onMouseUp === null || onMouseUp === void 0 ? void 0 : onMouseUp(getItemIndex(menuRef, event)), onBlur: event => fireNonCancelableEvent(onBlur, { relatedTarget: event.relatedTarget }), onFocus: () => fireNonCancelableEvent(onFocus), tabIndex: embedded ? 0 : -1, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, "aria-describedby": ariaDescribedby, "aria-multiselectable": role === 'listbox' && isMultiSelect ? true : undefined, "aria-required": ariaRequired }, open && children));
};
export default React.forwardRef(OptionsList);
//# sourceMappingURL=index.js.map