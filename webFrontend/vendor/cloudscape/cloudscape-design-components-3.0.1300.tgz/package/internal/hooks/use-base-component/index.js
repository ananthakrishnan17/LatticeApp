import { useComponentMetadata, useComponentMetrics, useFocusVisible, } from '@cloudscape-design/component-toolkit/internal';
import { PACKAGE_SOURCE, PACKAGE_VERSION, THEME } from '../../environment';
import { getVisualTheme } from '../../utils/get-visual-theme';
import { useVisualRefresh } from '../use-visual-mode';
import { useMissingStylesCheck } from './styles-check';
/**
 * This hook is used for components which are exported to customers. The returned __internalRootRef needs to be
 * attached to the (internal) component's root DOM node. The hook takes care of attaching the metadata to this
 * root DOM node and emits the telemetry for this component.
 */
export default function useBaseComponent(componentName, config, analyticsMetadata) {
    const isVisualRefresh = useVisualRefresh();
    const theme = getVisualTheme(THEME, isVisualRefresh);
    useComponentMetrics(componentName, { packageSource: PACKAGE_SOURCE, packageVersion: PACKAGE_VERSION, theme }, config);
    const elementRef = useComponentMetadata(componentName, { packageName: PACKAGE_SOURCE, version: PACKAGE_VERSION, theme }, analyticsMetadata);
    useMissingStylesCheck(elementRef);
    useFocusVisible(elementRef);
    return { __internalRootRef: elementRef };
}
//# sourceMappingURL=index.js.map