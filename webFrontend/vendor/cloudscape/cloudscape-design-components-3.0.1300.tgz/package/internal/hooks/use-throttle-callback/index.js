// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useMemo } from 'react';
import { throttle } from '../../utils/throttle';
export function useThrottleCallback(func, delay, deps) {
    // eslint-disable-next-line react-hooks/exhaustive-deps
    return useMemo(() => throttle(func, delay), deps);
}
//# sourceMappingURL=index.js.map