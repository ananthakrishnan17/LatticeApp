// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useRef } from 'react';
/**
 * Custom hook to handle IME composition state for preventing IME race conditions when pressing enter to end composition.
 *
 * IME generates duplicate Enter events:
 * 1. First Enter: Ends composition (isComposing=true -> false)
 * 2. Second Enter: Triggers normal action (isComposing=false)
 *
 * This hook tracks composition lifecycle to prevent the second Enter during the brief window.
 *
 * The optional `onCompositionEnd` callback fires synchronously when composition commits,
 * allowing callers to process the final composed text (e.g. trigger detection in token mode).
 */
export function useIMEComposition(elementRef, { onCompositionStart, onCompositionEnd } = {}) {
    const wasComposingRef = useRef(false);
    const onCompositionStartRef = useRef(onCompositionStart);
    onCompositionStartRef.current = onCompositionStart;
    const onCompositionEndRef = useRef(onCompositionEnd);
    onCompositionEndRef.current = onCompositionEnd;
    const handleCompositionStart = () => {
        var _a;
        wasComposingRef.current = true;
        (_a = onCompositionStartRef.current) === null || _a === void 0 ? void 0 : _a.call(onCompositionStartRef);
    };
    const handleCompositionEnd = () => {
        var _a;
        // Fire the callback while wasComposing is still true — this blocks the spurious
        // Enter keydown that fires synchronously after compositionend in some browsers.
        (_a = onCompositionEndRef.current) === null || _a === void 0 ? void 0 : _a.call(onCompositionEndRef);
        // Keep flag true briefly to catch immediate post-composition Enter events.
        requestAnimationFrame(() => {
            wasComposingRef.current = false;
        });
    };
    useEffect(() => {
        const element = elementRef.current;
        if (!element) {
            return;
        }
        element.addEventListener('compositionstart', handleCompositionStart);
        element.addEventListener('compositionend', handleCompositionEnd);
        return () => {
            element.removeEventListener('compositionstart', handleCompositionStart);
            element.removeEventListener('compositionend', handleCompositionEnd);
        };
    }, [elementRef]);
    const isComposing = () => wasComposingRef.current;
    return { isComposing };
}
//# sourceMappingURL=index.js.map