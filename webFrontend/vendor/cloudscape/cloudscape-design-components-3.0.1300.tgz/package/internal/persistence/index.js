// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
/* istanbul ignore file */
/* eslint-disable require-await, @typescript-eslint/no-unused-vars */
export function setPersistenceFunctionsForTesting(functions) {
    if (functions.persistFlashbarDismiss) {
        persistFlashbarDismiss = functions.persistFlashbarDismiss;
    }
    if (functions.retrieveFlashbarDismiss) {
        retrieveFlashbarDismiss = functions.retrieveFlashbarDismiss;
    }
    if (functions.persistAlertDismiss) {
        persistAlertDismiss = functions.persistAlertDismiss;
    }
    if (functions.retrieveAlertDismiss) {
        retrieveAlertDismiss = functions.retrieveAlertDismiss;
    }
    if (functions.persistFeatureNotifications) {
        persistFeatureNotifications = functions.persistFeatureNotifications;
    }
    if (functions.retrieveFeatureNotifications) {
        retrieveFeatureNotifications = functions.retrieveFeatureNotifications;
    }
}
export let persistFlashbarDismiss = async function (persistenceConfig) {
    return Promise.resolve();
};
export let retrieveFlashbarDismiss = async function (persistenceConfig) {
    return Promise.resolve(false);
};
export let persistAlertDismiss = async function (persistenceConfig) {
    return Promise.resolve();
};
export let retrieveAlertDismiss = async function (persistenceConfig) {
    return Promise.resolve(false);
};
export let persistFeatureNotifications = async function (persistenceConfig, value) {
    return Promise.resolve();
};
export let retrieveFeatureNotifications = async function (persistenceConfig) {
    return Promise.resolve({});
};
//# sourceMappingURL=index.js.map