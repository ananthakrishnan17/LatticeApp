// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import useBaseComponent from '../../hooks/use-base-component';
import { applyDisplayName } from '../../utils/apply-display-name';
import { getExternalProps } from '../../utils/external-props';
import InternalFeaturePrompt from './internal';
const FeaturePrompt = React.forwardRef(({ size = 'medium', position = 'top', ...rest }, ref) => {
    const baseComponentProps = useBaseComponent('FeaturePrompt', { props: { size, position } });
    const externalProps = getExternalProps(rest);
    return (React.createElement(InternalFeaturePrompt, { ref: ref, size: size, position: position, ...externalProps, ...baseComponentProps }));
});
applyDisplayName(FeaturePrompt, 'FeaturePrompt');
export default FeaturePrompt;
//# sourceMappingURL=index.js.map