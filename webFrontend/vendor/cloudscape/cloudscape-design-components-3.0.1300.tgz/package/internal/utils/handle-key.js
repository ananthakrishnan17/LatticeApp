// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { getIsRtl } from '@cloudscape-design/component-toolkit/internal';
import { KeyCode, KeyCodeA, KeyCodeDelete } from '../keycode';
import { isHTMLElement, isSVGElement } from './dom';
export function isEventLike(event) {
    return isHTMLElement(event.currentTarget) || isSVGElement(event.currentTarget);
}
export default function handleKey(event, { onActivate, onBackspace, onBlockEnd, onBlockStart, onDefault, onDelete, onEnd, onEnter, onEscape, onHome, onInlineEnd, onInlineStart, onPageDown, onPageUp, onSelectAll, onShiftEnter, onShiftInlineEnd, onShiftInlineStart, onSpace, onTab, }) {
    switch (event.keyCode) {
        case KeyCodeA:
            if ((event.ctrlKey || event.metaKey) && onSelectAll) {
                onSelectAll();
            }
            else {
                onDefault === null || onDefault === void 0 ? void 0 : onDefault();
            }
            break;
        case KeyCode.backspace:
            // TODO: Remove onDefault fallback once all callers handle backspace explicitly
            if (onBackspace) {
                onBackspace();
            }
            else {
                onDefault === null || onDefault === void 0 ? void 0 : onDefault();
            }
            break;
        case KeyCodeDelete:
            // TODO: Remove onDefault fallback once all callers handle delete explicitly
            if (onDelete) {
                onDelete();
            }
            else {
                onDefault === null || onDefault === void 0 ? void 0 : onDefault();
            }
            break;
        case KeyCode.down:
            onBlockEnd === null || onBlockEnd === void 0 ? void 0 : onBlockEnd();
            break;
        case KeyCode.end:
            onEnd === null || onEnd === void 0 ? void 0 : onEnd();
            break;
        case KeyCode.enter:
            if (event.shiftKey && onShiftEnter) {
                onShiftEnter();
            }
            else if (onEnter) {
                onEnter();
            }
            else {
                onActivate === null || onActivate === void 0 ? void 0 : onActivate();
            }
            break;
        case KeyCode.escape:
            onEscape === null || onEscape === void 0 ? void 0 : onEscape();
            break;
        case KeyCode.home:
            onHome === null || onHome === void 0 ? void 0 : onHome();
            break;
        case KeyCode.left:
            if (event.shiftKey && (onShiftInlineStart || onShiftInlineEnd)) {
                getIsRtl(event.currentTarget) ? onShiftInlineEnd === null || onShiftInlineEnd === void 0 ? void 0 : onShiftInlineEnd() : onShiftInlineStart === null || onShiftInlineStart === void 0 ? void 0 : onShiftInlineStart();
                break;
            }
            getIsRtl(event.currentTarget) ? onInlineEnd === null || onInlineEnd === void 0 ? void 0 : onInlineEnd() : onInlineStart === null || onInlineStart === void 0 ? void 0 : onInlineStart();
            break;
        case KeyCode.pageDown:
            onPageDown === null || onPageDown === void 0 ? void 0 : onPageDown();
            break;
        case KeyCode.pageUp:
            onPageUp === null || onPageUp === void 0 ? void 0 : onPageUp();
            break;
        case KeyCode.right:
            if (event.shiftKey && (onShiftInlineStart || onShiftInlineEnd)) {
                getIsRtl(event.currentTarget) ? onShiftInlineStart === null || onShiftInlineStart === void 0 ? void 0 : onShiftInlineStart() : onShiftInlineEnd === null || onShiftInlineEnd === void 0 ? void 0 : onShiftInlineEnd();
                break;
            }
            getIsRtl(event.currentTarget) ? onInlineStart === null || onInlineStart === void 0 ? void 0 : onInlineStart() : onInlineEnd === null || onInlineEnd === void 0 ? void 0 : onInlineEnd();
            break;
        case KeyCode.space:
            if (onSpace) {
                onSpace();
            }
            else {
                onActivate === null || onActivate === void 0 ? void 0 : onActivate();
            }
            break;
        case KeyCode.tab:
            // TODO: Remove onDefault fallback once all callers handle tab explicitly
            if (onTab) {
                onTab();
            }
            else {
                onDefault === null || onDefault === void 0 ? void 0 : onDefault();
            }
            break;
        case KeyCode.up:
            onBlockStart === null || onBlockStart === void 0 ? void 0 : onBlockStart();
            break;
        default:
            onDefault === null || onDefault === void 0 ? void 0 : onDefault();
            break;
    }
}
//# sourceMappingURL=handle-key.js.map