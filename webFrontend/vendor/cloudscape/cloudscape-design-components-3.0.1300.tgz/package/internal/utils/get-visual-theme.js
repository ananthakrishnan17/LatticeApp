// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export const getVisualTheme = (theme, isVR) => {
    if (theme === 'polaris' && isVR) {
        return 'vr';
    }
    return theme;
};
//# sourceMappingURL=get-visual-theme.js.map