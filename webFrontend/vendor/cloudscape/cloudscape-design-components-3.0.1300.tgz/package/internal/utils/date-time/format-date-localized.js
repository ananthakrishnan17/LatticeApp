// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { isValid, parseISO } from 'date-fns';
import { formatTimeOffsetLocalized } from './format-time-offset';
export default function formatDateLocalized({ date: isoDate, hideTimeOffset, isDateOnly, isMonthOnly, timeOffset, locale, }) {
    let date = parseISO(isoDate);
    // if the date is not ISO formatted, fallback to built-in date parsing
    if (!isValid(date)) {
        date = new Date(isoDate);
    }
    if (isMonthOnly) {
        const formattedMonthDate = new Intl.DateTimeFormat(locale, {
            month: 'long',
            year: 'numeric',
        }).format(date);
        return formattedMonthDate;
    }
    const formattedDate = new Intl.DateTimeFormat(locale, {
        month: 'long',
        year: 'numeric',
        day: 'numeric',
    }).format(date);
    if (isDateOnly) {
        return formattedDate;
    }
    const formattedTime = new Intl.DateTimeFormat(locale, {
        hour: '2-digit',
        hourCycle: 'h23',
        minute: '2-digit',
        second: '2-digit',
    }).format(date);
    const formattedDateTime = formattedDate + getDateTimeSeparator(locale) + formattedTime;
    if (hideTimeOffset) {
        return formattedDateTime;
    }
    const formattedTimeOffset = formatTimeOffsetLocalized(isoDate, timeOffset);
    return formattedDateTime + ' ' + formattedTimeOffset;
}
// Languages in which date and time are separated just with a space, without comma
const languagesWithoutDateTimeSeparator = ['ja', 'zh-CN', 'zh-TW'];
function getDateTimeSeparator(locale) {
    return locale && languagesWithoutDateTimeSeparator.includes(locale) ? ' ' : ', ';
}
//# sourceMappingURL=format-date-localized.js.map