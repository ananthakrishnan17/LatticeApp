export var preset = {
  "theme": {
    "id": "visual-refresh",
    "selector": "body",
    "modes": {
      "color": {
        "id": "color",
        "states": {
          "light": {
            "default": true
          },
          "dark": {
            "selector": ".awsui-dark-mode",
            "media": "not print"
          }
        }
      },
      "density": {
        "id": "density",
        "states": {
          "comfortable": {
            "default": true
          },
          "compact": {
            "selector": ".awsui-compact-mode"
          }
        }
      },
      "motion": {
        "id": "motion",
        "states": {
          "default": {
            "default": true
          },
          "disabled": {
            "selector": ".awsui-motion-disabled"
          }
        }
      }
    },
    "tokens": {
      "colorPrimary50": {
        "light": "#f0fbff",
        "dark": "#f0fbff"
      },
      "colorPrimary100": {
        "light": "#d1f1ff",
        "dark": "#d1f1ff"
      },
      "colorPrimary200": {
        "light": "#b8e7ff",
        "dark": "#b8e7ff"
      },
      "colorPrimary300": {
        "light": "#75cfff",
        "dark": "#75cfff"
      },
      "colorPrimary400": {
        "light": "#42b4ff",
        "dark": "#42b4ff"
      },
      "colorPrimary500": {
        "light": "#0099ff",
        "dark": "#0099ff"
      },
      "colorPrimary600": {
        "light": "#006ce0",
        "dark": "#006ce0"
      },
      "colorPrimary700": {
        "light": "#004a9e",
        "dark": "#004a9e"
      },
      "colorPrimary800": {
        "light": "#003b8f",
        "dark": "#003b8f"
      },
      "colorPrimary900": {
        "light": "#002b66",
        "dark": "#002b66"
      },
      "colorPrimary1000": {
        "light": "#001129",
        "dark": "#001129"
      },
      "colorNeutral50": {
        "light": "#fcfcfd",
        "dark": "#fcfcfd"
      },
      "colorNeutral100": {
        "light": "#f9f9fa",
        "dark": "#f9f9fa"
      },
      "colorNeutral150": {
        "light": "#f6f6f9",
        "dark": "#f6f6f9"
      },
      "colorNeutral200": {
        "light": "#f3f3f7",
        "dark": "#f3f3f7"
      },
      "colorNeutral250": {
        "light": "#ebebf0",
        "dark": "#ebebf0"
      },
      "colorNeutral300": {
        "light": "#dedee3",
        "dark": "#dedee3"
      },
      "colorNeutral350": {
        "light": "#c6c6cd",
        "dark": "#c6c6cd"
      },
      "colorNeutral400": {
        "light": "#b4b4bb",
        "dark": "#b4b4bb"
      },
      "colorNeutral450": {
        "light": "#a4a4ad",
        "dark": "#a4a4ad"
      },
      "colorNeutral500": {
        "light": "#8c8c94",
        "dark": "#8c8c94"
      },
      "colorNeutral550": {
        "light": "#72747e",
        "dark": "#72747e"
      },
      "colorNeutral600": {
        "light": "#656871",
        "dark": "#656871"
      },
      "colorNeutral650": {
        "light": "#424650",
        "dark": "#424650"
      },
      "colorNeutral700": {
        "light": "#333843",
        "dark": "#333843"
      },
      "colorNeutral750": {
        "light": "#232b37",
        "dark": "#232b37"
      },
      "colorNeutral800": {
        "light": "#1b232d",
        "dark": "#1b232d"
      },
      "colorNeutral850": {
        "light": "#161d26",
        "dark": "#161d26"
      },
      "colorNeutral900": {
        "light": "#131920",
        "dark": "#131920"
      },
      "colorNeutral950": {
        "light": "#0f141a",
        "dark": "#0f141a"
      },
      "colorNeutral1000": {
        "light": "#06080a",
        "dark": "#06080a"
      },
      "colorError50": {
        "light": "#fff5f5",
        "dark": "#fff5f5"
      },
      "colorError400": {
        "light": "#ff7a7a",
        "dark": "#ff7a7a"
      },
      "colorError600": {
        "light": "#db0000",
        "dark": "#db0000"
      },
      "colorError900": {
        "light": "#700000",
        "dark": "#700000"
      },
      "colorError1000": {
        "light": "#1f0000",
        "dark": "#1f0000"
      },
      "colorSuccess50": {
        "light": "#effff1",
        "dark": "#effff1"
      },
      "colorSuccess500": {
        "light": "#2bb534",
        "dark": "#2bb534"
      },
      "colorSuccess600": {
        "light": "#00802f",
        "dark": "#00802f"
      },
      "colorSuccess1000": {
        "light": "#001401",
        "dark": "#001401"
      },
      "colorWarning50": {
        "light": "#fffef0",
        "dark": "#fffef0"
      },
      "colorWarning400": {
        "light": "#ffe347",
        "dark": "#ffe347"
      },
      "colorWarning500": {
        "light": "#fbd332",
        "dark": "#fbd332"
      },
      "colorWarning900": {
        "light": "#855900",
        "dark": "#855900"
      },
      "colorWarning1000": {
        "light": "#191100",
        "dark": "#191100"
      },
      "colorInfo50": {
        "light": "#f0fbff",
        "dark": "#f0fbff"
      },
      "colorInfo300": {
        "light": "#75cfff",
        "dark": "#75cfff"
      },
      "colorInfo400": {
        "light": "#42b4ff",
        "dark": "#42b4ff"
      },
      "colorInfo600": {
        "light": "#006ce0",
        "dark": "#006ce0"
      },
      "colorInfo1000": {
        "light": "#001129",
        "dark": "#001129"
      },
      "colorGrey50": {
        "light": "#fcfcfd",
        "dark": "#fcfcfd"
      },
      "colorGrey100": {
        "light": "#f9f9fa",
        "dark": "#f9f9fa"
      },
      "colorGrey150": {
        "light": "#f6f6f9",
        "dark": "#f6f6f9"
      },
      "colorGrey200": {
        "light": "#f3f3f7",
        "dark": "#f3f3f7"
      },
      "colorGrey250": {
        "light": "#ebebf0",
        "dark": "#ebebf0"
      },
      "colorGrey300": {
        "light": "#dedee3",
        "dark": "#dedee3"
      },
      "colorGrey350": {
        "light": "#c6c6cd",
        "dark": "#c6c6cd"
      },
      "colorGrey400": {
        "light": "#b4b4bb",
        "dark": "#b4b4bb"
      },
      "colorGrey450": {
        "light": "#a4a4ad",
        "dark": "#a4a4ad"
      },
      "colorGrey500": {
        "light": "#8c8c94",
        "dark": "#8c8c94"
      },
      "colorGrey600": {
        "light": "#656871",
        "dark": "#656871"
      },
      "colorGrey650": {
        "light": "#424650",
        "dark": "#424650"
      },
      "colorGrey700": {
        "light": "#333843",
        "dark": "#333843"
      },
      "colorGrey750": {
        "light": "#232b37",
        "dark": "#232b37"
      },
      "colorGrey800": {
        "light": "#1b232d",
        "dark": "#1b232d"
      },
      "colorGrey850": {
        "light": "#161d26",
        "dark": "#161d26"
      },
      "colorGrey900": {
        "light": "#131920",
        "dark": "#131920"
      },
      "colorGrey950": {
        "light": "#0f141a",
        "dark": "#0f141a"
      },
      "colorGrey1000": {
        "light": "#06080a",
        "dark": "#06080a"
      },
      "colorBlue50": {
        "light": "#f0fbff",
        "dark": "#f0fbff"
      },
      "colorBlue100": {
        "light": "#d1f1ff",
        "dark": "#d1f1ff"
      },
      "colorBlue200": {
        "light": "#b8e7ff",
        "dark": "#b8e7ff"
      },
      "colorBlue300": {
        "light": "#75cfff",
        "dark": "#75cfff"
      },
      "colorBlue400": {
        "light": "#42b4ff",
        "dark": "#42b4ff"
      },
      "colorBlue600": {
        "light": "#006ce0",
        "dark": "#006ce0"
      },
      "colorBlue700": {
        "light": "#004a9e",
        "dark": "#004a9e"
      },
      "colorBlue900": {
        "light": "#002b66",
        "dark": "#002b66"
      },
      "colorBlue1000": {
        "light": "#001129",
        "dark": "#001129"
      },
      "colorGreen50": {
        "light": "#effff1",
        "dark": "#effff1"
      },
      "colorGreen500": {
        "light": "#2bb534",
        "dark": "#2bb534"
      },
      "colorGreen600": {
        "light": "#00802f",
        "dark": "#00802f"
      },
      "colorGreen900": {
        "light": "#00471e",
        "dark": "#00471e"
      },
      "colorGreen1000": {
        "light": "#001401",
        "dark": "#001401"
      },
      "colorRed50": {
        "light": "#fff5f5",
        "dark": "#fff5f5"
      },
      "colorRed400": {
        "light": "#ff7a7a",
        "dark": "#ff7a7a"
      },
      "colorRed600": {
        "light": "#db0000",
        "dark": "#db0000"
      },
      "colorRed900": {
        "light": "#700000",
        "dark": "#700000"
      },
      "colorRed1000": {
        "light": "#1f0000",
        "dark": "#1f0000"
      },
      "colorYellow50": {
        "light": "#fffef0",
        "dark": "#fffef0"
      },
      "colorYellow400": {
        "light": "#ffe347",
        "dark": "#ffe347"
      },
      "colorYellow500": {
        "light": "#fbd332",
        "dark": "#fbd332"
      },
      "colorYellow900": {
        "light": "#855900",
        "dark": "#855900"
      },
      "colorYellow1000": {
        "light": "#191100",
        "dark": "#191100"
      },
      "colorPurple400": {
        "light": "#bf80ff",
        "dark": "#bf80ff"
      },
      "colorPurple700": {
        "light": "#7300e5",
        "dark": "#7300e5"
      },
      "colorAmber400": {
        "light": "#ff9900",
        "dark": "#ff9900"
      },
      "colorAmber500": {
        "light": "#fa6f00",
        "dark": "#fa6f00"
      },
      "colorAwsSquidInk": {
        "light": "#232f3e",
        "dark": "#232f3e"
      },
      "colorTransparent": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBlack": {
        "light": "#000000",
        "dark": "#000000"
      },
      "colorWhite": {
        "light": "#ffffff",
        "dark": "#ffffff"
      },
      "colorChartsRed300": {
        "light": "#ea7158",
        "dark": "#d63f38"
      },
      "colorChartsRed400": {
        "light": "#dc5032",
        "dark": "#ed5958"
      },
      "colorChartsRed500": {
        "light": "#d13313",
        "dark": "#fe6e73"
      },
      "colorChartsRed600": {
        "light": "#ba2e0f",
        "dark": "#ff8a8a"
      },
      "colorChartsRed700": {
        "light": "#a82a0c",
        "dark": "#ffa09e"
      },
      "colorChartsRed800": {
        "light": "#972709",
        "dark": "#ffb3b0"
      },
      "colorChartsRed900": {
        "light": "#892407",
        "dark": "#ffc4c0"
      },
      "colorChartsRed1000": {
        "light": "#7d2105",
        "dark": "#ffd2cf"
      },
      "colorChartsRed1100": {
        "light": "#721e03",
        "dark": "#ffe0dd"
      },
      "colorChartsRed1200": {
        "light": "#671c00",
        "dark": "#ffecea"
      },
      "colorChartsOrange300": {
        "light": "#e07941",
        "dark": "#c55305"
      },
      "colorChartsOrange400": {
        "light": "#cc5f21",
        "dark": "#de6923"
      },
      "colorChartsOrange500": {
        "light": "#bc4d01",
        "dark": "#f27c36"
      },
      "colorChartsOrange600": {
        "light": "#a84401",
        "dark": "#f89256"
      },
      "colorChartsOrange700": {
        "light": "#983c02",
        "dark": "#fca572"
      },
      "colorChartsOrange800": {
        "light": "#8a3603",
        "dark": "#ffb68b"
      },
      "colorChartsOrange900": {
        "light": "#7e3103",
        "dark": "#ffc6a4"
      },
      "colorChartsOrange1000": {
        "light": "#732c02",
        "dark": "#ffd4bb"
      },
      "colorChartsOrange1100": {
        "light": "#692801",
        "dark": "#ffe1cf"
      },
      "colorChartsOrange1200": {
        "light": "#602400",
        "dark": "#ffede2"
      },
      "colorChartsYellow300": {
        "light": "#b2911c",
        "dark": "#977001"
      },
      "colorChartsYellow400": {
        "light": "#9c7b0b",
        "dark": "#b08400"
      },
      "colorChartsYellow500": {
        "light": "#8a6b05",
        "dark": "#c59600"
      },
      "colorChartsYellow600": {
        "light": "#7b5f04",
        "dark": "#d3a61c"
      },
      "colorChartsYellow700": {
        "light": "#6f5504",
        "dark": "#dfb52c"
      },
      "colorChartsYellow800": {
        "light": "#654d03",
        "dark": "#eac33a"
      },
      "colorChartsYellow900": {
        "light": "#5d4503",
        "dark": "#f1cf65"
      },
      "colorChartsYellow1000": {
        "light": "#553f03",
        "dark": "#f7db8a"
      },
      "colorChartsYellow1100": {
        "light": "#4d3901",
        "dark": "#fce5a8"
      },
      "colorChartsYellow1200": {
        "light": "#483300",
        "dark": "#ffefc9"
      },
      "colorChartsGreen300": {
        "light": "#67a353",
        "dark": "#48851a"
      },
      "colorChartsGreen400": {
        "light": "#41902c",
        "dark": "#5a9b29"
      },
      "colorChartsGreen500": {
        "light": "#1f8104",
        "dark": "#69ae34"
      },
      "colorChartsGreen600": {
        "light": "#1a7302",
        "dark": "#7dbd4c"
      },
      "colorChartsGreen700": {
        "light": "#176702",
        "dark": "#8fca61"
      },
      "colorChartsGreen800": {
        "light": "#145d02",
        "dark": "#9fd673"
      },
      "colorChartsGreen900": {
        "light": "#125502",
        "dark": "#b2df8d"
      },
      "colorChartsGreen1000": {
        "light": "#104d01",
        "dark": "#c5e7a8"
      },
      "colorChartsGreen1100": {
        "light": "#0f4601",
        "dark": "#d5efbe"
      },
      "colorChartsGreen1200": {
        "light": "#0d4000",
        "dark": "#e4f7d5"
      },
      "colorChartsTeal300": {
        "light": "#2ea597",
        "dark": "#018977"
      },
      "colorChartsTeal400": {
        "light": "#1c8e81",
        "dark": "#009d89"
      },
      "colorChartsTeal500": {
        "light": "#0d7d70",
        "dark": "#00b09b"
      },
      "colorChartsTeal600": {
        "light": "#096f64",
        "dark": "#40bfa9"
      },
      "colorChartsTeal700": {
        "light": "#06645a",
        "dark": "#5fccb7"
      },
      "colorChartsTeal800": {
        "light": "#045b52",
        "dark": "#77d7c3"
      },
      "colorChartsTeal900": {
        "light": "#03524a",
        "dark": "#94e0d0"
      },
      "colorChartsTeal1000": {
        "light": "#014b44",
        "dark": "#ace9db"
      },
      "colorChartsTeal1100": {
        "light": "#01443e",
        "dark": "#c2f0e6"
      },
      "colorChartsTeal1200": {
        "light": "#003e38",
        "dark": "#d7f7f0"
      },
      "colorChartsBlue1300": {
        "light": "#529ccb",
        "dark": "#00819c"
      },
      "colorChartsBlue1400": {
        "light": "#3184c2",
        "dark": "#0497ba"
      },
      "colorChartsBlue1500": {
        "light": "#0273bb",
        "dark": "#08aad2"
      },
      "colorChartsBlue1600": {
        "light": "#0166ab",
        "dark": "#44b9dd"
      },
      "colorChartsBlue1700": {
        "light": "#015b9d",
        "dark": "#63c6e7"
      },
      "colorChartsBlue1800": {
        "light": "#015292",
        "dark": "#79d2f0"
      },
      "colorChartsBlue1900": {
        "light": "#014a87",
        "dark": "#98dcf5"
      },
      "colorChartsBlue11000": {
        "light": "#01437d",
        "dark": "#b3e4f8"
      },
      "colorChartsBlue11100": {
        "light": "#003c75",
        "dark": "#caedfc"
      },
      "colorChartsBlue11200": {
        "light": "#00366d",
        "dark": "#ddf4ff"
      },
      "colorChartsBlue2300": {
        "light": "#688ae8",
        "dark": "#486de8"
      },
      "colorChartsBlue2400": {
        "light": "#5978e3",
        "dark": "#6384f5"
      },
      "colorChartsBlue2500": {
        "light": "#4066df",
        "dark": "#7698fe"
      },
      "colorChartsBlue2600": {
        "light": "#3759ce",
        "dark": "#8ea9ff"
      },
      "colorChartsBlue2700": {
        "light": "#314fbf",
        "dark": "#a2b8ff"
      },
      "colorChartsBlue2800": {
        "light": "#2c46b1",
        "dark": "#b1c5ff"
      },
      "colorChartsBlue2900": {
        "light": "#273ea5",
        "dark": "#c3d1ff"
      },
      "colorChartsBlue21000": {
        "light": "#23379b",
        "dark": "#d2dcff"
      },
      "colorChartsBlue21100": {
        "light": "#1f3191",
        "dark": "#dfe6ff"
      },
      "colorChartsBlue21200": {
        "light": "#1b2b88",
        "dark": "#ecf0ff"
      },
      "colorChartsPurple300": {
        "light": "#a783e1",
        "dark": "#8d59de"
      },
      "colorChartsPurple400": {
        "light": "#9469d6",
        "dark": "#a173ea"
      },
      "colorChartsPurple500": {
        "light": "#8456ce",
        "dark": "#b088f5"
      },
      "colorChartsPurple600": {
        "light": "#7749bf",
        "dark": "#bf9bf9"
      },
      "colorChartsPurple700": {
        "light": "#6b40b2",
        "dark": "#cbabfc"
      },
      "colorChartsPurple800": {
        "light": "#6237a7",
        "dark": "#d6baff"
      },
      "colorChartsPurple900": {
        "light": "#59309d",
        "dark": "#dfc8ff"
      },
      "colorChartsPurple1000": {
        "light": "#512994",
        "dark": "#e8d5ff"
      },
      "colorChartsPurple1100": {
        "light": "#4a238b",
        "dark": "#efe2ff"
      },
      "colorChartsPurple1200": {
        "light": "#431d84",
        "dark": "#f5edff"
      },
      "colorChartsPink300": {
        "light": "#da7596",
        "dark": "#c64a70"
      },
      "colorChartsPink400": {
        "light": "#ce567c",
        "dark": "#d56889"
      },
      "colorChartsPink500": {
        "light": "#c33d69",
        "dark": "#e07f9d"
      },
      "colorChartsPink600": {
        "light": "#b1325c",
        "dark": "#eb92ad"
      },
      "colorChartsPink700": {
        "light": "#a32952",
        "dark": "#f5a2bb"
      },
      "colorChartsPink800": {
        "light": "#962249",
        "dark": "#ffb0c8"
      },
      "colorChartsPink900": {
        "light": "#8b1b42",
        "dark": "#ffc1d4"
      },
      "colorChartsPink1000": {
        "light": "#81143b",
        "dark": "#ffd1de"
      },
      "colorChartsPink1100": {
        "light": "#780d35",
        "dark": "#ffdfe8"
      },
      "colorChartsPink1200": {
        "light": "#6f062f",
        "dark": "#ffecf1"
      },
      "colorChartsStatusCritical": {
        "light": "{colorChartsRed1000}",
        "dark": "{colorChartsRed300}"
      },
      "colorChartsStatusHigh": {
        "light": "{colorChartsRed600}",
        "dark": "{colorChartsRed500}"
      },
      "colorChartsStatusMedium": {
        "light": "{colorChartsOrange400}",
        "dark": "{colorChartsOrange600}"
      },
      "colorChartsStatusLow": {
        "light": "{colorChartsYellow300}",
        "dark": "{colorChartsYellow700}"
      },
      "colorChartsStatusPositive": {
        "light": "{colorChartsGreen300}",
        "dark": "{colorChartsGreen500}"
      },
      "colorChartsStatusInfo": {
        "light": "{colorChartsBlue1400}",
        "dark": "{colorChartsBlue1500}"
      },
      "colorChartsStatusNeutral": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorChartsThresholdNegative": {
        "light": "{colorError600}",
        "dark": "{colorError400}"
      },
      "colorChartsThresholdPositive": {
        "light": "{colorSuccess600}",
        "dark": "{colorSuccess500}"
      },
      "colorChartsThresholdInfo": {
        "light": "{colorInfo600}",
        "dark": "{colorInfo300}"
      },
      "colorChartsThresholdNeutral": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorChartsLineGrid": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral650}"
      },
      "colorChartsLineTick": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral650}"
      },
      "colorChartsLineAxis": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral650}"
      },
      "colorChartsPaletteCategorical1": {
        "light": "{colorChartsBlue2300}",
        "dark": "{colorChartsBlue2300}"
      },
      "colorChartsPaletteCategorical2": {
        "light": "{colorChartsPink500}",
        "dark": "{colorChartsPink500}"
      },
      "colorChartsPaletteCategorical3": {
        "light": "{colorChartsTeal300}",
        "dark": "{colorChartsTeal300}"
      },
      "colorChartsPaletteCategorical4": {
        "light": "{colorChartsPurple500}",
        "dark": "{colorChartsPurple500}"
      },
      "colorChartsPaletteCategorical5": {
        "light": "{colorChartsOrange300}",
        "dark": "{colorChartsOrange300}"
      },
      "colorChartsPaletteCategorical6": {
        "light": "{colorChartsBlue2600}",
        "dark": "{colorChartsBlue2600}"
      },
      "colorChartsPaletteCategorical7": {
        "light": "{colorChartsPink800}",
        "dark": "{colorChartsPink800}"
      },
      "colorChartsPaletteCategorical8": {
        "light": "{colorChartsTeal600}",
        "dark": "{colorChartsTeal600}"
      },
      "colorChartsPaletteCategorical9": {
        "light": "{colorChartsPurple800}",
        "dark": "{colorChartsPurple800}"
      },
      "colorChartsPaletteCategorical10": {
        "light": "{colorChartsOrange600}",
        "dark": "{colorChartsOrange600}"
      },
      "colorChartsPaletteCategorical11": {
        "light": "{colorChartsBlue2900}",
        "dark": "{colorChartsBlue2900}"
      },
      "colorChartsPaletteCategorical12": {
        "light": "{colorChartsPink1100}",
        "dark": "{colorChartsPink1100}"
      },
      "colorChartsPaletteCategorical13": {
        "light": "{colorChartsTeal900}",
        "dark": "{colorChartsTeal900}"
      },
      "colorChartsPaletteCategorical14": {
        "light": "{colorChartsPurple1100}",
        "dark": "{colorChartsPurple1100}"
      },
      "colorChartsPaletteCategorical15": {
        "light": "{colorChartsOrange900}",
        "dark": "{colorChartsOrange900}"
      },
      "colorChartsPaletteCategorical16": {
        "light": "{colorChartsBlue21200}",
        "dark": "{colorChartsBlue21200}"
      },
      "colorChartsPaletteCategorical17": {
        "light": "{colorChartsPink400}",
        "dark": "{colorChartsPink400}"
      },
      "colorChartsPaletteCategorical18": {
        "light": "{colorChartsTeal1200}",
        "dark": "{colorChartsTeal1200}"
      },
      "colorChartsPaletteCategorical19": {
        "light": "{colorChartsPurple400}",
        "dark": "{colorChartsPurple400}"
      },
      "colorChartsPaletteCategorical20": {
        "light": "{colorChartsOrange1200}",
        "dark": "{colorChartsOrange1200}"
      },
      "colorChartsPaletteCategorical21": {
        "light": "{colorChartsBlue2500}",
        "dark": "{colorChartsBlue2500}"
      },
      "colorChartsPaletteCategorical22": {
        "light": "{colorChartsPink700}",
        "dark": "{colorChartsPink700}"
      },
      "colorChartsPaletteCategorical23": {
        "light": "{colorChartsTeal500}",
        "dark": "{colorChartsTeal500}"
      },
      "colorChartsPaletteCategorical24": {
        "light": "{colorChartsPurple700}",
        "dark": "{colorChartsPurple700}"
      },
      "colorChartsPaletteCategorical25": {
        "light": "{colorChartsOrange500}",
        "dark": "{colorChartsOrange500}"
      },
      "colorChartsPaletteCategorical26": {
        "light": "{colorChartsBlue2800}",
        "dark": "{colorChartsBlue2800}"
      },
      "colorChartsPaletteCategorical27": {
        "light": "{colorChartsPink1000}",
        "dark": "{colorChartsPink1000}"
      },
      "colorChartsPaletteCategorical28": {
        "light": "{colorChartsTeal800}",
        "dark": "{colorChartsTeal800}"
      },
      "colorChartsPaletteCategorical29": {
        "light": "{colorChartsPurple1000}",
        "dark": "{colorChartsPurple1000}"
      },
      "colorChartsPaletteCategorical30": {
        "light": "{colorChartsOrange800}",
        "dark": "{colorChartsOrange800}"
      },
      "colorChartsPaletteCategorical31": {
        "light": "{colorChartsBlue21100}",
        "dark": "{colorChartsBlue21100}"
      },
      "colorChartsPaletteCategorical32": {
        "light": "{colorChartsPink300}",
        "dark": "{colorChartsPink300}"
      },
      "colorChartsPaletteCategorical33": {
        "light": "{colorChartsTeal1100}",
        "dark": "{colorChartsTeal1100}"
      },
      "colorChartsPaletteCategorical34": {
        "light": "{colorChartsPurple300}",
        "dark": "{colorChartsPurple300}"
      },
      "colorChartsPaletteCategorical35": {
        "light": "{colorChartsOrange1100}",
        "dark": "{colorChartsOrange1100}"
      },
      "colorChartsPaletteCategorical36": {
        "light": "{colorChartsBlue2400}",
        "dark": "{colorChartsBlue2400}"
      },
      "colorChartsPaletteCategorical37": {
        "light": "{colorChartsPink600}",
        "dark": "{colorChartsPink600}"
      },
      "colorChartsPaletteCategorical38": {
        "light": "{colorChartsTeal400}",
        "dark": "{colorChartsTeal400}"
      },
      "colorChartsPaletteCategorical39": {
        "light": "{colorChartsPurple600}",
        "dark": "{colorChartsPurple600}"
      },
      "colorChartsPaletteCategorical40": {
        "light": "{colorChartsOrange400}",
        "dark": "{colorChartsOrange400}"
      },
      "colorChartsPaletteCategorical41": {
        "light": "{colorChartsBlue2700}",
        "dark": "{colorChartsBlue2700}"
      },
      "colorChartsPaletteCategorical42": {
        "light": "{colorChartsPink900}",
        "dark": "{colorChartsPink900}"
      },
      "colorChartsPaletteCategorical43": {
        "light": "{colorChartsTeal700}",
        "dark": "{colorChartsTeal700}"
      },
      "colorChartsPaletteCategorical44": {
        "light": "{colorChartsPurple900}",
        "dark": "{colorChartsPurple900}"
      },
      "colorChartsPaletteCategorical45": {
        "light": "{colorChartsOrange700}",
        "dark": "{colorChartsOrange700}"
      },
      "colorChartsPaletteCategorical46": {
        "light": "{colorChartsBlue21000}",
        "dark": "{colorChartsBlue21000}"
      },
      "colorChartsPaletteCategorical47": {
        "light": "{colorChartsPink1200}",
        "dark": "{colorChartsPink1200}"
      },
      "colorChartsPaletteCategorical48": {
        "light": "{colorChartsTeal1000}",
        "dark": "{colorChartsTeal1000}"
      },
      "colorChartsPaletteCategorical49": {
        "light": "{colorChartsPurple1200}",
        "dark": "{colorChartsPurple1200}"
      },
      "colorChartsPaletteCategorical50": {
        "light": "{colorChartsOrange1000}",
        "dark": "{colorChartsOrange1000}"
      },
      "colorChartsErrorBarMarker": {
        "light": "{colorNeutral900}",
        "dark": "{colorWhite}"
      },
      "colorSeverityDarkRed": {
        "light": "#870303",
        "dark": "#d63f38"
      },
      "colorSeverityRed": {
        "light": "#ce3311",
        "dark": "#fe6e73"
      },
      "colorSeverityOrange": {
        "light": "#f89256",
        "dark": "#f89256"
      },
      "colorSeverityYellow": {
        "light": "#f2cd54",
        "dark": "#f2cd54"
      },
      "colorSeverityGrey": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral600}"
      },
      "colorBackgroundNotificationSeverityCritical": {
        "light": "{colorSeverityDarkRed}",
        "dark": "{colorSeverityDarkRed}"
      },
      "colorBackgroundNotificationSeverityHigh": {
        "light": "{colorSeverityRed}",
        "dark": "{colorSeverityRed}"
      },
      "colorBackgroundNotificationSeverityMedium": {
        "light": "{colorSeverityOrange}",
        "dark": "{colorSeverityOrange}"
      },
      "colorBackgroundNotificationSeverityLow": {
        "light": "{colorSeverityYellow}",
        "dark": "{colorSeverityYellow}"
      },
      "colorBackgroundNotificationSeverityNeutral": {
        "light": "{colorSeverityGrey}",
        "dark": "{colorSeverityGrey}"
      },
      "colorTextNotificationSeverityCritical": {
        "light": "{colorNeutral100}",
        "dark": "{colorBlack}"
      },
      "colorTextNotificationSeverityHigh": {
        "light": "{colorNeutral100}",
        "dark": "{colorNeutral950}"
      },
      "colorTextNotificationSeverityMedium": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral950}"
      },
      "colorTextNotificationSeverityLow": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral950}"
      },
      "colorTextNotificationSeverityNeutral": {
        "light": "{colorNeutral100}",
        "dark": "{colorNeutral100}"
      },
      "colorGreyOpaque10": {
        "light": "rgba(0, 0, 0, 0.1)",
        "dark": "rgba(0, 0, 0, 0.1)"
      },
      "colorGreyOpaque25": {
        "light": "rgba(255, 255, 255, 0.25)",
        "dark": "rgba(255, 255, 255, 0.25)"
      },
      "colorGreyOpaque40": {
        "light": "rgba(0, 0, 0, 0.4)",
        "dark": "rgba(0, 0, 0, 0.4)"
      },
      "colorGreyOpaque50": {
        "light": "rgba(0, 0, 0, 0.5)",
        "dark": "rgba(0, 0, 0, 0.5)"
      },
      "colorGreyOpaque70": {
        "light": "rgba(35, 43, 55, 0.7)",
        "dark": "rgba(15, 20, 26, 0.7)"
      },
      "colorGreyOpaque80": {
        "light": "rgba(22, 25, 31, 0.8)",
        "dark": "rgba(22, 25, 31, 0.8)"
      },
      "colorGreyOpaque90": {
        "light": "rgba(242, 243, 243, 0.9)",
        "dark": "rgba(242, 243, 243, 0.9)"
      },
      "colorGreyTransparent": {
        "light": "rgba(15, 20, 26, 0.12)",
        "dark": "rgba(15, 20, 26, 1)"
      },
      "colorGreyTransparentHeavy": {
        "light": "rgba(15, 20, 26, 0.12)",
        "dark": "rgba(15, 20, 26, 1)"
      },
      "colorGreyTransparentLight": {
        "light": "rgba(15, 20, 26, 0.12)",
        "dark": "rgba(15, 20, 26, 1)"
      },
      "colorBackgroundBadgeIcon": {
        "light": "{colorError600}",
        "dark": "{colorError400}"
      },
      "colorBackgroundButtonLinkActive": {
        "light": "{colorPrimary100}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundButtonLinkDefault": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBackgroundButtonLinkDisabled": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBackgroundButtonLinkHover": {
        "light": "{colorPrimary50}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundButtonNormalActive": {
        "light": "{colorPrimary100}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundButtonNormalDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundButtonNormalDisabled": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundButtonNormalHover": {
        "light": "{colorPrimary50}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundToggleButtonNormalPressed": {
        "light": "{colorPrimary100}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundButtonPrimaryActive": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary400}"
      },
      "colorBackgroundButtonPrimaryDefault": {
        "light": "{colorBorderButtonNormalDefault}",
        "dark": "{colorBorderButtonNormalDefault}"
      },
      "colorBackgroundButtonPrimaryDisabled": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral750}"
      },
      "colorBackgroundButtonPrimaryHover": {
        "light": "{colorBorderButtonNormalHover}",
        "dark": "{colorBorderButtonNormalHover}"
      },
      "colorBackgroundDirectionButtonActive": {
        "light": "{colorNeutral750}",
        "dark": "{colorNeutral750}"
      },
      "colorBackgroundDirectionButtonDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral650}"
      },
      "colorBackgroundDirectionButtonDisabled": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral750}"
      },
      "colorBackgroundDirectionButtonHover": {
        "light": "{colorNeutral700}",
        "dark": "{colorNeutral700}"
      },
      "colorTextDirectionButtonDefault": {
        "light": "{colorWhite}",
        "dark": "{colorWhite}"
      },
      "colorTextDirectionButtonDisabled": {
        "light": "{colorTextInteractiveDisabled}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorBackgroundCalendarCurrentDate": {
        "light": "{colorNeutral200}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundCellShaded": {
        "light": "{colorNeutral150}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundCodeEditorGutterActiveLineDefault": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral500}"
      },
      "colorBackgroundCodeEditorGutterActiveLineError": {
        "light": "{colorTextStatusError}",
        "dark": "{colorTextStatusError}"
      },
      "colorBackgroundCodeEditorGutterDefault": {
        "light": "{colorNeutral200}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundCodeEditorLoading": {
        "light": "{colorNeutral100}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundCodeEditorPaneItemHover": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundCodeEditorStatusBar": {
        "light": "{colorNeutral200}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundCard": {
        "light": "{colorBackgroundContainerContent}",
        "dark": "{colorBackgroundContainerContent}"
      },
      "colorBackgroundItemCard": {
        "light": "{colorBackgroundCard}",
        "dark": "{colorBackgroundCard}"
      },
      "colorBackgroundContainerContent": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundContainerHeader": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundControlChecked": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBackgroundControlDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundControlDisabled": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundDropdownItemDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundDropdownItemDimmed": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBackgroundDropdownItemFilterMatch": {
        "light": "{colorPrimary50}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundDropdownItemHover": {
        "light": "{colorNeutral200}",
        "dark": "{colorNeutral900}"
      },
      "colorBackgroundDropdownItemSelected": {
        "light": "{colorBackgroundItemSelected}",
        "dark": "{colorBackgroundItemSelected}"
      },
      "colorBackgroundHomeHeader": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral950}"
      },
      "colorBackgroundInlineCode": {
        "light": "rgba(0, 0, 0, 0.1)",
        "dark": "rgba(255, 255, 255, 0.1)"
      },
      "colorBackgroundInputDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundInputDisabled": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundItemSelected": {
        "light": "{colorPrimary50}",
        "dark": "{colorPrimary1000}"
      },
      "colorBackgroundLayoutMain": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundDrawer": {
        "light": "{colorBackgroundLayoutPanelContent}",
        "dark": "{colorBackgroundLayoutPanelContent}"
      },
      "colorBackgroundDrawerBackdrop": {
        "light": "{colorGreyOpaque70}",
        "dark": "{colorGreyOpaque70}"
      },
      "colorBackgroundLayoutMobilePanel": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral950}"
      },
      "colorBackgroundLayoutPanelContent": {
        "light": "{colorBackgroundContainerContent}",
        "dark": "{colorBackgroundContainerContent}"
      },
      "colorBackgroundLayoutPanelHover": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundLayoutToolbar": {
        "light": "{colorBackgroundLayoutPanelContent}",
        "dark": "{colorBackgroundLayoutPanelContent}"
      },
      "colorBackgroundLayoutToggleActive": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral650}"
      },
      "colorBackgroundLayoutToggleDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral650}"
      },
      "colorBackgroundLayoutToggleHover": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral600}"
      },
      "colorBackgroundLayoutToggleSelectedActive": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBackgroundLayoutToggleSelectedDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBackgroundLayoutToggleSelectedHover": {
        "light": "{colorPrimary700}",
        "dark": "{colorPrimary300}"
      },
      "colorBackgroundModalOverlay": {
        "light": "{colorGreyOpaque70}",
        "dark": "{colorGreyOpaque70}"
      },
      "colorBackgroundNotificationBlue": {
        "light": "{colorInfo600}",
        "dark": "{colorInfo600}"
      },
      "colorBackgroundNotificationGreen": {
        "light": "{colorSuccess600}",
        "dark": "{colorSuccess600}"
      },
      "colorBackgroundNotificationGrey": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral600}"
      },
      "colorBackgroundNotificationRed": {
        "light": "{colorError600}",
        "dark": "{colorError600}"
      },
      "colorBackgroundNotificationYellow": {
        "light": "{colorWarning400}",
        "dark": "{colorWarning400}"
      },
      "colorBackgroundNotificationStackBar": {
        "light": "{colorNeutral750}",
        "dark": "{colorNeutral750}"
      },
      "colorBackgroundNotificationStackBarActive": {
        "light": "{colorNeutral750}",
        "dark": "{colorNeutral750}"
      },
      "colorBackgroundNotificationStackBarHover": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral650}"
      },
      "colorBackgroundPopover": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundProgressBarValueDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBackgroundProgressBarDefault": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral700}"
      },
      "colorBackgroundSegmentActive": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBackgroundSegmentDefault": {
        "light": "{colorBackgroundButtonNormalDefault}",
        "dark": "{colorBackgroundButtonNormalDefault}"
      },
      "colorBackgroundSegmentDisabled": {
        "light": "{colorBackgroundButtonNormalDisabled}",
        "dark": "{colorBackgroundButtonNormalDisabled}"
      },
      "colorBackgroundSegmentHover": {
        "light": "{colorBackgroundButtonNormalHover}",
        "dark": "{colorBackgroundButtonNormalHover}"
      },
      "colorBackgroundSegmentWrapper": {
        "light": "{colorBackgroundContainerContent}",
        "dark": "{colorBackgroundContainerContent}"
      },
      "colorBackgroundSliderRangeDefault": {
        "light": "{colorBackgroundSliderHandleDefault}",
        "dark": "{colorBackgroundSliderHandleDefault}"
      },
      "colorBackgroundSliderRangeActive": {
        "light": "{colorBackgroundSliderHandleActive}",
        "dark": "{colorBackgroundSliderHandleActive}"
      },
      "colorBackgroundSliderHandleDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBackgroundSliderHandleActive": {
        "light": "{colorPrimary700}",
        "dark": "{colorPrimary300}"
      },
      "colorBackgroundSliderTrackDefault": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral600}"
      },
      "colorBackgroundSliderHandleRing": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundSliderHandleErrorDefault": {
        "light": "{colorTextStatusError}",
        "dark": "{colorTextStatusError}"
      },
      "colorBackgroundSliderHandleErrorActive": {
        "light": "{colorTextStatusError}",
        "dark": "{colorTextStatusError}"
      },
      "colorBackgroundSliderHandleWarningDefault": {
        "light": "{colorTextStatusWarning}",
        "dark": "{colorTextStatusWarning}"
      },
      "colorBackgroundSliderHandleWarningActive": {
        "light": "{colorTextStatusWarning}",
        "dark": "{colorTextStatusWarning}"
      },
      "colorBackgroundSliderRangeErrorDefault": {
        "light": "{colorTextStatusError}",
        "dark": "{colorTextStatusError}"
      },
      "colorBackgroundSliderRangeErrorActive": {
        "light": "{colorTextStatusError}",
        "dark": "{colorTextStatusError}"
      },
      "colorBackgroundSliderRangeWarningDefault": {
        "light": "{colorTextStatusWarning}",
        "dark": "{colorTextStatusWarning}"
      },
      "colorBackgroundSliderRangeWarningActive": {
        "light": "{colorTextStatusWarning}",
        "dark": "{colorTextStatusWarning}"
      },
      "colorBackgroundStatusError": {
        "light": "{colorError50}",
        "dark": "{colorError1000}"
      },
      "colorBackgroundStatusInfo": {
        "light": "{colorInfo50}",
        "dark": "{colorInfo1000}"
      },
      "colorBackgroundDialog": {
        "light": "{colorBackgroundStatusInfo}",
        "dark": "{colorBackgroundStatusInfo}"
      },
      "colorBackgroundStatusSuccess": {
        "light": "{colorSuccess50}",
        "dark": "{colorSuccess1000}"
      },
      "colorBackgroundStatusWarning": {
        "light": "{colorWarning50}",
        "dark": "{colorWarning1000}"
      },
      "colorBackgroundTableHeader": {
        "light": "{colorBackgroundContainerHeader}",
        "dark": "{colorBackgroundContainerHeader}"
      },
      "colorBackgroundTilesDisabled": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundToggleCheckedDisabled": {
        "light": "{colorPrimary200}",
        "dark": "{colorPrimary900}"
      },
      "colorBackgroundToggleDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral500}"
      },
      "colorBackgroundAvatarGenAi": {
        "light": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)",
        "dark": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)"
      },
      "colorBackgroundAvatarDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral650}"
      },
      "colorTextAvatar": {
        "light": "{colorWhite}",
        "dark": "{colorWhite}"
      },
      "colorBackgroundLoadingBarGenAi": {
        "light": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)",
        "dark": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)"
      },
      "colorBackgroundChatBubbleOutgoing": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBackgroundChatBubbleIncoming": {
        "light": "{colorNeutral150}",
        "dark": "{colorNeutral950}"
      },
      "colorTextChatBubbleOutgoing": {
        "light": "{colorTextBodyDefault}",
        "dark": "{colorTextBodyDefault}"
      },
      "colorTextChatBubbleIncoming": {
        "light": "{colorTextBodyDefault}",
        "dark": "{colorTextBodyDefault}"
      },
      "colorBorderButtonLinkDisabled": {
        "light": "{colorBackgroundButtonLinkDisabled}",
        "dark": "{colorBackgroundButtonLinkDisabled}"
      },
      "colorBorderButtonNormalActive": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorBorderButtonNormalDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBorderToggleButtonNormalPressed": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBorderButtonNormalDisabled": {
        "light": "{colorNeutral400}",
        "dark": "{colorNeutral600}"
      },
      "colorTextButtonNormalDisabled": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorBorderButtonNormalHover": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorTextButtonIconDisabled": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorBorderButtonPrimaryActive": {
        "light": "{colorBackgroundButtonPrimaryActive}",
        "dark": "{colorBackgroundButtonPrimaryActive}"
      },
      "colorBorderButtonPrimaryDefault": {
        "light": "{colorBackgroundButtonPrimaryDefault}",
        "dark": "{colorBackgroundButtonPrimaryDefault}"
      },
      "colorBorderButtonPrimaryDisabled": {
        "light": "{colorBackgroundButtonPrimaryDisabled}",
        "dark": "{colorBackgroundButtonPrimaryDisabled}"
      },
      "colorBorderButtonPrimaryHover": {
        "light": "{colorBackgroundButtonPrimaryHover}",
        "dark": "{colorBackgroundButtonPrimaryHover}"
      },
      "colorTextButtonPrimaryDisabled": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorItemSelected": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBorderCalendarGrid": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBorderCalendarGridSelectedFocusRing": {
        "light": "{colorNeutral100}",
        "dark": "{colorNeutral850}"
      },
      "colorBorderCellShaded": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral700}"
      },
      "colorBorderCodeEditorAceActiveLineLightTheme": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral300}"
      },
      "colorBorderCodeEditorAceActiveLineDarkTheme": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral600}"
      },
      "colorBorderCodeEditorDefault": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral600}"
      },
      "colorBorderCodeEditorPaneItemHover": {
        "light": "{colorBorderDropdownItemHover}",
        "dark": "{colorBorderDropdownItemHover}"
      },
      "colorBorderCard": {
        "light": "{colorBorderDividerDefault}",
        "dark": "{colorBorderDividerDefault}"
      },
      "colorBorderCardHighlighted": {
        "light": "{colorBorderItemSelected}",
        "dark": "{colorBorderItemSelected}"
      },
      "colorBorderItemCard": {
        "light": "{colorBorderCard}",
        "dark": "{colorBorderCard}"
      },
      "colorBorderItemCardHighlighted": {
        "light": "{colorBorderCardHighlighted}",
        "dark": "{colorBorderCardHighlighted}"
      },
      "colorBorderContainerDivider": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBorderContainerTop": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBorderControlChecked": {
        "light": "{colorBackgroundControlChecked}",
        "dark": "{colorBackgroundControlChecked}"
      },
      "colorBorderControlDefault": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorBorderControlDisabled": {
        "light": "{colorBackgroundControlDisabled}",
        "dark": "{colorBackgroundControlDisabled}"
      },
      "colorBorderDividerActive": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral100}"
      },
      "colorBorderDividerDefault": {
        "light": "{colorNeutral350}",
        "dark": "{colorNeutral650}"
      },
      "colorBorderDividerPanelBottom": {
        "light": "{colorBorderDividerDefault}",
        "dark": "{colorBorderDividerDefault}"
      },
      "colorBorderDividerPanelSide": {
        "light": "{colorBorderDividerDefault}",
        "dark": "{colorBorderDividerDefault}"
      },
      "colorBorderDividerSecondary": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral750}"
      },
      "colorBorderDropdownContainer": {
        "light": "{colorNeutral400}",
        "dark": "{colorNeutral600}"
      },
      "colorBorderDropdownGroup": {
        "light": "{colorBorderDropdownItemDefault}",
        "dark": "{colorBorderDropdownItemDefault}"
      },
      "colorBorderDropdownItemDefault": {
        "light": "{colorBorderDividerDefault}",
        "dark": "{colorBorderDividerDefault}"
      },
      "colorBorderDropdownItemHover": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral600}"
      },
      "colorBorderDropdownItemDimmedHover": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorBorderDropdownItemSelected": {
        "light": "{colorBorderItemSelected}",
        "dark": "{colorBorderItemSelected}"
      },
      "colorBorderDropdownItemTop": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorBorderEditableCellHover": {
        "light": "{colorBorderDropdownItemHover}",
        "dark": "{colorBorderDropdownItemHover}"
      },
      "colorBorderInputDefault": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral600}"
      },
      "colorBorderInputDisabled": {
        "light": "{colorBackgroundInputDisabled}",
        "dark": "{colorBackgroundInputDisabled}"
      },
      "colorBorderInputFocused": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBorderItemFocused": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBorderDropdownItemFocused": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral300}"
      },
      "colorBorderItemPlaceholder": {
        "light": "{colorBorderItemSelected}",
        "dark": "{colorBorderItemSelected}"
      },
      "colorBorderItemSelected": {
        "light": "{colorItemSelected}",
        "dark": "{colorItemSelected}"
      },
      "colorBorderLayout": {
        "light": "{colorNeutral350}",
        "dark": "{colorNeutral650}"
      },
      "colorBorderNotificationStackBar": {
        "light": "{colorNeutral750}",
        "dark": "{colorNeutral750}"
      },
      "colorBorderPanelHeader": {
        "light": "{colorBorderDividerDefault}",
        "dark": "{colorBorderDividerDefault}"
      },
      "colorBorderPopover": {
        "light": "{colorBorderDropdownContainer}",
        "dark": "{colorBorderDropdownContainer}"
      },
      "colorBorderSegmentActive": {
        "light": "{colorBorderSegmentDefault}",
        "dark": "{colorBorderSegmentDefault}"
      },
      "colorBorderSegmentDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral300}"
      },
      "colorBorderSegmentDisabled": {
        "light": "{colorBorderSegmentDefault}",
        "dark": "{colorBorderSegmentDefault}"
      },
      "colorBorderSegmentHover": {
        "light": "{colorBorderSegmentDefault}",
        "dark": "{colorBorderSegmentDefault}"
      },
      "colorBorderStatusError": {
        "light": "{colorError600}",
        "dark": "{colorError400}"
      },
      "colorBorderStatusInfo": {
        "light": "{colorInfo600}",
        "dark": "{colorInfo400}"
      },
      "colorBorderStatusSuccess": {
        "light": "{colorSuccess600}",
        "dark": "{colorSuccess500}"
      },
      "colorBorderStatusWarning": {
        "light": "{colorWarning900}",
        "dark": "{colorWarning500}"
      },
      "colorBorderDialog": {
        "light": "{colorBorderStatusInfo}",
        "dark": "{colorBorderStatusInfo}"
      },
      "colorBorderDividerInteractiveDefault": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral300}"
      },
      "colorBorderTabsDivider": {
        "light": "{colorNeutral350}",
        "dark": "{colorNeutral650}"
      },
      "colorBorderTabsShadow": {
        "light": "{colorGreyTransparent}",
        "dark": "{colorGreyTransparent}"
      },
      "colorBorderTabsUnderline": {
        "light": "{colorTextAccent}",
        "dark": "{colorTextAccent}"
      },
      "colorBorderTilesDisabled": {
        "light": "{colorBackgroundTilesDisabled}",
        "dark": "{colorBackgroundTilesDisabled}"
      },
      "colorBorderTutorial": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral650}"
      },
      "colorForegroundControlDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorForegroundControlDisabled": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorForegroundControlReadOnly": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorShadowDefault": {
        "light": "{colorGreyTransparentHeavy}",
        "dark": "{colorGreyTransparentHeavy}"
      },
      "colorShadowMedium": {
        "light": "{colorGreyTransparent}",
        "dark": "{colorGreyTransparent}"
      },
      "colorShadowSide": {
        "light": "{colorGreyTransparentLight}",
        "dark": "{colorGreyTransparentLight}"
      },
      "colorStrokeChartLine": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorStrokeCodeEditorGutterActiveLineDefault": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral800}"
      },
      "colorStrokeCodeEditorGutterActiveLineHover": {
        "light": "{colorNeutral100}",
        "dark": "{colorNeutral950}"
      },
      "colorTextAccent": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorTextBodyDefault": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral350}"
      },
      "colorTextBodySecondary": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral350}"
      },
      "colorTextBreadcrumbCurrent": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral500}"
      },
      "colorTextBreadcrumbIcon": {
        "light": "{colorNeutral500}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorTextButtonInlineIconDefault": {
        "light": "{colorTextLinkDefault}",
        "dark": "{colorTextLinkDefault}"
      },
      "colorTextButtonInlineIconDisabled": {
        "light": "{colorTextInteractiveDisabled}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorTextButtonInlineIconHover": {
        "light": "{colorTextLinkHover}",
        "dark": "{colorTextLinkHover}"
      },
      "colorTextButtonNormalActive": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorTextToggleButtonNormalPressed": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorTextButtonNormalDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorTextButtonNormalHover": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorTextLinkButtonNormalDefault": {
        "light": "{colorTextButtonNormalDefault}",
        "dark": "{colorTextButtonNormalDefault}"
      },
      "colorTextLinkButtonNormalHover": {
        "light": "{colorTextButtonNormalHover}",
        "dark": "{colorTextButtonNormalHover}"
      },
      "colorTextLinkButtonNormalActive": {
        "light": "{colorTextButtonNormalActive}",
        "dark": "{colorTextButtonNormalActive}"
      },
      "colorTextButtonLinkActive": {
        "light": "{colorTextButtonNormalActive}",
        "dark": "{colorTextButtonNormalActive}"
      },
      "colorTextButtonLinkDefault": {
        "light": "{colorTextButtonNormalDefault}",
        "dark": "{colorTextButtonNormalDefault}"
      },
      "colorTextButtonLinkDisabled": {
        "light": "{colorTextInteractiveDisabled}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorTextButtonLinkHover": {
        "light": "{colorTextButtonNormalHover}",
        "dark": "{colorTextButtonNormalHover}"
      },
      "colorTextButtonPrimaryActive": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextButtonPrimaryDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextButtonPrimaryHover": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextCalendarDateHover": {
        "light": "{colorTextDropdownItemDefault}",
        "dark": "{colorTextDropdownItemDefault}"
      },
      "colorTextCalendarMonth": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorTextCodeEditorGutterActiveLine": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextCodeEditorGutterDefault": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral300}"
      },
      "colorTextCodeEditorStatusBarDisabled": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral600}"
      },
      "colorTextCodeEditorTabButtonError": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextColumnHeader": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral400}"
      },
      "colorTextColumnSortingIcon": {
        "light": "{colorTextColumnHeader}",
        "dark": "{colorTextColumnHeader}"
      },
      "colorTextControlDisabled": {
        "light": "{colorTextInteractiveDisabled}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorTextCounter": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorTextDisabled": {
        "light": "{colorNeutral400}",
        "dark": "{colorNeutral600}"
      },
      "colorTextDisabledInlineEdit": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral400}"
      },
      "colorTextDropdownFooter": {
        "light": "{colorTextFormSecondary}",
        "dark": "{colorTextFormSecondary}"
      },
      "colorTextDropdownGroupLabel": {
        "light": "{colorTextGroupLabel}",
        "dark": "{colorTextGroupLabel}"
      },
      "colorTextDropdownItemDefault": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral300}"
      },
      "colorTextDropdownItemDimmed": {
        "light": "{colorTextInteractiveDisabled}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorTextDropdownItemDisabled": {
        "light": "{colorTextInteractiveDisabled}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorTextDropdownItemFilterMatch": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary300}"
      },
      "colorTextDropdownItemHighlighted": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral250}"
      },
      "colorTextDropdownItemSecondary": {
        "light": "{colorTextFormSecondary}",
        "dark": "{colorTextFormSecondary}"
      },
      "colorTextDropdownItemSecondaryHover": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral300}"
      },
      "colorTextEmpty": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral300}"
      },
      "colorTextExpandableSectionDefault": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral300}"
      },
      "colorTextExpandableSectionHover": {
        "light": "{colorTextAccent}",
        "dark": "{colorTextAccent}"
      },
      "colorTextExpandableSectionNavigationIconDefault": {
        "light": "{colorTextInteractiveDefault}",
        "dark": "{colorTextInteractiveDefault}"
      },
      "colorTextFormDefault": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral300}"
      },
      "colorTextFormLabel": {
        "light": "{colorTextFormDefault}",
        "dark": "{colorTextFormDefault}"
      },
      "colorTextFormSecondary": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorTextGroupLabel": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral350}"
      },
      "colorTextLabelGenAi": {
        "light": "{colorPurple700}",
        "dark": "{colorPurple400}"
      },
      "colorTextHeadingDefault": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral250}"
      },
      "colorTextHeadingSecondary": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral450}"
      },
      "colorTextHomeHeaderDefault": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral250}"
      },
      "colorTextHomeHeaderSecondary": {
        "light": "{colorNeutral350}",
        "dark": "{colorNeutral350}"
      },
      "colorTextIconCaret": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral450}"
      },
      "colorTextIconSubtle": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral400}"
      },
      "colorTextInputDisabled": {
        "light": "{colorNeutral400}",
        "dark": "{colorNeutral600}"
      },
      "colorTextInputPlaceholder": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorTextInputPlaceholderDisabled": {
        "light": "{colorTextInputDisabled}",
        "dark": "{colorTextInputDisabled}"
      },
      "colorTextInteractiveActive": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral100}"
      },
      "colorTextInteractiveDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral300}"
      },
      "colorTextInteractiveDisabled": {
        "light": "{colorNeutral400}",
        "dark": "{colorNeutral600}"
      },
      "colorTextInteractiveHover": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral100}"
      },
      "colorTextToggleButtonIconPressed": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral100}"
      },
      "colorTextInteractiveInvertedDefault": {
        "light": "{colorNeutral300}",
        "dark": "{colorNeutral300}"
      },
      "colorTextInteractiveInvertedHover": {
        "light": "{colorNeutral100}",
        "dark": "{colorNeutral100}"
      },
      "colorTextInverted": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextLabel": {
        "light": "{colorTextFormLabel}",
        "dark": "{colorTextFormLabel}"
      },
      "colorTextKeyValuePairsValue": {
        "light": "{colorTextBodyDefault}",
        "dark": "{colorTextBodyDefault}"
      },
      "colorTextLayoutToggle": {
        "light": "{colorWhite}",
        "dark": "{colorWhite}"
      },
      "colorTextLayoutToggleActive": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorTextLayoutToggleHover": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorTextLayoutToggleSelected": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextLinkDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorTextLinkHover": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorTextLinkDecorationDefault": {
        "light": "currentColor",
        "dark": "currentColor"
      },
      "colorTextLinkDecorationHover": {
        "light": "currentColor",
        "dark": "currentColor"
      },
      "colorTextLinkSecondaryDefault": {
        "light": "{colorTextLinkDefault}",
        "dark": "{colorTextLinkDefault}"
      },
      "colorTextLinkSecondaryHover": {
        "light": "{colorTextLinkHover}",
        "dark": "{colorTextLinkHover}"
      },
      "colorTextLinkInfoDefault": {
        "light": "{colorTextLinkDefault}",
        "dark": "{colorTextLinkDefault}"
      },
      "colorTextLinkInfoHover": {
        "light": "{colorTextLinkHover}",
        "dark": "{colorTextLinkHover}"
      },
      "colorTextLinkInvertedHover": {
        "light": "{colorWhite}",
        "dark": "{colorWhite}"
      },
      "colorTextLinkButtonUnderline": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorTextLinkButtonUnderlineHover": {
        "light": "transparent",
        "dark": "transparent"
      },
      "colorTextNotificationDefault": {
        "light": "{colorNeutral100}",
        "dark": "{colorNeutral100}"
      },
      "colorTextNotificationStackBar": {
        "light": "{colorWhite}",
        "dark": "{colorWhite}"
      },
      "colorTextNotificationYellow": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral950}"
      },
      "colorTextPaginationPageNumberActiveDisabled": {
        "light": "{colorTextInteractiveDisabled}",
        "dark": "{colorTextInteractiveDisabled}"
      },
      "colorTextPaginationPageNumberDefault": {
        "light": "{colorTextInteractiveDefault}",
        "dark": "{colorNeutral400}"
      },
      "colorTextSegmentActive": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral950}"
      },
      "colorTextSegmentDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral300}"
      },
      "colorTextSegmentHover": {
        "light": "{colorTextButtonNormalHover}",
        "dark": "{colorTextButtonNormalHover}"
      },
      "colorTextSmall": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorTextStatusError": {
        "light": "{colorError600}",
        "dark": "{colorError400}"
      },
      "colorTextStatusInactive": {
        "light": "{colorNeutral600}",
        "dark": "{colorNeutral450}"
      },
      "colorTextStatusInfo": {
        "light": "{colorInfo600}",
        "dark": "{colorInfo400}"
      },
      "colorTextStatusSuccess": {
        "light": "{colorSuccess600}",
        "dark": "{colorSuccess500}"
      },
      "colorTextStatusWarning": {
        "light": "{colorWarning900}",
        "dark": "{colorWarning500}"
      },
      "colorTextTopNavigationTitle": {
        "light": "{colorNeutral950}",
        "dark": "{colorNeutral100}"
      },
      "colorTextTutorialHotspotDefault": {
        "light": "{colorTextLinkDefault}",
        "dark": "{colorTextLinkDefault}"
      },
      "colorTextTutorialHotspotHover": {
        "light": "{colorTextLinkHover}",
        "dark": "{colorTextLinkHover}"
      },
      "colorBoardPlaceholderActive": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral600}"
      },
      "colorBoardPlaceholderHover": {
        "light": "{colorPrimary100}",
        "dark": "{colorPrimary600}"
      },
      "colorDragPlaceholderActive": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral600}"
      },
      "colorDragPlaceholderHover": {
        "light": "{colorPrimary100}",
        "dark": "{colorPrimary600}"
      },
      "colorDropzoneBackgroundDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorDropzoneBackgroundHover": {
        "light": "{colorPrimary50}",
        "dark": "{colorPrimary1000}"
      },
      "colorDropzoneTextDefault": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral350}"
      },
      "colorDropzoneTextHover": {
        "light": "{colorNeutral650}",
        "dark": "{colorNeutral350}"
      },
      "colorDropzoneBorderDefault": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral600}"
      },
      "colorDropzoneBorderHover": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorGapGlobalDrawer": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral950}"
      },
      "colorTreeViewConnectorLine": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral300}"
      },
      "colorBackgroundActionCardDefault": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorBackgroundActionCardHover": {
        "light": "{colorPrimary50}",
        "dark": "{colorNeutral800}"
      },
      "colorBackgroundActionCardActive": {
        "light": "{colorPrimary100}",
        "dark": "{colorNeutral700}"
      },
      "colorBorderActionCardDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorBorderActionCardHover": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorBorderActionCardActive": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorBorderActionCardDisabled": {
        "light": "{colorNeutral400}",
        "dark": "{colorNeutral600}"
      },
      "colorBackgroundActionCardDisabled": {
        "light": "{colorWhite}",
        "dark": "{colorNeutral850}"
      },
      "colorTextActionCardDisabled": {
        "light": "{colorNeutral500}",
        "dark": "{colorNeutral500}"
      },
      "colorIconActionCardDefault": {
        "light": "{colorPrimary600}",
        "dark": "{colorPrimary400}"
      },
      "colorIconActionCardHover": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorIconActionCardActive": {
        "light": "{colorPrimary900}",
        "dark": "{colorPrimary300}"
      },
      "colorIconActionCardDisabled": {
        "light": "{colorNeutral400}",
        "dark": "{colorNeutral600}"
      },
      "colorBackgroundSkeleton": {
        "light": "{colorNeutral250}",
        "dark": "{colorNeutral750}"
      },
      "colorBackgroundSkeletonWave": {
        "light": "{colorNeutral150}",
        "dark": "{colorNeutral700}"
      },
      "fontBoxValueLargeWeight": "700",
      "fontButtonLetterSpacing": "0.005em",
      "fontChartDetailSize": "{fontSizeBodyS}",
      "fontDecorationStyleLink": "solid",
      "fontDecorationThicknessLink": "1px",
      "fontDecorationThicknessLinkDisplayL": "2px",
      "fontDisplayLabelWeight": "700",
      "fontExpandableHeadingSize": "{fontSizeHeadingS}",
      "fontFamilyBase": "'Open Sans', 'Helvetica Neue', Roboto, Arial, sans-serif",
      "fontFamilyDisplay": "{fontFamilyBase}",
      "fontFamilyHeading": "{fontFamilyBase}",
      "fontFamilyMonospace": "Monaco, Menlo, Consolas, 'Courier Prime', Courier, 'Courier New', monospace",
      "fontHeaderH2DescriptionLineHeight": "{lineHeightBodyM}",
      "fontHeaderH2DescriptionSize": "{fontSizeBodyM}",
      "fontLinkButtonLetterSpacing": "{fontButtonLetterSpacing}",
      "fontLinkButtonWeight": "{fontWeightButton}",
      "fontPanelHeaderLineHeight": "{lineHeightHeadingM}",
      "fontPanelHeaderSize": "{fontSizeHeadingM}",
      "fontSizeBodyM": "14px",
      "fontSizeBodyS": "12px",
      "fontSizeDisplayL": "42px",
      "fontSizeFormLabel": "{fontSizeBodyM}",
      "fontSizeHeadingL": "20px",
      "fontSizeHeadingM": "18px",
      "fontSizeHeadingS": "16px",
      "fontSizeHeadingXl": "24px",
      "fontSizeHeadingXs": "14px",
      "fontSizeKeyValuePairsLabel": "{fontSizeBodyM}",
      "fontSizeTabs": "{fontSizeHeadingS}",
      "fontSmoothingMozOsx": "grayscale",
      "fontSmoothingWebkit": "antialiased",
      "fontWayfindingLinkActiveWeight": "700",
      "fontWeightAlertHeader": "700",
      "fontWeightBold": "700",
      "fontWeightBreadcrumbCurrent": "{fontWeightBold}",
      "fontWeightButton": "700",
      "fontWeightDisplayL": "700",
      "fontWeightFlashbarHeader": "700",
      "fontWeightFormLabel": "{fontDisplayLabelWeight}",
      "fontWeightHeadingL": "700",
      "fontWeightHeadingM": "700",
      "fontWeightHeadingS": "700",
      "fontWeightHeadingXl": "700",
      "fontWeightHeadingXs": "700",
      "fontWeightHeavy": "700",
      "fontWeightKeyValuePairsLabel": "{fontDisplayLabelWeight}",
      "fontWeightLighter": "300",
      "fontWeightNormal": "400",
      "fontWeightTabs": "700",
      "fontWeightTabsDisabled": "{fontWayfindingLinkActiveWeight}",
      "letterSpacingBodyS": "0.005em",
      "letterSpacingDisplayL": "-0.03em",
      "letterSpacingHeadingL": "-0.015em",
      "letterSpacingHeadingM": "-0.010em",
      "letterSpacingHeadingS": "-0.005em",
      "letterSpacingHeadingXl": "-0.02em",
      "letterSpacingHeadingXs": "normal",
      "lineHeightBodyM": "20px",
      "lineHeightBodyS": "16px",
      "lineHeightDisplayL": "48px",
      "lineHeightFormLabel": "{lineHeightBodyM}",
      "lineHeightHeadingL": "24px",
      "lineHeightHeadingM": "22px",
      "lineHeightHeadingS": "20px",
      "lineHeightHeadingXl": "30px",
      "lineHeightHeadingXs": "18px",
      "lineHeightKeyValuePairsLabel": "{lineHeightBodyM}",
      "lineHeightTabs": "{lineHeightHeadingS}",
      "borderActiveWidth": "4px",
      "borderCodeEditorStatusDividerWidth": "{borderDividerSectionWidth}",
      "borderContainerStickyWidth": "0px",
      "borderContainerTopWidth": "0px",
      "borderControlFocusRingShadowSpread": "1px",
      "borderControlInvalidFocusRingShadowSpread": "2px",
      "borderDividerListWidth": "1px",
      "borderDividerSectionWidth": "1px",
      "borderDropdownVirtualOffsetWidth": "2px",
      "borderInvalidWidth": "8px",
      "borderItemWidth": "2px",
      "borderLineChartDashArray": "3 5",
      "borderLineChartLineJoin": "round",
      "borderLineChartWidth": "2px",
      "borderPanelHeaderWidth": "1px",
      "borderPanelTopWidth": "1px",
      "borderRadiusAlert": "{borderRadiusFlashbar}",
      "borderRadiusBadge": "4px",
      "borderRadiusButton": "20px",
      "borderRadiusCalendarDayFocusRing": "3px",
      "borderRadiusCodeEditor": "{borderRadiusInput}",
      "borderRadiusCardDefault": "{borderRadiusContainer}",
      "borderRadiusCardEmbedded": "{borderRadiusChatBubble}",
      "borderRadiusItemCardDefault": "{borderRadiusCardDefault}",
      "borderRadiusItemCardEmbedded": "{borderRadiusCardEmbedded}",
      "borderRadiusContainer": "16px",
      "borderRadiusControlCircularFocusRing": "4px",
      "borderRadiusControlDefaultFocusRing": "4px",
      "borderRadiusDropdown": "{borderRadiusItem}",
      "borderRadiusDropzone": "12px",
      "borderRadiusFlashbar": "12px",
      "borderRadiusItem": "8px",
      "borderRadiusInput": "8px",
      "borderRadiusPopover": "{borderRadiusInput}",
      "borderRadiusTabsFocusRing": "20px",
      "borderRadiusTiles": "{borderRadiusInput}",
      "borderRadiusToken": "{borderRadiusInput}",
      "borderRadiusChatBubble": "8px",
      "borderRadiusTutorialPanelItem": "{borderRadiusInput}",
      "borderTableStickyWidth": "1px",
      "borderLinkFocusRingOutline": "0",
      "borderLinkFocusRingShadowSpread": "2px",
      "borderWidthCard": "{borderDividerSectionWidth}",
      "borderWidthCardSelected": "{borderItemWidth}",
      "borderWidthItemCard": "{borderWidthCard}",
      "borderWidthItemCardHighlighted": "{borderWidthCardSelected}",
      "borderWidthItemSelected": "2px",
      "borderWidthAlert": "2px",
      "borderWidthAlertBlockStart": "{borderWidthAlert}",
      "borderWidthAlertBlockEnd": "{borderWidthAlert}",
      "borderWidthAlertInlineStart": "{borderWidthAlert}",
      "borderWidthAlertInlineEnd": "{borderWidthAlert}",
      "borderWidthButton": "2px",
      "borderWidthDropdown": "2px",
      "borderWidthField": "1px",
      "borderWidthPopover": "2px",
      "borderWidthToken": "2px",
      "borderWidthIconSmall": "2px",
      "borderWidthIconNormal": "2px",
      "borderWidthIconMedium": "2px",
      "borderWidthIconBig": "3px",
      "borderWidthIconLarge": "4px",
      "borderRadiusActionCardDefault": "{borderRadiusCardDefault}",
      "borderRadiusActionCardEmbedded": "{borderRadiusCardEmbedded}",
      "borderWidthActionCardDefault": "{borderWidthCard}",
      "borderWidthActionCardHover": "{borderWidthCard}",
      "borderWidthActionCardActive": "{borderWidthCard}",
      "borderWidthActionCardDisabled": "{borderWidthCard}",
      "borderRadiusSkeleton": "8px",
      "motionDurationExtraFast": {
        "default": "45ms",
        "disabled": "0ms"
      },
      "motionDurationExtraSlow": {
        "default": "270ms",
        "disabled": "0ms"
      },
      "motionDurationFast": {
        "default": "90ms",
        "disabled": "0ms"
      },
      "motionDurationModerate": {
        "default": "135ms",
        "disabled": "0ms"
      },
      "motionDurationRefreshOnlyAmbient": {
        "default": "2000ms",
        "disabled": "0ms"
      },
      "motionDurationRefreshOnlyFast": {
        "default": "115ms",
        "disabled": "0ms"
      },
      "motionDurationRefreshOnlyMedium": {
        "default": "165ms",
        "disabled": "0ms"
      },
      "motionDurationRefreshOnlySlow": {
        "default": "250ms",
        "disabled": "0ms"
      },
      "motionDurationAvatarGenAiGradient": {
        "default": "3600ms",
        "disabled": "0ms"
      },
      "motionDurationAvatarLoadingDots": {
        "default": "1200ms",
        "disabled": "0ms"
      },
      "motionDurationRotate180": {
        "default": "{motionDurationModerate}",
        "disabled": "{motionDurationModerate}"
      },
      "motionDurationRotate90": {
        "default": "{motionDurationModerate}",
        "disabled": "{motionDurationModerate}"
      },
      "motionDurationShowPaced": {
        "default": "{motionDurationSlow}",
        "disabled": "{motionDurationSlow}"
      },
      "motionDurationShowQuick": {
        "default": "{motionDurationModerate}",
        "disabled": "{motionDurationModerate}"
      },
      "motionDurationSlow": {
        "default": "180ms",
        "disabled": "0ms"
      },
      "motionDurationTransitionQuick": {
        "default": "{motionDurationFast}",
        "disabled": "{motionDurationFast}"
      },
      "motionDurationTransitionShowPaced": {
        "default": "{motionDurationSlow}",
        "disabled": "{motionDurationSlow}"
      },
      "motionDurationTransitionShowQuick": {
        "default": "{motionDurationFast}",
        "disabled": "{motionDurationFast}"
      },
      "motionEasingEaseOutQuart": {
        "default": "cubic-bezier(0.165, 0.84, 0.44, 1)",
        "disabled": "cubic-bezier(0.165, 0.84, 0.44, 1)"
      },
      "motionEasingRefreshOnlyA": {
        "default": "cubic-bezier(0, 0, 0, 1)",
        "disabled": "cubic-bezier(0, 0, 0, 1)"
      },
      "motionEasingRefreshOnlyB": {
        "default": "cubic-bezier(1, 0, 0.83, 1)",
        "disabled": "cubic-bezier(1, 0, 0.83, 1)"
      },
      "motionEasingRefreshOnlyC": {
        "default": "cubic-bezier(0.84, 0, 0.16, 1)",
        "disabled": "cubic-bezier(0.84, 0, 0.16, 1)"
      },
      "motionEasingRefreshOnlyD": {
        "default": "cubic-bezier(0.33, 0, 0.67, 1)",
        "disabled": "cubic-bezier(0.33, 0, 0.67, 1)"
      },
      "motionEasingAvatarGenAiGradient": {
        "default": "cubic-bezier(0.7, 0, 0.3, 1)",
        "disabled": "cubic-bezier(0.7, 0, 0.3, 1)"
      },
      "motionEasingRotate180": {
        "default": "{motionEasingEaseOutQuart}",
        "disabled": "{motionEasingEaseOutQuart}"
      },
      "motionEasingRotate90": {
        "default": "{motionEasingEaseOutQuart}",
        "disabled": "{motionEasingEaseOutQuart}"
      },
      "motionEasingShowPaced": {
        "default": "ease-out",
        "disabled": "ease-out"
      },
      "motionEasingShowQuick": {
        "default": "ease-out",
        "disabled": "ease-out"
      },
      "motionEasingTransitionQuick": {
        "default": "linear",
        "disabled": "linear"
      },
      "motionEasingTransitionShowPaced": {
        "default": "ease-out",
        "disabled": "ease-out"
      },
      "motionEasingTransitionShowQuick": {
        "default": "linear",
        "disabled": "linear"
      },
      "motionEasingResponsive": {
        "default": "{motionEasingRefreshOnlyA}",
        "disabled": "{motionEasingRefreshOnlyA}"
      },
      "motionEasingSticky": {
        "default": "{motionEasingRefreshOnlyB}",
        "disabled": "{motionEasingRefreshOnlyB}"
      },
      "motionEasingExpressive": {
        "default": "{motionEasingRefreshOnlyC}",
        "disabled": "{motionEasingRefreshOnlyC}"
      },
      "motionDurationResponsive": {
        "default": "{motionDurationRefreshOnlyFast}",
        "disabled": "{motionDurationRefreshOnlyFast}"
      },
      "motionDurationExpressive": {
        "default": "{motionDurationRefreshOnlyMedium}",
        "disabled": "{motionDurationRefreshOnlyMedium}"
      },
      "motionDurationComplex": {
        "default": "{motionDurationRefreshOnlySlow}",
        "disabled": "{motionDurationRefreshOnlySlow}"
      },
      "motionKeyframesFadeIn": {
        "default": "awsui-fade-in-35003c",
        "disabled": "awsui-fade-in-35003c"
      },
      "motionKeyframesFadeOut": {
        "default": "awsui-fade-out-35003c",
        "disabled": "awsui-fade-out-35003c"
      },
      "motionKeyframesStatusIconError": {
        "default": "awsui-status-icon-error-35003c",
        "disabled": "awsui-status-icon-error-35003c"
      },
      "motionKeyframesScalePopup": {
        "default": "awsui-scale-popup-35003c",
        "disabled": "awsui-scale-popup-35003c"
      },
      "sizeCalendarGridWidth": {
        "comfortable": "238px",
        "compact": "238px"
      },
      "sizeControl": {
        "comfortable": "16px",
        "compact": "16px"
      },
      "sizeIconBig": {
        "comfortable": "32px",
        "compact": "32px"
      },
      "sizeIconLarge": {
        "comfortable": "48px",
        "compact": "48px"
      },
      "sizeIconMedium": {
        "comfortable": "20px",
        "compact": "20px"
      },
      "sizeIconNormal": {
        "comfortable": "16px",
        "compact": "16px"
      },
      "sizeTableSelectionHorizontal": {
        "comfortable": "40px",
        "compact": "40px"
      },
      "sizeVerticalInput": {
        "comfortable": "32px",
        "compact": "28px"
      },
      "sizeVerticalPanelIconOffset": {
        "comfortable": "15px",
        "compact": "13px"
      },
      "spaceAlertActionLeft": {
        "comfortable": "{spaceS}",
        "compact": "{spaceS}"
      },
      "spaceAlertHorizontal": {
        "comfortable": "{spaceFlashbarHorizontal}",
        "compact": "{spaceFlashbarHorizontal}"
      },
      "spaceAlertMessageRight": {
        "comfortable": "{spaceXxs}",
        "compact": "{spaceXxs}"
      },
      "spaceAlertVertical": {
        "comfortable": "{spaceFlashbarVertical}",
        "compact": "{spaceFlashbarVertical}"
      },
      "spaceButtonFocusOutlineGutter": {
        "comfortable": "4px",
        "compact": "4px"
      },
      "spaceButtonHorizontal": {
        "comfortable": "{spaceScaledL}",
        "compact": "{spaceScaledL}"
      },
      "spaceButtonVertical": {
        "comfortable": "{spaceScaledXxs}",
        "compact": "{spaceScaledXxs}"
      },
      "spaceTokenVertical": {
        "comfortable": "{spaceScaledXxs}",
        "compact": "{spaceScaledXxs}"
      },
      "spaceFieldVertical": {
        "comfortable": "5px",
        "compact": "3px"
      },
      "spaceButtonIconFocusOutlineGutterVertical": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceButtonIconOnlyHorizontal": {
        "comfortable": "6px",
        "compact": "{spaceXxs}"
      },
      "spaceButtonInlineIconFocusOutlineGutter": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceButtonModalDismissVertical": {
        "comfortable": "{spaceScaledXxxs}",
        "compact": "{spaceScaledXxxs}"
      },
      "spaceCalendarGridFocusOutlineGutter": {
        "comfortable": "-5px",
        "compact": "-5px"
      },
      "spaceCalendarGridSelectedFocusOutlineGutter": {
        "comfortable": "{spaceCalendarGridFocusOutlineGutter}",
        "compact": "{spaceCalendarGridFocusOutlineGutter}"
      },
      "spaceCalendarGridGutter": {
        "comfortable": "6px",
        "compact": "6px"
      },
      "spaceCardHorizontalDefault": {
        "comfortable": "{spaceContainerHorizontal}",
        "compact": "{spaceContainerHorizontal}"
      },
      "spaceCardHorizontalEmbedded": {
        "comfortable": "{spaceS}",
        "compact": "10px"
      },
      "spaceCardVerticalDefault": {
        "comfortable": "{spaceScaledM}",
        "compact": "{spaceScaledM}"
      },
      "spaceCardVerticalEmbedded": {
        "comfortable": "10px",
        "compact": "{spaceXs}"
      },
      "spaceItemCardHorizontalDefault": {
        "comfortable": "{spaceCardHorizontalDefault}",
        "compact": "{spaceCardHorizontalDefault}"
      },
      "spaceItemCardHorizontalEmbedded": {
        "comfortable": "{spaceCardHorizontalEmbedded}",
        "compact": "{spaceCardHorizontalEmbedded}"
      },
      "spaceItemCardVerticalDefault": {
        "comfortable": "{spaceCardVerticalDefault}",
        "compact": "{spaceCardVerticalDefault}"
      },
      "spaceItemCardVerticalEmbedded": {
        "comfortable": "{spaceCardVerticalEmbedded}",
        "compact": "{spaceCardVerticalEmbedded}"
      },
      "spaceCodeEditorStatusFocusOutlineGutter": {
        "comfortable": "-7px",
        "compact": "-7px"
      },
      "spaceContainerContentTop": {
        "comfortable": "{spaceXxs}",
        "compact": "{spaceXxs}"
      },
      "spaceContainerHeaderTop": {
        "comfortable": "{spaceS}",
        "compact": "{spaceS}"
      },
      "spaceContainerHeaderBottom": {
        "comfortable": "{spaceScaledXs}",
        "compact": "{spaceScaledXs}"
      },
      "spaceContainerHorizontal": {
        "comfortable": "{spaceL}",
        "compact": "{spaceL}"
      },
      "spaceContentHeaderPaddingBottom": {
        "comfortable": "{spaceScaledM}",
        "compact": "{spaceScaledM}"
      },
      "spaceDarkHeaderOverlapDistance": {
        "comfortable": "36px",
        "compact": "32px"
      },
      "spaceExpandableSectionIconOffsetTop": {
        "comfortable": "{spaceScaled2xXxs}",
        "compact": "{spaceScaled2xXxs}"
      },
      "spaceFieldHorizontal": {
        "comfortable": "{spaceS}",
        "compact": "{spaceS}"
      },
      "spaceFieldIconOffset": {
        "comfortable": "36px",
        "compact": "36px"
      },
      "spaceFilteringTokenDismissButtonFocusOutlineGutter": {
        "comfortable": "-5px",
        "compact": "-5px"
      },
      "spaceFilteringTokenOperationSelectFocusOutlineGutter": {
        "comfortable": "-5px",
        "compact": "-5px"
      },
      "spaceFlashbarActionLeft": {
        "comfortable": "{spaceS}",
        "compact": "{spaceS}"
      },
      "spaceFlashbarDismissRight": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceFlashbarHorizontal": {
        "comfortable": "{spaceM}",
        "compact": "{spaceM}"
      },
      "spaceFlashbarVertical": {
        "comfortable": "{spaceScaledXs}",
        "compact": "{spaceScaledXs}"
      },
      "spaceGridGutter": {
        "comfortable": "{spaceL}",
        "compact": "{spaceM}"
      },
      "spaceKeyValueGap": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceLayoutContentBottom": {
        "comfortable": "{spaceScaled2xXxxl}",
        "compact": "{spaceScaled2xXxxl}"
      },
      "spaceLayoutContentHorizontal": {
        "comfortable": "{spaceScaled2xXl}",
        "compact": "{spaceScaled2xXl}"
      },
      "spaceLayoutToggleDiameter": {
        "comfortable": "36px",
        "compact": "36px"
      },
      "spaceLayoutTogglePadding": {
        "comfortable": "{spaceStaticS}",
        "compact": "{spaceStaticS}"
      },
      "spaceModalContentBottom": {
        "comfortable": "{spaceScaled2xM}",
        "compact": "{spaceScaled2xM}"
      },
      "spaceModalHorizontal": {
        "comfortable": "{spaceContainerHorizontal}",
        "compact": "{spaceContainerHorizontal}"
      },
      "spacePanelContentBottom": {
        "comfortable": "{spaceScaledXxxl}",
        "compact": "{spaceScaledXxxl}"
      },
      "spacePanelContentTop": {
        "comfortable": "{spaceScaledL}",
        "compact": "{spaceScaledL}"
      },
      "spacePanelDividerMarginHorizontal": {
        "comfortable": "{spaceXs}",
        "compact": "{spaceXs}"
      },
      "spacePanelHeaderVertical": {
        "comfortable": "{spaceScaledL}",
        "compact": "{spaceScaledL}"
      },
      "spacePanelNavLeft": {
        "comfortable": "28px",
        "compact": "28px"
      },
      "spacePanelSideLeft": {
        "comfortable": "28px",
        "compact": "28px"
      },
      "spacePanelSideRight": {
        "comfortable": "{spaceScaledXl}",
        "compact": "{spaceScaledXl}"
      },
      "spacePanelSplitTop": {
        "comfortable": "{spaceScaledL}",
        "compact": "{spaceScaledL}"
      },
      "spacePanelSplitBottom": {
        "comfortable": "{spaceScaledL}",
        "compact": "{spaceScaledL}"
      },
      "spaceSegmentedControlFocusOutlineGutter": {
        "comfortable": "6px",
        "compact": "6px"
      },
      "spaceTabsContentTop": {
        "comfortable": "{spaceScaledS}",
        "compact": "{spaceScaledS}"
      },
      "spaceTabsFocusOutlineGutter": {
        "comfortable": "-8px",
        "compact": "-8px"
      },
      "spaceTabsVertical": {
        "comfortable": "{spaceScaledXxs}",
        "compact": "{spaceScaledXxs}"
      },
      "spaceTableContentBottom": {
        "comfortable": "{spaceXxs}",
        "compact": "{spaceXxs}"
      },
      "spaceTableEmbeddedHeaderTop": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceTableFooterHorizontal": {
        "comfortable": "{spaceTableHeaderHorizontal}",
        "compact": "{spaceTableHeaderHorizontal}"
      },
      "spaceTableHeaderFocusOutlineGutter": {
        "comfortable": "0px",
        "compact": "-1px"
      },
      "spaceTableHeaderHorizontal": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceTableHeaderToolsBottom": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceTableHeaderToolsFullPageBottom": {
        "comfortable": "4px",
        "compact": "4px"
      },
      "spaceTableHorizontal": {
        "comfortable": "{spaceContainerHorizontal}",
        "compact": "{spaceContainerHorizontal}"
      },
      "spaceTreeViewIndentation": {
        "comfortable": "{spaceXl}",
        "compact": "{spaceXl}"
      },
      "spaceTileGutter": {
        "comfortable": "{spaceXl}",
        "compact": "{spaceM}"
      },
      "spaceActionCardHorizontalDefault": {
        "comfortable": "{spaceCardHorizontalDefault}",
        "compact": "{spaceCardHorizontalDefault}"
      },
      "spaceActionCardHorizontalEmbedded": {
        "comfortable": "{spaceCardHorizontalEmbedded}",
        "compact": "{spaceCardHorizontalEmbedded}"
      },
      "spaceActionCardVerticalDefault": {
        "comfortable": "{spaceCardVerticalDefault}",
        "compact": "{spaceCardVerticalDefault}"
      },
      "spaceActionCardVerticalEmbedded": {
        "comfortable": "{spaceCardVerticalEmbedded}",
        "compact": "{spaceCardVerticalEmbedded}"
      },
      "spaceActionCardDescriptionPaddingTop": {
        "comfortable": "{spaceScaledXxs}",
        "compact": "{spaceScaledXxs}"
      },
      "spaceActionCardContentPaddingTop": {
        "comfortable": "{spaceScaledXs}",
        "compact": "{spaceScaledXs}"
      },
      "spaceOptionPaddingVertical": {
        "comfortable": "{spaceXxs}",
        "compact": "{spaceXxs}"
      },
      "spaceOptionPaddingHorizontal": {
        "comfortable": "{spaceL}",
        "compact": "{spaceL}"
      },
      "spaceScaled2xNone": {
        "comfortable": "{spaceNone}",
        "compact": "{spaceNone}"
      },
      "spaceScaled2xXxxs": {
        "comfortable": "{spaceXxxs}",
        "compact": "{spaceNone}"
      },
      "spaceScaled2xXxs": {
        "comfortable": "{spaceXxs}",
        "compact": "{spaceNone}"
      },
      "spaceScaled2xXs": {
        "comfortable": "{spaceXs}",
        "compact": "{spaceNone}"
      },
      "spaceScaled2xS": {
        "comfortable": "{spaceS}",
        "compact": "{spaceXxs}"
      },
      "spaceScaled2xM": {
        "comfortable": "{spaceM}",
        "compact": "{spaceXs}"
      },
      "spaceScaled2xL": {
        "comfortable": "{spaceL}",
        "compact": "{spaceS}"
      },
      "spaceScaled2xXl": {
        "comfortable": "{spaceXl}",
        "compact": "{spaceM}"
      },
      "spaceScaled2xXxl": {
        "comfortable": "{spaceXxl}",
        "compact": "{spaceL}"
      },
      "spaceScaled2xXxxl": {
        "comfortable": "{spaceXxxl}",
        "compact": "{spaceXl}"
      },
      "spaceScaledNone": {
        "comfortable": "{spaceNone}",
        "compact": "{spaceNone}"
      },
      "spaceScaledXxxs": {
        "comfortable": "{spaceXxxs}",
        "compact": "{spaceNone}"
      },
      "spaceScaledXxs": {
        "comfortable": "{spaceXxs}",
        "compact": "{spaceXxxs}"
      },
      "spaceScaledXs": {
        "comfortable": "{spaceXs}",
        "compact": "{spaceXxs}"
      },
      "spaceScaledS": {
        "comfortable": "{spaceS}",
        "compact": "{spaceXs}"
      },
      "spaceScaledM": {
        "comfortable": "{spaceM}",
        "compact": "{spaceS}"
      },
      "spaceScaledL": {
        "comfortable": "{spaceL}",
        "compact": "{spaceM}"
      },
      "spaceScaledXl": {
        "comfortable": "{spaceXl}",
        "compact": "{spaceL}"
      },
      "spaceScaledXxl": {
        "comfortable": "{spaceXxl}",
        "compact": "{spaceXl}"
      },
      "spaceScaledXxxl": {
        "comfortable": "{spaceXxxl}",
        "compact": "{spaceXxl}"
      },
      "spaceStaticXxxs": {
        "comfortable": "{spaceXxxs}",
        "compact": "{spaceXxxs}"
      },
      "spaceStaticXxs": {
        "comfortable": "{spaceXxs}",
        "compact": "{spaceXxs}"
      },
      "spaceStaticXs": {
        "comfortable": "{spaceXs}",
        "compact": "{spaceXs}"
      },
      "spaceStaticS": {
        "comfortable": "{spaceS}",
        "compact": "{spaceS}"
      },
      "spaceStaticM": {
        "comfortable": "{spaceM}",
        "compact": "{spaceM}"
      },
      "spaceStaticL": {
        "comfortable": "{spaceL}",
        "compact": "{spaceL}"
      },
      "spaceStaticXl": {
        "comfortable": "{spaceXl}",
        "compact": "{spaceXl}"
      },
      "spaceStaticXxl": {
        "comfortable": "{spaceXxl}",
        "compact": "{spaceXxl}"
      },
      "spaceStaticXxxl": {
        "comfortable": "{spaceXxxl}",
        "compact": "{spaceXxxl}"
      },
      "spaceNone": {
        "comfortable": "0px",
        "compact": "0px"
      },
      "spaceXxxs": {
        "comfortable": "2px",
        "compact": "2px"
      },
      "spaceXxs": {
        "comfortable": "4px",
        "compact": "4px"
      },
      "spaceXs": {
        "comfortable": "8px",
        "compact": "8px"
      },
      "spaceS": {
        "comfortable": "12px",
        "compact": "12px"
      },
      "spaceM": {
        "comfortable": "16px",
        "compact": "16px"
      },
      "spaceL": {
        "comfortable": "20px",
        "compact": "20px"
      },
      "spaceXl": {
        "comfortable": "24px",
        "compact": "24px"
      },
      "spaceXxl": {
        "comfortable": "32px",
        "compact": "32px"
      },
      "spaceXxxl": {
        "comfortable": "40px",
        "compact": "40px"
      },
      "shadowCard": {
        "light": "none",
        "dark": "none"
      },
      "shadowItemCard": {
        "light": "{shadowCard}",
        "dark": "{shadowCard}"
      },
      "shadowContainer": {
        "light": "0px 0px 1px 1px #e9ebed, 0px 1px 8px 2px rgba(0, 7, 22, 0.12)",
        "dark": "0px 1px 8px 2px rgba(0, 7, 22, 0.6)"
      },
      "shadowContainerActive": {
        "light": "0px 1px 1px 1px #e9ebed, 0px 6px 36px #0007161a",
        "dark": "0px 1px 1px 1px #192534, 0px 6px 36px #00040c"
      },
      "shadowDropdown": {
        "light": "0px 4px 20px 1px rgba(0, 7, 22, 0.10)",
        "dark": "0px 4px 20px 1px rgba(0, 4, 12, 1)"
      },
      "shadowDropup": {
        "light": "{shadowDropdown}",
        "dark": "{shadowDropdown}"
      },
      "shadowFlashCollapsed": {
        "light": "0px 4px 4px rgba(0, 0, 0, 0.25)",
        "dark": "0px 4px 4px rgba(0, 0, 0, 0.25)"
      },
      "shadowFlashSticky": {
        "light": "0px 4px 8px rgba(0, 7, 22, 0.10)",
        "dark": "0px 4px 8px rgba(0, 7, 22, 0.5)"
      },
      "shadowModal": {
        "light": "{shadowDropdown}",
        "dark": "{shadowDropdown}"
      },
      "shadowPanel": {
        "light": "0px 0px 0px 1px #b6bec9",
        "dark": "0px 0px 0px 1px #414d5c"
      },
      "shadowPanelToggle": {
        "light": "0px 6px 12px 1px rgba(0, 7, 22, 0.12)",
        "dark": "0px 6px 12px 1px rgba(0, 7, 22, 1)"
      },
      "shadowPopover": {
        "light": "{shadowDropdown}",
        "dark": "{shadowDropdown}"
      },
      "shadowSplitBottom": {
        "light": "0px -36px 36px -36px rgba(0, 7, 22, 0.10)",
        "dark": "0px -36px 36px -36px rgba(0, 7, 22, 1)"
      },
      "shadowSplitSide": {
        "light": "-1px 0px 1px 0px #e9ebed, -36px 6px 36px -36px rgba(0, 7, 22, 0.10)",
        "dark": "-1px 0px 1px 0px #192534, -36px 6px 36px -36px rgba(0, 7, 22, 1)"
      },
      "shadowSticky": {
        "light": "0px 4px 8px 1px rgba(0, 7, 22, 0.10)",
        "dark": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)"
      },
      "shadowStickyEmbedded": {
        "light": "0px 2px 0px 0px #e9ebed, 0px 16px 16px -12px rgba(0, 7, 22, 0.10)",
        "dark": "0px 2px 0px 0px #414d5c, 0px 16px 16px -12px rgba(0, 7, 22, 1)"
      },
      "shadowStickyColumnFirst": {
        "light": "4px 0px 8px 1px rgba(0, 7, 22, 0.1)",
        "dark": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)"
      },
      "shadowStickyColumnLast": {
        "light": "-4px 0 8px 1px rgba(0, 28, 36, 0.1)",
        "dark": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)"
      }
    },
    "contexts": {
      "compact-table": {
        "id": "compact-table",
        "selector": ".awsui-context-compact-table",
        "tokens": {
          "spaceAlertActionLeft": {
            "comfortable": "{spaceS}",
            "compact": "{spaceS}"
          },
          "spaceAlertHorizontal": {
            "comfortable": "{spaceFlashbarHorizontal}",
            "compact": "{spaceFlashbarHorizontal}"
          },
          "spaceAlertMessageRight": {
            "comfortable": "{spaceXxs}",
            "compact": "{spaceXxs}"
          },
          "spaceAlertVertical": {
            "comfortable": "{spaceFlashbarVertical}",
            "compact": "{spaceFlashbarVertical}"
          },
          "spaceButtonFocusOutlineGutter": {
            "comfortable": "4px",
            "compact": "4px"
          },
          "spaceButtonHorizontal": {
            "comfortable": "{spaceScaledL}",
            "compact": "{spaceScaledL}"
          },
          "spaceButtonVertical": {
            "comfortable": "{spaceScaledXxs}",
            "compact": "{spaceScaledXxs}"
          },
          "spaceTokenVertical": {
            "comfortable": "{spaceScaledXxs}",
            "compact": "{spaceScaledXxs}"
          },
          "spaceFieldVertical": {
            "comfortable": "5px",
            "compact": "3px"
          },
          "spaceButtonIconFocusOutlineGutterVertical": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceButtonIconOnlyHorizontal": {
            "comfortable": "6px",
            "compact": "{spaceXxs}"
          },
          "spaceButtonInlineIconFocusOutlineGutter": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceButtonModalDismissVertical": {
            "comfortable": "{spaceScaledXxxs}",
            "compact": "{spaceScaledXxxs}"
          },
          "spaceCalendarGridFocusOutlineGutter": {
            "comfortable": "-5px",
            "compact": "-5px"
          },
          "spaceCalendarGridSelectedFocusOutlineGutter": {
            "comfortable": "{spaceCalendarGridFocusOutlineGutter}",
            "compact": "{spaceCalendarGridFocusOutlineGutter}"
          },
          "spaceCalendarGridGutter": {
            "comfortable": "6px",
            "compact": "6px"
          },
          "spaceCardHorizontalDefault": {
            "comfortable": "{spaceContainerHorizontal}",
            "compact": "{spaceContainerHorizontal}"
          },
          "spaceCardHorizontalEmbedded": {
            "comfortable": "{spaceS}",
            "compact": "10px"
          },
          "spaceCardVerticalDefault": {
            "comfortable": "{spaceScaledM}",
            "compact": "{spaceScaledM}"
          },
          "spaceCardVerticalEmbedded": {
            "comfortable": "10px",
            "compact": "{spaceXs}"
          },
          "spaceItemCardHorizontalDefault": {
            "comfortable": "{spaceCardHorizontalDefault}",
            "compact": "{spaceCardHorizontalDefault}"
          },
          "spaceItemCardHorizontalEmbedded": {
            "comfortable": "{spaceCardHorizontalEmbedded}",
            "compact": "{spaceCardHorizontalEmbedded}"
          },
          "spaceItemCardVerticalDefault": {
            "comfortable": "{spaceCardVerticalDefault}",
            "compact": "{spaceCardVerticalDefault}"
          },
          "spaceItemCardVerticalEmbedded": {
            "comfortable": "{spaceCardVerticalEmbedded}",
            "compact": "{spaceCardVerticalEmbedded}"
          },
          "spaceCodeEditorStatusFocusOutlineGutter": {
            "comfortable": "-7px",
            "compact": "-7px"
          },
          "spaceContainerContentTop": {
            "comfortable": "{spaceXxs}",
            "compact": "{spaceXxs}"
          },
          "spaceContainerHeaderTop": {
            "comfortable": "{spaceS}",
            "compact": "{spaceS}"
          },
          "spaceContainerHeaderBottom": {
            "comfortable": "{spaceScaledXs}",
            "compact": "{spaceScaledXs}"
          },
          "spaceContainerHorizontal": {
            "comfortable": "{spaceL}",
            "compact": "{spaceL}"
          },
          "spaceContentHeaderPaddingBottom": {
            "comfortable": "{spaceScaledM}",
            "compact": "{spaceScaledM}"
          },
          "spaceDarkHeaderOverlapDistance": {
            "comfortable": "36px",
            "compact": "32px"
          },
          "spaceExpandableSectionIconOffsetTop": {
            "comfortable": "{spaceScaled2xXxs}",
            "compact": "{spaceScaled2xXxs}"
          },
          "spaceFieldHorizontal": {
            "comfortable": "{spaceS}",
            "compact": "{spaceS}"
          },
          "spaceFieldIconOffset": {
            "comfortable": "36px",
            "compact": "36px"
          },
          "spaceFilteringTokenDismissButtonFocusOutlineGutter": {
            "comfortable": "-5px",
            "compact": "-5px"
          },
          "spaceFilteringTokenOperationSelectFocusOutlineGutter": {
            "comfortable": "-5px",
            "compact": "-5px"
          },
          "spaceFlashbarActionLeft": {
            "comfortable": "{spaceS}",
            "compact": "{spaceS}"
          },
          "spaceFlashbarDismissRight": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceFlashbarHorizontal": {
            "comfortable": "{spaceM}",
            "compact": "{spaceM}"
          },
          "spaceFlashbarVertical": {
            "comfortable": "{spaceScaledXs}",
            "compact": "{spaceScaledXs}"
          },
          "spaceGridGutter": {
            "comfortable": "{spaceL}",
            "compact": "{spaceM}"
          },
          "spaceKeyValueGap": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceLayoutContentBottom": {
            "comfortable": "{spaceScaled2xXxxl}",
            "compact": "{spaceScaled2xXxxl}"
          },
          "spaceLayoutContentHorizontal": {
            "comfortable": "{spaceScaled2xXl}",
            "compact": "{spaceScaled2xXl}"
          },
          "spaceLayoutToggleDiameter": {
            "comfortable": "36px",
            "compact": "36px"
          },
          "spaceLayoutTogglePadding": {
            "comfortable": "{spaceStaticS}",
            "compact": "{spaceStaticS}"
          },
          "spaceModalContentBottom": {
            "comfortable": "{spaceScaled2xM}",
            "compact": "{spaceScaled2xM}"
          },
          "spaceModalHorizontal": {
            "comfortable": "{spaceContainerHorizontal}",
            "compact": "{spaceContainerHorizontal}"
          },
          "spacePanelContentBottom": {
            "comfortable": "{spaceScaledXxxl}",
            "compact": "{spaceScaledXxxl}"
          },
          "spacePanelContentTop": {
            "comfortable": "{spaceScaledL}",
            "compact": "{spaceScaledL}"
          },
          "spacePanelDividerMarginHorizontal": {
            "comfortable": "{spaceXs}",
            "compact": "{spaceXs}"
          },
          "spacePanelHeaderVertical": {
            "comfortable": "{spaceScaledL}",
            "compact": "{spaceScaledL}"
          },
          "spacePanelNavLeft": {
            "comfortable": "28px",
            "compact": "28px"
          },
          "spacePanelSideLeft": {
            "comfortable": "28px",
            "compact": "28px"
          },
          "spacePanelSideRight": {
            "comfortable": "{spaceScaledXl}",
            "compact": "{spaceScaledXl}"
          },
          "spacePanelSplitTop": {
            "comfortable": "{spaceScaledL}",
            "compact": "{spaceScaledL}"
          },
          "spacePanelSplitBottom": {
            "comfortable": "{spaceScaledL}",
            "compact": "{spaceScaledL}"
          },
          "spaceSegmentedControlFocusOutlineGutter": {
            "comfortable": "6px",
            "compact": "6px"
          },
          "spaceTabsContentTop": {
            "comfortable": "{spaceScaledS}",
            "compact": "{spaceScaledS}"
          },
          "spaceTabsFocusOutlineGutter": {
            "comfortable": "-8px",
            "compact": "-8px"
          },
          "spaceTabsVertical": {
            "comfortable": "{spaceScaledXxs}",
            "compact": "{spaceScaledXxs}"
          },
          "spaceTableContentBottom": {
            "comfortable": "{spaceXxs}",
            "compact": "{spaceXxs}"
          },
          "spaceTableEmbeddedHeaderTop": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceTableFooterHorizontal": {
            "comfortable": "{spaceTableHeaderHorizontal}",
            "compact": "{spaceTableHeaderHorizontal}"
          },
          "spaceTableHeaderFocusOutlineGutter": {
            "comfortable": "0px",
            "compact": "-1px"
          },
          "spaceTableHeaderHorizontal": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceTableHeaderToolsBottom": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceTableHeaderToolsFullPageBottom": {
            "comfortable": "4px",
            "compact": "4px"
          },
          "spaceTableHorizontal": {
            "comfortable": "{spaceContainerHorizontal}",
            "compact": "{spaceContainerHorizontal}"
          },
          "spaceTreeViewIndentation": {
            "comfortable": "{spaceXl}",
            "compact": "{spaceXl}"
          },
          "spaceTileGutter": {
            "comfortable": "{spaceXl}",
            "compact": "{spaceM}"
          },
          "spaceActionCardHorizontalDefault": {
            "comfortable": "{spaceCardHorizontalDefault}",
            "compact": "{spaceCardHorizontalDefault}"
          },
          "spaceActionCardHorizontalEmbedded": {
            "comfortable": "{spaceCardHorizontalEmbedded}",
            "compact": "{spaceCardHorizontalEmbedded}"
          },
          "spaceActionCardVerticalDefault": {
            "comfortable": "{spaceCardVerticalDefault}",
            "compact": "{spaceCardVerticalDefault}"
          },
          "spaceActionCardVerticalEmbedded": {
            "comfortable": "{spaceCardVerticalEmbedded}",
            "compact": "{spaceCardVerticalEmbedded}"
          },
          "spaceActionCardDescriptionPaddingTop": {
            "comfortable": "{spaceScaledXxs}",
            "compact": "{spaceScaledXxs}"
          },
          "spaceActionCardContentPaddingTop": {
            "comfortable": "{spaceScaledXs}",
            "compact": "{spaceScaledXs}"
          },
          "spaceOptionPaddingVertical": {
            "comfortable": "{spaceXxs}",
            "compact": "{spaceXxs}"
          },
          "spaceOptionPaddingHorizontal": {
            "comfortable": "{spaceL}",
            "compact": "{spaceL}"
          },
          "spaceScaled2xNone": {
            "comfortable": "{spaceNone}",
            "compact": "{spaceNone}"
          },
          "spaceScaled2xXxxs": {
            "comfortable": "{spaceXxxs}",
            "compact": "{spaceNone}"
          },
          "spaceScaled2xXxs": {
            "comfortable": "{spaceXxs}",
            "compact": "{spaceNone}"
          },
          "spaceScaled2xXs": {
            "comfortable": "{spaceXs}",
            "compact": "{spaceNone}"
          },
          "spaceScaled2xS": {
            "comfortable": "{spaceS}",
            "compact": "{spaceXxs}"
          },
          "spaceScaled2xM": {
            "comfortable": "{spaceM}",
            "compact": "{spaceXs}"
          },
          "spaceScaled2xL": {
            "comfortable": "{spaceL}",
            "compact": "{spaceS}"
          },
          "spaceScaled2xXl": {
            "comfortable": "{spaceXl}",
            "compact": "{spaceM}"
          },
          "spaceScaled2xXxl": {
            "comfortable": "{spaceXxl}",
            "compact": "{spaceL}"
          },
          "spaceScaled2xXxxl": {
            "comfortable": "{spaceXxxl}",
            "compact": "{spaceXl}"
          },
          "spaceScaledNone": {
            "comfortable": "{spaceNone}",
            "compact": "{spaceNone}"
          },
          "spaceScaledXxxs": {
            "comfortable": "{spaceNone}",
            "compact": "{spaceNone}"
          },
          "spaceScaledXxs": {
            "comfortable": "{spaceXxxs}",
            "compact": "{spaceXxxs}"
          },
          "spaceScaledXs": {
            "comfortable": "{spaceXxs}",
            "compact": "{spaceXxs}"
          },
          "spaceScaledS": {
            "comfortable": "{spaceXs}",
            "compact": "{spaceXs}"
          },
          "spaceScaledM": {
            "comfortable": "{spaceS}",
            "compact": "{spaceS}"
          },
          "spaceScaledL": {
            "comfortable": "{spaceM}",
            "compact": "{spaceM}"
          },
          "spaceScaledXl": {
            "comfortable": "{spaceL}",
            "compact": "{spaceL}"
          },
          "spaceScaledXxl": {
            "comfortable": "{spaceXl}",
            "compact": "{spaceXl}"
          },
          "spaceScaledXxxl": {
            "comfortable": "{spaceXxl}",
            "compact": "{spaceXxl}"
          },
          "spaceStaticXxxs": {
            "comfortable": "{spaceXxxs}",
            "compact": "{spaceXxxs}"
          },
          "spaceStaticXxs": {
            "comfortable": "{spaceXxs}",
            "compact": "{spaceXxs}"
          },
          "spaceStaticXs": {
            "comfortable": "{spaceXs}",
            "compact": "{spaceXs}"
          },
          "spaceStaticS": {
            "comfortable": "{spaceS}",
            "compact": "{spaceS}"
          },
          "spaceStaticM": {
            "comfortable": "{spaceM}",
            "compact": "{spaceM}"
          },
          "spaceStaticL": {
            "comfortable": "{spaceL}",
            "compact": "{spaceL}"
          },
          "spaceStaticXl": {
            "comfortable": "{spaceXl}",
            "compact": "{spaceXl}"
          },
          "spaceStaticXxl": {
            "comfortable": "{spaceXxl}",
            "compact": "{spaceXxl}"
          },
          "spaceStaticXxxl": {
            "comfortable": "{spaceXxxl}",
            "compact": "{spaceXxxl}"
          },
          "spaceNone": {
            "comfortable": "0px",
            "compact": "0px"
          },
          "spaceXxxs": {
            "comfortable": "2px",
            "compact": "2px"
          },
          "spaceXxs": {
            "comfortable": "4px",
            "compact": "4px"
          },
          "spaceXs": {
            "comfortable": "8px",
            "compact": "8px"
          },
          "spaceS": {
            "comfortable": "12px",
            "compact": "12px"
          },
          "spaceM": {
            "comfortable": "16px",
            "compact": "16px"
          },
          "spaceL": {
            "comfortable": "20px",
            "compact": "20px"
          },
          "spaceXl": {
            "comfortable": "24px",
            "compact": "24px"
          },
          "spaceXxl": {
            "comfortable": "32px",
            "compact": "32px"
          },
          "spaceXxxl": {
            "comfortable": "40px",
            "compact": "40px"
          },
          "sizeVerticalInput": {
            "comfortable": "28px",
            "compact": "28px"
          }
        }
      },
      "top-navigation": {
        "id": "top-navigation",
        "selector": ".awsui-context-top-navigation",
        "tokens": {
          "colorGreyOpaque10": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(0, 0, 0, 0.1)"
          },
          "colorGreyOpaque25": {
            "light": "rgba(255, 255, 255, 0.25)",
            "dark": "rgba(255, 255, 255, 0.25)"
          },
          "colorGreyOpaque40": {
            "light": "rgba(0, 0, 0, 0.4)",
            "dark": "rgba(0, 0, 0, 0.4)"
          },
          "colorGreyOpaque50": {
            "light": "rgba(0, 0, 0, 0.5)",
            "dark": "rgba(0, 0, 0, 0.5)"
          },
          "colorGreyOpaque70": {
            "light": "rgba(15, 20, 26, 0.7)",
            "dark": "rgba(15, 20, 26, 0.7)"
          },
          "colorGreyOpaque80": {
            "light": "rgba(22, 25, 31, 0.8)",
            "dark": "rgba(22, 25, 31, 0.8)"
          },
          "colorGreyOpaque90": {
            "light": "rgba(242, 243, 243, 0.9)",
            "dark": "rgba(242, 243, 243, 0.9)"
          },
          "colorGreyTransparent": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentHeavy": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentLight": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorBackgroundBadgeIcon": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorBackgroundButtonLinkActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonLinkDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkDisabled": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundButtonNormalActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonNormalDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundButtonNormalDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundButtonNormalHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleButtonNormalPressed": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonPrimaryActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundButtonPrimaryDefault": {
            "light": "{colorBorderButtonNormalDefault}",
            "dark": "{colorBorderButtonNormalDefault}"
          },
          "colorBackgroundButtonPrimaryDisabled": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundButtonPrimaryHover": {
            "light": "{colorBorderButtonNormalHover}",
            "dark": "{colorBorderButtonNormalHover}"
          },
          "colorBackgroundDirectionButtonActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundDirectionButtonDisabled": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorTextDirectionButtonDefault": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextDirectionButtonDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorBackgroundCalendarCurrentDate": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCellShaded": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundCodeEditorGutterActiveLineError": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundCodeEditorGutterDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorLoading": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorPaneItemHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCodeEditorStatusBar": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCard": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundItemCard": {
            "light": "{colorBackgroundCard}",
            "dark": "{colorBackgroundCard}"
          },
          "colorBackgroundContainerContent": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundContainerHeader": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlChecked": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundControlDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlDisabled": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundDropdownItemDimmed": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundDropdownItemFilterMatch": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemHover": {
            "light": "{colorNeutral900}",
            "dark": "{colorNeutral900}"
          },
          "colorBackgroundDropdownItemSelected": {
            "light": "{colorBackgroundItemSelected}",
            "dark": "{colorBackgroundItemSelected}"
          },
          "colorBackgroundHomeHeader": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundInlineCode": {
            "light": "rgba(255, 255, 255, 0.1)",
            "dark": "rgba(255, 255, 255, 0.1)"
          },
          "colorBackgroundInputDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundInputDisabled": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundItemSelected": {
            "light": "{colorPrimary1000}",
            "dark": "{colorPrimary1000}"
          },
          "colorBackgroundLayoutMain": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundDrawer": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundDrawerBackdrop": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundLayoutMobilePanel": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundLayoutPanelContent": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundLayoutPanelHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundLayoutToolbar": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundLayoutToggleActive": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundLayoutToggleSelectedActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundModalOverlay": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundNotificationBlue": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo600}"
          },
          "colorBackgroundNotificationGreen": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess600}"
          },
          "colorBackgroundNotificationGrey": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationRed": {
            "light": "{colorError600}",
            "dark": "{colorError600}"
          },
          "colorBackgroundNotificationYellow": {
            "light": "{colorWarning400}",
            "dark": "{colorWarning400}"
          },
          "colorBackgroundNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundPopover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundProgressBarValueDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundProgressBarDefault": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundSegmentActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSegmentDefault": {
            "light": "{colorBackgroundButtonNormalDefault}",
            "dark": "{colorBackgroundButtonNormalDefault}"
          },
          "colorBackgroundSegmentDisabled": {
            "light": "{colorBackgroundButtonNormalDisabled}",
            "dark": "{colorBackgroundButtonNormalDisabled}"
          },
          "colorBackgroundSegmentHover": {
            "light": "{colorBackgroundButtonNormalHover}",
            "dark": "{colorBackgroundButtonNormalHover}"
          },
          "colorBackgroundSegmentWrapper": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundSliderRangeDefault": {
            "light": "{colorBackgroundSliderHandleDefault}",
            "dark": "{colorBackgroundSliderHandleDefault}"
          },
          "colorBackgroundSliderRangeActive": {
            "light": "{colorBackgroundSliderHandleActive}",
            "dark": "{colorBackgroundSliderHandleActive}"
          },
          "colorBackgroundSliderHandleDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSliderHandleActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundSliderTrackDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSliderHandleRing": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundSliderHandleErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderHandleWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundStatusError": {
            "light": "{colorError1000}",
            "dark": "{colorError1000}"
          },
          "colorBackgroundStatusInfo": {
            "light": "{colorInfo1000}",
            "dark": "{colorInfo1000}"
          },
          "colorBackgroundDialog": {
            "light": "{colorBackgroundStatusInfo}",
            "dark": "{colorBackgroundStatusInfo}"
          },
          "colorBackgroundStatusSuccess": {
            "light": "{colorSuccess1000}",
            "dark": "{colorSuccess1000}"
          },
          "colorBackgroundStatusWarning": {
            "light": "{colorWarning1000}",
            "dark": "{colorWarning1000}"
          },
          "colorBackgroundTableHeader": {
            "light": "{colorBackgroundContainerHeader}",
            "dark": "{colorBackgroundContainerHeader}"
          },
          "colorBackgroundTilesDisabled": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleCheckedDisabled": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary900}"
          },
          "colorBackgroundToggleDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundAvatarGenAi": {
            "light": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)",
            "dark": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)"
          },
          "colorBackgroundAvatarDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextAvatar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBackgroundLoadingBarGenAi": {
            "light": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)",
            "dark": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)"
          },
          "colorBackgroundChatBubbleOutgoing": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundChatBubbleIncoming": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextChatBubbleOutgoing": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextChatBubbleIncoming": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorBorderButtonLinkDisabled": {
            "light": "{colorBackgroundButtonLinkDisabled}",
            "dark": "{colorBackgroundButtonLinkDisabled}"
          },
          "colorBorderButtonNormalActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderButtonNormalDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderToggleButtonNormalPressed": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderButtonNormalDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextButtonNormalDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonNormalHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonIconDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonPrimaryActive": {
            "light": "{colorBackgroundButtonPrimaryActive}",
            "dark": "{colorBackgroundButtonPrimaryActive}"
          },
          "colorBorderButtonPrimaryDefault": {
            "light": "{colorBackgroundButtonPrimaryDefault}",
            "dark": "{colorBackgroundButtonPrimaryDefault}"
          },
          "colorBorderButtonPrimaryDisabled": {
            "light": "{colorBackgroundButtonPrimaryDisabled}",
            "dark": "{colorBackgroundButtonPrimaryDisabled}"
          },
          "colorBorderButtonPrimaryHover": {
            "light": "{colorBackgroundButtonPrimaryHover}",
            "dark": "{colorBackgroundButtonPrimaryHover}"
          },
          "colorTextButtonPrimaryDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorItemSelected": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderCalendarGrid": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderCalendarGridSelectedFocusRing": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBorderCellShaded": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderCodeEditorAceActiveLineLightTheme": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderCodeEditorAceActiveLineDarkTheme": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorPaneItemHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderCard": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderCardHighlighted": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemCard": {
            "light": "{colorBorderCard}",
            "dark": "{colorBorderCard}"
          },
          "colorBorderItemCardHighlighted": {
            "light": "{colorBorderCardHighlighted}",
            "dark": "{colorBorderCardHighlighted}"
          },
          "colorBorderContainerDivider": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderContainerTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderControlChecked": {
            "light": "{colorBackgroundControlChecked}",
            "dark": "{colorBackgroundControlChecked}"
          },
          "colorBorderControlDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderControlDisabled": {
            "light": "{colorBackgroundControlDisabled}",
            "dark": "{colorBackgroundControlDisabled}"
          },
          "colorBorderDividerActive": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDividerDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderDividerPanelBottom": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerPanelSide": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerSecondary": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderDropdownContainer": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownGroup": {
            "light": "{colorBorderDropdownItemDefault}",
            "dark": "{colorBorderDropdownItemDefault}"
          },
          "colorBorderDropdownItemDefault": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDropdownItemHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownItemDimmedHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderDropdownItemSelected": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderDropdownItemTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderEditableCellHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderInputDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderInputDisabled": {
            "light": "{colorBackgroundInputDisabled}",
            "dark": "{colorBackgroundInputDisabled}"
          },
          "colorBorderInputFocused": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderItemFocused": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderDropdownItemFocused": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderItemPlaceholder": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemSelected": {
            "light": "{colorItemSelected}",
            "dark": "{colorItemSelected}"
          },
          "colorBorderLayout": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderPanelHeader": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderPopover": {
            "light": "{colorBorderDropdownContainer}",
            "dark": "{colorBorderDropdownContainer}"
          },
          "colorBorderSegmentActive": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderSegmentDisabled": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentHover": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderStatusError": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorBorderStatusInfo": {
            "light": "{colorInfo400}",
            "dark": "{colorInfo400}"
          },
          "colorBorderStatusSuccess": {
            "light": "{colorSuccess500}",
            "dark": "{colorSuccess500}"
          },
          "colorBorderStatusWarning": {
            "light": "{colorWarning500}",
            "dark": "{colorWarning500}"
          },
          "colorBorderDialog": {
            "light": "{colorBorderStatusInfo}",
            "dark": "{colorBorderStatusInfo}"
          },
          "colorBorderDividerInteractiveDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderTabsDivider": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderTabsShadow": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorBorderTabsUnderline": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorBorderTilesDisabled": {
            "light": "{colorBackgroundTilesDisabled}",
            "dark": "{colorBackgroundTilesDisabled}"
          },
          "colorBorderTutorial": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorForegroundControlDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorForegroundControlDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorForegroundControlReadOnly": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorShadowDefault": {
            "light": "{colorGreyTransparentHeavy}",
            "dark": "{colorGreyTransparentHeavy}"
          },
          "colorShadowMedium": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorShadowSide": {
            "light": "{colorGreyTransparentLight}",
            "dark": "{colorGreyTransparentLight}"
          },
          "colorStrokeChartLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorStrokeCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorStrokeCodeEditorGutterActiveLineHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextAccent": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextBodyDefault": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBodySecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBreadcrumbCurrent": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorTextBreadcrumbIcon": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextButtonInlineIconDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextButtonNormalActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextToggleButtonNormalPressed": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonNormalDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextButtonNormalHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextLinkButtonNormalDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextLinkButtonNormalHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextLinkButtonNormalActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextButtonLinkDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonLinkHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonPrimaryActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCalendarDateHover": {
            "light": "{colorTextDropdownItemDefault}",
            "dark": "{colorTextDropdownItemDefault}"
          },
          "colorTextCalendarMonth": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextCodeEditorGutterActiveLine": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCodeEditorGutterDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextCodeEditorStatusBarDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextCodeEditorTabButtonError": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextColumnHeader": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextColumnSortingIcon": {
            "light": "{colorTextColumnHeader}",
            "dark": "{colorTextColumnHeader}"
          },
          "colorTextControlDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextCounter": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextDisabledInlineEdit": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextDropdownFooter": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownGroupLabel": {
            "light": "{colorTextGroupLabel}",
            "dark": "{colorTextGroupLabel}"
          },
          "colorTextDropdownItemDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextDropdownItemDimmed": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemFilterMatch": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextDropdownItemHighlighted": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextDropdownItemSecondary": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownItemSecondaryHover": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextEmpty": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionHover": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorTextExpandableSectionNavigationIconDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorTextInteractiveDefault}"
          },
          "colorTextFormDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextFormLabel": {
            "light": "{colorTextFormDefault}",
            "dark": "{colorTextFormDefault}"
          },
          "colorTextFormSecondary": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextGroupLabel": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextLabelGenAi": {
            "light": "{colorPurple400}",
            "dark": "{colorPurple400}"
          },
          "colorTextHeadingDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHeadingSecondary": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextHomeHeaderDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHomeHeaderSecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextIconCaret": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextIconSubtle": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextInputDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInputPlaceholder": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextInputPlaceholderDisabled": {
            "light": "{colorTextInputDisabled}",
            "dark": "{colorTextInputDisabled}"
          },
          "colorTextInteractiveActive": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInteractiveHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextToggleButtonIconPressed": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveInvertedDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveInvertedHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInverted": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLabel": {
            "light": "{colorTextFormLabel}",
            "dark": "{colorTextFormLabel}"
          },
          "colorTextKeyValuePairsValue": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextLayoutToggle": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLayoutToggleActive": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorTextLayoutToggleHover": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLayoutToggleSelected": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLinkDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLinkHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextLinkDecorationDefault": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkDecorationHover": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkSecondaryDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkSecondaryHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInfoDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkInfoHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInvertedHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonUnderline": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextLinkButtonUnderlineHover": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextNotificationDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextNotificationStackBar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextNotificationYellow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextPaginationPageNumberActiveDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextPaginationPageNumberDefault": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextSegmentActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextSegmentDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextSegmentHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextSmall": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusError": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorTextStatusInactive": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusInfo": {
            "light": "{colorInfo400}",
            "dark": "{colorInfo400}"
          },
          "colorTextStatusSuccess": {
            "light": "{colorSuccess500}",
            "dark": "{colorSuccess500}"
          },
          "colorTextStatusWarning": {
            "light": "{colorWarning500}",
            "dark": "{colorWarning500}"
          },
          "colorTextTopNavigationTitle": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextTutorialHotspotDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextTutorialHotspotHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorBoardPlaceholderActive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBoardPlaceholderHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary600}"
          },
          "colorDragPlaceholderActive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorDragPlaceholderHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary600}"
          },
          "colorDropzoneBackgroundDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorDropzoneBackgroundHover": {
            "light": "{colorPrimary1000}",
            "dark": "{colorPrimary1000}"
          },
          "colorDropzoneTextDefault": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneTextHover": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneBorderDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorDropzoneBorderHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorGapGlobalDrawer": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTreeViewConnectorLine": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBackgroundActionCardDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundActionCardHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundActionCardActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderActionCardDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderActionCardHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundActionCardDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorTextActionCardDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorIconActionCardDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorIconActionCardHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSkeleton": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundSkeletonWave": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorPrimary50": "#f0fbff",
          "colorPrimary100": "#d1f1ff",
          "colorPrimary200": "#b8e7ff",
          "colorPrimary300": "#75cfff",
          "colorPrimary400": "#42b4ff",
          "colorPrimary500": "#0099ff",
          "colorPrimary600": "#006ce0",
          "colorPrimary700": "#004a9e",
          "colorPrimary800": "#003b8f",
          "colorPrimary900": "#002b66",
          "colorPrimary1000": "#001129",
          "colorNeutral50": "#fcfcfd",
          "colorNeutral100": "#f9f9fa",
          "colorNeutral150": "#f6f6f9",
          "colorNeutral200": "#f3f3f7",
          "colorNeutral250": "#ebebf0",
          "colorNeutral300": "#dedee3",
          "colorNeutral350": "#c6c6cd",
          "colorNeutral400": "#b4b4bb",
          "colorNeutral450": "#a4a4ad",
          "colorNeutral500": "#8c8c94",
          "colorNeutral550": "#72747e",
          "colorNeutral600": "#656871",
          "colorNeutral650": "#424650",
          "colorNeutral700": "#333843",
          "colorNeutral750": "#232b37",
          "colorNeutral800": "#1b232d",
          "colorNeutral850": "#161d26",
          "colorNeutral900": "#131920",
          "colorNeutral950": "#0f141a",
          "colorNeutral1000": "#06080a",
          "colorError50": "#fff5f5",
          "colorError400": "#ff7a7a",
          "colorError600": "#db0000",
          "colorError900": "#700000",
          "colorError1000": "#1f0000",
          "colorSuccess50": "#effff1",
          "colorSuccess500": "#2bb534",
          "colorSuccess600": "#00802f",
          "colorSuccess1000": "#001401",
          "colorWarning50": "#fffef0",
          "colorWarning400": "#ffe347",
          "colorWarning500": "#fbd332",
          "colorWarning900": "#855900",
          "colorWarning1000": "#191100",
          "colorInfo50": "#f0fbff",
          "colorInfo300": "#75cfff",
          "colorInfo400": "#42b4ff",
          "colorInfo600": "#006ce0",
          "colorInfo1000": "#001129",
          "colorChartsStatusNeutral": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorChartsThresholdNegative": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorChartsThresholdPositive": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorChartsThresholdInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo300}"
          },
          "colorChartsThresholdNeutral": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorChartsLineGrid": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorChartsLineTick": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorChartsLineAxis": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorChartsErrorBarMarker": {
            "light": "{colorNeutral900}",
            "dark": "{colorWhite}"
          },
          "colorSeverityGrey": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationSeverityNeutral": {
            "light": "{colorSeverityGrey}",
            "dark": "{colorSeverityGrey}"
          },
          "colorTextNotificationSeverityCritical": {
            "light": "{colorNeutral100}",
            "dark": "{colorBlack}"
          },
          "colorTextNotificationSeverityHigh": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral950}"
          },
          "colorTextNotificationSeverityMedium": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextNotificationSeverityLow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextNotificationSeverityNeutral": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          }
        },
        "defaultMode": "dark"
      },
      "header": {
        "id": "header",
        "selector": ".awsui-context-content-header",
        "tokens": {
          "shadowCard": {
            "light": "none",
            "dark": "none"
          },
          "shadowItemCard": {
            "light": "{shadowCard}",
            "dark": "{shadowCard}"
          },
          "shadowContainer": {
            "light": "0px 1px 8px 2px rgba(0, 7, 22, 0.6)",
            "dark": "0px 1px 8px 2px rgba(0, 7, 22, 0.6)"
          },
          "shadowContainerActive": {
            "light": "0px 1px 1px 1px #192534, 0px 6px 36px #00040c",
            "dark": "0px 1px 1px 1px #192534, 0px 6px 36px #00040c"
          },
          "shadowDropdown": {
            "light": "0px 4px 20px 1px rgba(0, 4, 12, 1)",
            "dark": "0px 4px 20px 1px rgba(0, 4, 12, 1)"
          },
          "shadowDropup": {
            "light": "{shadowDropdown}",
            "dark": "{shadowDropdown}"
          },
          "shadowFlashCollapsed": {
            "light": "0px 4px 4px rgba(0, 0, 0, 0.25)",
            "dark": "0px 4px 4px rgba(0, 0, 0, 0.25)"
          },
          "shadowFlashSticky": {
            "light": "0px 4px 8px rgba(0, 7, 22, 0.10)",
            "dark": "0px 4px 8px rgba(0, 7, 22, 0.5)"
          },
          "shadowModal": {
            "light": "{shadowDropdown}",
            "dark": "{shadowDropdown}"
          },
          "shadowPanel": {
            "light": "0px 0px 0px 1px #b6bec9",
            "dark": "0px 0px 0px 1px #414d5c"
          },
          "shadowPanelToggle": {
            "light": "0px 6px 12px 1px rgba(0, 7, 22, 0.12)",
            "dark": "0px 6px 12px 1px rgba(0, 7, 22, 1)"
          },
          "shadowPopover": {
            "light": "{shadowDropdown}",
            "dark": "{shadowDropdown}"
          },
          "shadowSplitBottom": {
            "light": "0px -36px 36px -36px rgba(0, 7, 22, 1)",
            "dark": "0px -36px 36px -36px rgba(0, 7, 22, 1)"
          },
          "shadowSplitSide": {
            "light": "-1px 0px 1px 0px #192534, -36px 6px 36px -36px rgba(0, 7, 22, 1)",
            "dark": "-1px 0px 1px 0px #192534, -36px 6px 36px -36px rgba(0, 7, 22, 1)"
          },
          "shadowSticky": {
            "light": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)",
            "dark": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)"
          },
          "shadowStickyEmbedded": {
            "light": "0px 2px 0px 0px #414d5c, 0px 16px 16px -12px rgba(0, 7, 22, 1)",
            "dark": "0px 2px 0px 0px #414d5c, 0px 16px 16px -12px rgba(0, 7, 22, 1)"
          },
          "shadowStickyColumnFirst": {
            "light": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)",
            "dark": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)"
          },
          "shadowStickyColumnLast": {
            "light": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)",
            "dark": "0px 4px 8px 1px rgba(0, 7, 22, 0.5)"
          },
          "colorGreyOpaque10": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(0, 0, 0, 0.1)"
          },
          "colorGreyOpaque25": {
            "light": "rgba(255, 255, 255, 0.25)",
            "dark": "rgba(255, 255, 255, 0.25)"
          },
          "colorGreyOpaque40": {
            "light": "rgba(0, 0, 0, 0.4)",
            "dark": "rgba(0, 0, 0, 0.4)"
          },
          "colorGreyOpaque50": {
            "light": "rgba(0, 0, 0, 0.5)",
            "dark": "rgba(0, 0, 0, 0.5)"
          },
          "colorGreyOpaque70": {
            "light": "rgba(15, 20, 26, 0.7)",
            "dark": "rgba(15, 20, 26, 0.7)"
          },
          "colorGreyOpaque80": {
            "light": "rgba(22, 25, 31, 0.8)",
            "dark": "rgba(22, 25, 31, 0.8)"
          },
          "colorGreyOpaque90": {
            "light": "rgba(242, 243, 243, 0.9)",
            "dark": "rgba(242, 243, 243, 0.9)"
          },
          "colorGreyTransparent": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentHeavy": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentLight": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorBackgroundBadgeIcon": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorBackgroundButtonLinkActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonLinkDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkDisabled": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundButtonNormalActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonNormalDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundButtonNormalDisabled": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundButtonNormalHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleButtonNormalPressed": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonPrimaryActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundButtonPrimaryDefault": {
            "light": "{colorBorderButtonNormalDefault}",
            "dark": "{colorBorderButtonNormalDefault}"
          },
          "colorBackgroundButtonPrimaryDisabled": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundButtonPrimaryHover": {
            "light": "{colorBorderButtonNormalHover}",
            "dark": "{colorBorderButtonNormalHover}"
          },
          "colorBackgroundDirectionButtonActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundDirectionButtonDisabled": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorTextDirectionButtonDefault": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextDirectionButtonDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorBackgroundCalendarCurrentDate": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCellShaded": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundCodeEditorGutterActiveLineError": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundCodeEditorGutterDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorLoading": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorPaneItemHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCodeEditorStatusBar": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCard": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundItemCard": {
            "light": "{colorBackgroundCard}",
            "dark": "{colorBackgroundCard}"
          },
          "colorBackgroundContainerContent": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundContainerHeader": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlChecked": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundControlDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundControlDisabled": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundDropdownItemDimmed": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundDropdownItemFilterMatch": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemHover": {
            "light": "{colorNeutral900}",
            "dark": "{colorNeutral900}"
          },
          "colorBackgroundDropdownItemSelected": {
            "light": "{colorBackgroundItemSelected}",
            "dark": "{colorBackgroundItemSelected}"
          },
          "colorBackgroundHomeHeader": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundInlineCode": {
            "light": "rgba(255, 255, 255, 0.1)",
            "dark": "rgba(255, 255, 255, 0.1)"
          },
          "colorBackgroundInputDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundInputDisabled": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundItemSelected": {
            "light": "{colorPrimary1000}",
            "dark": "{colorPrimary1000}"
          },
          "colorBackgroundLayoutMain": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundDrawer": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundDrawerBackdrop": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundLayoutMobilePanel": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundLayoutPanelContent": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundLayoutPanelHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundLayoutToolbar": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundLayoutToggleActive": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundLayoutToggleSelectedActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundModalOverlay": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundNotificationBlue": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo600}"
          },
          "colorBackgroundNotificationGreen": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess600}"
          },
          "colorBackgroundNotificationGrey": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationRed": {
            "light": "{colorError600}",
            "dark": "{colorError600}"
          },
          "colorBackgroundNotificationYellow": {
            "light": "{colorWarning400}",
            "dark": "{colorWarning400}"
          },
          "colorBackgroundNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundPopover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundProgressBarValueDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundProgressBarDefault": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundSegmentActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSegmentDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundSegmentDisabled": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundSegmentHover": {
            "light": "{colorBackgroundButtonNormalHover}",
            "dark": "{colorBackgroundButtonNormalHover}"
          },
          "colorBackgroundSegmentWrapper": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundSliderRangeDefault": {
            "light": "{colorBackgroundSliderHandleDefault}",
            "dark": "{colorBackgroundSliderHandleDefault}"
          },
          "colorBackgroundSliderRangeActive": {
            "light": "{colorBackgroundSliderHandleActive}",
            "dark": "{colorBackgroundSliderHandleActive}"
          },
          "colorBackgroundSliderHandleDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSliderHandleActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundSliderTrackDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSliderHandleRing": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundSliderHandleErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderHandleWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundStatusError": {
            "light": "{colorError1000}",
            "dark": "{colorError1000}"
          },
          "colorBackgroundStatusInfo": {
            "light": "{colorInfo1000}",
            "dark": "{colorInfo1000}"
          },
          "colorBackgroundDialog": {
            "light": "{colorBackgroundStatusInfo}",
            "dark": "{colorBackgroundStatusInfo}"
          },
          "colorBackgroundStatusSuccess": {
            "light": "{colorSuccess1000}",
            "dark": "{colorSuccess1000}"
          },
          "colorBackgroundStatusWarning": {
            "light": "{colorWarning1000}",
            "dark": "{colorWarning1000}"
          },
          "colorBackgroundTableHeader": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundTilesDisabled": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleCheckedDisabled": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary900}"
          },
          "colorBackgroundToggleDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundAvatarGenAi": {
            "light": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)",
            "dark": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)"
          },
          "colorBackgroundAvatarDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextAvatar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBackgroundLoadingBarGenAi": {
            "light": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)",
            "dark": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)"
          },
          "colorBackgroundChatBubbleOutgoing": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundChatBubbleIncoming": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextChatBubbleOutgoing": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextChatBubbleIncoming": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorBorderButtonLinkDisabled": {
            "light": "{colorBackgroundButtonLinkDisabled}",
            "dark": "{colorBackgroundButtonLinkDisabled}"
          },
          "colorBorderButtonNormalActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderButtonNormalDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderToggleButtonNormalPressed": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderButtonNormalDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextButtonNormalDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonNormalHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonIconDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonPrimaryActive": {
            "light": "{colorBackgroundButtonPrimaryActive}",
            "dark": "{colorBackgroundButtonPrimaryActive}"
          },
          "colorBorderButtonPrimaryDefault": {
            "light": "{colorBackgroundButtonPrimaryDefault}",
            "dark": "{colorBackgroundButtonPrimaryDefault}"
          },
          "colorBorderButtonPrimaryDisabled": {
            "light": "{colorBackgroundButtonPrimaryDisabled}",
            "dark": "{colorBackgroundButtonPrimaryDisabled}"
          },
          "colorBorderButtonPrimaryHover": {
            "light": "{colorBackgroundButtonPrimaryHover}",
            "dark": "{colorBackgroundButtonPrimaryHover}"
          },
          "colorTextButtonPrimaryDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorItemSelected": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderCalendarGrid": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderCalendarGridSelectedFocusRing": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBorderCellShaded": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderCodeEditorAceActiveLineLightTheme": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderCodeEditorAceActiveLineDarkTheme": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorPaneItemHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderCard": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderCardHighlighted": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemCard": {
            "light": "{colorBorderCard}",
            "dark": "{colorBorderCard}"
          },
          "colorBorderItemCardHighlighted": {
            "light": "{colorBorderCardHighlighted}",
            "dark": "{colorBorderCardHighlighted}"
          },
          "colorBorderContainerDivider": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderContainerTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderControlChecked": {
            "light": "{colorBackgroundControlChecked}",
            "dark": "{colorBackgroundControlChecked}"
          },
          "colorBorderControlDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderControlDisabled": {
            "light": "{colorBackgroundControlDisabled}",
            "dark": "{colorBackgroundControlDisabled}"
          },
          "colorBorderDividerActive": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDividerDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderDividerPanelBottom": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerPanelSide": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerSecondary": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderDropdownContainer": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownGroup": {
            "light": "{colorBorderDropdownItemDefault}",
            "dark": "{colorBorderDropdownItemDefault}"
          },
          "colorBorderDropdownItemDefault": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDropdownItemHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownItemDimmedHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderDropdownItemSelected": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderDropdownItemTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderEditableCellHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderInputDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderInputDisabled": {
            "light": "{colorBackgroundInputDisabled}",
            "dark": "{colorBackgroundInputDisabled}"
          },
          "colorBorderInputFocused": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderItemFocused": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderDropdownItemFocused": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderItemPlaceholder": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemSelected": {
            "light": "{colorItemSelected}",
            "dark": "{colorItemSelected}"
          },
          "colorBorderLayout": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderPanelHeader": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderPopover": {
            "light": "{colorBorderDropdownContainer}",
            "dark": "{colorBorderDropdownContainer}"
          },
          "colorBorderSegmentActive": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderSegmentDisabled": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentHover": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderStatusError": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorBorderStatusInfo": {
            "light": "{colorInfo400}",
            "dark": "{colorInfo400}"
          },
          "colorBorderStatusSuccess": {
            "light": "{colorSuccess500}",
            "dark": "{colorSuccess500}"
          },
          "colorBorderStatusWarning": {
            "light": "{colorWarning500}",
            "dark": "{colorWarning500}"
          },
          "colorBorderDialog": {
            "light": "{colorBorderStatusInfo}",
            "dark": "{colorBorderStatusInfo}"
          },
          "colorBorderDividerInteractiveDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderTabsDivider": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderTabsShadow": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorBorderTabsUnderline": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorBorderTilesDisabled": {
            "light": "{colorBackgroundTilesDisabled}",
            "dark": "{colorBackgroundTilesDisabled}"
          },
          "colorBorderTutorial": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorForegroundControlDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorForegroundControlDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorForegroundControlReadOnly": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorShadowDefault": {
            "light": "{colorGreyTransparentHeavy}",
            "dark": "{colorGreyTransparentHeavy}"
          },
          "colorShadowMedium": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorShadowSide": {
            "light": "{colorGreyTransparentLight}",
            "dark": "{colorGreyTransparentLight}"
          },
          "colorStrokeChartLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorStrokeCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorStrokeCodeEditorGutterActiveLineHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextAccent": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextBodyDefault": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBodySecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBreadcrumbCurrent": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorTextBreadcrumbIcon": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextButtonInlineIconDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextButtonNormalActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextToggleButtonNormalPressed": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonNormalDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextButtonNormalHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextLinkButtonNormalDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextLinkButtonNormalHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextLinkButtonNormalActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextButtonLinkDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonLinkHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonPrimaryActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCalendarDateHover": {
            "light": "{colorTextDropdownItemDefault}",
            "dark": "{colorTextDropdownItemDefault}"
          },
          "colorTextCalendarMonth": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextCodeEditorGutterActiveLine": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCodeEditorGutterDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextCodeEditorStatusBarDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextCodeEditorTabButtonError": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextColumnHeader": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextColumnSortingIcon": {
            "light": "{colorTextColumnHeader}",
            "dark": "{colorTextColumnHeader}"
          },
          "colorTextControlDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextCounter": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextDisabledInlineEdit": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextDropdownFooter": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownGroupLabel": {
            "light": "{colorTextGroupLabel}",
            "dark": "{colorTextGroupLabel}"
          },
          "colorTextDropdownItemDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextDropdownItemDimmed": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemFilterMatch": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextDropdownItemHighlighted": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextDropdownItemSecondary": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownItemSecondaryHover": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextEmpty": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionHover": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorTextExpandableSectionNavigationIconDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorTextInteractiveDefault}"
          },
          "colorTextFormDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextFormLabel": {
            "light": "{colorTextFormDefault}",
            "dark": "{colorTextFormDefault}"
          },
          "colorTextFormSecondary": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextGroupLabel": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextLabelGenAi": {
            "light": "{colorPurple400}",
            "dark": "{colorPurple400}"
          },
          "colorTextHeadingDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHeadingSecondary": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextHomeHeaderDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHomeHeaderSecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextIconCaret": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextIconSubtle": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextInputDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInputPlaceholder": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextInputPlaceholderDisabled": {
            "light": "{colorTextInputDisabled}",
            "dark": "{colorTextInputDisabled}"
          },
          "colorTextInteractiveActive": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInteractiveHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextToggleButtonIconPressed": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveInvertedDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveInvertedHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInverted": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLabel": {
            "light": "{colorTextFormLabel}",
            "dark": "{colorTextFormLabel}"
          },
          "colorTextKeyValuePairsValue": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextLayoutToggle": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLayoutToggleActive": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorTextLayoutToggleHover": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLayoutToggleSelected": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLinkDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLinkHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextLinkDecorationDefault": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkDecorationHover": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkSecondaryDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkSecondaryHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInfoDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkInfoHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInvertedHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonUnderline": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextLinkButtonUnderlineHover": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextNotificationDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextNotificationStackBar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextNotificationYellow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextPaginationPageNumberActiveDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextPaginationPageNumberDefault": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextSegmentActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextSegmentDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextSegmentHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextSmall": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusError": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorTextStatusInactive": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusInfo": {
            "light": "{colorInfo400}",
            "dark": "{colorInfo400}"
          },
          "colorTextStatusSuccess": {
            "light": "{colorSuccess500}",
            "dark": "{colorSuccess500}"
          },
          "colorTextStatusWarning": {
            "light": "{colorWarning500}",
            "dark": "{colorWarning500}"
          },
          "colorTextTopNavigationTitle": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextTutorialHotspotDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextTutorialHotspotHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorBoardPlaceholderActive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBoardPlaceholderHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary600}"
          },
          "colorDragPlaceholderActive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorDragPlaceholderHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary600}"
          },
          "colorDropzoneBackgroundDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorDropzoneBackgroundHover": {
            "light": "{colorPrimary1000}",
            "dark": "{colorPrimary1000}"
          },
          "colorDropzoneTextDefault": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneTextHover": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneBorderDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorDropzoneBorderHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorGapGlobalDrawer": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTreeViewConnectorLine": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBackgroundActionCardDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundActionCardHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundActionCardActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderActionCardDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderActionCardHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundActionCardDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorTextActionCardDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorIconActionCardDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorIconActionCardHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSkeleton": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundSkeletonWave": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorPrimary50": "#f0fbff",
          "colorPrimary100": "#d1f1ff",
          "colorPrimary200": "#b8e7ff",
          "colorPrimary300": "#75cfff",
          "colorPrimary400": "#42b4ff",
          "colorPrimary500": "#0099ff",
          "colorPrimary600": "#006ce0",
          "colorPrimary700": "#004a9e",
          "colorPrimary800": "#003b8f",
          "colorPrimary900": "#002b66",
          "colorPrimary1000": "#001129",
          "colorNeutral50": "#fcfcfd",
          "colorNeutral100": "#f9f9fa",
          "colorNeutral150": "#f6f6f9",
          "colorNeutral200": "#f3f3f7",
          "colorNeutral250": "#ebebf0",
          "colorNeutral300": "#dedee3",
          "colorNeutral350": "#c6c6cd",
          "colorNeutral400": "#b4b4bb",
          "colorNeutral450": "#a4a4ad",
          "colorNeutral500": "#8c8c94",
          "colorNeutral550": "#72747e",
          "colorNeutral600": "#656871",
          "colorNeutral650": "#424650",
          "colorNeutral700": "#333843",
          "colorNeutral750": "#232b37",
          "colorNeutral800": "#1b232d",
          "colorNeutral850": "#161d26",
          "colorNeutral900": "#131920",
          "colorNeutral950": "#0f141a",
          "colorNeutral1000": "#06080a",
          "colorError50": "#fff5f5",
          "colorError400": "#ff7a7a",
          "colorError600": "#db0000",
          "colorError900": "#700000",
          "colorError1000": "#1f0000",
          "colorSuccess50": "#effff1",
          "colorSuccess500": "#2bb534",
          "colorSuccess600": "#00802f",
          "colorSuccess1000": "#001401",
          "colorWarning50": "#fffef0",
          "colorWarning400": "#ffe347",
          "colorWarning500": "#fbd332",
          "colorWarning900": "#855900",
          "colorWarning1000": "#191100",
          "colorInfo50": "#f0fbff",
          "colorInfo300": "#75cfff",
          "colorInfo400": "#42b4ff",
          "colorInfo600": "#006ce0",
          "colorInfo1000": "#001129",
          "colorChartsStatusNeutral": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorChartsThresholdNegative": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorChartsThresholdPositive": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorChartsThresholdInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo300}"
          },
          "colorChartsThresholdNeutral": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorChartsLineGrid": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorChartsLineTick": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorChartsLineAxis": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorChartsErrorBarMarker": {
            "light": "{colorNeutral900}",
            "dark": "{colorWhite}"
          },
          "colorSeverityGrey": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationSeverityNeutral": {
            "light": "{colorSeverityGrey}",
            "dark": "{colorSeverityGrey}"
          },
          "colorTextNotificationSeverityCritical": {
            "light": "{colorNeutral100}",
            "dark": "{colorBlack}"
          },
          "colorTextNotificationSeverityHigh": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral950}"
          },
          "colorTextNotificationSeverityMedium": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextNotificationSeverityLow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextNotificationSeverityNeutral": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          }
        },
        "defaultMode": "dark"
      },
      "flashbar": {
        "id": "flashbar",
        "selector": ".awsui-context-flashbar",
        "tokens": {
          "colorGreyOpaque10": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(0, 0, 0, 0.1)"
          },
          "colorGreyOpaque25": {
            "light": "rgba(255, 255, 255, 0.25)",
            "dark": "rgba(255, 255, 255, 0.25)"
          },
          "colorGreyOpaque40": {
            "light": "rgba(0, 0, 0, 0.4)",
            "dark": "rgba(0, 0, 0, 0.4)"
          },
          "colorGreyOpaque50": {
            "light": "rgba(0, 0, 0, 0.5)",
            "dark": "rgba(0, 0, 0, 0.5)"
          },
          "colorGreyOpaque70": {
            "light": "rgba(35, 43, 55, 0.7)",
            "dark": "rgba(15, 20, 26, 0.7)"
          },
          "colorGreyOpaque80": {
            "light": "rgba(22, 25, 31, 0.8)",
            "dark": "rgba(22, 25, 31, 0.8)"
          },
          "colorGreyOpaque90": {
            "light": "rgba(242, 243, 243, 0.9)",
            "dark": "rgba(242, 243, 243, 0.9)"
          },
          "colorGreyTransparent": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentHeavy": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentLight": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorBackgroundBadgeIcon": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorBackgroundButtonLinkActive": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonLinkDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkDisabled": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundButtonNormalActive": {
            "light": "rgba(0, 7, 22, 0.2)",
            "dark": "rgba(0, 7, 22, 0.2)"
          },
          "colorBackgroundButtonNormalDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonNormalDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundButtonNormalHover": {
            "light": "rgba(0, 7, 22, 0.15)",
            "dark": "rgba(0, 7, 22, 0.15)"
          },
          "colorBackgroundToggleButtonNormalPressed": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonPrimaryActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundButtonPrimaryDefault": {
            "light": "{colorBorderButtonNormalDefault}",
            "dark": "{colorBorderButtonNormalDefault}"
          },
          "colorBackgroundButtonPrimaryDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundButtonPrimaryHover": {
            "light": "{colorBorderButtonNormalHover}",
            "dark": "{colorBorderButtonNormalHover}"
          },
          "colorBackgroundDirectionButtonActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundDirectionButtonDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorTextDirectionButtonDefault": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextDirectionButtonDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorBackgroundCalendarCurrentDate": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCellShaded": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundCodeEditorGutterActiveLineError": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundCodeEditorGutterDefault": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorLoading": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorPaneItemHover": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCodeEditorStatusBar": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCard": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundItemCard": {
            "light": "{colorBackgroundCard}",
            "dark": "{colorBackgroundCard}"
          },
          "colorBackgroundContainerContent": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundContainerHeader": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlChecked": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundControlDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlDisabled": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundDropdownItemDimmed": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundDropdownItemFilterMatch": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemHover": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral900}"
          },
          "colorBackgroundDropdownItemSelected": {
            "light": "{colorBackgroundItemSelected}",
            "dark": "{colorBackgroundItemSelected}"
          },
          "colorBackgroundHomeHeader": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundInlineCode": {
            "light": "rgba(0, 0, 0, 0.2)",
            "dark": "rgba(0, 0, 0, 0.2)"
          },
          "colorBackgroundInputDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundInputDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundItemSelected": {
            "light": "{colorPrimary50}",
            "dark": "{colorPrimary1000}"
          },
          "colorBackgroundLayoutMain": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundDrawer": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundDrawerBackdrop": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundLayoutMobilePanel": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundLayoutPanelContent": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundLayoutPanelHover": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundLayoutToolbar": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundLayoutToggleActive": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundLayoutToggleSelectedActive": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedHover": {
            "light": "{colorPrimary700}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundModalOverlay": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundNotificationBlue": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo600}"
          },
          "colorBackgroundNotificationGreen": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess600}"
          },
          "colorBackgroundNotificationGrey": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationRed": {
            "light": "{colorError600}",
            "dark": "{colorError600}"
          },
          "colorBackgroundNotificationYellow": {
            "light": "{colorWarning400}",
            "dark": "{colorWarning400}"
          },
          "colorBackgroundNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundPopover": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundProgressBarValueDefault": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBackgroundProgressBarDefault": {
            "light": "{colorGreyOpaque25}",
            "dark": "{colorGreyOpaque25}"
          },
          "colorBackgroundSegmentActive": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSegmentDefault": {
            "light": "{colorBackgroundButtonNormalDefault}",
            "dark": "{colorBackgroundButtonNormalDefault}"
          },
          "colorBackgroundSegmentDisabled": {
            "light": "{colorBackgroundButtonNormalDisabled}",
            "dark": "{colorBackgroundButtonNormalDisabled}"
          },
          "colorBackgroundSegmentHover": {
            "light": "{colorBackgroundButtonNormalHover}",
            "dark": "{colorBackgroundButtonNormalHover}"
          },
          "colorBackgroundSegmentWrapper": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundSliderRangeDefault": {
            "light": "{colorBackgroundSliderHandleDefault}",
            "dark": "{colorBackgroundSliderHandleDefault}"
          },
          "colorBackgroundSliderRangeActive": {
            "light": "{colorBackgroundSliderHandleActive}",
            "dark": "{colorBackgroundSliderHandleActive}"
          },
          "colorBackgroundSliderHandleDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSliderHandleActive": {
            "light": "{colorPrimary700}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundSliderTrackDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSliderHandleRing": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundSliderHandleErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderHandleWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundStatusError": {
            "light": "{colorError50}",
            "dark": "{colorError1000}"
          },
          "colorBackgroundStatusInfo": {
            "light": "{colorInfo50}",
            "dark": "{colorInfo1000}"
          },
          "colorBackgroundDialog": {
            "light": "{colorBackgroundStatusInfo}",
            "dark": "{colorBackgroundStatusInfo}"
          },
          "colorBackgroundStatusSuccess": {
            "light": "{colorSuccess50}",
            "dark": "{colorSuccess1000}"
          },
          "colorBackgroundStatusWarning": {
            "light": "{colorWarning50}",
            "dark": "{colorWarning1000}"
          },
          "colorBackgroundTableHeader": {
            "light": "{colorBackgroundContainerHeader}",
            "dark": "{colorBackgroundContainerHeader}"
          },
          "colorBackgroundTilesDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleCheckedDisabled": {
            "light": "{colorPrimary200}",
            "dark": "{colorPrimary900}"
          },
          "colorBackgroundToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundAvatarGenAi": {
            "light": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)",
            "dark": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)"
          },
          "colorBackgroundAvatarDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextAvatar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBackgroundLoadingBarGenAi": {
            "light": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)",
            "dark": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)"
          },
          "colorBackgroundChatBubbleOutgoing": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundChatBubbleIncoming": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral950}"
          },
          "colorTextChatBubbleOutgoing": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextChatBubbleIncoming": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorBorderButtonLinkDisabled": {
            "light": "{colorBackgroundButtonLinkDisabled}",
            "dark": "{colorBackgroundButtonLinkDisabled}"
          },
          "colorBorderButtonNormalActive": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBorderButtonNormalDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderToggleButtonNormalPressed": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderButtonNormalDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextButtonNormalDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonNormalHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextButtonIconDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonPrimaryActive": {
            "light": "{colorBackgroundButtonPrimaryActive}",
            "dark": "{colorBackgroundButtonPrimaryActive}"
          },
          "colorBorderButtonPrimaryDefault": {
            "light": "{colorBackgroundButtonPrimaryDefault}",
            "dark": "{colorBackgroundButtonPrimaryDefault}"
          },
          "colorBorderButtonPrimaryDisabled": {
            "light": "{colorBackgroundButtonPrimaryDisabled}",
            "dark": "{colorBackgroundButtonPrimaryDisabled}"
          },
          "colorBorderButtonPrimaryHover": {
            "light": "{colorBackgroundButtonPrimaryHover}",
            "dark": "{colorBackgroundButtonPrimaryHover}"
          },
          "colorTextButtonPrimaryDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorItemSelected": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderCalendarGrid": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderCalendarGridSelectedFocusRing": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral850}"
          },
          "colorBorderCellShaded": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderCodeEditorAceActiveLineLightTheme": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderCodeEditorAceActiveLineDarkTheme": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorPaneItemHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderCard": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderCardHighlighted": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemCard": {
            "light": "{colorBorderCard}",
            "dark": "{colorBorderCard}"
          },
          "colorBorderItemCardHighlighted": {
            "light": "{colorBorderCardHighlighted}",
            "dark": "{colorBorderCardHighlighted}"
          },
          "colorBorderContainerDivider": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderContainerTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderControlChecked": {
            "light": "{colorBackgroundControlChecked}",
            "dark": "{colorBackgroundControlChecked}"
          },
          "colorBorderControlDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderControlDisabled": {
            "light": "{colorBackgroundControlDisabled}",
            "dark": "{colorBackgroundControlDisabled}"
          },
          "colorBorderDividerActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDividerDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDividerPanelBottom": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerPanelSide": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerSecondary": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderDropdownContainer": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownGroup": {
            "light": "{colorBorderDropdownItemDefault}",
            "dark": "{colorBorderDropdownItemDefault}"
          },
          "colorBorderDropdownItemDefault": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDropdownItemHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownItemDimmedHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderDropdownItemSelected": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderDropdownItemTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderEditableCellHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderInputDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderInputDisabled": {
            "light": "{colorBackgroundInputDisabled}",
            "dark": "{colorBackgroundInputDisabled}"
          },
          "colorBorderInputFocused": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderItemFocused": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDropdownItemFocused": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderItemPlaceholder": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemSelected": {
            "light": "{colorItemSelected}",
            "dark": "{colorItemSelected}"
          },
          "colorBorderLayout": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderPanelHeader": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderPopover": {
            "light": "{colorBorderDropdownContainer}",
            "dark": "{colorBorderDropdownContainer}"
          },
          "colorBorderSegmentActive": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderSegmentDisabled": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentHover": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderStatusError": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorBorderStatusInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo400}"
          },
          "colorBorderStatusSuccess": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorBorderStatusWarning": {
            "light": "{colorWarning900}",
            "dark": "{colorWarning500}"
          },
          "colorBorderDialog": {
            "light": "{colorBorderStatusInfo}",
            "dark": "{colorBorderStatusInfo}"
          },
          "colorBorderDividerInteractiveDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderTabsDivider": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderTabsShadow": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorBorderTabsUnderline": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorBorderTilesDisabled": {
            "light": "{colorBackgroundTilesDisabled}",
            "dark": "{colorBackgroundTilesDisabled}"
          },
          "colorBorderTutorial": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorForegroundControlDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorForegroundControlDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorForegroundControlReadOnly": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorShadowDefault": {
            "light": "{colorGreyTransparentHeavy}",
            "dark": "{colorGreyTransparentHeavy}"
          },
          "colorShadowMedium": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorShadowSide": {
            "light": "{colorGreyTransparentLight}",
            "dark": "{colorGreyTransparentLight}"
          },
          "colorStrokeChartLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorStrokeCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral800}"
          },
          "colorStrokeCodeEditorGutterActiveLineHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral950}"
          },
          "colorTextAccent": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorTextBodyDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextBodySecondary": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextBreadcrumbCurrent": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral500}"
          },
          "colorTextBreadcrumbIcon": {
            "light": "{colorNeutral500}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextButtonInlineIconDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextButtonNormalActive": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextToggleButtonNormalPressed": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonNormalDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextButtonNormalHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonNormalDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextLinkButtonNormalHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextLinkButtonNormalActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextButtonLinkDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonLinkHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonPrimaryActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryHover": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCalendarDateHover": {
            "light": "{colorTextDropdownItemDefault}",
            "dark": "{colorTextDropdownItemDefault}"
          },
          "colorTextCalendarMonth": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextCodeEditorGutterActiveLine": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCodeEditorGutterDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextCodeEditorStatusBarDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorTextCodeEditorTabButtonError": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextColumnHeader": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral400}"
          },
          "colorTextColumnSortingIcon": {
            "light": "{colorTextColumnHeader}",
            "dark": "{colorTextColumnHeader}"
          },
          "colorTextControlDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextCounter": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextDisabledInlineEdit": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral400}"
          },
          "colorTextDropdownFooter": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownGroupLabel": {
            "light": "{colorTextGroupLabel}",
            "dark": "{colorTextGroupLabel}"
          },
          "colorTextDropdownItemDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextDropdownItemDimmed": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemFilterMatch": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary300}"
          },
          "colorTextDropdownItemHighlighted": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral250}"
          },
          "colorTextDropdownItemSecondary": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownItemSecondaryHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral300}"
          },
          "colorTextEmpty": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextExpandableSectionHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextExpandableSectionNavigationIconDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorTextInteractiveDefault}"
          },
          "colorTextFormDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextFormLabel": {
            "light": "{colorTextFormDefault}",
            "dark": "{colorTextFormDefault}"
          },
          "colorTextFormSecondary": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextGroupLabel": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorTextLabelGenAi": {
            "light": "{colorPurple700}",
            "dark": "{colorPurple400}"
          },
          "colorTextHeadingDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHeadingSecondary": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextHomeHeaderDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHomeHeaderSecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextIconCaret": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral450}"
          },
          "colorTextIconSubtle": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral400}"
          },
          "colorTextInputDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInputPlaceholder": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextInputPlaceholderDisabled": {
            "light": "{colorTextInputDisabled}",
            "dark": "{colorTextInputDisabled}"
          },
          "colorTextInteractiveActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInteractiveHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextToggleButtonIconPressed": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveInvertedDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveInvertedHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInverted": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLabel": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextKeyValuePairsValue": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextLayoutToggle": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLayoutToggleActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorTextLayoutToggleHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLayoutToggleSelected": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLinkDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextLinkHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkDecorationDefault": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkDecorationHover": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkSecondaryDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkSecondaryHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInfoDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkInfoHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInvertedHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonUnderline": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextLinkButtonUnderlineHover": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextNotificationDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextNotificationStackBar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextNotificationYellow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextPaginationPageNumberActiveDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextPaginationPageNumberDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorNeutral400}"
          },
          "colorTextSegmentActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextSegmentDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorTextSegmentHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextSmall": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusError": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorTextStatusInactive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo400}"
          },
          "colorTextStatusSuccess": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorTextStatusWarning": {
            "light": "{colorWarning900}",
            "dark": "{colorWarning500}"
          },
          "colorTextTopNavigationTitle": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextTutorialHotspotDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextTutorialHotspotHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBoardPlaceholderActive": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral600}"
          },
          "colorBoardPlaceholderHover": {
            "light": "{colorPrimary100}",
            "dark": "{colorPrimary600}"
          },
          "colorDragPlaceholderActive": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral600}"
          },
          "colorDragPlaceholderHover": {
            "light": "{colorPrimary100}",
            "dark": "{colorPrimary600}"
          },
          "colorDropzoneBackgroundDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorDropzoneBackgroundHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorPrimary1000}"
          },
          "colorDropzoneTextDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneTextHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneBorderDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorDropzoneBorderHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorGapGlobalDrawer": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral950}"
          },
          "colorTreeViewConnectorLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral300}"
          },
          "colorBackgroundActionCardDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundActionCardHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundActionCardActive": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderActionCardDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderActionCardHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundActionCardDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorTextActionCardDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorIconActionCardDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorIconActionCardHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSkeleton": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundSkeletonWave": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral700}"
          }
        }
      },
      "flashbar-warning": {
        "id": "flashbar-warning",
        "selector": ".awsui-context-flashbar-warning",
        "tokens": {
          "colorGreyOpaque10": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(0, 0, 0, 0.1)"
          },
          "colorGreyOpaque25": {
            "light": "rgba(255, 255, 255, 0.25)",
            "dark": "rgba(255, 255, 255, 0.25)"
          },
          "colorGreyOpaque40": {
            "light": "rgba(0, 0, 0, 0.4)",
            "dark": "rgba(0, 0, 0, 0.4)"
          },
          "colorGreyOpaque50": {
            "light": "rgba(0, 0, 0, 0.5)",
            "dark": "rgba(0, 0, 0, 0.5)"
          },
          "colorGreyOpaque70": {
            "light": "rgba(35, 43, 55, 0.7)",
            "dark": "rgba(15, 20, 26, 0.7)"
          },
          "colorGreyOpaque80": {
            "light": "rgba(22, 25, 31, 0.8)",
            "dark": "rgba(22, 25, 31, 0.8)"
          },
          "colorGreyOpaque90": {
            "light": "rgba(242, 243, 243, 0.9)",
            "dark": "rgba(242, 243, 243, 0.9)"
          },
          "colorGreyTransparent": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentHeavy": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentLight": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorBackgroundBadgeIcon": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorBackgroundButtonLinkActive": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonLinkDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkDisabled": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundButtonNormalActive": {
            "light": "rgba(0, 7, 22, 0.1)",
            "dark": "rgba(0, 7, 22, 0.1)"
          },
          "colorBackgroundButtonNormalDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonNormalDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundButtonNormalHover": {
            "light": "rgba(0, 7, 22, 0.05)",
            "dark": "rgba(0, 7, 22, 0.05)"
          },
          "colorBackgroundToggleButtonNormalPressed": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonPrimaryActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundButtonPrimaryDefault": {
            "light": "{colorBorderButtonNormalDefault}",
            "dark": "{colorBorderButtonNormalDefault}"
          },
          "colorBackgroundButtonPrimaryDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundButtonPrimaryHover": {
            "light": "{colorBorderButtonNormalHover}",
            "dark": "{colorBorderButtonNormalHover}"
          },
          "colorBackgroundDirectionButtonActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundDirectionButtonDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorTextDirectionButtonDefault": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextDirectionButtonDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorBackgroundCalendarCurrentDate": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCellShaded": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundCodeEditorGutterActiveLineError": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundCodeEditorGutterDefault": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorLoading": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorPaneItemHover": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCodeEditorStatusBar": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCard": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundItemCard": {
            "light": "{colorBackgroundCard}",
            "dark": "{colorBackgroundCard}"
          },
          "colorBackgroundContainerContent": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundContainerHeader": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlChecked": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundControlDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlDisabled": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundDropdownItemDimmed": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundDropdownItemFilterMatch": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemHover": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral900}"
          },
          "colorBackgroundDropdownItemSelected": {
            "light": "{colorBackgroundItemSelected}",
            "dark": "{colorBackgroundItemSelected}"
          },
          "colorBackgroundHomeHeader": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundInlineCode": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(0, 0, 0, 0.1)"
          },
          "colorBackgroundInputDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundInputDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundItemSelected": {
            "light": "{colorPrimary50}",
            "dark": "{colorPrimary1000}"
          },
          "colorBackgroundLayoutMain": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundDrawer": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundDrawerBackdrop": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundLayoutMobilePanel": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundLayoutPanelContent": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundLayoutPanelHover": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundLayoutToolbar": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundLayoutToggleActive": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundLayoutToggleSelectedActive": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedHover": {
            "light": "{colorPrimary700}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundModalOverlay": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundNotificationBlue": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo600}"
          },
          "colorBackgroundNotificationGreen": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess600}"
          },
          "colorBackgroundNotificationGrey": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationRed": {
            "light": "{colorError600}",
            "dark": "{colorError600}"
          },
          "colorBackgroundNotificationYellow": {
            "light": "{colorWarning400}",
            "dark": "{colorWarning400}"
          },
          "colorBackgroundNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundPopover": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundProgressBarValueDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundProgressBarDefault": {
            "light": "{colorGreyOpaque10}",
            "dark": "{colorGreyOpaque10}"
          },
          "colorBackgroundSegmentActive": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSegmentDefault": {
            "light": "{colorBackgroundButtonNormalDefault}",
            "dark": "{colorBackgroundButtonNormalDefault}"
          },
          "colorBackgroundSegmentDisabled": {
            "light": "{colorBackgroundButtonNormalDisabled}",
            "dark": "{colorBackgroundButtonNormalDisabled}"
          },
          "colorBackgroundSegmentHover": {
            "light": "{colorBackgroundButtonNormalHover}",
            "dark": "{colorBackgroundButtonNormalHover}"
          },
          "colorBackgroundSegmentWrapper": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundSliderRangeDefault": {
            "light": "{colorBackgroundSliderHandleDefault}",
            "dark": "{colorBackgroundSliderHandleDefault}"
          },
          "colorBackgroundSliderRangeActive": {
            "light": "{colorBackgroundSliderHandleActive}",
            "dark": "{colorBackgroundSliderHandleActive}"
          },
          "colorBackgroundSliderHandleDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSliderHandleActive": {
            "light": "{colorPrimary700}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundSliderTrackDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSliderHandleRing": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundSliderHandleErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderHandleWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundStatusError": {
            "light": "{colorError50}",
            "dark": "{colorError1000}"
          },
          "colorBackgroundStatusInfo": {
            "light": "{colorInfo50}",
            "dark": "{colorInfo1000}"
          },
          "colorBackgroundDialog": {
            "light": "{colorBackgroundStatusInfo}",
            "dark": "{colorBackgroundStatusInfo}"
          },
          "colorBackgroundStatusSuccess": {
            "light": "{colorSuccess50}",
            "dark": "{colorSuccess1000}"
          },
          "colorBackgroundStatusWarning": {
            "light": "{colorWarning50}",
            "dark": "{colorWarning1000}"
          },
          "colorBackgroundTableHeader": {
            "light": "{colorBackgroundContainerHeader}",
            "dark": "{colorBackgroundContainerHeader}"
          },
          "colorBackgroundTilesDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleCheckedDisabled": {
            "light": "{colorPrimary200}",
            "dark": "{colorPrimary900}"
          },
          "colorBackgroundToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundAvatarGenAi": {
            "light": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)",
            "dark": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)"
          },
          "colorBackgroundAvatarDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextAvatar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBackgroundLoadingBarGenAi": {
            "light": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)",
            "dark": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)"
          },
          "colorBackgroundChatBubbleOutgoing": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundChatBubbleIncoming": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral950}"
          },
          "colorTextChatBubbleOutgoing": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextChatBubbleIncoming": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorBorderButtonLinkDisabled": {
            "light": "{colorBackgroundButtonLinkDisabled}",
            "dark": "{colorBackgroundButtonLinkDisabled}"
          },
          "colorBorderButtonNormalActive": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorBorderButtonNormalDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorBorderToggleButtonNormalPressed": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderButtonNormalDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextButtonNormalDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonNormalHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonIconDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonPrimaryActive": {
            "light": "{colorBackgroundButtonPrimaryActive}",
            "dark": "{colorBackgroundButtonPrimaryActive}"
          },
          "colorBorderButtonPrimaryDefault": {
            "light": "{colorBackgroundButtonPrimaryDefault}",
            "dark": "{colorBackgroundButtonPrimaryDefault}"
          },
          "colorBorderButtonPrimaryDisabled": {
            "light": "{colorBackgroundButtonPrimaryDisabled}",
            "dark": "{colorBackgroundButtonPrimaryDisabled}"
          },
          "colorBorderButtonPrimaryHover": {
            "light": "{colorBackgroundButtonPrimaryHover}",
            "dark": "{colorBackgroundButtonPrimaryHover}"
          },
          "colorTextButtonPrimaryDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorItemSelected": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderCalendarGrid": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderCalendarGridSelectedFocusRing": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral850}"
          },
          "colorBorderCellShaded": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderCodeEditorAceActiveLineLightTheme": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderCodeEditorAceActiveLineDarkTheme": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorPaneItemHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderCard": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderCardHighlighted": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemCard": {
            "light": "{colorBorderCard}",
            "dark": "{colorBorderCard}"
          },
          "colorBorderItemCardHighlighted": {
            "light": "{colorBorderCardHighlighted}",
            "dark": "{colorBorderCardHighlighted}"
          },
          "colorBorderContainerDivider": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderContainerTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderControlChecked": {
            "light": "{colorBackgroundControlChecked}",
            "dark": "{colorBackgroundControlChecked}"
          },
          "colorBorderControlDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderControlDisabled": {
            "light": "{colorBackgroundControlDisabled}",
            "dark": "{colorBackgroundControlDisabled}"
          },
          "colorBorderDividerActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDividerDefault": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorBorderDividerPanelBottom": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerPanelSide": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerSecondary": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderDropdownContainer": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownGroup": {
            "light": "{colorBorderDropdownItemDefault}",
            "dark": "{colorBorderDropdownItemDefault}"
          },
          "colorBorderDropdownItemDefault": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDropdownItemHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownItemDimmedHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderDropdownItemSelected": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderDropdownItemTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderEditableCellHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderInputDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderInputDisabled": {
            "light": "{colorBackgroundInputDisabled}",
            "dark": "{colorBackgroundInputDisabled}"
          },
          "colorBorderInputFocused": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderItemFocused": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorBorderDropdownItemFocused": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderItemPlaceholder": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemSelected": {
            "light": "{colorItemSelected}",
            "dark": "{colorItemSelected}"
          },
          "colorBorderLayout": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderPanelHeader": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderPopover": {
            "light": "{colorBorderDropdownContainer}",
            "dark": "{colorBorderDropdownContainer}"
          },
          "colorBorderSegmentActive": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderSegmentDisabled": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentHover": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderStatusError": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorBorderStatusInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo400}"
          },
          "colorBorderStatusSuccess": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorBorderStatusWarning": {
            "light": "{colorWarning900}",
            "dark": "{colorWarning500}"
          },
          "colorBorderDialog": {
            "light": "{colorBorderStatusInfo}",
            "dark": "{colorBorderStatusInfo}"
          },
          "colorBorderDividerInteractiveDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderTabsDivider": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderTabsShadow": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorBorderTabsUnderline": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorBorderTilesDisabled": {
            "light": "{colorBackgroundTilesDisabled}",
            "dark": "{colorBackgroundTilesDisabled}"
          },
          "colorBorderTutorial": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorForegroundControlDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorForegroundControlDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorForegroundControlReadOnly": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorShadowDefault": {
            "light": "{colorGreyTransparentHeavy}",
            "dark": "{colorGreyTransparentHeavy}"
          },
          "colorShadowMedium": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorShadowSide": {
            "light": "{colorGreyTransparentLight}",
            "dark": "{colorGreyTransparentLight}"
          },
          "colorStrokeChartLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorStrokeCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral800}"
          },
          "colorStrokeCodeEditorGutterActiveLineHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral950}"
          },
          "colorTextAccent": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorTextBodyDefault": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextBodySecondary": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextBreadcrumbCurrent": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral500}"
          },
          "colorTextBreadcrumbIcon": {
            "light": "{colorNeutral500}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextButtonInlineIconDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextButtonNormalActive": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextToggleButtonNormalPressed": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonNormalDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextButtonNormalHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLinkButtonNormalDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkButtonNormalHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkButtonNormalActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextButtonLinkDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonLinkHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonPrimaryActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryHover": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCalendarDateHover": {
            "light": "{colorTextDropdownItemDefault}",
            "dark": "{colorTextDropdownItemDefault}"
          },
          "colorTextCalendarMonth": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextCodeEditorGutterActiveLine": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCodeEditorGutterDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextCodeEditorStatusBarDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorTextCodeEditorTabButtonError": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextColumnHeader": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral400}"
          },
          "colorTextColumnSortingIcon": {
            "light": "{colorTextColumnHeader}",
            "dark": "{colorTextColumnHeader}"
          },
          "colorTextControlDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextCounter": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextDisabledInlineEdit": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral400}"
          },
          "colorTextDropdownFooter": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownGroupLabel": {
            "light": "{colorTextGroupLabel}",
            "dark": "{colorTextGroupLabel}"
          },
          "colorTextDropdownItemDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextDropdownItemDimmed": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemFilterMatch": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary300}"
          },
          "colorTextDropdownItemHighlighted": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral250}"
          },
          "colorTextDropdownItemSecondary": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownItemSecondaryHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral300}"
          },
          "colorTextEmpty": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionDefault": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextExpandableSectionHover": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextExpandableSectionNavigationIconDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorTextInteractiveDefault}"
          },
          "colorTextFormDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextFormLabel": {
            "light": "{colorTextFormDefault}",
            "dark": "{colorTextFormDefault}"
          },
          "colorTextFormSecondary": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextGroupLabel": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorTextLabelGenAi": {
            "light": "{colorPurple700}",
            "dark": "{colorPurple400}"
          },
          "colorTextHeadingDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHeadingSecondary": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextHomeHeaderDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHomeHeaderSecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextIconCaret": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral450}"
          },
          "colorTextIconSubtle": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral400}"
          },
          "colorTextInputDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInputPlaceholder": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextInputPlaceholderDisabled": {
            "light": "{colorTextInputDisabled}",
            "dark": "{colorTextInputDisabled}"
          },
          "colorTextInteractiveActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInteractiveHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextToggleButtonIconPressed": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveInvertedDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextInteractiveInvertedHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextInverted": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLabel": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextKeyValuePairsValue": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextLayoutToggle": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLayoutToggleActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorTextLayoutToggleHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLayoutToggleSelected": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLinkDefault": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextLinkHover": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextLinkDecorationDefault": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkDecorationHover": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkSecondaryDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkSecondaryHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInfoDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkInfoHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInvertedHover": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextLinkButtonUnderline": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextLinkButtonUnderlineHover": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextNotificationDefault": {
            "light": "{colorTextNotificationYellow}",
            "dark": "{colorTextNotificationYellow}"
          },
          "colorTextNotificationStackBar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextNotificationYellow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextPaginationPageNumberActiveDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextPaginationPageNumberDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorNeutral400}"
          },
          "colorTextSegmentActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextSegmentDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorTextSegmentHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextSmall": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusError": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorTextStatusInactive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo400}"
          },
          "colorTextStatusSuccess": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorTextStatusWarning": {
            "light": "{colorWarning900}",
            "dark": "{colorWarning500}"
          },
          "colorTextTopNavigationTitle": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextTutorialHotspotDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextTutorialHotspotHover": {
            "light": "{colorNeutral900}",
            "dark": "{colorNeutral900}"
          },
          "colorBoardPlaceholderActive": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral600}"
          },
          "colorBoardPlaceholderHover": {
            "light": "{colorPrimary100}",
            "dark": "{colorPrimary600}"
          },
          "colorDragPlaceholderActive": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral600}"
          },
          "colorDragPlaceholderHover": {
            "light": "{colorPrimary100}",
            "dark": "{colorPrimary600}"
          },
          "colorDropzoneBackgroundDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorDropzoneBackgroundHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorPrimary1000}"
          },
          "colorDropzoneTextDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneTextHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneBorderDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorDropzoneBorderHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorGapGlobalDrawer": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral950}"
          },
          "colorTreeViewConnectorLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral300}"
          },
          "colorBackgroundActionCardDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundActionCardHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundActionCardActive": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderActionCardDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderActionCardHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundActionCardDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorTextActionCardDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorIconActionCardDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorIconActionCardHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSkeleton": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundSkeletonWave": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral700}"
          }
        }
      },
      "alert": {
        "id": "alert",
        "selector": ".awsui-context-alert",
        "tokens": {
          "colorGreyOpaque10": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(0, 0, 0, 0.1)"
          },
          "colorGreyOpaque25": {
            "light": "rgba(255, 255, 255, 0.25)",
            "dark": "rgba(255, 255, 255, 0.25)"
          },
          "colorGreyOpaque40": {
            "light": "rgba(0, 0, 0, 0.4)",
            "dark": "rgba(0, 0, 0, 0.4)"
          },
          "colorGreyOpaque50": {
            "light": "rgba(0, 0, 0, 0.5)",
            "dark": "rgba(0, 0, 0, 0.5)"
          },
          "colorGreyOpaque70": {
            "light": "rgba(35, 43, 55, 0.7)",
            "dark": "rgba(15, 20, 26, 0.7)"
          },
          "colorGreyOpaque80": {
            "light": "rgba(22, 25, 31, 0.8)",
            "dark": "rgba(22, 25, 31, 0.8)"
          },
          "colorGreyOpaque90": {
            "light": "rgba(242, 243, 243, 0.9)",
            "dark": "rgba(242, 243, 243, 0.9)"
          },
          "colorGreyTransparent": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentHeavy": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentLight": {
            "light": "rgba(15, 20, 26, 0.12)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorBackgroundBadgeIcon": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorBackgroundButtonLinkActive": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonLinkDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkDisabled": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundButtonNormalActive": {
            "light": "rgba(0, 7, 22, 0.1)",
            "dark": "rgba(255, 255, 255, 0.15)"
          },
          "colorBackgroundButtonNormalDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonNormalDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundButtonNormalHover": {
            "light": "rgba(0, 7, 22, 0.05)",
            "dark": "rgba(255, 255, 255, 0.1)"
          },
          "colorBackgroundToggleButtonNormalPressed": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonPrimaryActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundButtonPrimaryDefault": {
            "light": "{colorBorderButtonNormalDefault}",
            "dark": "{colorBorderButtonNormalDefault}"
          },
          "colorBackgroundButtonPrimaryDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundButtonPrimaryHover": {
            "light": "{colorBorderButtonNormalHover}",
            "dark": "{colorBorderButtonNormalHover}"
          },
          "colorBackgroundDirectionButtonActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundDirectionButtonDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorTextDirectionButtonDefault": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextDirectionButtonDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorBackgroundCalendarCurrentDate": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCellShaded": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundCodeEditorGutterActiveLineError": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundCodeEditorGutterDefault": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorLoading": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorPaneItemHover": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCodeEditorStatusBar": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCard": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundItemCard": {
            "light": "{colorBackgroundCard}",
            "dark": "{colorBackgroundCard}"
          },
          "colorBackgroundContainerContent": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundContainerHeader": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlChecked": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundControlDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlDisabled": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundDropdownItemDimmed": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundDropdownItemFilterMatch": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemHover": {
            "light": "{colorNeutral200}",
            "dark": "{colorNeutral900}"
          },
          "colorBackgroundDropdownItemSelected": {
            "light": "{colorBackgroundItemSelected}",
            "dark": "{colorBackgroundItemSelected}"
          },
          "colorBackgroundHomeHeader": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundInlineCode": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(255, 255, 255, 0.1)"
          },
          "colorBackgroundInputDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundInputDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundItemSelected": {
            "light": "{colorPrimary50}",
            "dark": "{colorPrimary1000}"
          },
          "colorBackgroundLayoutMain": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundDrawer": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundDrawerBackdrop": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundLayoutMobilePanel": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundLayoutPanelContent": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundLayoutPanelHover": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundLayoutToolbar": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundLayoutToggleActive": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundLayoutToggleSelectedActive": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedHover": {
            "light": "{colorPrimary700}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundModalOverlay": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundNotificationBlue": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo600}"
          },
          "colorBackgroundNotificationGreen": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess600}"
          },
          "colorBackgroundNotificationGrey": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationRed": {
            "light": "{colorError600}",
            "dark": "{colorError600}"
          },
          "colorBackgroundNotificationYellow": {
            "light": "{colorWarning400}",
            "dark": "{colorWarning400}"
          },
          "colorBackgroundNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundPopover": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundProgressBarValueDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundProgressBarDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundSegmentActive": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSegmentDefault": {
            "light": "{colorBackgroundButtonNormalDefault}",
            "dark": "{colorBackgroundButtonNormalDefault}"
          },
          "colorBackgroundSegmentDisabled": {
            "light": "{colorBackgroundButtonNormalDisabled}",
            "dark": "{colorBackgroundButtonNormalDisabled}"
          },
          "colorBackgroundSegmentHover": {
            "light": "{colorBackgroundButtonNormalHover}",
            "dark": "{colorBackgroundButtonNormalHover}"
          },
          "colorBackgroundSegmentWrapper": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundSliderRangeDefault": {
            "light": "{colorBackgroundSliderHandleDefault}",
            "dark": "{colorBackgroundSliderHandleDefault}"
          },
          "colorBackgroundSliderRangeActive": {
            "light": "{colorBackgroundSliderHandleActive}",
            "dark": "{colorBackgroundSliderHandleActive}"
          },
          "colorBackgroundSliderHandleDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSliderHandleActive": {
            "light": "{colorPrimary700}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundSliderTrackDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSliderHandleRing": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundSliderHandleErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderHandleWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundStatusError": {
            "light": "{colorError50}",
            "dark": "{colorError1000}"
          },
          "colorBackgroundStatusInfo": {
            "light": "{colorInfo50}",
            "dark": "{colorInfo1000}"
          },
          "colorBackgroundDialog": {
            "light": "{colorBackgroundStatusInfo}",
            "dark": "{colorBackgroundStatusInfo}"
          },
          "colorBackgroundStatusSuccess": {
            "light": "{colorSuccess50}",
            "dark": "{colorSuccess1000}"
          },
          "colorBackgroundStatusWarning": {
            "light": "{colorWarning50}",
            "dark": "{colorWarning1000}"
          },
          "colorBackgroundTableHeader": {
            "light": "{colorBackgroundContainerHeader}",
            "dark": "{colorBackgroundContainerHeader}"
          },
          "colorBackgroundTilesDisabled": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleCheckedDisabled": {
            "light": "{colorPrimary200}",
            "dark": "{colorPrimary900}"
          },
          "colorBackgroundToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundAvatarGenAi": {
            "light": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)",
            "dark": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)"
          },
          "colorBackgroundAvatarDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextAvatar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBackgroundLoadingBarGenAi": {
            "light": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)",
            "dark": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)"
          },
          "colorBackgroundChatBubbleOutgoing": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundChatBubbleIncoming": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral950}"
          },
          "colorTextChatBubbleOutgoing": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextChatBubbleIncoming": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorBorderButtonLinkDisabled": {
            "light": "{colorBackgroundButtonLinkDisabled}",
            "dark": "{colorBackgroundButtonLinkDisabled}"
          },
          "colorBorderButtonNormalActive": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorBorderButtonNormalDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorBorderToggleButtonNormalPressed": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderButtonNormalDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextButtonNormalDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonNormalHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonIconDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonPrimaryActive": {
            "light": "{colorBackgroundButtonPrimaryActive}",
            "dark": "{colorBackgroundButtonPrimaryActive}"
          },
          "colorBorderButtonPrimaryDefault": {
            "light": "{colorBackgroundButtonPrimaryDefault}",
            "dark": "{colorBackgroundButtonPrimaryDefault}"
          },
          "colorBorderButtonPrimaryDisabled": {
            "light": "{colorBackgroundButtonPrimaryDisabled}",
            "dark": "{colorBackgroundButtonPrimaryDisabled}"
          },
          "colorBorderButtonPrimaryHover": {
            "light": "{colorBackgroundButtonPrimaryHover}",
            "dark": "{colorBackgroundButtonPrimaryHover}"
          },
          "colorTextButtonPrimaryDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorItemSelected": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderCalendarGrid": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderCalendarGridSelectedFocusRing": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral850}"
          },
          "colorBorderCellShaded": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderCodeEditorAceActiveLineLightTheme": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderCodeEditorAceActiveLineDarkTheme": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorPaneItemHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderCard": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderCardHighlighted": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemCard": {
            "light": "{colorBorderCard}",
            "dark": "{colorBorderCard}"
          },
          "colorBorderItemCardHighlighted": {
            "light": "{colorBorderCardHighlighted}",
            "dark": "{colorBorderCardHighlighted}"
          },
          "colorBorderContainerDivider": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderContainerTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderControlChecked": {
            "light": "{colorBackgroundControlChecked}",
            "dark": "{colorBackgroundControlChecked}"
          },
          "colorBorderControlDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderControlDisabled": {
            "light": "{colorBackgroundControlDisabled}",
            "dark": "{colorBackgroundControlDisabled}"
          },
          "colorBorderDividerActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDividerDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorBorderDividerPanelBottom": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerPanelSide": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerSecondary": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderDropdownContainer": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownGroup": {
            "light": "{colorBorderDropdownItemDefault}",
            "dark": "{colorBorderDropdownItemDefault}"
          },
          "colorBorderDropdownItemDefault": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDropdownItemHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownItemDimmedHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderDropdownItemSelected": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderDropdownItemTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderEditableCellHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderInputDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderInputDisabled": {
            "light": "{colorBackgroundInputDisabled}",
            "dark": "{colorBackgroundInputDisabled}"
          },
          "colorBorderInputFocused": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderItemFocused": {
            "light": "{colorPrimary600}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDropdownItemFocused": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderItemPlaceholder": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemSelected": {
            "light": "{colorItemSelected}",
            "dark": "{colorItemSelected}"
          },
          "colorBorderLayout": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderPanelHeader": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderPopover": {
            "light": "{colorBorderDropdownContainer}",
            "dark": "{colorBorderDropdownContainer}"
          },
          "colorBorderSegmentActive": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderSegmentDisabled": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentHover": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderStatusError": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorBorderStatusInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo400}"
          },
          "colorBorderStatusSuccess": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorBorderStatusWarning": {
            "light": "{colorWarning900}",
            "dark": "{colorWarning500}"
          },
          "colorBorderDialog": {
            "light": "{colorBorderStatusInfo}",
            "dark": "{colorBorderStatusInfo}"
          },
          "colorBorderDividerInteractiveDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderTabsDivider": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderTabsShadow": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorBorderTabsUnderline": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorBorderTilesDisabled": {
            "light": "{colorBackgroundTilesDisabled}",
            "dark": "{colorBackgroundTilesDisabled}"
          },
          "colorBorderTutorial": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral650}"
          },
          "colorForegroundControlDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorForegroundControlDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorForegroundControlReadOnly": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorShadowDefault": {
            "light": "{colorGreyTransparentHeavy}",
            "dark": "{colorGreyTransparentHeavy}"
          },
          "colorShadowMedium": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorShadowSide": {
            "light": "{colorGreyTransparentLight}",
            "dark": "{colorGreyTransparentLight}"
          },
          "colorStrokeChartLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorStrokeCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral800}"
          },
          "colorStrokeCodeEditorGutterActiveLineHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral950}"
          },
          "colorTextAccent": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorTextBodyDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBodySecondary": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBreadcrumbCurrent": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral500}"
          },
          "colorTextBreadcrumbIcon": {
            "light": "{colorNeutral500}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextButtonInlineIconDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextButtonNormalActive": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextToggleButtonNormalPressed": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonNormalDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorTextButtonNormalHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonNormalDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkButtonNormalHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkButtonNormalActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextButtonLinkDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonLinkHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonPrimaryActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryHover": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCalendarDateHover": {
            "light": "{colorTextDropdownItemDefault}",
            "dark": "{colorTextDropdownItemDefault}"
          },
          "colorTextCalendarMonth": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextCodeEditorGutterActiveLine": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCodeEditorGutterDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextCodeEditorStatusBarDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorTextCodeEditorTabButtonError": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextColumnHeader": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral400}"
          },
          "colorTextColumnSortingIcon": {
            "light": "{colorTextColumnHeader}",
            "dark": "{colorTextColumnHeader}"
          },
          "colorTextControlDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextCounter": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextDisabledInlineEdit": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral400}"
          },
          "colorTextDropdownFooter": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownGroupLabel": {
            "light": "{colorTextGroupLabel}",
            "dark": "{colorTextGroupLabel}"
          },
          "colorTextDropdownItemDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextDropdownItemDimmed": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemFilterMatch": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary300}"
          },
          "colorTextDropdownItemHighlighted": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral250}"
          },
          "colorTextDropdownItemSecondary": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownItemSecondaryHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral300}"
          },
          "colorTextEmpty": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextExpandableSectionHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextExpandableSectionNavigationIconDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorTextInteractiveDefault}"
          },
          "colorTextFormDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral300}"
          },
          "colorTextFormLabel": {
            "light": "{colorTextFormDefault}",
            "dark": "{colorTextFormDefault}"
          },
          "colorTextFormSecondary": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextGroupLabel": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorTextLabelGenAi": {
            "light": "{colorPurple700}",
            "dark": "{colorPurple400}"
          },
          "colorTextHeadingDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHeadingSecondary": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral450}"
          },
          "colorTextHomeHeaderDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHomeHeaderSecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextIconCaret": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral450}"
          },
          "colorTextIconSubtle": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral400}"
          },
          "colorTextInputDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInputPlaceholder": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextInputPlaceholderDisabled": {
            "light": "{colorTextInputDisabled}",
            "dark": "{colorTextInputDisabled}"
          },
          "colorTextInteractiveActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInteractiveHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextToggleButtonIconPressed": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveInvertedDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveInvertedHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInverted": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLabel": {
            "light": "{colorTextFormLabel}",
            "dark": "{colorTextFormLabel}"
          },
          "colorTextKeyValuePairsValue": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextLayoutToggle": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLayoutToggleActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorTextLayoutToggleHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLayoutToggleSelected": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLinkDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLinkHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorTextLinkDecorationDefault": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkDecorationHover": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkSecondaryDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkSecondaryHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInfoDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkInfoHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInvertedHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonUnderline": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextLinkButtonUnderlineHover": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextNotificationDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextNotificationStackBar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextNotificationYellow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextPaginationPageNumberActiveDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextPaginationPageNumberDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorNeutral400}"
          },
          "colorTextSegmentActive": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral950}"
          },
          "colorTextSegmentDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral300}"
          },
          "colorTextSegmentHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextSmall": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusError": {
            "light": "{colorError600}",
            "dark": "{colorError400}"
          },
          "colorTextStatusInactive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusInfo": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo400}"
          },
          "colorTextStatusSuccess": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess500}"
          },
          "colorTextStatusWarning": {
            "light": "{colorWarning900}",
            "dark": "{colorWarning500}"
          },
          "colorTextTopNavigationTitle": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral100}"
          },
          "colorTextTutorialHotspotDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextTutorialHotspotHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorBoardPlaceholderActive": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral600}"
          },
          "colorBoardPlaceholderHover": {
            "light": "{colorPrimary100}",
            "dark": "{colorPrimary600}"
          },
          "colorDragPlaceholderActive": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral600}"
          },
          "colorDragPlaceholderHover": {
            "light": "{colorPrimary100}",
            "dark": "{colorPrimary600}"
          },
          "colorDropzoneBackgroundDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorDropzoneBackgroundHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorPrimary1000}"
          },
          "colorDropzoneTextDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneTextHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneBorderDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral600}"
          },
          "colorDropzoneBorderHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorGapGlobalDrawer": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral950}"
          },
          "colorTreeViewConnectorLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral300}"
          },
          "colorBackgroundActionCardDefault": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundActionCardHover": {
            "light": "{colorPrimary50}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundActionCardActive": {
            "light": "{colorPrimary100}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderActionCardDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderActionCardHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundActionCardDisabled": {
            "light": "{colorWhite}",
            "dark": "{colorNeutral850}"
          },
          "colorTextActionCardDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorIconActionCardDefault": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary400}"
          },
          "colorIconActionCardHover": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardActive": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardDisabled": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSkeleton": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundSkeletonWave": {
            "light": "{colorNeutral150}",
            "dark": "{colorNeutral700}"
          },
          "fontExpandableHeadingSize": "14px",
          "borderDividerSectionWidth": "1px"
        }
      },
      "alert-header": {
        "id": "alert-header",
        "selector": ".awsui-context-content-header .awsui-context-alert",
        "tokens": {
          "colorGreyOpaque10": {
            "light": "rgba(0, 0, 0, 0.1)",
            "dark": "rgba(0, 0, 0, 0.1)"
          },
          "colorGreyOpaque25": {
            "light": "rgba(255, 255, 255, 0.25)",
            "dark": "rgba(255, 255, 255, 0.25)"
          },
          "colorGreyOpaque40": {
            "light": "rgba(0, 0, 0, 0.4)",
            "dark": "rgba(0, 0, 0, 0.4)"
          },
          "colorGreyOpaque50": {
            "light": "rgba(0, 0, 0, 0.5)",
            "dark": "rgba(0, 0, 0, 0.5)"
          },
          "colorGreyOpaque70": {
            "light": "rgba(15, 20, 26, 0.7)",
            "dark": "rgba(15, 20, 26, 0.7)"
          },
          "colorGreyOpaque80": {
            "light": "rgba(22, 25, 31, 0.8)",
            "dark": "rgba(22, 25, 31, 0.8)"
          },
          "colorGreyOpaque90": {
            "light": "rgba(242, 243, 243, 0.9)",
            "dark": "rgba(242, 243, 243, 0.9)"
          },
          "colorGreyTransparent": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentHeavy": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorGreyTransparentLight": {
            "light": "rgba(15, 20, 26, 1)",
            "dark": "rgba(15, 20, 26, 1)"
          },
          "colorBackgroundBadgeIcon": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorBackgroundButtonLinkActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonLinkDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkDisabled": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonLinkHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundButtonNormalActive": {
            "light": "rgba(255, 255, 255, 0.15)",
            "dark": "rgba(255, 255, 255, 0.15)"
          },
          "colorBackgroundButtonNormalDefault": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundButtonNormalDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundButtonNormalHover": {
            "light": "rgba(255, 255, 255, 0.1)",
            "dark": "rgba(255, 255, 255, 0.1)"
          },
          "colorBackgroundToggleButtonNormalPressed": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundButtonPrimaryActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundButtonPrimaryDefault": {
            "light": "{colorBorderButtonNormalDefault}",
            "dark": "{colorBorderButtonNormalDefault}"
          },
          "colorBackgroundButtonPrimaryDisabled": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundButtonPrimaryHover": {
            "light": "{colorBorderButtonNormalHover}",
            "dark": "{colorBorderButtonNormalHover}"
          },
          "colorBackgroundDirectionButtonActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundDirectionButtonDisabled": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundDirectionButtonHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorTextDirectionButtonDefault": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextDirectionButtonDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorBackgroundCalendarCurrentDate": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCellShaded": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundCodeEditorGutterActiveLineError": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundCodeEditorGutterDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorLoading": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCodeEditorPaneItemHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundCodeEditorStatusBar": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundCard": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundItemCard": {
            "light": "{colorBackgroundCard}",
            "dark": "{colorBackgroundCard}"
          },
          "colorBackgroundContainerContent": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundContainerHeader": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlChecked": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundControlDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundControlDisabled": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundDropdownItemDimmed": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundDropdownItemFilterMatch": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundDropdownItemHover": {
            "light": "{colorNeutral900}",
            "dark": "{colorNeutral900}"
          },
          "colorBackgroundDropdownItemSelected": {
            "light": "{colorBackgroundItemSelected}",
            "dark": "{colorBackgroundItemSelected}"
          },
          "colorBackgroundHomeHeader": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundInlineCode": {
            "light": "rgba(255, 255, 255, 0.1)",
            "dark": "rgba(255, 255, 255, 0.1)"
          },
          "colorBackgroundInputDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundInputDisabled": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundItemSelected": {
            "light": "{colorPrimary1000}",
            "dark": "{colorPrimary1000}"
          },
          "colorBackgroundLayoutMain": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundDrawer": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundDrawerBackdrop": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundLayoutMobilePanel": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorBackgroundLayoutPanelContent": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundLayoutPanelHover": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundLayoutToolbar": {
            "light": "{colorBackgroundLayoutPanelContent}",
            "dark": "{colorBackgroundLayoutPanelContent}"
          },
          "colorBackgroundLayoutToggleActive": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundLayoutToggleHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundLayoutToggleSelectedActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundLayoutToggleSelectedHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundModalOverlay": {
            "light": "{colorGreyOpaque70}",
            "dark": "{colorGreyOpaque70}"
          },
          "colorBackgroundNotificationBlue": {
            "light": "{colorInfo600}",
            "dark": "{colorInfo600}"
          },
          "colorBackgroundNotificationGreen": {
            "light": "{colorSuccess600}",
            "dark": "{colorSuccess600}"
          },
          "colorBackgroundNotificationGrey": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundNotificationRed": {
            "light": "{colorError600}",
            "dark": "{colorError600}"
          },
          "colorBackgroundNotificationYellow": {
            "light": "{colorWarning400}",
            "dark": "{colorWarning400}"
          },
          "colorBackgroundNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarActive": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundNotificationStackBarHover": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBackgroundPopover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundProgressBarValueDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundProgressBarDefault": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBackgroundSegmentActive": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSegmentDefault": {
            "light": "{colorBackgroundButtonNormalDefault}",
            "dark": "{colorBackgroundButtonNormalDefault}"
          },
          "colorBackgroundSegmentDisabled": {
            "light": "{colorBackgroundButtonNormalDisabled}",
            "dark": "{colorBackgroundButtonNormalDisabled}"
          },
          "colorBackgroundSegmentHover": {
            "light": "{colorBackgroundButtonNormalHover}",
            "dark": "{colorBackgroundButtonNormalHover}"
          },
          "colorBackgroundSegmentWrapper": {
            "light": "{colorBackgroundContainerContent}",
            "dark": "{colorBackgroundContainerContent}"
          },
          "colorBackgroundSliderRangeDefault": {
            "light": "{colorBackgroundSliderHandleDefault}",
            "dark": "{colorBackgroundSliderHandleDefault}"
          },
          "colorBackgroundSliderRangeActive": {
            "light": "{colorBackgroundSliderHandleActive}",
            "dark": "{colorBackgroundSliderHandleActive}"
          },
          "colorBackgroundSliderHandleDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBackgroundSliderHandleActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBackgroundSliderTrackDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSliderHandleRing": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundSliderHandleErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderHandleWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderHandleWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeErrorDefault": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeErrorActive": {
            "light": "{colorTextStatusError}",
            "dark": "{colorTextStatusError}"
          },
          "colorBackgroundSliderRangeWarningDefault": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundSliderRangeWarningActive": {
            "light": "{colorTextStatusWarning}",
            "dark": "{colorTextStatusWarning}"
          },
          "colorBackgroundStatusError": {
            "light": "{colorError1000}",
            "dark": "{colorError1000}"
          },
          "colorBackgroundStatusInfo": {
            "light": "{colorInfo1000}",
            "dark": "{colorInfo1000}"
          },
          "colorBackgroundDialog": {
            "light": "{colorBackgroundStatusInfo}",
            "dark": "{colorBackgroundStatusInfo}"
          },
          "colorBackgroundStatusSuccess": {
            "light": "{colorSuccess1000}",
            "dark": "{colorSuccess1000}"
          },
          "colorBackgroundStatusWarning": {
            "light": "{colorWarning1000}",
            "dark": "{colorWarning1000}"
          },
          "colorBackgroundTableHeader": {
            "light": "{colorBackgroundContainerHeader}",
            "dark": "{colorBackgroundContainerHeader}"
          },
          "colorBackgroundTilesDisabled": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundToggleCheckedDisabled": {
            "light": "{colorPrimary900}",
            "dark": "{colorPrimary900}"
          },
          "colorBackgroundToggleDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBackgroundAvatarGenAi": {
            "light": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)",
            "dark": "radial-gradient(circle farthest-corner at top right, #b8e7ff 0%, #0099ff 25%, #5c7fff 40% , #8575ff 60%, #962eff 80%)"
          },
          "colorBackgroundAvatarDefault": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorTextAvatar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorBackgroundLoadingBarGenAi": {
            "light": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)",
            "dark": "linear-gradient(90deg, #b8e7ff 0%, #0099ff 10%, #5c7fff 24%, #8575ff 50%, #962eff 76%, #0099ff 90%, #b8e7ff 100%)"
          },
          "colorBackgroundChatBubbleOutgoing": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBackgroundChatBubbleIncoming": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextChatBubbleOutgoing": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextChatBubbleIncoming": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorBorderButtonLinkDisabled": {
            "light": "{colorBackgroundButtonLinkDisabled}",
            "dark": "{colorBackgroundButtonLinkDisabled}"
          },
          "colorBorderButtonNormalActive": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorBorderButtonNormalDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorBorderToggleButtonNormalPressed": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderButtonNormalDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextButtonNormalDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonNormalHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonIconDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderButtonPrimaryActive": {
            "light": "{colorBackgroundButtonPrimaryActive}",
            "dark": "{colorBackgroundButtonPrimaryActive}"
          },
          "colorBorderButtonPrimaryDefault": {
            "light": "{colorBackgroundButtonPrimaryDefault}",
            "dark": "{colorBackgroundButtonPrimaryDefault}"
          },
          "colorBorderButtonPrimaryDisabled": {
            "light": "{colorBackgroundButtonPrimaryDisabled}",
            "dark": "{colorBackgroundButtonPrimaryDisabled}"
          },
          "colorBorderButtonPrimaryHover": {
            "light": "{colorBackgroundButtonPrimaryHover}",
            "dark": "{colorBackgroundButtonPrimaryHover}"
          },
          "colorTextButtonPrimaryDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorItemSelected": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderCalendarGrid": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderCalendarGridSelectedFocusRing": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBorderCellShaded": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderCodeEditorAceActiveLineLightTheme": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderCodeEditorAceActiveLineDarkTheme": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderCodeEditorPaneItemHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderCard": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderCardHighlighted": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemCard": {
            "light": "{colorBorderCard}",
            "dark": "{colorBorderCard}"
          },
          "colorBorderItemCardHighlighted": {
            "light": "{colorBorderCardHighlighted}",
            "dark": "{colorBorderCardHighlighted}"
          },
          "colorBorderContainerDivider": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderContainerTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderControlChecked": {
            "light": "{colorBackgroundControlChecked}",
            "dark": "{colorBackgroundControlChecked}"
          },
          "colorBorderControlDefault": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderControlDisabled": {
            "light": "{colorBackgroundControlDisabled}",
            "dark": "{colorBackgroundControlDisabled}"
          },
          "colorBorderDividerActive": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDividerDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorBorderDividerPanelBottom": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerPanelSide": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDividerSecondary": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderDropdownContainer": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownGroup": {
            "light": "{colorBorderDropdownItemDefault}",
            "dark": "{colorBorderDropdownItemDefault}"
          },
          "colorBorderDropdownItemDefault": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderDropdownItemHover": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderDropdownItemDimmedHover": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorBorderDropdownItemSelected": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderDropdownItemTop": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorBorderEditableCellHover": {
            "light": "{colorBorderDropdownItemHover}",
            "dark": "{colorBorderDropdownItemHover}"
          },
          "colorBorderInputDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBorderInputDisabled": {
            "light": "{colorBackgroundInputDisabled}",
            "dark": "{colorBackgroundInputDisabled}"
          },
          "colorBorderInputFocused": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderItemFocused": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorBorderDropdownItemFocused": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderItemPlaceholder": {
            "light": "{colorBorderItemSelected}",
            "dark": "{colorBorderItemSelected}"
          },
          "colorBorderItemSelected": {
            "light": "{colorItemSelected}",
            "dark": "{colorItemSelected}"
          },
          "colorBorderLayout": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderNotificationStackBar": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBorderPanelHeader": {
            "light": "{colorBorderDividerDefault}",
            "dark": "{colorBorderDividerDefault}"
          },
          "colorBorderPopover": {
            "light": "{colorBorderDropdownContainer}",
            "dark": "{colorBorderDropdownContainer}"
          },
          "colorBorderSegmentActive": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderSegmentDisabled": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderSegmentHover": {
            "light": "{colorBorderSegmentDefault}",
            "dark": "{colorBorderSegmentDefault}"
          },
          "colorBorderStatusError": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorBorderStatusInfo": {
            "light": "{colorInfo400}",
            "dark": "{colorInfo400}"
          },
          "colorBorderStatusSuccess": {
            "light": "{colorSuccess500}",
            "dark": "{colorSuccess500}"
          },
          "colorBorderStatusWarning": {
            "light": "{colorWarning500}",
            "dark": "{colorWarning500}"
          },
          "colorBorderDialog": {
            "light": "{colorBorderStatusInfo}",
            "dark": "{colorBorderStatusInfo}"
          },
          "colorBorderDividerInteractiveDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBorderTabsDivider": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorBorderTabsShadow": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorBorderTabsUnderline": {
            "light": "{colorTextAccent}",
            "dark": "{colorTextAccent}"
          },
          "colorBorderTilesDisabled": {
            "light": "{colorBackgroundTilesDisabled}",
            "dark": "{colorBackgroundTilesDisabled}"
          },
          "colorBorderTutorial": {
            "light": "{colorNeutral650}",
            "dark": "{colorNeutral650}"
          },
          "colorForegroundControlDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorForegroundControlDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorForegroundControlReadOnly": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorShadowDefault": {
            "light": "{colorGreyTransparentHeavy}",
            "dark": "{colorGreyTransparentHeavy}"
          },
          "colorShadowMedium": {
            "light": "{colorGreyTransparent}",
            "dark": "{colorGreyTransparent}"
          },
          "colorShadowSide": {
            "light": "{colorGreyTransparentLight}",
            "dark": "{colorGreyTransparentLight}"
          },
          "colorStrokeChartLine": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorStrokeCodeEditorGutterActiveLineDefault": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorStrokeCodeEditorGutterActiveLineHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextAccent": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextBodyDefault": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBodySecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextBreadcrumbCurrent": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorTextBreadcrumbIcon": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextButtonInlineIconDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonInlineIconHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextButtonNormalActive": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextToggleButtonNormalPressed": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextButtonNormalDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextButtonNormalHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonNormalDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkButtonNormalHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkButtonNormalActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkActive": {
            "light": "{colorTextButtonNormalActive}",
            "dark": "{colorTextButtonNormalActive}"
          },
          "colorTextButtonLinkDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextButtonLinkDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextButtonLinkHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextButtonPrimaryActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryDefault": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextButtonPrimaryHover": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCalendarDateHover": {
            "light": "{colorTextDropdownItemDefault}",
            "dark": "{colorTextDropdownItemDefault}"
          },
          "colorTextCalendarMonth": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextCodeEditorGutterActiveLine": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextCodeEditorGutterDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextCodeEditorStatusBarDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextCodeEditorTabButtonError": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextColumnHeader": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextColumnSortingIcon": {
            "light": "{colorTextColumnHeader}",
            "dark": "{colorTextColumnHeader}"
          },
          "colorTextControlDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextCounter": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextDisabledInlineEdit": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextDropdownFooter": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownGroupLabel": {
            "light": "{colorTextGroupLabel}",
            "dark": "{colorTextGroupLabel}"
          },
          "colorTextDropdownItemDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextDropdownItemDimmed": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextDropdownItemFilterMatch": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextDropdownItemHighlighted": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextDropdownItemSecondary": {
            "light": "{colorTextFormSecondary}",
            "dark": "{colorTextFormSecondary}"
          },
          "colorTextDropdownItemSecondaryHover": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextEmpty": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextExpandableSectionDefault": {
            "light": "{colorTextButtonNormalDefault}",
            "dark": "{colorTextButtonNormalDefault}"
          },
          "colorTextExpandableSectionHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextExpandableSectionNavigationIconDefault": {
            "light": "{colorTextInteractiveDefault}",
            "dark": "{colorTextInteractiveDefault}"
          },
          "colorTextFormDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextFormLabel": {
            "light": "{colorTextFormDefault}",
            "dark": "{colorTextFormDefault}"
          },
          "colorTextFormSecondary": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextGroupLabel": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextLabelGenAi": {
            "light": "{colorPurple400}",
            "dark": "{colorPurple400}"
          },
          "colorTextHeadingDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHeadingSecondary": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextHomeHeaderDefault": {
            "light": "{colorNeutral250}",
            "dark": "{colorNeutral250}"
          },
          "colorTextHomeHeaderSecondary": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorTextIconCaret": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextIconSubtle": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextInputDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInputPlaceholder": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextInputPlaceholderDisabled": {
            "light": "{colorTextInputDisabled}",
            "dark": "{colorTextInputDisabled}"
          },
          "colorTextInteractiveActive": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorTextInteractiveHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextToggleButtonIconPressed": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInteractiveInvertedDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextInteractiveInvertedHover": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextInverted": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLabel": {
            "light": "{colorTextFormLabel}",
            "dark": "{colorTextFormLabel}"
          },
          "colorTextKeyValuePairsValue": {
            "light": "{colorTextBodyDefault}",
            "dark": "{colorTextBodyDefault}"
          },
          "colorTextLayoutToggle": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLayoutToggleActive": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorTextLayoutToggleHover": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLayoutToggleSelected": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextLinkDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorTextLinkHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorTextLinkDecorationDefault": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkDecorationHover": {
            "light": "currentColor",
            "dark": "currentColor"
          },
          "colorTextLinkSecondaryDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkSecondaryHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInfoDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextLinkInfoHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorTextLinkInvertedHover": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextLinkButtonUnderline": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextLinkButtonUnderlineHover": {
            "light": "transparent",
            "dark": "transparent"
          },
          "colorTextNotificationDefault": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextNotificationStackBar": {
            "light": "{colorWhite}",
            "dark": "{colorWhite}"
          },
          "colorTextNotificationYellow": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextPaginationPageNumberActiveDisabled": {
            "light": "{colorTextInteractiveDisabled}",
            "dark": "{colorTextInteractiveDisabled}"
          },
          "colorTextPaginationPageNumberDefault": {
            "light": "{colorNeutral400}",
            "dark": "{colorNeutral400}"
          },
          "colorTextSegmentActive": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTextSegmentDefault": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorTextSegmentHover": {
            "light": "{colorTextButtonNormalHover}",
            "dark": "{colorTextButtonNormalHover}"
          },
          "colorTextSmall": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusError": {
            "light": "{colorError400}",
            "dark": "{colorError400}"
          },
          "colorTextStatusInactive": {
            "light": "{colorNeutral450}",
            "dark": "{colorNeutral450}"
          },
          "colorTextStatusInfo": {
            "light": "{colorInfo400}",
            "dark": "{colorInfo400}"
          },
          "colorTextStatusSuccess": {
            "light": "{colorSuccess500}",
            "dark": "{colorSuccess500}"
          },
          "colorTextStatusWarning": {
            "light": "{colorWarning500}",
            "dark": "{colorWarning500}"
          },
          "colorTextTopNavigationTitle": {
            "light": "{colorNeutral100}",
            "dark": "{colorNeutral100}"
          },
          "colorTextTutorialHotspotDefault": {
            "light": "{colorTextLinkDefault}",
            "dark": "{colorTextLinkDefault}"
          },
          "colorTextTutorialHotspotHover": {
            "light": "{colorTextLinkHover}",
            "dark": "{colorTextLinkHover}"
          },
          "colorBoardPlaceholderActive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBoardPlaceholderHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary600}"
          },
          "colorDragPlaceholderActive": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorDragPlaceholderHover": {
            "light": "{colorPrimary600}",
            "dark": "{colorPrimary600}"
          },
          "colorDropzoneBackgroundDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorDropzoneBackgroundHover": {
            "light": "{colorPrimary1000}",
            "dark": "{colorPrimary1000}"
          },
          "colorDropzoneTextDefault": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneTextHover": {
            "light": "{colorNeutral350}",
            "dark": "{colorNeutral350}"
          },
          "colorDropzoneBorderDefault": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorDropzoneBorderHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorGapGlobalDrawer": {
            "light": "{colorNeutral950}",
            "dark": "{colorNeutral950}"
          },
          "colorTreeViewConnectorLine": {
            "light": "{colorNeutral300}",
            "dark": "{colorNeutral300}"
          },
          "colorBackgroundActionCardDefault": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorBackgroundActionCardHover": {
            "light": "{colorNeutral800}",
            "dark": "{colorNeutral800}"
          },
          "colorBackgroundActionCardActive": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          },
          "colorBorderActionCardDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorBorderActionCardHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorBorderActionCardDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundActionCardDisabled": {
            "light": "{colorNeutral850}",
            "dark": "{colorNeutral850}"
          },
          "colorTextActionCardDisabled": {
            "light": "{colorNeutral500}",
            "dark": "{colorNeutral500}"
          },
          "colorIconActionCardDefault": {
            "light": "{colorPrimary400}",
            "dark": "{colorPrimary400}"
          },
          "colorIconActionCardHover": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardActive": {
            "light": "{colorPrimary300}",
            "dark": "{colorPrimary300}"
          },
          "colorIconActionCardDisabled": {
            "light": "{colorNeutral600}",
            "dark": "{colorNeutral600}"
          },
          "colorBackgroundSkeleton": {
            "light": "{colorNeutral750}",
            "dark": "{colorNeutral750}"
          },
          "colorBackgroundSkeletonWave": {
            "light": "{colorNeutral700}",
            "dark": "{colorNeutral700}"
          }
        }
      },
      "app-layout-toolbar": {
        "id": "app-layout-toolbar",
        "selector": ".awsui-context-app-layout-toolbar",
        "tokens": {
          "colorBackgroundLayoutMain": {
            "light": "{colorNeutral50}",
            "dark": "{colorNeutral900}"
          }
        }
      }
    },
    "tokenModeMap": {
      "colorPrimary50": "color",
      "colorPrimary100": "color",
      "colorPrimary200": "color",
      "colorPrimary300": "color",
      "colorPrimary400": "color",
      "colorPrimary500": "color",
      "colorPrimary600": "color",
      "colorPrimary700": "color",
      "colorPrimary800": "color",
      "colorPrimary900": "color",
      "colorPrimary1000": "color",
      "colorNeutral50": "color",
      "colorNeutral100": "color",
      "colorNeutral150": "color",
      "colorNeutral200": "color",
      "colorNeutral250": "color",
      "colorNeutral300": "color",
      "colorNeutral350": "color",
      "colorNeutral400": "color",
      "colorNeutral450": "color",
      "colorNeutral500": "color",
      "colorNeutral550": "color",
      "colorNeutral600": "color",
      "colorNeutral650": "color",
      "colorNeutral700": "color",
      "colorNeutral750": "color",
      "colorNeutral800": "color",
      "colorNeutral850": "color",
      "colorNeutral900": "color",
      "colorNeutral950": "color",
      "colorNeutral1000": "color",
      "colorError50": "color",
      "colorError400": "color",
      "colorError600": "color",
      "colorError900": "color",
      "colorError1000": "color",
      "colorSuccess50": "color",
      "colorSuccess500": "color",
      "colorSuccess600": "color",
      "colorSuccess1000": "color",
      "colorWarning50": "color",
      "colorWarning400": "color",
      "colorWarning500": "color",
      "colorWarning900": "color",
      "colorWarning1000": "color",
      "colorInfo50": "color",
      "colorInfo300": "color",
      "colorInfo400": "color",
      "colorInfo600": "color",
      "colorInfo1000": "color",
      "colorGrey50": "color",
      "colorGrey100": "color",
      "colorGrey150": "color",
      "colorGrey200": "color",
      "colorGrey250": "color",
      "colorGrey300": "color",
      "colorGrey350": "color",
      "colorGrey400": "color",
      "colorGrey450": "color",
      "colorGrey500": "color",
      "colorGrey600": "color",
      "colorGrey650": "color",
      "colorGrey700": "color",
      "colorGrey750": "color",
      "colorGrey800": "color",
      "colorGrey850": "color",
      "colorGrey900": "color",
      "colorGrey950": "color",
      "colorGrey1000": "color",
      "colorBlue50": "color",
      "colorBlue100": "color",
      "colorBlue200": "color",
      "colorBlue300": "color",
      "colorBlue400": "color",
      "colorBlue600": "color",
      "colorBlue700": "color",
      "colorBlue900": "color",
      "colorBlue1000": "color",
      "colorGreen50": "color",
      "colorGreen500": "color",
      "colorGreen600": "color",
      "colorGreen900": "color",
      "colorGreen1000": "color",
      "colorRed50": "color",
      "colorRed400": "color",
      "colorRed600": "color",
      "colorRed900": "color",
      "colorRed1000": "color",
      "colorYellow50": "color",
      "colorYellow400": "color",
      "colorYellow500": "color",
      "colorYellow900": "color",
      "colorYellow1000": "color",
      "colorPurple400": "color",
      "colorPurple700": "color",
      "colorAmber400": "color",
      "colorAmber500": "color",
      "colorAwsSquidInk": "color",
      "colorTransparent": "color",
      "colorBlack": "color",
      "colorWhite": "color",
      "colorChartsRed300": "color",
      "colorChartsRed400": "color",
      "colorChartsRed500": "color",
      "colorChartsRed600": "color",
      "colorChartsRed700": "color",
      "colorChartsRed800": "color",
      "colorChartsRed900": "color",
      "colorChartsRed1000": "color",
      "colorChartsRed1100": "color",
      "colorChartsRed1200": "color",
      "colorChartsOrange300": "color",
      "colorChartsOrange400": "color",
      "colorChartsOrange500": "color",
      "colorChartsOrange600": "color",
      "colorChartsOrange700": "color",
      "colorChartsOrange800": "color",
      "colorChartsOrange900": "color",
      "colorChartsOrange1000": "color",
      "colorChartsOrange1100": "color",
      "colorChartsOrange1200": "color",
      "colorChartsYellow300": "color",
      "colorChartsYellow400": "color",
      "colorChartsYellow500": "color",
      "colorChartsYellow600": "color",
      "colorChartsYellow700": "color",
      "colorChartsYellow800": "color",
      "colorChartsYellow900": "color",
      "colorChartsYellow1000": "color",
      "colorChartsYellow1100": "color",
      "colorChartsYellow1200": "color",
      "colorChartsGreen300": "color",
      "colorChartsGreen400": "color",
      "colorChartsGreen500": "color",
      "colorChartsGreen600": "color",
      "colorChartsGreen700": "color",
      "colorChartsGreen800": "color",
      "colorChartsGreen900": "color",
      "colorChartsGreen1000": "color",
      "colorChartsGreen1100": "color",
      "colorChartsGreen1200": "color",
      "colorChartsTeal300": "color",
      "colorChartsTeal400": "color",
      "colorChartsTeal500": "color",
      "colorChartsTeal600": "color",
      "colorChartsTeal700": "color",
      "colorChartsTeal800": "color",
      "colorChartsTeal900": "color",
      "colorChartsTeal1000": "color",
      "colorChartsTeal1100": "color",
      "colorChartsTeal1200": "color",
      "colorChartsBlue1300": "color",
      "colorChartsBlue1400": "color",
      "colorChartsBlue1500": "color",
      "colorChartsBlue1600": "color",
      "colorChartsBlue1700": "color",
      "colorChartsBlue1800": "color",
      "colorChartsBlue1900": "color",
      "colorChartsBlue11000": "color",
      "colorChartsBlue11100": "color",
      "colorChartsBlue11200": "color",
      "colorChartsBlue2300": "color",
      "colorChartsBlue2400": "color",
      "colorChartsBlue2500": "color",
      "colorChartsBlue2600": "color",
      "colorChartsBlue2700": "color",
      "colorChartsBlue2800": "color",
      "colorChartsBlue2900": "color",
      "colorChartsBlue21000": "color",
      "colorChartsBlue21100": "color",
      "colorChartsBlue21200": "color",
      "colorChartsPurple300": "color",
      "colorChartsPurple400": "color",
      "colorChartsPurple500": "color",
      "colorChartsPurple600": "color",
      "colorChartsPurple700": "color",
      "colorChartsPurple800": "color",
      "colorChartsPurple900": "color",
      "colorChartsPurple1000": "color",
      "colorChartsPurple1100": "color",
      "colorChartsPurple1200": "color",
      "colorChartsPink300": "color",
      "colorChartsPink400": "color",
      "colorChartsPink500": "color",
      "colorChartsPink600": "color",
      "colorChartsPink700": "color",
      "colorChartsPink800": "color",
      "colorChartsPink900": "color",
      "colorChartsPink1000": "color",
      "colorChartsPink1100": "color",
      "colorChartsPink1200": "color",
      "colorChartsStatusCritical": "color",
      "colorChartsStatusHigh": "color",
      "colorChartsStatusMedium": "color",
      "colorChartsStatusLow": "color",
      "colorChartsStatusPositive": "color",
      "colorChartsStatusInfo": "color",
      "colorChartsStatusNeutral": "color",
      "colorChartsThresholdNegative": "color",
      "colorChartsThresholdPositive": "color",
      "colorChartsThresholdInfo": "color",
      "colorChartsThresholdNeutral": "color",
      "colorChartsLineGrid": "color",
      "colorChartsLineTick": "color",
      "colorChartsLineAxis": "color",
      "colorChartsPaletteCategorical1": "color",
      "colorChartsPaletteCategorical2": "color",
      "colorChartsPaletteCategorical3": "color",
      "colorChartsPaletteCategorical4": "color",
      "colorChartsPaletteCategorical5": "color",
      "colorChartsPaletteCategorical6": "color",
      "colorChartsPaletteCategorical7": "color",
      "colorChartsPaletteCategorical8": "color",
      "colorChartsPaletteCategorical9": "color",
      "colorChartsPaletteCategorical10": "color",
      "colorChartsPaletteCategorical11": "color",
      "colorChartsPaletteCategorical12": "color",
      "colorChartsPaletteCategorical13": "color",
      "colorChartsPaletteCategorical14": "color",
      "colorChartsPaletteCategorical15": "color",
      "colorChartsPaletteCategorical16": "color",
      "colorChartsPaletteCategorical17": "color",
      "colorChartsPaletteCategorical18": "color",
      "colorChartsPaletteCategorical19": "color",
      "colorChartsPaletteCategorical20": "color",
      "colorChartsPaletteCategorical21": "color",
      "colorChartsPaletteCategorical22": "color",
      "colorChartsPaletteCategorical23": "color",
      "colorChartsPaletteCategorical24": "color",
      "colorChartsPaletteCategorical25": "color",
      "colorChartsPaletteCategorical26": "color",
      "colorChartsPaletteCategorical27": "color",
      "colorChartsPaletteCategorical28": "color",
      "colorChartsPaletteCategorical29": "color",
      "colorChartsPaletteCategorical30": "color",
      "colorChartsPaletteCategorical31": "color",
      "colorChartsPaletteCategorical32": "color",
      "colorChartsPaletteCategorical33": "color",
      "colorChartsPaletteCategorical34": "color",
      "colorChartsPaletteCategorical35": "color",
      "colorChartsPaletteCategorical36": "color",
      "colorChartsPaletteCategorical37": "color",
      "colorChartsPaletteCategorical38": "color",
      "colorChartsPaletteCategorical39": "color",
      "colorChartsPaletteCategorical40": "color",
      "colorChartsPaletteCategorical41": "color",
      "colorChartsPaletteCategorical42": "color",
      "colorChartsPaletteCategorical43": "color",
      "colorChartsPaletteCategorical44": "color",
      "colorChartsPaletteCategorical45": "color",
      "colorChartsPaletteCategorical46": "color",
      "colorChartsPaletteCategorical47": "color",
      "colorChartsPaletteCategorical48": "color",
      "colorChartsPaletteCategorical49": "color",
      "colorChartsPaletteCategorical50": "color",
      "colorChartsErrorBarMarker": "color",
      "colorSeverityDarkRed": "color",
      "colorSeverityRed": "color",
      "colorSeverityOrange": "color",
      "colorSeverityYellow": "color",
      "colorSeverityGrey": "color",
      "colorBackgroundNotificationSeverityCritical": "color",
      "colorBackgroundNotificationSeverityHigh": "color",
      "colorBackgroundNotificationSeverityMedium": "color",
      "colorBackgroundNotificationSeverityLow": "color",
      "colorBackgroundNotificationSeverityNeutral": "color",
      "colorTextNotificationSeverityCritical": "color",
      "colorTextNotificationSeverityHigh": "color",
      "colorTextNotificationSeverityMedium": "color",
      "colorTextNotificationSeverityLow": "color",
      "colorTextNotificationSeverityNeutral": "color",
      "colorGreyOpaque10": "color",
      "colorGreyOpaque25": "color",
      "colorGreyOpaque40": "color",
      "colorGreyOpaque50": "color",
      "colorGreyOpaque70": "color",
      "colorGreyOpaque80": "color",
      "colorGreyOpaque90": "color",
      "colorGreyTransparent": "color",
      "colorGreyTransparentHeavy": "color",
      "colorGreyTransparentLight": "color",
      "colorBackgroundBadgeIcon": "color",
      "colorBackgroundButtonLinkActive": "color",
      "colorBackgroundButtonLinkDefault": "color",
      "colorBackgroundButtonLinkDisabled": "color",
      "colorBackgroundButtonLinkHover": "color",
      "colorBackgroundButtonNormalActive": "color",
      "colorBackgroundButtonNormalDefault": "color",
      "colorBackgroundButtonNormalDisabled": "color",
      "colorBackgroundButtonNormalHover": "color",
      "colorBackgroundToggleButtonNormalPressed": "color",
      "colorBackgroundButtonPrimaryActive": "color",
      "colorBackgroundButtonPrimaryDefault": "color",
      "colorBackgroundButtonPrimaryDisabled": "color",
      "colorBackgroundButtonPrimaryHover": "color",
      "colorBackgroundDirectionButtonActive": "color",
      "colorBackgroundDirectionButtonDefault": "color",
      "colorBackgroundDirectionButtonDisabled": "color",
      "colorBackgroundDirectionButtonHover": "color",
      "colorTextDirectionButtonDefault": "color",
      "colorTextDirectionButtonDisabled": "color",
      "colorBackgroundCalendarCurrentDate": "color",
      "colorBackgroundCellShaded": "color",
      "colorBackgroundCodeEditorGutterActiveLineDefault": "color",
      "colorBackgroundCodeEditorGutterActiveLineError": "color",
      "colorBackgroundCodeEditorGutterDefault": "color",
      "colorBackgroundCodeEditorLoading": "color",
      "colorBackgroundCodeEditorPaneItemHover": "color",
      "colorBackgroundCodeEditorStatusBar": "color",
      "colorBackgroundCard": "color",
      "colorBackgroundItemCard": "color",
      "colorBackgroundContainerContent": "color",
      "colorBackgroundContainerHeader": "color",
      "colorBackgroundControlChecked": "color",
      "colorBackgroundControlDefault": "color",
      "colorBackgroundControlDisabled": "color",
      "colorBackgroundDropdownItemDefault": "color",
      "colorBackgroundDropdownItemDimmed": "color",
      "colorBackgroundDropdownItemFilterMatch": "color",
      "colorBackgroundDropdownItemHover": "color",
      "colorBackgroundDropdownItemSelected": "color",
      "colorBackgroundHomeHeader": "color",
      "colorBackgroundInlineCode": "color",
      "colorBackgroundInputDefault": "color",
      "colorBackgroundInputDisabled": "color",
      "colorBackgroundItemSelected": "color",
      "colorBackgroundLayoutMain": "color",
      "colorBackgroundDrawer": "color",
      "colorBackgroundDrawerBackdrop": "color",
      "colorBackgroundLayoutMobilePanel": "color",
      "colorBackgroundLayoutPanelContent": "color",
      "colorBackgroundLayoutPanelHover": "color",
      "colorBackgroundLayoutToolbar": "color",
      "colorBackgroundLayoutToggleActive": "color",
      "colorBackgroundLayoutToggleDefault": "color",
      "colorBackgroundLayoutToggleHover": "color",
      "colorBackgroundLayoutToggleSelectedActive": "color",
      "colorBackgroundLayoutToggleSelectedDefault": "color",
      "colorBackgroundLayoutToggleSelectedHover": "color",
      "colorBackgroundModalOverlay": "color",
      "colorBackgroundNotificationBlue": "color",
      "colorBackgroundNotificationGreen": "color",
      "colorBackgroundNotificationGrey": "color",
      "colorBackgroundNotificationRed": "color",
      "colorBackgroundNotificationYellow": "color",
      "colorBackgroundNotificationStackBar": "color",
      "colorBackgroundNotificationStackBarActive": "color",
      "colorBackgroundNotificationStackBarHover": "color",
      "colorBackgroundPopover": "color",
      "colorBackgroundProgressBarValueDefault": "color",
      "colorBackgroundProgressBarDefault": "color",
      "colorBackgroundSegmentActive": "color",
      "colorBackgroundSegmentDefault": "color",
      "colorBackgroundSegmentDisabled": "color",
      "colorBackgroundSegmentHover": "color",
      "colorBackgroundSegmentWrapper": "color",
      "colorBackgroundSliderRangeDefault": "color",
      "colorBackgroundSliderRangeActive": "color",
      "colorBackgroundSliderHandleDefault": "color",
      "colorBackgroundSliderHandleActive": "color",
      "colorBackgroundSliderTrackDefault": "color",
      "colorBackgroundSliderHandleRing": "color",
      "colorBackgroundSliderHandleErrorDefault": "color",
      "colorBackgroundSliderHandleErrorActive": "color",
      "colorBackgroundSliderHandleWarningDefault": "color",
      "colorBackgroundSliderHandleWarningActive": "color",
      "colorBackgroundSliderRangeErrorDefault": "color",
      "colorBackgroundSliderRangeErrorActive": "color",
      "colorBackgroundSliderRangeWarningDefault": "color",
      "colorBackgroundSliderRangeWarningActive": "color",
      "colorBackgroundStatusError": "color",
      "colorBackgroundStatusInfo": "color",
      "colorBackgroundDialog": "color",
      "colorBackgroundStatusSuccess": "color",
      "colorBackgroundStatusWarning": "color",
      "colorBackgroundTableHeader": "color",
      "colorBackgroundTilesDisabled": "color",
      "colorBackgroundToggleCheckedDisabled": "color",
      "colorBackgroundToggleDefault": "color",
      "colorBackgroundAvatarGenAi": "color",
      "colorBackgroundAvatarDefault": "color",
      "colorTextAvatar": "color",
      "colorBackgroundLoadingBarGenAi": "color",
      "colorBackgroundChatBubbleOutgoing": "color",
      "colorBackgroundChatBubbleIncoming": "color",
      "colorTextChatBubbleOutgoing": "color",
      "colorTextChatBubbleIncoming": "color",
      "colorBorderButtonLinkDisabled": "color",
      "colorBorderButtonNormalActive": "color",
      "colorBorderButtonNormalDefault": "color",
      "colorBorderToggleButtonNormalPressed": "color",
      "colorBorderButtonNormalDisabled": "color",
      "colorTextButtonNormalDisabled": "color",
      "colorBorderButtonNormalHover": "color",
      "colorTextButtonIconDisabled": "color",
      "colorBorderButtonPrimaryActive": "color",
      "colorBorderButtonPrimaryDefault": "color",
      "colorBorderButtonPrimaryDisabled": "color",
      "colorBorderButtonPrimaryHover": "color",
      "colorTextButtonPrimaryDisabled": "color",
      "colorItemSelected": "color",
      "colorBorderCalendarGrid": "color",
      "colorBorderCalendarGridSelectedFocusRing": "color",
      "colorBorderCellShaded": "color",
      "colorBorderCodeEditorAceActiveLineLightTheme": "color",
      "colorBorderCodeEditorAceActiveLineDarkTheme": "color",
      "colorBorderCodeEditorDefault": "color",
      "colorBorderCodeEditorPaneItemHover": "color",
      "colorBorderCard": "color",
      "colorBorderCardHighlighted": "color",
      "colorBorderItemCard": "color",
      "colorBorderItemCardHighlighted": "color",
      "colorBorderContainerDivider": "color",
      "colorBorderContainerTop": "color",
      "colorBorderControlChecked": "color",
      "colorBorderControlDefault": "color",
      "colorBorderControlDisabled": "color",
      "colorBorderDividerActive": "color",
      "colorBorderDividerDefault": "color",
      "colorBorderDividerPanelBottom": "color",
      "colorBorderDividerPanelSide": "color",
      "colorBorderDividerSecondary": "color",
      "colorBorderDropdownContainer": "color",
      "colorBorderDropdownGroup": "color",
      "colorBorderDropdownItemDefault": "color",
      "colorBorderDropdownItemHover": "color",
      "colorBorderDropdownItemDimmedHover": "color",
      "colorBorderDropdownItemSelected": "color",
      "colorBorderDropdownItemTop": "color",
      "colorBorderEditableCellHover": "color",
      "colorBorderInputDefault": "color",
      "colorBorderInputDisabled": "color",
      "colorBorderInputFocused": "color",
      "colorBorderItemFocused": "color",
      "colorBorderDropdownItemFocused": "color",
      "colorBorderItemPlaceholder": "color",
      "colorBorderItemSelected": "color",
      "colorBorderLayout": "color",
      "colorBorderNotificationStackBar": "color",
      "colorBorderPanelHeader": "color",
      "colorBorderPopover": "color",
      "colorBorderSegmentActive": "color",
      "colorBorderSegmentDefault": "color",
      "colorBorderSegmentDisabled": "color",
      "colorBorderSegmentHover": "color",
      "colorBorderStatusError": "color",
      "colorBorderStatusInfo": "color",
      "colorBorderStatusSuccess": "color",
      "colorBorderStatusWarning": "color",
      "colorBorderDialog": "color",
      "colorBorderDividerInteractiveDefault": "color",
      "colorBorderTabsDivider": "color",
      "colorBorderTabsShadow": "color",
      "colorBorderTabsUnderline": "color",
      "colorBorderTilesDisabled": "color",
      "colorBorderTutorial": "color",
      "colorForegroundControlDefault": "color",
      "colorForegroundControlDisabled": "color",
      "colorForegroundControlReadOnly": "color",
      "colorShadowDefault": "color",
      "colorShadowMedium": "color",
      "colorShadowSide": "color",
      "colorStrokeChartLine": "color",
      "colorStrokeCodeEditorGutterActiveLineDefault": "color",
      "colorStrokeCodeEditorGutterActiveLineHover": "color",
      "colorTextAccent": "color",
      "colorTextBodyDefault": "color",
      "colorTextBodySecondary": "color",
      "colorTextBreadcrumbCurrent": "color",
      "colorTextBreadcrumbIcon": "color",
      "colorTextButtonInlineIconDefault": "color",
      "colorTextButtonInlineIconDisabled": "color",
      "colorTextButtonInlineIconHover": "color",
      "colorTextButtonNormalActive": "color",
      "colorTextToggleButtonNormalPressed": "color",
      "colorTextButtonNormalDefault": "color",
      "colorTextButtonNormalHover": "color",
      "colorTextLinkButtonNormalDefault": "color",
      "colorTextLinkButtonNormalHover": "color",
      "colorTextLinkButtonNormalActive": "color",
      "colorTextButtonLinkActive": "color",
      "colorTextButtonLinkDefault": "color",
      "colorTextButtonLinkDisabled": "color",
      "colorTextButtonLinkHover": "color",
      "colorTextButtonPrimaryActive": "color",
      "colorTextButtonPrimaryDefault": "color",
      "colorTextButtonPrimaryHover": "color",
      "colorTextCalendarDateHover": "color",
      "colorTextCalendarMonth": "color",
      "colorTextCodeEditorGutterActiveLine": "color",
      "colorTextCodeEditorGutterDefault": "color",
      "colorTextCodeEditorStatusBarDisabled": "color",
      "colorTextCodeEditorTabButtonError": "color",
      "colorTextColumnHeader": "color",
      "colorTextColumnSortingIcon": "color",
      "colorTextControlDisabled": "color",
      "colorTextCounter": "color",
      "colorTextDisabled": "color",
      "colorTextDisabledInlineEdit": "color",
      "colorTextDropdownFooter": "color",
      "colorTextDropdownGroupLabel": "color",
      "colorTextDropdownItemDefault": "color",
      "colorTextDropdownItemDimmed": "color",
      "colorTextDropdownItemDisabled": "color",
      "colorTextDropdownItemFilterMatch": "color",
      "colorTextDropdownItemHighlighted": "color",
      "colorTextDropdownItemSecondary": "color",
      "colorTextDropdownItemSecondaryHover": "color",
      "colorTextEmpty": "color",
      "colorTextExpandableSectionDefault": "color",
      "colorTextExpandableSectionHover": "color",
      "colorTextExpandableSectionNavigationIconDefault": "color",
      "colorTextFormDefault": "color",
      "colorTextFormLabel": "color",
      "colorTextFormSecondary": "color",
      "colorTextGroupLabel": "color",
      "colorTextLabelGenAi": "color",
      "colorTextHeadingDefault": "color",
      "colorTextHeadingSecondary": "color",
      "colorTextHomeHeaderDefault": "color",
      "colorTextHomeHeaderSecondary": "color",
      "colorTextIconCaret": "color",
      "colorTextIconSubtle": "color",
      "colorTextInputDisabled": "color",
      "colorTextInputPlaceholder": "color",
      "colorTextInputPlaceholderDisabled": "color",
      "colorTextInteractiveActive": "color",
      "colorTextInteractiveDefault": "color",
      "colorTextInteractiveDisabled": "color",
      "colorTextInteractiveHover": "color",
      "colorTextToggleButtonIconPressed": "color",
      "colorTextInteractiveInvertedDefault": "color",
      "colorTextInteractiveInvertedHover": "color",
      "colorTextInverted": "color",
      "colorTextLabel": "color",
      "colorTextKeyValuePairsValue": "color",
      "colorTextLayoutToggle": "color",
      "colorTextLayoutToggleActive": "color",
      "colorTextLayoutToggleHover": "color",
      "colorTextLayoutToggleSelected": "color",
      "colorTextLinkDefault": "color",
      "colorTextLinkHover": "color",
      "colorTextLinkDecorationDefault": "color",
      "colorTextLinkDecorationHover": "color",
      "colorTextLinkSecondaryDefault": "color",
      "colorTextLinkSecondaryHover": "color",
      "colorTextLinkInfoDefault": "color",
      "colorTextLinkInfoHover": "color",
      "colorTextLinkInvertedHover": "color",
      "colorTextLinkButtonUnderline": "color",
      "colorTextLinkButtonUnderlineHover": "color",
      "colorTextNotificationDefault": "color",
      "colorTextNotificationStackBar": "color",
      "colorTextNotificationYellow": "color",
      "colorTextPaginationPageNumberActiveDisabled": "color",
      "colorTextPaginationPageNumberDefault": "color",
      "colorTextSegmentActive": "color",
      "colorTextSegmentDefault": "color",
      "colorTextSegmentHover": "color",
      "colorTextSmall": "color",
      "colorTextStatusError": "color",
      "colorTextStatusInactive": "color",
      "colorTextStatusInfo": "color",
      "colorTextStatusSuccess": "color",
      "colorTextStatusWarning": "color",
      "colorTextTopNavigationTitle": "color",
      "colorTextTutorialHotspotDefault": "color",
      "colorTextTutorialHotspotHover": "color",
      "colorBoardPlaceholderActive": "color",
      "colorBoardPlaceholderHover": "color",
      "colorDragPlaceholderActive": "color",
      "colorDragPlaceholderHover": "color",
      "colorDropzoneBackgroundDefault": "color",
      "colorDropzoneBackgroundHover": "color",
      "colorDropzoneTextDefault": "color",
      "colorDropzoneTextHover": "color",
      "colorDropzoneBorderDefault": "color",
      "colorDropzoneBorderHover": "color",
      "colorGapGlobalDrawer": "color",
      "colorTreeViewConnectorLine": "color",
      "colorBackgroundActionCardDefault": "color",
      "colorBackgroundActionCardHover": "color",
      "colorBackgroundActionCardActive": "color",
      "colorBorderActionCardDefault": "color",
      "colorBorderActionCardHover": "color",
      "colorBorderActionCardActive": "color",
      "colorBorderActionCardDisabled": "color",
      "colorBackgroundActionCardDisabled": "color",
      "colorTextActionCardDisabled": "color",
      "colorIconActionCardDefault": "color",
      "colorIconActionCardHover": "color",
      "colorIconActionCardActive": "color",
      "colorIconActionCardDisabled": "color",
      "colorBackgroundSkeleton": "color",
      "colorBackgroundSkeletonWave": "color",
      "motionDurationExtraFast": "motion",
      "motionDurationExtraSlow": "motion",
      "motionDurationFast": "motion",
      "motionDurationModerate": "motion",
      "motionDurationRefreshOnlyAmbient": "motion",
      "motionDurationRefreshOnlyFast": "motion",
      "motionDurationRefreshOnlyMedium": "motion",
      "motionDurationRefreshOnlySlow": "motion",
      "motionDurationAvatarGenAiGradient": "motion",
      "motionDurationAvatarLoadingDots": "motion",
      "motionDurationRotate180": "motion",
      "motionDurationRotate90": "motion",
      "motionDurationShowPaced": "motion",
      "motionDurationShowQuick": "motion",
      "motionDurationSlow": "motion",
      "motionDurationTransitionQuick": "motion",
      "motionDurationTransitionShowPaced": "motion",
      "motionDurationTransitionShowQuick": "motion",
      "motionEasingEaseOutQuart": "motion",
      "motionEasingRefreshOnlyA": "motion",
      "motionEasingRefreshOnlyB": "motion",
      "motionEasingRefreshOnlyC": "motion",
      "motionEasingRefreshOnlyD": "motion",
      "motionEasingAvatarGenAiGradient": "motion",
      "motionEasingRotate180": "motion",
      "motionEasingRotate90": "motion",
      "motionEasingShowPaced": "motion",
      "motionEasingShowQuick": "motion",
      "motionEasingTransitionQuick": "motion",
      "motionEasingTransitionShowPaced": "motion",
      "motionEasingTransitionShowQuick": "motion",
      "motionEasingResponsive": "motion",
      "motionEasingSticky": "motion",
      "motionEasingExpressive": "motion",
      "motionDurationResponsive": "motion",
      "motionDurationExpressive": "motion",
      "motionDurationComplex": "motion",
      "motionKeyframesFadeIn": "motion",
      "motionKeyframesFadeOut": "motion",
      "motionKeyframesStatusIconError": "motion",
      "motionKeyframesScalePopup": "motion",
      "sizeCalendarGridWidth": "density",
      "sizeControl": "density",
      "sizeIconBig": "density",
      "sizeIconLarge": "density",
      "sizeIconMedium": "density",
      "sizeIconNormal": "density",
      "sizeTableSelectionHorizontal": "density",
      "sizeVerticalInput": "density",
      "sizeVerticalPanelIconOffset": "density",
      "spaceAlertActionLeft": "density",
      "spaceAlertHorizontal": "density",
      "spaceAlertMessageRight": "density",
      "spaceAlertVertical": "density",
      "spaceButtonFocusOutlineGutter": "density",
      "spaceButtonHorizontal": "density",
      "spaceButtonVertical": "density",
      "spaceTokenVertical": "density",
      "spaceFieldVertical": "density",
      "spaceButtonIconFocusOutlineGutterVertical": "density",
      "spaceButtonIconOnlyHorizontal": "density",
      "spaceButtonInlineIconFocusOutlineGutter": "density",
      "spaceButtonModalDismissVertical": "density",
      "spaceCalendarGridFocusOutlineGutter": "density",
      "spaceCalendarGridSelectedFocusOutlineGutter": "density",
      "spaceCalendarGridGutter": "density",
      "spaceCardHorizontalDefault": "density",
      "spaceCardHorizontalEmbedded": "density",
      "spaceCardVerticalDefault": "density",
      "spaceCardVerticalEmbedded": "density",
      "spaceItemCardHorizontalDefault": "density",
      "spaceItemCardHorizontalEmbedded": "density",
      "spaceItemCardVerticalDefault": "density",
      "spaceItemCardVerticalEmbedded": "density",
      "spaceCodeEditorStatusFocusOutlineGutter": "density",
      "spaceContainerContentTop": "density",
      "spaceContainerHeaderTop": "density",
      "spaceContainerHeaderBottom": "density",
      "spaceContainerHorizontal": "density",
      "spaceContentHeaderPaddingBottom": "density",
      "spaceDarkHeaderOverlapDistance": "density",
      "spaceExpandableSectionIconOffsetTop": "density",
      "spaceFieldHorizontal": "density",
      "spaceFieldIconOffset": "density",
      "spaceFilteringTokenDismissButtonFocusOutlineGutter": "density",
      "spaceFilteringTokenOperationSelectFocusOutlineGutter": "density",
      "spaceFlashbarActionLeft": "density",
      "spaceFlashbarDismissRight": "density",
      "spaceFlashbarHorizontal": "density",
      "spaceFlashbarVertical": "density",
      "spaceGridGutter": "density",
      "spaceKeyValueGap": "density",
      "spaceLayoutContentBottom": "density",
      "spaceLayoutContentHorizontal": "density",
      "spaceLayoutToggleDiameter": "density",
      "spaceLayoutTogglePadding": "density",
      "spaceModalContentBottom": "density",
      "spaceModalHorizontal": "density",
      "spacePanelContentBottom": "density",
      "spacePanelContentTop": "density",
      "spacePanelDividerMarginHorizontal": "density",
      "spacePanelHeaderVertical": "density",
      "spacePanelNavLeft": "density",
      "spacePanelSideLeft": "density",
      "spacePanelSideRight": "density",
      "spacePanelSplitTop": "density",
      "spacePanelSplitBottom": "density",
      "spaceSegmentedControlFocusOutlineGutter": "density",
      "spaceTabsContentTop": "density",
      "spaceTabsFocusOutlineGutter": "density",
      "spaceTabsVertical": "density",
      "spaceTableContentBottom": "density",
      "spaceTableEmbeddedHeaderTop": "density",
      "spaceTableFooterHorizontal": "density",
      "spaceTableHeaderFocusOutlineGutter": "density",
      "spaceTableHeaderHorizontal": "density",
      "spaceTableHeaderToolsBottom": "density",
      "spaceTableHeaderToolsFullPageBottom": "density",
      "spaceTableHorizontal": "density",
      "spaceTreeViewIndentation": "density",
      "spaceTileGutter": "density",
      "spaceActionCardHorizontalDefault": "density",
      "spaceActionCardHorizontalEmbedded": "density",
      "spaceActionCardVerticalDefault": "density",
      "spaceActionCardVerticalEmbedded": "density",
      "spaceActionCardDescriptionPaddingTop": "density",
      "spaceActionCardContentPaddingTop": "density",
      "spaceOptionPaddingVertical": "density",
      "spaceOptionPaddingHorizontal": "density",
      "spaceScaled2xNone": "density",
      "spaceScaled2xXxxs": "density",
      "spaceScaled2xXxs": "density",
      "spaceScaled2xXs": "density",
      "spaceScaled2xS": "density",
      "spaceScaled2xM": "density",
      "spaceScaled2xL": "density",
      "spaceScaled2xXl": "density",
      "spaceScaled2xXxl": "density",
      "spaceScaled2xXxxl": "density",
      "spaceScaledNone": "density",
      "spaceScaledXxxs": "density",
      "spaceScaledXxs": "density",
      "spaceScaledXs": "density",
      "spaceScaledS": "density",
      "spaceScaledM": "density",
      "spaceScaledL": "density",
      "spaceScaledXl": "density",
      "spaceScaledXxl": "density",
      "spaceScaledXxxl": "density",
      "spaceStaticXxxs": "density",
      "spaceStaticXxs": "density",
      "spaceStaticXs": "density",
      "spaceStaticS": "density",
      "spaceStaticM": "density",
      "spaceStaticL": "density",
      "spaceStaticXl": "density",
      "spaceStaticXxl": "density",
      "spaceStaticXxxl": "density",
      "spaceNone": "density",
      "spaceXxxs": "density",
      "spaceXxs": "density",
      "spaceXs": "density",
      "spaceS": "density",
      "spaceM": "density",
      "spaceL": "density",
      "spaceXl": "density",
      "spaceXxl": "density",
      "spaceXxxl": "density",
      "shadowCard": "color",
      "shadowItemCard": "color",
      "shadowContainer": "color",
      "shadowContainerActive": "color",
      "shadowDropdown": "color",
      "shadowDropup": "color",
      "shadowFlashCollapsed": "color",
      "shadowFlashSticky": "color",
      "shadowModal": "color",
      "shadowPanel": "color",
      "shadowPanelToggle": "color",
      "shadowPopover": "color",
      "shadowSplitBottom": "color",
      "shadowSplitSide": "color",
      "shadowSticky": "color",
      "shadowStickyEmbedded": "color",
      "shadowStickyColumnFirst": "color",
      "shadowStickyColumnLast": "color"
    },
    "referenceTokens": {
      "color": {
        "primary": {
          "50": {
            "light": "#f0fbff",
            "dark": "#f0fbff"
          },
          "100": {
            "light": "#d1f1ff",
            "dark": "#d1f1ff"
          },
          "200": {
            "light": "#b8e7ff",
            "dark": "#b8e7ff"
          },
          "300": {
            "light": "#75cfff",
            "dark": "#75cfff"
          },
          "400": {
            "light": "#42b4ff",
            "dark": "#42b4ff"
          },
          "500": {
            "light": "#0099ff",
            "dark": "#0099ff"
          },
          "600": {
            "light": "#006ce0",
            "dark": "#006ce0"
          },
          "700": {
            "light": "#004a9e",
            "dark": "#004a9e"
          },
          "800": {
            "light": "#003b8f",
            "dark": "#003b8f"
          },
          "900": {
            "light": "#002b66",
            "dark": "#002b66"
          },
          "1000": {
            "light": "#001129",
            "dark": "#001129"
          }
        },
        "neutral": {
          "50": {
            "light": "#fcfcfd",
            "dark": "#fcfcfd"
          },
          "100": {
            "light": "#f9f9fa",
            "dark": "#f9f9fa"
          },
          "150": {
            "light": "#f6f6f9",
            "dark": "#f6f6f9"
          },
          "200": {
            "light": "#f3f3f7",
            "dark": "#f3f3f7"
          },
          "250": {
            "light": "#ebebf0",
            "dark": "#ebebf0"
          },
          "300": {
            "light": "#dedee3",
            "dark": "#dedee3"
          },
          "350": {
            "light": "#c6c6cd",
            "dark": "#c6c6cd"
          },
          "400": {
            "light": "#b4b4bb",
            "dark": "#b4b4bb"
          },
          "450": {
            "light": "#a4a4ad",
            "dark": "#a4a4ad"
          },
          "500": {
            "light": "#8c8c94",
            "dark": "#8c8c94"
          },
          "550": {
            "light": "#72747e",
            "dark": "#72747e"
          },
          "600": {
            "light": "#656871",
            "dark": "#656871"
          },
          "650": {
            "light": "#424650",
            "dark": "#424650"
          },
          "700": {
            "light": "#333843",
            "dark": "#333843"
          },
          "750": {
            "light": "#232b37",
            "dark": "#232b37"
          },
          "800": {
            "light": "#1b232d",
            "dark": "#1b232d"
          },
          "850": {
            "light": "#161d26",
            "dark": "#161d26"
          },
          "900": {
            "light": "#131920",
            "dark": "#131920"
          },
          "950": {
            "light": "#0f141a",
            "dark": "#0f141a"
          },
          "1000": {
            "light": "#06080a",
            "dark": "#06080a"
          }
        },
        "error": {
          "50": {
            "light": "#fff5f5",
            "dark": "#fff5f5"
          },
          "400": {
            "light": "#ff7a7a",
            "dark": "#ff7a7a"
          },
          "600": {
            "light": "#db0000",
            "dark": "#db0000"
          },
          "900": {
            "light": "#700000",
            "dark": "#700000"
          },
          "1000": {
            "light": "#1f0000",
            "dark": "#1f0000"
          }
        },
        "success": {
          "50": {
            "light": "#effff1",
            "dark": "#effff1"
          },
          "500": {
            "light": "#2bb534",
            "dark": "#2bb534"
          },
          "600": {
            "light": "#00802f",
            "dark": "#00802f"
          },
          "1000": {
            "light": "#001401",
            "dark": "#001401"
          }
        },
        "warning": {
          "50": {
            "light": "#fffef0",
            "dark": "#fffef0"
          },
          "400": {
            "light": "#ffe347",
            "dark": "#ffe347"
          },
          "500": {
            "light": "#fbd332",
            "dark": "#fbd332"
          },
          "900": {
            "light": "#855900",
            "dark": "#855900"
          },
          "1000": {
            "light": "#191100",
            "dark": "#191100"
          }
        },
        "info": {
          "50": {
            "light": "#f0fbff",
            "dark": "#f0fbff"
          },
          "300": {
            "light": "#75cfff",
            "dark": "#75cfff"
          },
          "400": {
            "light": "#42b4ff",
            "dark": "#42b4ff"
          },
          "600": {
            "light": "#006ce0",
            "dark": "#006ce0"
          },
          "1000": {
            "light": "#001129",
            "dark": "#001129"
          }
        }
      }
    }
  },
  "secondary": [],
  "themeable": [
    "colorChartsStatusCritical",
    "colorChartsStatusHigh",
    "colorChartsStatusMedium",
    "colorChartsStatusLow",
    "colorChartsStatusPositive",
    "colorChartsStatusInfo",
    "colorChartsStatusNeutral",
    "colorChartsThresholdNegative",
    "colorChartsThresholdPositive",
    "colorChartsThresholdInfo",
    "colorChartsThresholdNeutral",
    "colorChartsPaletteCategorical1",
    "colorChartsPaletteCategorical2",
    "colorChartsPaletteCategorical3",
    "colorChartsPaletteCategorical4",
    "colorChartsPaletteCategorical5",
    "colorChartsPaletteCategorical6",
    "colorChartsPaletteCategorical7",
    "colorChartsPaletteCategorical8",
    "colorChartsPaletteCategorical9",
    "colorChartsPaletteCategorical10",
    "colorChartsPaletteCategorical11",
    "colorChartsPaletteCategorical12",
    "colorChartsPaletteCategorical13",
    "colorChartsPaletteCategorical14",
    "colorChartsPaletteCategorical15",
    "colorChartsPaletteCategorical16",
    "colorChartsPaletteCategorical17",
    "colorChartsPaletteCategorical18",
    "colorChartsPaletteCategorical19",
    "colorChartsPaletteCategorical20",
    "colorChartsPaletteCategorical21",
    "colorChartsPaletteCategorical22",
    "colorChartsPaletteCategorical23",
    "colorChartsPaletteCategorical24",
    "colorChartsPaletteCategorical25",
    "colorChartsPaletteCategorical26",
    "colorChartsPaletteCategorical27",
    "colorChartsPaletteCategorical28",
    "colorChartsPaletteCategorical29",
    "colorChartsPaletteCategorical30",
    "colorChartsPaletteCategorical31",
    "colorChartsPaletteCategorical32",
    "colorChartsPaletteCategorical33",
    "colorChartsPaletteCategorical34",
    "colorChartsPaletteCategorical35",
    "colorChartsPaletteCategorical36",
    "colorChartsPaletteCategorical37",
    "colorChartsPaletteCategorical38",
    "colorChartsPaletteCategorical39",
    "colorChartsPaletteCategorical40",
    "colorChartsPaletteCategorical41",
    "colorChartsPaletteCategorical42",
    "colorChartsPaletteCategorical43",
    "colorChartsPaletteCategorical44",
    "colorChartsPaletteCategorical45",
    "colorChartsPaletteCategorical46",
    "colorChartsPaletteCategorical47",
    "colorChartsPaletteCategorical48",
    "colorChartsPaletteCategorical49",
    "colorChartsPaletteCategorical50",
    "colorChartsErrorBarMarker",
    "colorBackgroundNotificationSeverityCritical",
    "colorBackgroundNotificationSeverityHigh",
    "colorBackgroundNotificationSeverityMedium",
    "colorBackgroundNotificationSeverityLow",
    "colorBackgroundNotificationSeverityNeutral",
    "colorTextNotificationSeverityCritical",
    "colorTextNotificationSeverityHigh",
    "colorTextNotificationSeverityMedium",
    "colorTextNotificationSeverityLow",
    "colorTextNotificationSeverityNeutral",
    "colorBackgroundButtonLinkActive",
    "colorBackgroundButtonLinkDefault",
    "colorBackgroundButtonLinkDisabled",
    "colorBackgroundButtonLinkHover",
    "colorBackgroundButtonNormalActive",
    "colorBackgroundButtonNormalDefault",
    "colorBackgroundButtonNormalDisabled",
    "colorBackgroundButtonNormalHover",
    "colorBackgroundToggleButtonNormalPressed",
    "colorBackgroundButtonPrimaryActive",
    "colorBackgroundButtonPrimaryDefault",
    "colorBackgroundButtonPrimaryDisabled",
    "colorBackgroundButtonPrimaryHover",
    "colorBackgroundCellShaded",
    "colorBackgroundCard",
    "colorBackgroundContainerContent",
    "colorBackgroundContainerHeader",
    "colorBackgroundControlChecked",
    "colorBackgroundControlDefault",
    "colorBackgroundControlDisabled",
    "colorBackgroundDropdownItemDefault",
    "colorBackgroundDropdownItemFilterMatch",
    "colorBackgroundDropdownItemHover",
    "colorBackgroundDropdownItemSelected",
    "colorBackgroundHomeHeader",
    "colorBackgroundInputDefault",
    "colorBackgroundInputDisabled",
    "colorBackgroundItemSelected",
    "colorBackgroundLayoutMain",
    "colorBackgroundLayoutToolbar",
    "colorBackgroundLayoutToggleActive",
    "colorBackgroundLayoutToggleDefault",
    "colorBackgroundLayoutToggleHover",
    "colorBackgroundLayoutToggleSelectedActive",
    "colorBackgroundLayoutToggleSelectedDefault",
    "colorBackgroundLayoutToggleSelectedHover",
    "colorBackgroundNotificationBlue",
    "colorBackgroundNotificationGreen",
    "colorBackgroundNotificationGrey",
    "colorBackgroundNotificationRed",
    "colorBackgroundNotificationYellow",
    "colorBackgroundPopover",
    "colorBackgroundProgressBarValueDefault",
    "colorBackgroundProgressBarDefault",
    "colorBackgroundSegmentActive",
    "colorBackgroundSegmentDefault",
    "colorBackgroundSegmentDisabled",
    "colorBackgroundSegmentHover",
    "colorBackgroundSegmentWrapper",
    "colorBackgroundSliderRangeDefault",
    "colorBackgroundSliderRangeActive",
    "colorBackgroundSliderHandleDefault",
    "colorBackgroundSliderHandleActive",
    "colorBackgroundSliderTrackDefault",
    "colorBackgroundStatusError",
    "colorBackgroundStatusInfo",
    "colorBackgroundDialog",
    "colorBackgroundStatusSuccess",
    "colorBackgroundStatusWarning",
    "colorBackgroundToggleCheckedDisabled",
    "colorBackgroundChatBubbleOutgoing",
    "colorBackgroundChatBubbleIncoming",
    "colorTextChatBubbleOutgoing",
    "colorTextChatBubbleIncoming",
    "colorBorderButtonLinkDisabled",
    "colorBorderButtonNormalActive",
    "colorBorderButtonNormalDefault",
    "colorBorderToggleButtonNormalPressed",
    "colorBorderButtonNormalDisabled",
    "colorTextButtonNormalDisabled",
    "colorBorderButtonNormalHover",
    "colorTextButtonIconDisabled",
    "colorBorderButtonPrimaryActive",
    "colorBorderButtonPrimaryDefault",
    "colorBorderButtonPrimaryDisabled",
    "colorBorderButtonPrimaryHover",
    "colorTextButtonPrimaryDisabled",
    "colorItemSelected",
    "colorBorderCard",
    "colorBorderContainerTop",
    "colorBorderControlDefault",
    "colorBorderDividerDefault",
    "colorBorderDividerSecondary",
    "colorBorderDropdownContainer",
    "colorBorderDropdownItemHover",
    "colorBorderInputDefault",
    "colorBorderInputFocused",
    "colorBorderItemFocused",
    "colorBorderDropdownItemFocused",
    "colorBorderItemSelected",
    "colorBorderLayout",
    "colorBorderPopover",
    "colorBorderSegmentActive",
    "colorBorderSegmentDefault",
    "colorBorderSegmentDisabled",
    "colorBorderSegmentHover",
    "colorBorderStatusError",
    "colorBorderStatusInfo",
    "colorBorderStatusSuccess",
    "colorBorderStatusWarning",
    "colorBorderDialog",
    "colorForegroundControlDefault",
    "colorForegroundControlDisabled",
    "colorForegroundControlReadOnly",
    "colorTextAccent",
    "colorTextBodyDefault",
    "colorTextBodySecondary",
    "colorTextBreadcrumbCurrent",
    "colorTextBreadcrumbIcon",
    "colorTextButtonInlineIconDefault",
    "colorTextButtonInlineIconDisabled",
    "colorTextButtonInlineIconHover",
    "colorTextButtonNormalActive",
    "colorTextToggleButtonNormalPressed",
    "colorTextButtonNormalDefault",
    "colorTextButtonNormalHover",
    "colorTextLinkButtonNormalDefault",
    "colorTextLinkButtonNormalHover",
    "colorTextLinkButtonNormalActive",
    "colorTextButtonLinkActive",
    "colorTextButtonLinkDefault",
    "colorTextButtonLinkDisabled",
    "colorTextButtonLinkHover",
    "colorTextButtonPrimaryActive",
    "colorTextButtonPrimaryDefault",
    "colorTextButtonPrimaryHover",
    "colorTextCounter",
    "colorTextDropdownItemDefault",
    "colorTextDropdownItemDisabled",
    "colorTextDropdownItemFilterMatch",
    "colorTextDropdownItemHighlighted",
    "colorTextDropdownItemSecondary",
    "colorTextEmpty",
    "colorTextFormDefault",
    "colorTextFormLabel",
    "colorTextFormSecondary",
    "colorTextGroupLabel",
    "colorTextHeadingDefault",
    "colorTextHeadingSecondary",
    "colorTextHomeHeaderDefault",
    "colorTextHomeHeaderSecondary",
    "colorTextIconSubtle",
    "colorTextInputDisabled",
    "colorTextInputPlaceholder",
    "colorTextInteractiveActive",
    "colorTextInteractiveDefault",
    "colorTextInteractiveDisabled",
    "colorTextInteractiveHover",
    "colorTextToggleButtonIconPressed",
    "colorTextInteractiveInvertedDefault",
    "colorTextInteractiveInvertedHover",
    "colorTextLabel",
    "colorTextKeyValuePairsValue",
    "colorTextLayoutToggle",
    "colorTextLayoutToggleActive",
    "colorTextLayoutToggleHover",
    "colorTextLayoutToggleSelected",
    "colorTextLinkDefault",
    "colorTextLinkHover",
    "colorTextLinkDecorationDefault",
    "colorTextLinkDecorationHover",
    "colorTextLinkSecondaryDefault",
    "colorTextLinkSecondaryHover",
    "colorTextLinkInfoDefault",
    "colorTextLinkInfoHover",
    "colorTextNotificationDefault",
    "colorTextSegmentActive",
    "colorTextSegmentDefault",
    "colorTextSegmentHover",
    "colorTextStatusError",
    "colorTextStatusInactive",
    "colorTextStatusInfo",
    "colorTextStatusSuccess",
    "colorTextStatusWarning",
    "colorTextTopNavigationTitle",
    "colorDropzoneBackgroundDefault",
    "colorDropzoneBackgroundHover",
    "colorDropzoneTextDefault",
    "colorDropzoneTextHover",
    "colorDropzoneBorderDefault",
    "colorDropzoneBorderHover",
    "colorTreeViewConnectorLine",
    "colorBackgroundActionCardDefault",
    "colorBackgroundActionCardHover",
    "colorBackgroundActionCardActive",
    "colorBorderActionCardDefault",
    "colorBorderActionCardHover",
    "colorBorderActionCardActive",
    "colorBorderActionCardDisabled",
    "colorBackgroundActionCardDisabled",
    "colorTextActionCardDisabled",
    "fontDecorationStyleLink",
    "fontDecorationThicknessLink",
    "fontDecorationThicknessLinkDisplayL",
    "fontFamilyBase",
    "fontFamilyDisplay",
    "fontFamilyHeading",
    "fontFamilyMonospace",
    "fontSizeBodyM",
    "fontSizeBodyS",
    "fontSizeDisplayL",
    "fontSizeFormLabel",
    "fontSizeHeadingL",
    "fontSizeHeadingM",
    "fontSizeHeadingS",
    "fontSizeHeadingXl",
    "fontSizeHeadingXs",
    "fontSizeKeyValuePairsLabel",
    "fontSizeTabs",
    "fontWeightAlertHeader",
    "fontWeightBold",
    "fontWeightBreadcrumbCurrent",
    "fontWeightButton",
    "fontWeightDisplayL",
    "fontWeightFlashbarHeader",
    "fontWeightFormLabel",
    "fontWeightHeadingL",
    "fontWeightHeadingM",
    "fontWeightHeadingS",
    "fontWeightHeadingXl",
    "fontWeightHeadingXs",
    "fontWeightHeavy",
    "fontWeightKeyValuePairsLabel",
    "fontWeightLighter",
    "fontWeightNormal",
    "fontWeightTabs",
    "fontWeightTabsDisabled",
    "letterSpacingDisplayL",
    "letterSpacingHeadingL",
    "letterSpacingHeadingM",
    "letterSpacingHeadingS",
    "letterSpacingHeadingXl",
    "letterSpacingHeadingXs",
    "lineHeightBodyM",
    "lineHeightBodyS",
    "lineHeightDisplayL",
    "lineHeightFormLabel",
    "lineHeightHeadingL",
    "lineHeightHeadingM",
    "lineHeightHeadingS",
    "lineHeightHeadingXl",
    "lineHeightHeadingXs",
    "lineHeightKeyValuePairsLabel",
    "lineHeightTabs",
    "borderRadiusAlert",
    "borderRadiusBadge",
    "borderRadiusButton",
    "borderRadiusCalendarDayFocusRing",
    "borderRadiusCardDefault",
    "borderRadiusCardEmbedded",
    "borderRadiusContainer",
    "borderRadiusControlCircularFocusRing",
    "borderRadiusControlDefaultFocusRing",
    "borderRadiusDropdown",
    "borderRadiusDropzone",
    "borderRadiusFlashbar",
    "borderRadiusItem",
    "borderRadiusInput",
    "borderRadiusPopover",
    "borderRadiusTabsFocusRing",
    "borderRadiusTiles",
    "borderRadiusToken",
    "borderRadiusTutorialPanelItem",
    "borderWidthCard",
    "borderWidthCardSelected",
    "borderWidthItemSelected",
    "borderWidthAlert",
    "borderWidthAlertBlockStart",
    "borderWidthAlertBlockEnd",
    "borderWidthAlertInlineStart",
    "borderWidthAlertInlineEnd",
    "borderWidthButton",
    "borderWidthDropdown",
    "borderWidthField",
    "borderWidthPopover",
    "borderWidthToken",
    "borderWidthIconSmall",
    "borderWidthIconNormal",
    "borderWidthIconMedium",
    "borderWidthIconBig",
    "borderWidthIconLarge",
    "borderRadiusActionCardDefault",
    "borderRadiusActionCardEmbedded",
    "borderWidthActionCardDefault",
    "borderWidthActionCardHover",
    "borderWidthActionCardActive",
    "borderWidthActionCardDisabled",
    "sizeVerticalInput",
    "spaceAlertVertical",
    "spaceButtonHorizontal",
    "spaceButtonVertical",
    "spaceTokenVertical",
    "spaceFieldVertical",
    "spaceCardHorizontalDefault",
    "spaceCardHorizontalEmbedded",
    "spaceCardVerticalDefault",
    "spaceCardVerticalEmbedded",
    "spaceTabsVertical",
    "spaceActionCardHorizontalDefault",
    "spaceActionCardHorizontalEmbedded",
    "spaceActionCardVerticalDefault",
    "spaceActionCardVerticalEmbedded",
    "shadowCard"
  ],
  "exposed": [
    "colorChartsRed300",
    "colorChartsRed400",
    "colorChartsRed500",
    "colorChartsRed600",
    "colorChartsRed700",
    "colorChartsRed800",
    "colorChartsRed900",
    "colorChartsRed1000",
    "colorChartsRed1100",
    "colorChartsRed1200",
    "colorChartsOrange300",
    "colorChartsOrange400",
    "colorChartsOrange500",
    "colorChartsOrange600",
    "colorChartsOrange700",
    "colorChartsOrange800",
    "colorChartsOrange900",
    "colorChartsOrange1000",
    "colorChartsOrange1100",
    "colorChartsOrange1200",
    "colorChartsYellow300",
    "colorChartsYellow400",
    "colorChartsYellow500",
    "colorChartsYellow600",
    "colorChartsYellow700",
    "colorChartsYellow800",
    "colorChartsYellow900",
    "colorChartsYellow1000",
    "colorChartsYellow1100",
    "colorChartsYellow1200",
    "colorChartsGreen300",
    "colorChartsGreen400",
    "colorChartsGreen500",
    "colorChartsGreen600",
    "colorChartsGreen700",
    "colorChartsGreen800",
    "colorChartsGreen900",
    "colorChartsGreen1000",
    "colorChartsGreen1100",
    "colorChartsGreen1200",
    "colorChartsTeal300",
    "colorChartsTeal400",
    "colorChartsTeal500",
    "colorChartsTeal600",
    "colorChartsTeal700",
    "colorChartsTeal800",
    "colorChartsTeal900",
    "colorChartsTeal1000",
    "colorChartsTeal1100",
    "colorChartsTeal1200",
    "colorChartsBlue1300",
    "colorChartsBlue1400",
    "colorChartsBlue1500",
    "colorChartsBlue1600",
    "colorChartsBlue1700",
    "colorChartsBlue1800",
    "colorChartsBlue1900",
    "colorChartsBlue11000",
    "colorChartsBlue11100",
    "colorChartsBlue11200",
    "colorChartsBlue2300",
    "colorChartsBlue2400",
    "colorChartsBlue2500",
    "colorChartsBlue2600",
    "colorChartsBlue2700",
    "colorChartsBlue2800",
    "colorChartsBlue2900",
    "colorChartsBlue21000",
    "colorChartsBlue21100",
    "colorChartsBlue21200",
    "colorChartsPurple300",
    "colorChartsPurple400",
    "colorChartsPurple500",
    "colorChartsPurple600",
    "colorChartsPurple700",
    "colorChartsPurple800",
    "colorChartsPurple900",
    "colorChartsPurple1000",
    "colorChartsPurple1100",
    "colorChartsPurple1200",
    "colorChartsPink300",
    "colorChartsPink400",
    "colorChartsPink500",
    "colorChartsPink600",
    "colorChartsPink700",
    "colorChartsPink800",
    "colorChartsPink900",
    "colorChartsPink1000",
    "colorChartsPink1100",
    "colorChartsPink1200",
    "colorChartsStatusCritical",
    "colorChartsStatusHigh",
    "colorChartsStatusMedium",
    "colorChartsStatusLow",
    "colorChartsStatusPositive",
    "colorChartsStatusInfo",
    "colorChartsStatusNeutral",
    "colorChartsThresholdNegative",
    "colorChartsThresholdPositive",
    "colorChartsThresholdInfo",
    "colorChartsThresholdNeutral",
    "colorChartsLineGrid",
    "colorChartsLineTick",
    "colorChartsLineAxis",
    "colorChartsPaletteCategorical1",
    "colorChartsPaletteCategorical2",
    "colorChartsPaletteCategorical3",
    "colorChartsPaletteCategorical4",
    "colorChartsPaletteCategorical5",
    "colorChartsPaletteCategorical6",
    "colorChartsPaletteCategorical7",
    "colorChartsPaletteCategorical8",
    "colorChartsPaletteCategorical9",
    "colorChartsPaletteCategorical10",
    "colorChartsPaletteCategorical11",
    "colorChartsPaletteCategorical12",
    "colorChartsPaletteCategorical13",
    "colorChartsPaletteCategorical14",
    "colorChartsPaletteCategorical15",
    "colorChartsPaletteCategorical16",
    "colorChartsPaletteCategorical17",
    "colorChartsPaletteCategorical18",
    "colorChartsPaletteCategorical19",
    "colorChartsPaletteCategorical20",
    "colorChartsPaletteCategorical21",
    "colorChartsPaletteCategorical22",
    "colorChartsPaletteCategorical23",
    "colorChartsPaletteCategorical24",
    "colorChartsPaletteCategorical25",
    "colorChartsPaletteCategorical26",
    "colorChartsPaletteCategorical27",
    "colorChartsPaletteCategorical28",
    "colorChartsPaletteCategorical29",
    "colorChartsPaletteCategorical30",
    "colorChartsPaletteCategorical31",
    "colorChartsPaletteCategorical32",
    "colorChartsPaletteCategorical33",
    "colorChartsPaletteCategorical34",
    "colorChartsPaletteCategorical35",
    "colorChartsPaletteCategorical36",
    "colorChartsPaletteCategorical37",
    "colorChartsPaletteCategorical38",
    "colorChartsPaletteCategorical39",
    "colorChartsPaletteCategorical40",
    "colorChartsPaletteCategorical41",
    "colorChartsPaletteCategorical42",
    "colorChartsPaletteCategorical43",
    "colorChartsPaletteCategorical44",
    "colorChartsPaletteCategorical45",
    "colorChartsPaletteCategorical46",
    "colorChartsPaletteCategorical47",
    "colorChartsPaletteCategorical48",
    "colorChartsPaletteCategorical49",
    "colorChartsPaletteCategorical50",
    "colorChartsErrorBarMarker",
    "colorBackgroundNotificationSeverityCritical",
    "colorBackgroundNotificationSeverityHigh",
    "colorBackgroundNotificationSeverityMedium",
    "colorBackgroundNotificationSeverityLow",
    "colorBackgroundNotificationSeverityNeutral",
    "colorTextNotificationSeverityCritical",
    "colorTextNotificationSeverityHigh",
    "colorTextNotificationSeverityMedium",
    "colorTextNotificationSeverityLow",
    "colorTextNotificationSeverityNeutral",
    "colorBackgroundButtonLinkActive",
    "colorBackgroundButtonLinkDefault",
    "colorBackgroundButtonLinkDisabled",
    "colorBackgroundButtonLinkHover",
    "colorBackgroundButtonNormalActive",
    "colorBackgroundButtonNormalDefault",
    "colorBackgroundButtonNormalDisabled",
    "colorBackgroundButtonNormalHover",
    "colorBackgroundToggleButtonNormalPressed",
    "colorBackgroundButtonPrimaryActive",
    "colorBackgroundButtonPrimaryDefault",
    "colorBackgroundButtonPrimaryDisabled",
    "colorBackgroundButtonPrimaryHover",
    "colorBackgroundCellShaded",
    "colorBackgroundCard",
    "colorBackgroundContainerContent",
    "colorBackgroundContainerHeader",
    "colorBackgroundControlChecked",
    "colorBackgroundControlDefault",
    "colorBackgroundControlDisabled",
    "colorBackgroundDropdownItemDefault",
    "colorBackgroundDropdownItemFilterMatch",
    "colorBackgroundDropdownItemHover",
    "colorBackgroundDropdownItemSelected",
    "colorBackgroundHomeHeader",
    "colorBackgroundInputDefault",
    "colorBackgroundInputDisabled",
    "colorBackgroundItemSelected",
    "colorBackgroundLayoutMain",
    "colorBackgroundLayoutToolbar",
    "colorBackgroundLayoutToggleActive",
    "colorBackgroundLayoutToggleDefault",
    "colorBackgroundLayoutToggleHover",
    "colorBackgroundLayoutToggleSelectedActive",
    "colorBackgroundLayoutToggleSelectedDefault",
    "colorBackgroundLayoutToggleSelectedHover",
    "colorBackgroundNotificationBlue",
    "colorBackgroundNotificationGreen",
    "colorBackgroundNotificationGrey",
    "colorBackgroundNotificationRed",
    "colorBackgroundNotificationYellow",
    "colorBackgroundPopover",
    "colorBackgroundProgressBarValueDefault",
    "colorBackgroundProgressBarDefault",
    "colorBackgroundSegmentActive",
    "colorBackgroundSegmentDefault",
    "colorBackgroundSegmentDisabled",
    "colorBackgroundSegmentHover",
    "colorBackgroundSegmentWrapper",
    "colorBackgroundSliderRangeDefault",
    "colorBackgroundSliderRangeActive",
    "colorBackgroundSliderHandleDefault",
    "colorBackgroundSliderHandleActive",
    "colorBackgroundSliderTrackDefault",
    "colorBackgroundStatusError",
    "colorBackgroundStatusInfo",
    "colorBackgroundDialog",
    "colorBackgroundStatusSuccess",
    "colorBackgroundStatusWarning",
    "colorBackgroundToggleCheckedDisabled",
    "colorBackgroundAvatarGenAi",
    "colorBackgroundAvatarDefault",
    "colorTextAvatar",
    "colorBackgroundLoadingBarGenAi",
    "colorBackgroundChatBubbleOutgoing",
    "colorBackgroundChatBubbleIncoming",
    "colorTextChatBubbleOutgoing",
    "colorTextChatBubbleIncoming",
    "colorBorderButtonLinkDisabled",
    "colorBorderButtonNormalActive",
    "colorBorderButtonNormalDefault",
    "colorBorderToggleButtonNormalPressed",
    "colorBorderButtonNormalDisabled",
    "colorTextButtonNormalDisabled",
    "colorBorderButtonNormalHover",
    "colorTextButtonIconDisabled",
    "colorBorderButtonPrimaryActive",
    "colorBorderButtonPrimaryDefault",
    "colorBorderButtonPrimaryDisabled",
    "colorBorderButtonPrimaryHover",
    "colorTextButtonPrimaryDisabled",
    "colorItemSelected",
    "colorBorderCard",
    "colorBorderContainerTop",
    "colorBorderControlDefault",
    "colorBorderDividerDefault",
    "colorBorderDividerSecondary",
    "colorBorderDropdownContainer",
    "colorBorderDropdownItemHover",
    "colorBorderInputDefault",
    "colorBorderInputFocused",
    "colorBorderItemFocused",
    "colorBorderDropdownItemFocused",
    "colorBorderItemSelected",
    "colorBorderPopover",
    "colorBorderSegmentActive",
    "colorBorderSegmentDefault",
    "colorBorderSegmentDisabled",
    "colorBorderSegmentHover",
    "colorBorderStatusError",
    "colorBorderStatusInfo",
    "colorBorderStatusSuccess",
    "colorBorderStatusWarning",
    "colorBorderDialog",
    "colorForegroundControlDefault",
    "colorForegroundControlDisabled",
    "colorForegroundControlReadOnly",
    "colorTextAccent",
    "colorTextBodyDefault",
    "colorTextBodySecondary",
    "colorTextBreadcrumbCurrent",
    "colorTextBreadcrumbIcon",
    "colorTextButtonInlineIconDefault",
    "colorTextButtonInlineIconDisabled",
    "colorTextButtonInlineIconHover",
    "colorTextButtonNormalActive",
    "colorTextToggleButtonNormalPressed",
    "colorTextButtonNormalDefault",
    "colorTextButtonNormalHover",
    "colorTextButtonLinkActive",
    "colorTextButtonLinkDefault",
    "colorTextButtonLinkDisabled",
    "colorTextButtonLinkHover",
    "colorTextButtonPrimaryActive",
    "colorTextButtonPrimaryDefault",
    "colorTextButtonPrimaryHover",
    "colorTextCounter",
    "colorTextDropdownItemDefault",
    "colorTextDropdownItemDisabled",
    "colorTextDropdownItemFilterMatch",
    "colorTextDropdownItemHighlighted",
    "colorTextDropdownItemSecondary",
    "colorTextEmpty",
    "colorTextFormDefault",
    "colorTextFormSecondary",
    "colorTextGroupLabel",
    "colorTextLabelGenAi",
    "colorTextHeadingDefault",
    "colorTextHeadingSecondary",
    "colorTextHomeHeaderDefault",
    "colorTextHomeHeaderSecondary",
    "colorTextIconSubtle",
    "colorTextInputDisabled",
    "colorTextInputPlaceholder",
    "colorTextInteractiveActive",
    "colorTextInteractiveDefault",
    "colorTextInteractiveDisabled",
    "colorTextInteractiveHover",
    "colorTextToggleButtonIconPressed",
    "colorTextInteractiveInvertedDefault",
    "colorTextInteractiveInvertedHover",
    "colorTextLabel",
    "colorTextLayoutToggle",
    "colorTextLayoutToggleActive",
    "colorTextLayoutToggleHover",
    "colorTextLayoutToggleSelected",
    "colorTextLinkDefault",
    "colorTextLinkHover",
    "colorTextLinkSecondaryDefault",
    "colorTextLinkSecondaryHover",
    "colorTextLinkInfoDefault",
    "colorTextLinkInfoHover",
    "colorTextNotificationDefault",
    "colorTextSegmentActive",
    "colorTextSegmentDefault",
    "colorTextSegmentHover",
    "colorTextStatusError",
    "colorTextStatusInactive",
    "colorTextStatusInfo",
    "colorTextStatusSuccess",
    "colorTextStatusWarning",
    "colorTextTopNavigationTitle",
    "colorBoardPlaceholderActive",
    "colorBoardPlaceholderHover",
    "colorDragPlaceholderActive",
    "colorDragPlaceholderHover",
    "colorDropzoneBackgroundDefault",
    "colorDropzoneBackgroundHover",
    "colorDropzoneTextDefault",
    "colorDropzoneTextHover",
    "colorDropzoneBorderDefault",
    "colorDropzoneBorderHover",
    "colorTreeViewConnectorLine",
    "colorBackgroundActionCardDefault",
    "colorBackgroundActionCardHover",
    "colorBackgroundActionCardActive",
    "colorBorderActionCardDefault",
    "colorBorderActionCardHover",
    "colorBorderActionCardActive",
    "colorBorderActionCardDisabled",
    "colorBackgroundActionCardDisabled",
    "colorTextActionCardDisabled",
    "fontFamilyBase",
    "fontFamilyDisplay",
    "fontFamilyHeading",
    "fontFamilyMonospace",
    "fontSizeBodyM",
    "fontSizeBodyS",
    "fontSizeDisplayL",
    "fontSizeHeadingL",
    "fontSizeHeadingM",
    "fontSizeHeadingS",
    "fontSizeHeadingXl",
    "fontSizeHeadingXs",
    "fontSizeTabs",
    "fontWeightAlertHeader",
    "fontWeightBold",
    "fontWeightButton",
    "fontWeightDisplayL",
    "fontWeightFlashbarHeader",
    "fontWeightHeadingL",
    "fontWeightHeadingM",
    "fontWeightHeadingS",
    "fontWeightHeadingXl",
    "fontWeightHeadingXs",
    "fontWeightHeavy",
    "fontWeightLighter",
    "fontWeightNormal",
    "fontWeightTabs",
    "fontWeightTabsDisabled",
    "letterSpacingDisplayL",
    "letterSpacingHeadingL",
    "letterSpacingHeadingM",
    "letterSpacingHeadingS",
    "letterSpacingHeadingXl",
    "letterSpacingHeadingXs",
    "lineHeightBodyM",
    "lineHeightBodyS",
    "lineHeightDisplayL",
    "lineHeightHeadingL",
    "lineHeightHeadingM",
    "lineHeightHeadingS",
    "lineHeightHeadingXl",
    "lineHeightHeadingXs",
    "lineHeightTabs",
    "borderRadiusAlert",
    "borderRadiusBadge",
    "borderRadiusButton",
    "borderRadiusCalendarDayFocusRing",
    "borderRadiusCardDefault",
    "borderRadiusCardEmbedded",
    "borderRadiusContainer",
    "borderRadiusControlCircularFocusRing",
    "borderRadiusControlDefaultFocusRing",
    "borderRadiusDropdown",
    "borderRadiusDropzone",
    "borderRadiusFlashbar",
    "borderRadiusItem",
    "borderRadiusInput",
    "borderRadiusPopover",
    "borderRadiusTabsFocusRing",
    "borderRadiusTiles",
    "borderRadiusToken",
    "borderRadiusChatBubble",
    "borderRadiusTutorialPanelItem",
    "borderWidthCard",
    "borderWidthCardSelected",
    "borderWidthItemSelected",
    "borderWidthAlert",
    "borderWidthAlertBlockStart",
    "borderWidthAlertBlockEnd",
    "borderWidthAlertInlineStart",
    "borderWidthAlertInlineEnd",
    "borderWidthButton",
    "borderWidthDropdown",
    "borderWidthField",
    "borderWidthPopover",
    "borderWidthToken",
    "borderWidthIconSmall",
    "borderWidthIconNormal",
    "borderWidthIconMedium",
    "borderWidthIconBig",
    "borderWidthIconLarge",
    "borderRadiusActionCardDefault",
    "borderRadiusActionCardEmbedded",
    "borderWidthActionCardDefault",
    "borderWidthActionCardHover",
    "borderWidthActionCardActive",
    "borderWidthActionCardDisabled",
    "motionDurationAvatarGenAiGradient",
    "motionDurationAvatarLoadingDots",
    "motionEasingAvatarGenAiGradient",
    "motionEasingResponsive",
    "motionEasingSticky",
    "motionEasingExpressive",
    "motionDurationResponsive",
    "motionDurationExpressive",
    "motionDurationComplex",
    "motionKeyframesFadeIn",
    "motionKeyframesFadeOut",
    "motionKeyframesStatusIconError",
    "motionKeyframesScalePopup",
    "sizeVerticalInput",
    "spaceAlertVertical",
    "spaceButtonHorizontal",
    "spaceButtonVertical",
    "spaceTokenVertical",
    "spaceFieldVertical",
    "spaceCardHorizontalDefault",
    "spaceCardHorizontalEmbedded",
    "spaceCardVerticalDefault",
    "spaceCardVerticalEmbedded",
    "spaceContainerHorizontal",
    "spaceFieldHorizontal",
    "spaceTabsVertical",
    "spaceTreeViewIndentation",
    "spaceActionCardHorizontalDefault",
    "spaceActionCardHorizontalEmbedded",
    "spaceActionCardVerticalDefault",
    "spaceActionCardVerticalEmbedded",
    "spaceOptionPaddingVertical",
    "spaceOptionPaddingHorizontal",
    "spaceScaledXxxs",
    "spaceScaledXxs",
    "spaceScaledXs",
    "spaceScaledS",
    "spaceScaledM",
    "spaceScaledL",
    "spaceScaledXl",
    "spaceScaledXxl",
    "spaceScaledXxxl",
    "spaceStaticXxxs",
    "spaceStaticXxs",
    "spaceStaticXs",
    "spaceStaticS",
    "spaceStaticM",
    "spaceStaticL",
    "spaceStaticXl",
    "spaceStaticXxl",
    "spaceStaticXxxl",
    "shadowCard",
    "shadowContainerActive"
  ],
  "variablesMap": {
    "colorPrimary50": "color-primary-50",
    "colorPrimary100": "color-primary-100",
    "colorPrimary200": "color-primary-200",
    "colorPrimary300": "color-primary-300",
    "colorPrimary400": "color-primary-400",
    "colorPrimary500": "color-primary-500",
    "colorPrimary600": "color-primary-600",
    "colorPrimary700": "color-primary-700",
    "colorPrimary800": "color-primary-800",
    "colorPrimary900": "color-primary-900",
    "colorPrimary1000": "color-primary-1000",
    "colorNeutral50": "color-neutral-50",
    "colorNeutral100": "color-neutral-100",
    "colorNeutral150": "color-neutral-150",
    "colorNeutral200": "color-neutral-200",
    "colorNeutral250": "color-neutral-250",
    "colorNeutral300": "color-neutral-300",
    "colorNeutral350": "color-neutral-350",
    "colorNeutral400": "color-neutral-400",
    "colorNeutral450": "color-neutral-450",
    "colorNeutral500": "color-neutral-500",
    "colorNeutral550": "color-neutral-550",
    "colorNeutral600": "color-neutral-600",
    "colorNeutral650": "color-neutral-650",
    "colorNeutral700": "color-neutral-700",
    "colorNeutral750": "color-neutral-750",
    "colorNeutral800": "color-neutral-800",
    "colorNeutral850": "color-neutral-850",
    "colorNeutral900": "color-neutral-900",
    "colorNeutral950": "color-neutral-950",
    "colorNeutral1000": "color-neutral-1000",
    "colorError50": "color-error-50",
    "colorError400": "color-error-400",
    "colorError600": "color-error-600",
    "colorError900": "color-error-900",
    "colorError1000": "color-error-1000",
    "colorSuccess50": "color-success-50",
    "colorSuccess500": "color-success-500",
    "colorSuccess600": "color-success-600",
    "colorSuccess1000": "color-success-1000",
    "colorWarning50": "color-warning-50",
    "colorWarning400": "color-warning-400",
    "colorWarning500": "color-warning-500",
    "colorWarning900": "color-warning-900",
    "colorWarning1000": "color-warning-1000",
    "colorInfo50": "color-info-50",
    "colorInfo300": "color-info-300",
    "colorInfo400": "color-info-400",
    "colorInfo600": "color-info-600",
    "colorInfo1000": "color-info-1000",
    "colorGrey50": "color-grey-50",
    "colorGrey100": "color-grey-100",
    "colorGrey150": "color-grey-150",
    "colorGrey200": "color-grey-200",
    "colorGrey250": "color-grey-250",
    "colorGrey300": "color-grey-300",
    "colorGrey350": "color-grey-350",
    "colorGrey400": "color-grey-400",
    "colorGrey450": "color-grey-450",
    "colorGrey500": "color-grey-500",
    "colorGrey600": "color-grey-600",
    "colorGrey650": "color-grey-650",
    "colorGrey700": "color-grey-700",
    "colorGrey750": "color-grey-750",
    "colorGrey800": "color-grey-800",
    "colorGrey850": "color-grey-850",
    "colorGrey900": "color-grey-900",
    "colorGrey950": "color-grey-950",
    "colorGrey1000": "color-grey-1000",
    "colorBlue50": "color-blue-50",
    "colorBlue100": "color-blue-100",
    "colorBlue200": "color-blue-200",
    "colorBlue300": "color-blue-300",
    "colorBlue400": "color-blue-400",
    "colorBlue600": "color-blue-600",
    "colorBlue700": "color-blue-700",
    "colorBlue900": "color-blue-900",
    "colorBlue1000": "color-blue-1000",
    "colorGreen50": "color-green-50",
    "colorGreen500": "color-green-500",
    "colorGreen600": "color-green-600",
    "colorGreen900": "color-green-900",
    "colorGreen1000": "color-green-1000",
    "colorRed50": "color-red-50",
    "colorRed400": "color-red-400",
    "colorRed600": "color-red-600",
    "colorRed900": "color-red-900",
    "colorRed1000": "color-red-1000",
    "colorYellow50": "color-yellow-50",
    "colorYellow400": "color-yellow-400",
    "colorYellow500": "color-yellow-500",
    "colorYellow900": "color-yellow-900",
    "colorYellow1000": "color-yellow-1000",
    "colorPurple400": "color-purple-400",
    "colorPurple700": "color-purple-700",
    "colorAmber400": "color-amber-400",
    "colorAmber500": "color-amber-500",
    "colorAwsSquidInk": "color-aws-squid-ink",
    "colorTransparent": "color-transparent",
    "colorBlack": "color-black",
    "colorWhite": "color-white",
    "colorChartsRed300": "color-charts-red-300",
    "colorChartsRed400": "color-charts-red-400",
    "colorChartsRed500": "color-charts-red-500",
    "colorChartsRed600": "color-charts-red-600",
    "colorChartsRed700": "color-charts-red-700",
    "colorChartsRed800": "color-charts-red-800",
    "colorChartsRed900": "color-charts-red-900",
    "colorChartsRed1000": "color-charts-red-1000",
    "colorChartsRed1100": "color-charts-red-1100",
    "colorChartsRed1200": "color-charts-red-1200",
    "colorChartsOrange300": "color-charts-orange-300",
    "colorChartsOrange400": "color-charts-orange-400",
    "colorChartsOrange500": "color-charts-orange-500",
    "colorChartsOrange600": "color-charts-orange-600",
    "colorChartsOrange700": "color-charts-orange-700",
    "colorChartsOrange800": "color-charts-orange-800",
    "colorChartsOrange900": "color-charts-orange-900",
    "colorChartsOrange1000": "color-charts-orange-1000",
    "colorChartsOrange1100": "color-charts-orange-1100",
    "colorChartsOrange1200": "color-charts-orange-1200",
    "colorChartsYellow300": "color-charts-yellow-300",
    "colorChartsYellow400": "color-charts-yellow-400",
    "colorChartsYellow500": "color-charts-yellow-500",
    "colorChartsYellow600": "color-charts-yellow-600",
    "colorChartsYellow700": "color-charts-yellow-700",
    "colorChartsYellow800": "color-charts-yellow-800",
    "colorChartsYellow900": "color-charts-yellow-900",
    "colorChartsYellow1000": "color-charts-yellow-1000",
    "colorChartsYellow1100": "color-charts-yellow-1100",
    "colorChartsYellow1200": "color-charts-yellow-1200",
    "colorChartsGreen300": "color-charts-green-300",
    "colorChartsGreen400": "color-charts-green-400",
    "colorChartsGreen500": "color-charts-green-500",
    "colorChartsGreen600": "color-charts-green-600",
    "colorChartsGreen700": "color-charts-green-700",
    "colorChartsGreen800": "color-charts-green-800",
    "colorChartsGreen900": "color-charts-green-900",
    "colorChartsGreen1000": "color-charts-green-1000",
    "colorChartsGreen1100": "color-charts-green-1100",
    "colorChartsGreen1200": "color-charts-green-1200",
    "colorChartsTeal300": "color-charts-teal-300",
    "colorChartsTeal400": "color-charts-teal-400",
    "colorChartsTeal500": "color-charts-teal-500",
    "colorChartsTeal600": "color-charts-teal-600",
    "colorChartsTeal700": "color-charts-teal-700",
    "colorChartsTeal800": "color-charts-teal-800",
    "colorChartsTeal900": "color-charts-teal-900",
    "colorChartsTeal1000": "color-charts-teal-1000",
    "colorChartsTeal1100": "color-charts-teal-1100",
    "colorChartsTeal1200": "color-charts-teal-1200",
    "colorChartsBlue1300": "color-charts-blue-1-300",
    "colorChartsBlue1400": "color-charts-blue-1-400",
    "colorChartsBlue1500": "color-charts-blue-1-500",
    "colorChartsBlue1600": "color-charts-blue-1-600",
    "colorChartsBlue1700": "color-charts-blue-1-700",
    "colorChartsBlue1800": "color-charts-blue-1-800",
    "colorChartsBlue1900": "color-charts-blue-1-900",
    "colorChartsBlue11000": "color-charts-blue-1-1000",
    "colorChartsBlue11100": "color-charts-blue-1-1100",
    "colorChartsBlue11200": "color-charts-blue-1-1200",
    "colorChartsBlue2300": "color-charts-blue-2-300",
    "colorChartsBlue2400": "color-charts-blue-2-400",
    "colorChartsBlue2500": "color-charts-blue-2-500",
    "colorChartsBlue2600": "color-charts-blue-2-600",
    "colorChartsBlue2700": "color-charts-blue-2-700",
    "colorChartsBlue2800": "color-charts-blue-2-800",
    "colorChartsBlue2900": "color-charts-blue-2-900",
    "colorChartsBlue21000": "color-charts-blue-2-1000",
    "colorChartsBlue21100": "color-charts-blue-2-1100",
    "colorChartsBlue21200": "color-charts-blue-2-1200",
    "colorChartsPurple300": "color-charts-purple-300",
    "colorChartsPurple400": "color-charts-purple-400",
    "colorChartsPurple500": "color-charts-purple-500",
    "colorChartsPurple600": "color-charts-purple-600",
    "colorChartsPurple700": "color-charts-purple-700",
    "colorChartsPurple800": "color-charts-purple-800",
    "colorChartsPurple900": "color-charts-purple-900",
    "colorChartsPurple1000": "color-charts-purple-1000",
    "colorChartsPurple1100": "color-charts-purple-1100",
    "colorChartsPurple1200": "color-charts-purple-1200",
    "colorChartsPink300": "color-charts-pink-300",
    "colorChartsPink400": "color-charts-pink-400",
    "colorChartsPink500": "color-charts-pink-500",
    "colorChartsPink600": "color-charts-pink-600",
    "colorChartsPink700": "color-charts-pink-700",
    "colorChartsPink800": "color-charts-pink-800",
    "colorChartsPink900": "color-charts-pink-900",
    "colorChartsPink1000": "color-charts-pink-1000",
    "colorChartsPink1100": "color-charts-pink-1100",
    "colorChartsPink1200": "color-charts-pink-1200",
    "colorChartsStatusCritical": "color-charts-status-critical",
    "colorChartsStatusHigh": "color-charts-status-high",
    "colorChartsStatusMedium": "color-charts-status-medium",
    "colorChartsStatusLow": "color-charts-status-low",
    "colorChartsStatusPositive": "color-charts-status-positive",
    "colorChartsStatusInfo": "color-charts-status-info",
    "colorChartsStatusNeutral": "color-charts-status-neutral",
    "colorChartsThresholdNegative": "color-charts-threshold-negative",
    "colorChartsThresholdPositive": "color-charts-threshold-positive",
    "colorChartsThresholdInfo": "color-charts-threshold-info",
    "colorChartsThresholdNeutral": "color-charts-threshold-neutral",
    "colorChartsLineGrid": "color-charts-line-grid",
    "colorChartsLineTick": "color-charts-line-tick",
    "colorChartsLineAxis": "color-charts-line-axis",
    "colorChartsPaletteCategorical1": "color-charts-palette-categorical-1",
    "colorChartsPaletteCategorical2": "color-charts-palette-categorical-2",
    "colorChartsPaletteCategorical3": "color-charts-palette-categorical-3",
    "colorChartsPaletteCategorical4": "color-charts-palette-categorical-4",
    "colorChartsPaletteCategorical5": "color-charts-palette-categorical-5",
    "colorChartsPaletteCategorical6": "color-charts-palette-categorical-6",
    "colorChartsPaletteCategorical7": "color-charts-palette-categorical-7",
    "colorChartsPaletteCategorical8": "color-charts-palette-categorical-8",
    "colorChartsPaletteCategorical9": "color-charts-palette-categorical-9",
    "colorChartsPaletteCategorical10": "color-charts-palette-categorical-10",
    "colorChartsPaletteCategorical11": "color-charts-palette-categorical-11",
    "colorChartsPaletteCategorical12": "color-charts-palette-categorical-12",
    "colorChartsPaletteCategorical13": "color-charts-palette-categorical-13",
    "colorChartsPaletteCategorical14": "color-charts-palette-categorical-14",
    "colorChartsPaletteCategorical15": "color-charts-palette-categorical-15",
    "colorChartsPaletteCategorical16": "color-charts-palette-categorical-16",
    "colorChartsPaletteCategorical17": "color-charts-palette-categorical-17",
    "colorChartsPaletteCategorical18": "color-charts-palette-categorical-18",
    "colorChartsPaletteCategorical19": "color-charts-palette-categorical-19",
    "colorChartsPaletteCategorical20": "color-charts-palette-categorical-20",
    "colorChartsPaletteCategorical21": "color-charts-palette-categorical-21",
    "colorChartsPaletteCategorical22": "color-charts-palette-categorical-22",
    "colorChartsPaletteCategorical23": "color-charts-palette-categorical-23",
    "colorChartsPaletteCategorical24": "color-charts-palette-categorical-24",
    "colorChartsPaletteCategorical25": "color-charts-palette-categorical-25",
    "colorChartsPaletteCategorical26": "color-charts-palette-categorical-26",
    "colorChartsPaletteCategorical27": "color-charts-palette-categorical-27",
    "colorChartsPaletteCategorical28": "color-charts-palette-categorical-28",
    "colorChartsPaletteCategorical29": "color-charts-palette-categorical-29",
    "colorChartsPaletteCategorical30": "color-charts-palette-categorical-30",
    "colorChartsPaletteCategorical31": "color-charts-palette-categorical-31",
    "colorChartsPaletteCategorical32": "color-charts-palette-categorical-32",
    "colorChartsPaletteCategorical33": "color-charts-palette-categorical-33",
    "colorChartsPaletteCategorical34": "color-charts-palette-categorical-34",
    "colorChartsPaletteCategorical35": "color-charts-palette-categorical-35",
    "colorChartsPaletteCategorical36": "color-charts-palette-categorical-36",
    "colorChartsPaletteCategorical37": "color-charts-palette-categorical-37",
    "colorChartsPaletteCategorical38": "color-charts-palette-categorical-38",
    "colorChartsPaletteCategorical39": "color-charts-palette-categorical-39",
    "colorChartsPaletteCategorical40": "color-charts-palette-categorical-40",
    "colorChartsPaletteCategorical41": "color-charts-palette-categorical-41",
    "colorChartsPaletteCategorical42": "color-charts-palette-categorical-42",
    "colorChartsPaletteCategorical43": "color-charts-palette-categorical-43",
    "colorChartsPaletteCategorical44": "color-charts-palette-categorical-44",
    "colorChartsPaletteCategorical45": "color-charts-palette-categorical-45",
    "colorChartsPaletteCategorical46": "color-charts-palette-categorical-46",
    "colorChartsPaletteCategorical47": "color-charts-palette-categorical-47",
    "colorChartsPaletteCategorical48": "color-charts-palette-categorical-48",
    "colorChartsPaletteCategorical49": "color-charts-palette-categorical-49",
    "colorChartsPaletteCategorical50": "color-charts-palette-categorical-50",
    "colorChartsErrorBarMarker": "color-charts-error-bar-marker",
    "colorSeverityDarkRed": "color-severity-dark-red",
    "colorSeverityRed": "color-severity-red",
    "colorSeverityOrange": "color-severity-orange",
    "colorSeverityYellow": "color-severity-yellow",
    "colorSeverityGrey": "color-severity-grey",
    "colorBackgroundNotificationSeverityCritical": "color-background-notification-severity-critical",
    "colorBackgroundNotificationSeverityHigh": "color-background-notification-severity-high",
    "colorBackgroundNotificationSeverityMedium": "color-background-notification-severity-medium",
    "colorBackgroundNotificationSeverityLow": "color-background-notification-severity-low",
    "colorBackgroundNotificationSeverityNeutral": "color-background-notification-severity-neutral",
    "colorTextNotificationSeverityCritical": "color-text-notification-severity-critical",
    "colorTextNotificationSeverityHigh": "color-text-notification-severity-high",
    "colorTextNotificationSeverityMedium": "color-text-notification-severity-medium",
    "colorTextNotificationSeverityLow": "color-text-notification-severity-low",
    "colorTextNotificationSeverityNeutral": "color-text-notification-severity-neutral",
    "colorGreyOpaque10": "color-grey-opaque-10",
    "colorGreyOpaque25": "color-grey-opaque-25",
    "colorGreyOpaque40": "color-grey-opaque-40",
    "colorGreyOpaque50": "color-grey-opaque-50",
    "colorGreyOpaque70": "color-grey-opaque-70",
    "colorGreyOpaque80": "color-grey-opaque-80",
    "colorGreyOpaque90": "color-grey-opaque-90",
    "colorGreyTransparent": "color-grey-transparent",
    "colorGreyTransparentHeavy": "color-grey-transparent-heavy",
    "colorGreyTransparentLight": "color-grey-transparent-light",
    "colorBackgroundBadgeIcon": "color-background-badge-icon",
    "colorBackgroundButtonLinkActive": "color-background-button-link-active",
    "colorBackgroundButtonLinkDefault": "color-background-button-link-default",
    "colorBackgroundButtonLinkDisabled": "color-background-button-link-disabled",
    "colorBackgroundButtonLinkHover": "color-background-button-link-hover",
    "colorBackgroundButtonNormalActive": "color-background-button-normal-active",
    "colorBackgroundButtonNormalDefault": "color-background-button-normal-default",
    "colorBackgroundButtonNormalDisabled": "color-background-button-normal-disabled",
    "colorBackgroundButtonNormalHover": "color-background-button-normal-hover",
    "colorBackgroundToggleButtonNormalPressed": "color-background-toggle-button-normal-pressed",
    "colorBackgroundButtonPrimaryActive": "color-background-button-primary-active",
    "colorBackgroundButtonPrimaryDefault": "color-background-button-primary-default",
    "colorBackgroundButtonPrimaryDisabled": "color-background-button-primary-disabled",
    "colorBackgroundButtonPrimaryHover": "color-background-button-primary-hover",
    "colorBackgroundDirectionButtonActive": "color-background-direction-button-active",
    "colorBackgroundDirectionButtonDefault": "color-background-direction-button-default",
    "colorBackgroundDirectionButtonDisabled": "color-background-direction-button-disabled",
    "colorBackgroundDirectionButtonHover": "color-background-direction-button-hover",
    "colorTextDirectionButtonDefault": "color-text-direction-button-default",
    "colorTextDirectionButtonDisabled": "color-text-direction-button-disabled",
    "colorBackgroundCalendarCurrentDate": "color-background-calendar-current-date",
    "colorBackgroundCellShaded": "color-background-cell-shaded",
    "colorBackgroundCodeEditorGutterActiveLineDefault": "color-background-code-editor-gutter-active-line-default",
    "colorBackgroundCodeEditorGutterActiveLineError": "color-background-code-editor-gutter-active-line-error",
    "colorBackgroundCodeEditorGutterDefault": "color-background-code-editor-gutter-default",
    "colorBackgroundCodeEditorLoading": "color-background-code-editor-loading",
    "colorBackgroundCodeEditorPaneItemHover": "color-background-code-editor-pane-item-hover",
    "colorBackgroundCodeEditorStatusBar": "color-background-code-editor-status-bar",
    "colorBackgroundCard": "color-background-card",
    "colorBackgroundItemCard": "color-background-item-card",
    "colorBackgroundContainerContent": "color-background-container-content",
    "colorBackgroundContainerHeader": "color-background-container-header",
    "colorBackgroundControlChecked": "color-background-control-checked",
    "colorBackgroundControlDefault": "color-background-control-default",
    "colorBackgroundControlDisabled": "color-background-control-disabled",
    "colorBackgroundDropdownItemDefault": "color-background-dropdown-item-default",
    "colorBackgroundDropdownItemDimmed": "color-background-dropdown-item-dimmed",
    "colorBackgroundDropdownItemFilterMatch": "color-background-dropdown-item-filter-match",
    "colorBackgroundDropdownItemHover": "color-background-dropdown-item-hover",
    "colorBackgroundDropdownItemSelected": "color-background-dropdown-item-selected",
    "colorBackgroundHomeHeader": "color-background-home-header",
    "colorBackgroundInlineCode": "color-background-inline-code",
    "colorBackgroundInputDefault": "color-background-input-default",
    "colorBackgroundInputDisabled": "color-background-input-disabled",
    "colorBackgroundItemSelected": "color-background-item-selected",
    "colorBackgroundLayoutMain": "color-background-layout-main",
    "colorBackgroundDrawer": "color-background-drawer",
    "colorBackgroundDrawerBackdrop": "color-background-drawer-backdrop",
    "colorBackgroundLayoutMobilePanel": "color-background-layout-mobile-panel",
    "colorBackgroundLayoutPanelContent": "color-background-layout-panel-content",
    "colorBackgroundLayoutPanelHover": "color-background-layout-panel-hover",
    "colorBackgroundLayoutToolbar": "color-background-layout-toolbar",
    "colorBackgroundLayoutToggleActive": "color-background-layout-toggle-active",
    "colorBackgroundLayoutToggleDefault": "color-background-layout-toggle-default",
    "colorBackgroundLayoutToggleHover": "color-background-layout-toggle-hover",
    "colorBackgroundLayoutToggleSelectedActive": "color-background-layout-toggle-selected-active",
    "colorBackgroundLayoutToggleSelectedDefault": "color-background-layout-toggle-selected-default",
    "colorBackgroundLayoutToggleSelectedHover": "color-background-layout-toggle-selected-hover",
    "colorBackgroundModalOverlay": "color-background-modal-overlay",
    "colorBackgroundNotificationBlue": "color-background-notification-blue",
    "colorBackgroundNotificationGreen": "color-background-notification-green",
    "colorBackgroundNotificationGrey": "color-background-notification-grey",
    "colorBackgroundNotificationRed": "color-background-notification-red",
    "colorBackgroundNotificationYellow": "color-background-notification-yellow",
    "colorBackgroundNotificationStackBar": "color-background-notification-stack-bar",
    "colorBackgroundNotificationStackBarActive": "color-background-notification-stack-bar-active",
    "colorBackgroundNotificationStackBarHover": "color-background-notification-stack-bar-hover",
    "colorBackgroundPopover": "color-background-popover",
    "colorBackgroundProgressBarValueDefault": "color-background-progress-bar-value-default",
    "colorBackgroundProgressBarDefault": "color-background-progress-bar-default",
    "colorBackgroundSegmentActive": "color-background-segment-active",
    "colorBackgroundSegmentDefault": "color-background-segment-default",
    "colorBackgroundSegmentDisabled": "color-background-segment-disabled",
    "colorBackgroundSegmentHover": "color-background-segment-hover",
    "colorBackgroundSegmentWrapper": "color-background-segment-wrapper",
    "colorBackgroundSliderRangeDefault": "color-background-slider-range-default",
    "colorBackgroundSliderRangeActive": "color-background-slider-range-active",
    "colorBackgroundSliderHandleDefault": "color-background-slider-handle-default",
    "colorBackgroundSliderHandleActive": "color-background-slider-handle-active",
    "colorBackgroundSliderTrackDefault": "color-background-slider-track-default",
    "colorBackgroundSliderHandleRing": "color-background-slider-handle-ring",
    "colorBackgroundSliderHandleErrorDefault": "color-background-slider-handle-error-default",
    "colorBackgroundSliderHandleErrorActive": "color-background-slider-handle-error-active",
    "colorBackgroundSliderHandleWarningDefault": "color-background-slider-handle-warning-default",
    "colorBackgroundSliderHandleWarningActive": "color-background-slider-handle-warning-active",
    "colorBackgroundSliderRangeErrorDefault": "color-background-slider-range-error-default",
    "colorBackgroundSliderRangeErrorActive": "color-background-slider-range-error-active",
    "colorBackgroundSliderRangeWarningDefault": "color-background-slider-range-warning-default",
    "colorBackgroundSliderRangeWarningActive": "color-background-slider-range-warning-active",
    "colorBackgroundStatusError": "color-background-status-error",
    "colorBackgroundStatusInfo": "color-background-status-info",
    "colorBackgroundDialog": "color-background-dialog",
    "colorBackgroundStatusSuccess": "color-background-status-success",
    "colorBackgroundStatusWarning": "color-background-status-warning",
    "colorBackgroundTableHeader": "color-background-table-header",
    "colorBackgroundTilesDisabled": "color-background-tiles-disabled",
    "colorBackgroundToggleCheckedDisabled": "color-background-toggle-checked-disabled",
    "colorBackgroundToggleDefault": "color-background-toggle-default",
    "colorBackgroundAvatarGenAi": "color-background-avatar-gen-ai",
    "colorBackgroundAvatarDefault": "color-background-avatar-default",
    "colorTextAvatar": "color-text-avatar",
    "colorBackgroundLoadingBarGenAi": "color-background-loading-bar-gen-ai",
    "colorBackgroundChatBubbleOutgoing": "color-background-chat-bubble-outgoing",
    "colorBackgroundChatBubbleIncoming": "color-background-chat-bubble-incoming",
    "colorTextChatBubbleOutgoing": "color-text-chat-bubble-outgoing",
    "colorTextChatBubbleIncoming": "color-text-chat-bubble-incoming",
    "colorBorderButtonLinkDisabled": "color-border-button-link-disabled",
    "colorBorderButtonNormalActive": "color-border-button-normal-active",
    "colorBorderButtonNormalDefault": "color-border-button-normal-default",
    "colorBorderToggleButtonNormalPressed": "color-border-toggle-button-normal-pressed",
    "colorBorderButtonNormalDisabled": "color-border-button-normal-disabled",
    "colorTextButtonNormalDisabled": "color-text-button-normal-disabled",
    "colorBorderButtonNormalHover": "color-border-button-normal-hover",
    "colorTextButtonIconDisabled": "color-text-button-icon-disabled",
    "colorBorderButtonPrimaryActive": "color-border-button-primary-active",
    "colorBorderButtonPrimaryDefault": "color-border-button-primary-default",
    "colorBorderButtonPrimaryDisabled": "color-border-button-primary-disabled",
    "colorBorderButtonPrimaryHover": "color-border-button-primary-hover",
    "colorTextButtonPrimaryDisabled": "color-text-button-primary-disabled",
    "colorItemSelected": "color-item-selected",
    "colorBorderCalendarGrid": "color-border-calendar-grid",
    "colorBorderCalendarGridSelectedFocusRing": "color-border-calendar-grid-selected-focus-ring",
    "colorBorderCellShaded": "color-border-cell-shaded",
    "colorBorderCodeEditorAceActiveLineLightTheme": "color-border-code-editor-ace-active-line-light-theme",
    "colorBorderCodeEditorAceActiveLineDarkTheme": "color-border-code-editor-ace-active-line-dark-theme",
    "colorBorderCodeEditorDefault": "color-border-code-editor-default",
    "colorBorderCodeEditorPaneItemHover": "color-border-code-editor-pane-item-hover",
    "colorBorderCard": "color-border-card",
    "colorBorderCardHighlighted": "color-border-card-highlighted",
    "colorBorderItemCard": "color-border-item-card",
    "colorBorderItemCardHighlighted": "color-border-item-card-highlighted",
    "colorBorderContainerDivider": "color-border-container-divider",
    "colorBorderContainerTop": "color-border-container-top",
    "colorBorderControlChecked": "color-border-control-checked",
    "colorBorderControlDefault": "color-border-control-default",
    "colorBorderControlDisabled": "color-border-control-disabled",
    "colorBorderDividerActive": "color-border-divider-active",
    "colorBorderDividerDefault": "color-border-divider-default",
    "colorBorderDividerPanelBottom": "color-border-divider-panel-bottom",
    "colorBorderDividerPanelSide": "color-border-divider-panel-side",
    "colorBorderDividerSecondary": "color-border-divider-secondary",
    "colorBorderDropdownContainer": "color-border-dropdown-container",
    "colorBorderDropdownGroup": "color-border-dropdown-group",
    "colorBorderDropdownItemDefault": "color-border-dropdown-item-default",
    "colorBorderDropdownItemHover": "color-border-dropdown-item-hover",
    "colorBorderDropdownItemDimmedHover": "color-border-dropdown-item-dimmed-hover",
    "colorBorderDropdownItemSelected": "color-border-dropdown-item-selected",
    "colorBorderDropdownItemTop": "color-border-dropdown-item-top",
    "colorBorderEditableCellHover": "color-border-editable-cell-hover",
    "colorBorderInputDefault": "color-border-input-default",
    "colorBorderInputDisabled": "color-border-input-disabled",
    "colorBorderInputFocused": "color-border-input-focused",
    "colorBorderItemFocused": "color-border-item-focused",
    "colorBorderDropdownItemFocused": "color-border-dropdown-item-focused",
    "colorBorderItemPlaceholder": "color-border-item-placeholder",
    "colorBorderItemSelected": "color-border-item-selected",
    "colorBorderLayout": "color-border-layout",
    "colorBorderNotificationStackBar": "color-border-notification-stack-bar",
    "colorBorderPanelHeader": "color-border-panel-header",
    "colorBorderPopover": "color-border-popover",
    "colorBorderSegmentActive": "color-border-segment-active",
    "colorBorderSegmentDefault": "color-border-segment-default",
    "colorBorderSegmentDisabled": "color-border-segment-disabled",
    "colorBorderSegmentHover": "color-border-segment-hover",
    "colorBorderStatusError": "color-border-status-error",
    "colorBorderStatusInfo": "color-border-status-info",
    "colorBorderStatusSuccess": "color-border-status-success",
    "colorBorderStatusWarning": "color-border-status-warning",
    "colorBorderDialog": "color-border-dialog",
    "colorBorderDividerInteractiveDefault": "color-border-divider-interactive-default",
    "colorBorderTabsDivider": "color-border-tabs-divider",
    "colorBorderTabsShadow": "color-border-tabs-shadow",
    "colorBorderTabsUnderline": "color-border-tabs-underline",
    "colorBorderTilesDisabled": "color-border-tiles-disabled",
    "colorBorderTutorial": "color-border-tutorial",
    "colorForegroundControlDefault": "color-foreground-control-default",
    "colorForegroundControlDisabled": "color-foreground-control-disabled",
    "colorForegroundControlReadOnly": "color-foreground-control-read-only",
    "colorShadowDefault": "color-shadow-default",
    "colorShadowMedium": "color-shadow-medium",
    "colorShadowSide": "color-shadow-side",
    "colorStrokeChartLine": "color-stroke-chart-line",
    "colorStrokeCodeEditorGutterActiveLineDefault": "color-stroke-code-editor-gutter-active-line-default",
    "colorStrokeCodeEditorGutterActiveLineHover": "color-stroke-code-editor-gutter-active-line-hover",
    "colorTextAccent": "color-text-accent",
    "colorTextBodyDefault": "color-text-body-default",
    "colorTextBodySecondary": "color-text-body-secondary",
    "colorTextBreadcrumbCurrent": "color-text-breadcrumb-current",
    "colorTextBreadcrumbIcon": "color-text-breadcrumb-icon",
    "colorTextButtonInlineIconDefault": "color-text-button-inline-icon-default",
    "colorTextButtonInlineIconDisabled": "color-text-button-inline-icon-disabled",
    "colorTextButtonInlineIconHover": "color-text-button-inline-icon-hover",
    "colorTextButtonNormalActive": "color-text-button-normal-active",
    "colorTextToggleButtonNormalPressed": "color-text-toggle-button-normal-pressed",
    "colorTextButtonNormalDefault": "color-text-button-normal-default",
    "colorTextButtonNormalHover": "color-text-button-normal-hover",
    "colorTextLinkButtonNormalDefault": "color-text-link-button-normal-default",
    "colorTextLinkButtonNormalHover": "color-text-link-button-normal-hover",
    "colorTextLinkButtonNormalActive": "color-text-link-button-normal-active",
    "colorTextButtonLinkActive": "color-text-button-link-active",
    "colorTextButtonLinkDefault": "color-text-button-link-default",
    "colorTextButtonLinkDisabled": "color-text-button-link-disabled",
    "colorTextButtonLinkHover": "color-text-button-link-hover",
    "colorTextButtonPrimaryActive": "color-text-button-primary-active",
    "colorTextButtonPrimaryDefault": "color-text-button-primary-default",
    "colorTextButtonPrimaryHover": "color-text-button-primary-hover",
    "colorTextCalendarDateHover": "color-text-calendar-date-hover",
    "colorTextCalendarMonth": "color-text-calendar-month",
    "colorTextCodeEditorGutterActiveLine": "color-text-code-editor-gutter-active-line",
    "colorTextCodeEditorGutterDefault": "color-text-code-editor-gutter-default",
    "colorTextCodeEditorStatusBarDisabled": "color-text-code-editor-status-bar-disabled",
    "colorTextCodeEditorTabButtonError": "color-text-code-editor-tab-button-error",
    "colorTextColumnHeader": "color-text-column-header",
    "colorTextColumnSortingIcon": "color-text-column-sorting-icon",
    "colorTextControlDisabled": "color-text-control-disabled",
    "colorTextCounter": "color-text-counter",
    "colorTextDisabled": "color-text-disabled",
    "colorTextDisabledInlineEdit": "color-text-disabled-inline-edit",
    "colorTextDropdownFooter": "color-text-dropdown-footer",
    "colorTextDropdownGroupLabel": "color-text-dropdown-group-label",
    "colorTextDropdownItemDefault": "color-text-dropdown-item-default",
    "colorTextDropdownItemDimmed": "color-text-dropdown-item-dimmed",
    "colorTextDropdownItemDisabled": "color-text-dropdown-item-disabled",
    "colorTextDropdownItemFilterMatch": "color-text-dropdown-item-filter-match",
    "colorTextDropdownItemHighlighted": "color-text-dropdown-item-highlighted",
    "colorTextDropdownItemSecondary": "color-text-dropdown-item-secondary",
    "colorTextDropdownItemSecondaryHover": "color-text-dropdown-item-secondary-hover",
    "colorTextEmpty": "color-text-empty",
    "colorTextExpandableSectionDefault": "color-text-expandable-section-default",
    "colorTextExpandableSectionHover": "color-text-expandable-section-hover",
    "colorTextExpandableSectionNavigationIconDefault": "color-text-expandable-section-navigation-icon-default",
    "colorTextFormDefault": "color-text-form-default",
    "colorTextFormLabel": "color-text-form-label",
    "colorTextFormSecondary": "color-text-form-secondary",
    "colorTextGroupLabel": "color-text-group-label",
    "colorTextLabelGenAi": "color-text-label-gen-ai",
    "colorTextHeadingDefault": "color-text-heading-default",
    "colorTextHeadingSecondary": "color-text-heading-secondary",
    "colorTextHomeHeaderDefault": "color-text-home-header-default",
    "colorTextHomeHeaderSecondary": "color-text-home-header-secondary",
    "colorTextIconCaret": "color-text-icon-caret",
    "colorTextIconSubtle": "color-text-icon-subtle",
    "colorTextInputDisabled": "color-text-input-disabled",
    "colorTextInputPlaceholder": "color-text-input-placeholder",
    "colorTextInputPlaceholderDisabled": "color-text-input-placeholder-disabled",
    "colorTextInteractiveActive": "color-text-interactive-active",
    "colorTextInteractiveDefault": "color-text-interactive-default",
    "colorTextInteractiveDisabled": "color-text-interactive-disabled",
    "colorTextInteractiveHover": "color-text-interactive-hover",
    "colorTextToggleButtonIconPressed": "color-text-toggle-button-icon-pressed",
    "colorTextInteractiveInvertedDefault": "color-text-interactive-inverted-default",
    "colorTextInteractiveInvertedHover": "color-text-interactive-inverted-hover",
    "colorTextInverted": "color-text-inverted",
    "colorTextLabel": "color-text-label",
    "colorTextKeyValuePairsValue": "color-text-key-value-pairs-value",
    "colorTextLayoutToggle": "color-text-layout-toggle",
    "colorTextLayoutToggleActive": "color-text-layout-toggle-active",
    "colorTextLayoutToggleHover": "color-text-layout-toggle-hover",
    "colorTextLayoutToggleSelected": "color-text-layout-toggle-selected",
    "colorTextLinkDefault": "color-text-link-default",
    "colorTextLinkHover": "color-text-link-hover",
    "colorTextLinkDecorationDefault": "color-text-link-decoration-default",
    "colorTextLinkDecorationHover": "color-text-link-decoration-hover",
    "colorTextLinkSecondaryDefault": "color-text-link-secondary-default",
    "colorTextLinkSecondaryHover": "color-text-link-secondary-hover",
    "colorTextLinkInfoDefault": "color-text-link-info-default",
    "colorTextLinkInfoHover": "color-text-link-info-hover",
    "colorTextLinkInvertedHover": "color-text-link-inverted-hover",
    "colorTextLinkButtonUnderline": "color-text-link-button-underline",
    "colorTextLinkButtonUnderlineHover": "color-text-link-button-underline-hover",
    "colorTextNotificationDefault": "color-text-notification-default",
    "colorTextNotificationStackBar": "color-text-notification-stack-bar",
    "colorTextNotificationYellow": "color-text-notification-yellow",
    "colorTextPaginationPageNumberActiveDisabled": "color-text-pagination-page-number-active-disabled",
    "colorTextPaginationPageNumberDefault": "color-text-pagination-page-number-default",
    "colorTextSegmentActive": "color-text-segment-active",
    "colorTextSegmentDefault": "color-text-segment-default",
    "colorTextSegmentHover": "color-text-segment-hover",
    "colorTextSmall": "color-text-small",
    "colorTextStatusError": "color-text-status-error",
    "colorTextStatusInactive": "color-text-status-inactive",
    "colorTextStatusInfo": "color-text-status-info",
    "colorTextStatusSuccess": "color-text-status-success",
    "colorTextStatusWarning": "color-text-status-warning",
    "colorTextTopNavigationTitle": "color-text-top-navigation-title",
    "colorTextTutorialHotspotDefault": "color-text-tutorial-hotspot-default",
    "colorTextTutorialHotspotHover": "color-text-tutorial-hotspot-hover",
    "colorBoardPlaceholderActive": "color-board-placeholder-active",
    "colorBoardPlaceholderHover": "color-board-placeholder-hover",
    "colorDragPlaceholderActive": "color-drag-placeholder-active",
    "colorDragPlaceholderHover": "color-drag-placeholder-hover",
    "colorDropzoneBackgroundDefault": "color-dropzone-background-default",
    "colorDropzoneBackgroundHover": "color-dropzone-background-hover",
    "colorDropzoneTextDefault": "color-dropzone-text-default",
    "colorDropzoneTextHover": "color-dropzone-text-hover",
    "colorDropzoneBorderDefault": "color-dropzone-border-default",
    "colorDropzoneBorderHover": "color-dropzone-border-hover",
    "colorGapGlobalDrawer": "color-gap-global-drawer",
    "colorTreeViewConnectorLine": "color-tree-view-connector-line",
    "colorBackgroundActionCardDefault": "color-background-action-card-default",
    "colorBackgroundActionCardHover": "color-background-action-card-hover",
    "colorBackgroundActionCardActive": "color-background-action-card-active",
    "colorBorderActionCardDefault": "color-border-action-card-default",
    "colorBorderActionCardHover": "color-border-action-card-hover",
    "colorBorderActionCardActive": "color-border-action-card-active",
    "colorBorderActionCardDisabled": "color-border-action-card-disabled",
    "colorBackgroundActionCardDisabled": "color-background-action-card-disabled",
    "colorTextActionCardDisabled": "color-text-action-card-disabled",
    "colorIconActionCardDefault": "color-icon-action-card-default",
    "colorIconActionCardHover": "color-icon-action-card-hover",
    "colorIconActionCardActive": "color-icon-action-card-active",
    "colorIconActionCardDisabled": "color-icon-action-card-disabled",
    "colorBackgroundSkeleton": "color-background-skeleton",
    "colorBackgroundSkeletonWave": "color-background-skeleton-wave",
    "fontBoxValueLargeWeight": "font-box-value-large-weight",
    "fontButtonLetterSpacing": "font-button-letter-spacing",
    "fontChartDetailSize": "font-chart-detail-size",
    "fontDecorationStyleLink": "font-decoration-style-link",
    "fontDecorationThicknessLink": "font-decoration-thickness-link",
    "fontDecorationThicknessLinkDisplayL": "font-decoration-thickness-link-display-l",
    "fontDisplayLabelWeight": "font-display-label-weight",
    "fontExpandableHeadingSize": "font-expandable-heading-size",
    "fontFamilyBase": "font-family-base",
    "fontFamilyDisplay": "font-family-display",
    "fontFamilyHeading": "font-family-heading",
    "fontFamilyMonospace": "font-family-monospace",
    "fontHeaderH2DescriptionLineHeight": "font-header-h2-description-line-height",
    "fontHeaderH2DescriptionSize": "font-header-h2-description-size",
    "fontLinkButtonLetterSpacing": "font-link-button-letter-spacing",
    "fontLinkButtonWeight": "font-link-button-weight",
    "fontPanelHeaderLineHeight": "font-panel-header-line-height",
    "fontPanelHeaderSize": "font-panel-header-size",
    "fontSizeBodyM": "font-size-body-m",
    "fontSizeBodyS": "font-size-body-s",
    "fontSizeDisplayL": "font-size-display-l",
    "fontSizeFormLabel": "font-size-form-label",
    "fontSizeHeadingL": "font-size-heading-l",
    "fontSizeHeadingM": "font-size-heading-m",
    "fontSizeHeadingS": "font-size-heading-s",
    "fontSizeHeadingXl": "font-size-heading-xl",
    "fontSizeHeadingXs": "font-size-heading-xs",
    "fontSizeKeyValuePairsLabel": "font-size-key-value-pairs-label",
    "fontSizeTabs": "font-size-tabs",
    "fontSmoothingMozOsx": "font-smoothing-moz-osx",
    "fontSmoothingWebkit": "font-smoothing-webkit",
    "fontWayfindingLinkActiveWeight": "font-wayfinding-link-active-weight",
    "fontWeightAlertHeader": "font-weight-alert-header",
    "fontWeightBold": "font-weight-bold",
    "fontWeightBreadcrumbCurrent": "font-weight-breadcrumb-current",
    "fontWeightButton": "font-weight-button",
    "fontWeightDisplayL": "font-weight-display-l",
    "fontWeightFlashbarHeader": "font-weight-flashbar-header",
    "fontWeightFormLabel": "font-weight-form-label",
    "fontWeightHeadingL": "font-weight-heading-l",
    "fontWeightHeadingM": "font-weight-heading-m",
    "fontWeightHeadingS": "font-weight-heading-s",
    "fontWeightHeadingXl": "font-weight-heading-xl",
    "fontWeightHeadingXs": "font-weight-heading-xs",
    "fontWeightHeavy": "font-weight-heavy",
    "fontWeightKeyValuePairsLabel": "font-weight-key-value-pairs-label",
    "fontWeightLighter": "font-weight-lighter",
    "fontWeightNormal": "font-weight-normal",
    "fontWeightTabs": "font-weight-tabs",
    "fontWeightTabsDisabled": "font-weight-tabs-disabled",
    "letterSpacingBodyS": "letter-spacing-body-s",
    "letterSpacingDisplayL": "letter-spacing-display-l",
    "letterSpacingHeadingL": "letter-spacing-heading-l",
    "letterSpacingHeadingM": "letter-spacing-heading-m",
    "letterSpacingHeadingS": "letter-spacing-heading-s",
    "letterSpacingHeadingXl": "letter-spacing-heading-xl",
    "letterSpacingHeadingXs": "letter-spacing-heading-xs",
    "lineHeightBodyM": "line-height-body-m",
    "lineHeightBodyS": "line-height-body-s",
    "lineHeightDisplayL": "line-height-display-l",
    "lineHeightFormLabel": "line-height-form-label",
    "lineHeightHeadingL": "line-height-heading-l",
    "lineHeightHeadingM": "line-height-heading-m",
    "lineHeightHeadingS": "line-height-heading-s",
    "lineHeightHeadingXl": "line-height-heading-xl",
    "lineHeightHeadingXs": "line-height-heading-xs",
    "lineHeightKeyValuePairsLabel": "line-height-key-value-pairs-label",
    "lineHeightTabs": "line-height-tabs",
    "borderActiveWidth": "border-active-width",
    "borderCodeEditorStatusDividerWidth": "border-code-editor-status-divider-width",
    "borderContainerStickyWidth": "border-container-sticky-width",
    "borderContainerTopWidth": "border-container-top-width",
    "borderControlFocusRingShadowSpread": "border-control-focus-ring-shadow-spread",
    "borderControlInvalidFocusRingShadowSpread": "border-control-invalid-focus-ring-shadow-spread",
    "borderDividerListWidth": "border-divider-list-width",
    "borderDividerSectionWidth": "border-divider-section-width",
    "borderDropdownVirtualOffsetWidth": "border-dropdown-virtual-offset-width",
    "borderInvalidWidth": "border-invalid-width",
    "borderItemWidth": "border-item-width",
    "borderLineChartDashArray": "border-line-chart-dash-array",
    "borderLineChartLineJoin": "border-line-chart-line-join",
    "borderLineChartWidth": "border-line-chart-width",
    "borderPanelHeaderWidth": "border-panel-header-width",
    "borderPanelTopWidth": "border-panel-top-width",
    "borderRadiusAlert": "border-radius-alert",
    "borderRadiusBadge": "border-radius-badge",
    "borderRadiusButton": "border-radius-button",
    "borderRadiusCalendarDayFocusRing": "border-radius-calendar-day-focus-ring",
    "borderRadiusCodeEditor": "border-radius-code-editor",
    "borderRadiusCardDefault": "border-radius-card-default",
    "borderRadiusCardEmbedded": "border-radius-card-embedded",
    "borderRadiusItemCardDefault": "border-radius-item-card-default",
    "borderRadiusItemCardEmbedded": "border-radius-item-card-embedded",
    "borderRadiusContainer": "border-radius-container",
    "borderRadiusControlCircularFocusRing": "border-radius-control-circular-focus-ring",
    "borderRadiusControlDefaultFocusRing": "border-radius-control-default-focus-ring",
    "borderRadiusDropdown": "border-radius-dropdown",
    "borderRadiusDropzone": "border-radius-dropzone",
    "borderRadiusFlashbar": "border-radius-flashbar",
    "borderRadiusItem": "border-radius-item",
    "borderRadiusInput": "border-radius-input",
    "borderRadiusPopover": "border-radius-popover",
    "borderRadiusTabsFocusRing": "border-radius-tabs-focus-ring",
    "borderRadiusTiles": "border-radius-tiles",
    "borderRadiusToken": "border-radius-token",
    "borderRadiusChatBubble": "border-radius-chat-bubble",
    "borderRadiusTutorialPanelItem": "border-radius-tutorial-panel-item",
    "borderTableStickyWidth": "border-table-sticky-width",
    "borderLinkFocusRingOutline": "border-link-focus-ring-outline",
    "borderLinkFocusRingShadowSpread": "border-link-focus-ring-shadow-spread",
    "borderWidthCard": "border-width-card",
    "borderWidthCardSelected": "border-width-card-selected",
    "borderWidthItemCard": "border-width-item-card",
    "borderWidthItemCardHighlighted": "border-width-item-card-highlighted",
    "borderWidthItemSelected": "border-width-item-selected",
    "borderWidthAlert": "border-width-alert",
    "borderWidthAlertBlockStart": "border-width-alert-block-start",
    "borderWidthAlertBlockEnd": "border-width-alert-block-end",
    "borderWidthAlertInlineStart": "border-width-alert-inline-start",
    "borderWidthAlertInlineEnd": "border-width-alert-inline-end",
    "borderWidthButton": "border-width-button",
    "borderWidthDropdown": "border-width-dropdown",
    "borderWidthField": "border-width-field",
    "borderWidthPopover": "border-width-popover",
    "borderWidthToken": "border-width-token",
    "borderWidthIconSmall": "border-width-icon-small",
    "borderWidthIconNormal": "border-width-icon-normal",
    "borderWidthIconMedium": "border-width-icon-medium",
    "borderWidthIconBig": "border-width-icon-big",
    "borderWidthIconLarge": "border-width-icon-large",
    "borderRadiusActionCardDefault": "border-radius-action-card-default",
    "borderRadiusActionCardEmbedded": "border-radius-action-card-embedded",
    "borderWidthActionCardDefault": "border-width-action-card-default",
    "borderWidthActionCardHover": "border-width-action-card-hover",
    "borderWidthActionCardActive": "border-width-action-card-active",
    "borderWidthActionCardDisabled": "border-width-action-card-disabled",
    "borderRadiusSkeleton": "border-radius-skeleton",
    "motionDurationExtraFast": "motion-duration-extra-fast",
    "motionDurationExtraSlow": "motion-duration-extra-slow",
    "motionDurationFast": "motion-duration-fast",
    "motionDurationModerate": "motion-duration-moderate",
    "motionDurationRefreshOnlyAmbient": "motion-duration-refresh-only-ambient",
    "motionDurationRefreshOnlyFast": "motion-duration-refresh-only-fast",
    "motionDurationRefreshOnlyMedium": "motion-duration-refresh-only-medium",
    "motionDurationRefreshOnlySlow": "motion-duration-refresh-only-slow",
    "motionDurationAvatarGenAiGradient": "motion-duration-avatar-gen-ai-gradient",
    "motionDurationAvatarLoadingDots": "motion-duration-avatar-loading-dots",
    "motionDurationRotate180": "motion-duration-rotate-180",
    "motionDurationRotate90": "motion-duration-rotate-90",
    "motionDurationShowPaced": "motion-duration-show-paced",
    "motionDurationShowQuick": "motion-duration-show-quick",
    "motionDurationSlow": "motion-duration-slow",
    "motionDurationTransitionQuick": "motion-duration-transition-quick",
    "motionDurationTransitionShowPaced": "motion-duration-transition-show-paced",
    "motionDurationTransitionShowQuick": "motion-duration-transition-show-quick",
    "motionEasingEaseOutQuart": "motion-easing-ease-out-quart",
    "motionEasingRefreshOnlyA": "motion-easing-refresh-only-a",
    "motionEasingRefreshOnlyB": "motion-easing-refresh-only-b",
    "motionEasingRefreshOnlyC": "motion-easing-refresh-only-c",
    "motionEasingRefreshOnlyD": "motion-easing-refresh-only-d",
    "motionEasingAvatarGenAiGradient": "motion-easing-avatar-gen-ai-gradient",
    "motionEasingRotate180": "motion-easing-rotate-180",
    "motionEasingRotate90": "motion-easing-rotate-90",
    "motionEasingShowPaced": "motion-easing-show-paced",
    "motionEasingShowQuick": "motion-easing-show-quick",
    "motionEasingTransitionQuick": "motion-easing-transition-quick",
    "motionEasingTransitionShowPaced": "motion-easing-transition-show-paced",
    "motionEasingTransitionShowQuick": "motion-easing-transition-show-quick",
    "motionEasingResponsive": "motion-easing-responsive",
    "motionEasingSticky": "motion-easing-sticky",
    "motionEasingExpressive": "motion-easing-expressive",
    "motionDurationResponsive": "motion-duration-responsive",
    "motionDurationExpressive": "motion-duration-expressive",
    "motionDurationComplex": "motion-duration-complex",
    "motionKeyframesFadeIn": "motion-keyframes-fade-in",
    "motionKeyframesFadeOut": "motion-keyframes-fade-out",
    "motionKeyframesStatusIconError": "motion-keyframes-status-icon-error",
    "motionKeyframesScalePopup": "motion-keyframes-scale-popup",
    "sizeCalendarGridWidth": "size-calendar-grid-width",
    "sizeControl": "size-control",
    "sizeIconBig": "size-icon-big",
    "sizeIconLarge": "size-icon-large",
    "sizeIconMedium": "size-icon-medium",
    "sizeIconNormal": "size-icon-normal",
    "sizeTableSelectionHorizontal": "size-table-selection-horizontal",
    "sizeVerticalInput": "size-vertical-input",
    "sizeVerticalPanelIconOffset": "size-vertical-panel-icon-offset",
    "spaceAlertActionLeft": "space-alert-action-left",
    "spaceAlertHorizontal": "space-alert-horizontal",
    "spaceAlertMessageRight": "space-alert-message-right",
    "spaceAlertVertical": "space-alert-vertical",
    "spaceButtonFocusOutlineGutter": "space-button-focus-outline-gutter",
    "spaceButtonHorizontal": "space-button-horizontal",
    "spaceButtonVertical": "space-button-vertical",
    "spaceTokenVertical": "space-token-vertical",
    "spaceFieldVertical": "space-field-vertical",
    "spaceButtonIconFocusOutlineGutterVertical": "space-button-icon-focus-outline-gutter-vertical",
    "spaceButtonIconOnlyHorizontal": "space-button-icon-only-horizontal",
    "spaceButtonInlineIconFocusOutlineGutter": "space-button-inline-icon-focus-outline-gutter",
    "spaceButtonModalDismissVertical": "space-button-modal-dismiss-vertical",
    "spaceCalendarGridFocusOutlineGutter": "space-calendar-grid-focus-outline-gutter",
    "spaceCalendarGridSelectedFocusOutlineGutter": "space-calendar-grid-selected-focus-outline-gutter",
    "spaceCalendarGridGutter": "space-calendar-grid-gutter",
    "spaceCardHorizontalDefault": "space-card-horizontal-default",
    "spaceCardHorizontalEmbedded": "space-card-horizontal-embedded",
    "spaceCardVerticalDefault": "space-card-vertical-default",
    "spaceCardVerticalEmbedded": "space-card-vertical-embedded",
    "spaceItemCardHorizontalDefault": "space-item-card-horizontal-default",
    "spaceItemCardHorizontalEmbedded": "space-item-card-horizontal-embedded",
    "spaceItemCardVerticalDefault": "space-item-card-vertical-default",
    "spaceItemCardVerticalEmbedded": "space-item-card-vertical-embedded",
    "spaceCodeEditorStatusFocusOutlineGutter": "space-code-editor-status-focus-outline-gutter",
    "spaceContainerContentTop": "space-container-content-top",
    "spaceContainerHeaderTop": "space-container-header-top",
    "spaceContainerHeaderBottom": "space-container-header-bottom",
    "spaceContainerHorizontal": "space-container-horizontal",
    "spaceContentHeaderPaddingBottom": "space-content-header-padding-bottom",
    "spaceDarkHeaderOverlapDistance": "space-dark-header-overlap-distance",
    "spaceExpandableSectionIconOffsetTop": "space-expandable-section-icon-offset-top",
    "spaceFieldHorizontal": "space-field-horizontal",
    "spaceFieldIconOffset": "space-field-icon-offset",
    "spaceFilteringTokenDismissButtonFocusOutlineGutter": "space-filtering-token-dismiss-button-focus-outline-gutter",
    "spaceFilteringTokenOperationSelectFocusOutlineGutter": "space-filtering-token-operation-select-focus-outline-gutter",
    "spaceFlashbarActionLeft": "space-flashbar-action-left",
    "spaceFlashbarDismissRight": "space-flashbar-dismiss-right",
    "spaceFlashbarHorizontal": "space-flashbar-horizontal",
    "spaceFlashbarVertical": "space-flashbar-vertical",
    "spaceGridGutter": "space-grid-gutter",
    "spaceKeyValueGap": "space-key-value-gap",
    "spaceLayoutContentBottom": "space-layout-content-bottom",
    "spaceLayoutContentHorizontal": "space-layout-content-horizontal",
    "spaceLayoutToggleDiameter": "space-layout-toggle-diameter",
    "spaceLayoutTogglePadding": "space-layout-toggle-padding",
    "spaceModalContentBottom": "space-modal-content-bottom",
    "spaceModalHorizontal": "space-modal-horizontal",
    "spacePanelContentBottom": "space-panel-content-bottom",
    "spacePanelContentTop": "space-panel-content-top",
    "spacePanelDividerMarginHorizontal": "space-panel-divider-margin-horizontal",
    "spacePanelHeaderVertical": "space-panel-header-vertical",
    "spacePanelNavLeft": "space-panel-nav-left",
    "spacePanelSideLeft": "space-panel-side-left",
    "spacePanelSideRight": "space-panel-side-right",
    "spacePanelSplitTop": "space-panel-split-top",
    "spacePanelSplitBottom": "space-panel-split-bottom",
    "spaceSegmentedControlFocusOutlineGutter": "space-segmented-control-focus-outline-gutter",
    "spaceTabsContentTop": "space-tabs-content-top",
    "spaceTabsFocusOutlineGutter": "space-tabs-focus-outline-gutter",
    "spaceTabsVertical": "space-tabs-vertical",
    "spaceTableContentBottom": "space-table-content-bottom",
    "spaceTableEmbeddedHeaderTop": "space-table-embedded-header-top",
    "spaceTableFooterHorizontal": "space-table-footer-horizontal",
    "spaceTableHeaderFocusOutlineGutter": "space-table-header-focus-outline-gutter",
    "spaceTableHeaderHorizontal": "space-table-header-horizontal",
    "spaceTableHeaderToolsBottom": "space-table-header-tools-bottom",
    "spaceTableHeaderToolsFullPageBottom": "space-table-header-tools-full-page-bottom",
    "spaceTableHorizontal": "space-table-horizontal",
    "spaceTreeViewIndentation": "space-tree-view-indentation",
    "spaceTileGutter": "space-tile-gutter",
    "spaceActionCardHorizontalDefault": "space-action-card-horizontal-default",
    "spaceActionCardHorizontalEmbedded": "space-action-card-horizontal-embedded",
    "spaceActionCardVerticalDefault": "space-action-card-vertical-default",
    "spaceActionCardVerticalEmbedded": "space-action-card-vertical-embedded",
    "spaceActionCardDescriptionPaddingTop": "space-action-card-description-padding-top",
    "spaceActionCardContentPaddingTop": "space-action-card-content-padding-top",
    "spaceOptionPaddingVertical": "space-option-padding-vertical",
    "spaceOptionPaddingHorizontal": "space-option-padding-horizontal",
    "spaceScaled2xNone": "space-scaled-2x-none",
    "spaceScaled2xXxxs": "space-scaled-2x-xxxs",
    "spaceScaled2xXxs": "space-scaled-2x-xxs",
    "spaceScaled2xXs": "space-scaled-2x-xs",
    "spaceScaled2xS": "space-scaled-2x-s",
    "spaceScaled2xM": "space-scaled-2x-m",
    "spaceScaled2xL": "space-scaled-2x-l",
    "spaceScaled2xXl": "space-scaled-2x-xl",
    "spaceScaled2xXxl": "space-scaled-2x-xxl",
    "spaceScaled2xXxxl": "space-scaled-2x-xxxl",
    "spaceScaledNone": "space-scaled-none",
    "spaceScaledXxxs": "space-scaled-xxxs",
    "spaceScaledXxs": "space-scaled-xxs",
    "spaceScaledXs": "space-scaled-xs",
    "spaceScaledS": "space-scaled-s",
    "spaceScaledM": "space-scaled-m",
    "spaceScaledL": "space-scaled-l",
    "spaceScaledXl": "space-scaled-xl",
    "spaceScaledXxl": "space-scaled-xxl",
    "spaceScaledXxxl": "space-scaled-xxxl",
    "spaceStaticXxxs": "space-static-xxxs",
    "spaceStaticXxs": "space-static-xxs",
    "spaceStaticXs": "space-static-xs",
    "spaceStaticS": "space-static-s",
    "spaceStaticM": "space-static-m",
    "spaceStaticL": "space-static-l",
    "spaceStaticXl": "space-static-xl",
    "spaceStaticXxl": "space-static-xxl",
    "spaceStaticXxxl": "space-static-xxxl",
    "spaceNone": "space-none",
    "spaceXxxs": "space-xxxs",
    "spaceXxs": "space-xxs",
    "spaceXs": "space-xs",
    "spaceS": "space-s",
    "spaceM": "space-m",
    "spaceL": "space-l",
    "spaceXl": "space-xl",
    "spaceXxl": "space-xxl",
    "spaceXxxl": "space-xxxl",
    "shadowCard": "shadow-card",
    "shadowItemCard": "shadow-item-card",
    "shadowContainer": "shadow-container",
    "shadowContainerActive": "shadow-container-active",
    "shadowDropdown": "shadow-dropdown",
    "shadowDropup": "shadow-dropup",
    "shadowFlashCollapsed": "shadow-flash-collapsed",
    "shadowFlashSticky": "shadow-flash-sticky",
    "shadowModal": "shadow-modal",
    "shadowPanel": "shadow-panel",
    "shadowPanelToggle": "shadow-panel-toggle",
    "shadowPopover": "shadow-popover",
    "shadowSplitBottom": "shadow-split-bottom",
    "shadowSplitSide": "shadow-split-side",
    "shadowSticky": "shadow-sticky",
    "shadowStickyEmbedded": "shadow-sticky-embedded",
    "shadowStickyColumnFirst": "shadow-sticky-column-first",
    "shadowStickyColumnLast": "shadow-sticky-column-last"
  },
  "propertiesMap": {
    "colorPrimary50": "--color-primary-50-1y05xv",
    "colorPrimary100": "--color-primary-100-f62fz9",
    "colorPrimary200": "--color-primary-200-vubr4w",
    "colorPrimary300": "--color-primary-300-5q65ox",
    "colorPrimary400": "--color-primary-400-n8h4bx",
    "colorPrimary500": "--color-primary-500-q9c16y",
    "colorPrimary600": "--color-primary-600-1lcy1k",
    "colorPrimary700": "--color-primary-700-n6k121",
    "colorPrimary800": "--color-primary-800-j9rj38",
    "colorPrimary900": "--color-primary-900-a5kqrr",
    "colorPrimary1000": "--color-primary-1000-7umopx",
    "colorNeutral50": "--color-neutral-50-pvu04n",
    "colorNeutral100": "--color-neutral-100-gk3lvf",
    "colorNeutral150": "--color-neutral-150-gezhen",
    "colorNeutral200": "--color-neutral-200-fqt4tz",
    "colorNeutral250": "--color-neutral-250-vs1is4",
    "colorNeutral300": "--color-neutral-300-08wi6k",
    "colorNeutral350": "--color-neutral-350-dq6kfr",
    "colorNeutral400": "--color-neutral-400-wtst55",
    "colorNeutral450": "--color-neutral-450-kn0235",
    "colorNeutral500": "--color-neutral-500-8van0b",
    "colorNeutral550": "--color-neutral-550-z2a44u",
    "colorNeutral600": "--color-neutral-600-fln1ww",
    "colorNeutral650": "--color-neutral-650-miik4f",
    "colorNeutral700": "--color-neutral-700-qw8ats",
    "colorNeutral750": "--color-neutral-750-pi9qqd",
    "colorNeutral800": "--color-neutral-800-t7j5ap",
    "colorNeutral850": "--color-neutral-850-3f0gro",
    "colorNeutral900": "--color-neutral-900-v0mtoc",
    "colorNeutral950": "--color-neutral-950-lxybh8",
    "colorNeutral1000": "--color-neutral-1000-7ovvlt",
    "colorError50": "--color-error-50-1upkvz",
    "colorError400": "--color-error-400-c0knb8",
    "colorError600": "--color-error-600-mdn3ng",
    "colorError900": "--color-error-900-skonp1",
    "colorError1000": "--color-error-1000-ecmudm",
    "colorSuccess50": "--color-success-50-yow9uc",
    "colorSuccess500": "--color-success-500-hhxb4g",
    "colorSuccess600": "--color-success-600-g7hz2i",
    "colorSuccess1000": "--color-success-1000-xy1gvq",
    "colorWarning50": "--color-warning-50-uxheb8",
    "colorWarning400": "--color-warning-400-55puga",
    "colorWarning500": "--color-warning-500-zidhub",
    "colorWarning900": "--color-warning-900-kpxt8c",
    "colorWarning1000": "--color-warning-1000-65l070",
    "colorInfo50": "--color-info-50-cdvtrs",
    "colorInfo300": "--color-info-300-q9xd1l",
    "colorInfo400": "--color-info-400-674xac",
    "colorInfo600": "--color-info-600-un21zh",
    "colorInfo1000": "--color-info-1000-s77ok9",
    "colorGrey50": "--color-grey-50-mhbfod",
    "colorGrey100": "--color-grey-100-2sczed",
    "colorGrey150": "--color-grey-150-znah9n",
    "colorGrey200": "--color-grey-200-s986pt",
    "colorGrey250": "--color-grey-250-l5wm60",
    "colorGrey300": "--color-grey-300-tqmb21",
    "colorGrey350": "--color-grey-350-brqf9i",
    "colorGrey400": "--color-grey-400-oueki4",
    "colorGrey450": "--color-grey-450-6n5usg",
    "colorGrey500": "--color-grey-500-argwpz",
    "colorGrey600": "--color-grey-600-qux9qr",
    "colorGrey650": "--color-grey-650-5vpn76",
    "colorGrey700": "--color-grey-700-i9hww0",
    "colorGrey750": "--color-grey-750-3a32f4",
    "colorGrey800": "--color-grey-800-38aulk",
    "colorGrey850": "--color-grey-850-fg4m0u",
    "colorGrey900": "--color-grey-900-2zzggd",
    "colorGrey950": "--color-grey-950-rpj9g8",
    "colorGrey1000": "--color-grey-1000-kdxctl",
    "colorBlue50": "--color-blue-50-1qtweg",
    "colorBlue100": "--color-blue-100-a7atso",
    "colorBlue200": "--color-blue-200-66lcr3",
    "colorBlue300": "--color-blue-300-s2r2o0",
    "colorBlue400": "--color-blue-400-h2lqfk",
    "colorBlue600": "--color-blue-600-dkpfum",
    "colorBlue700": "--color-blue-700-lcgdon",
    "colorBlue900": "--color-blue-900-k0czor",
    "colorBlue1000": "--color-blue-1000-fmz0jt",
    "colorGreen50": "--color-green-50-p1p8l4",
    "colorGreen500": "--color-green-500-c2uzi6",
    "colorGreen600": "--color-green-600-vdmico",
    "colorGreen900": "--color-green-900-6aqp28",
    "colorGreen1000": "--color-green-1000-tarlm7",
    "colorRed50": "--color-red-50-k823mj",
    "colorRed400": "--color-red-400-40ay29",
    "colorRed600": "--color-red-600-lxm4n7",
    "colorRed900": "--color-red-900-gj885t",
    "colorRed1000": "--color-red-1000-jtashw",
    "colorYellow50": "--color-yellow-50-wk1vy0",
    "colorYellow400": "--color-yellow-400-q4m2pa",
    "colorYellow500": "--color-yellow-500-rj98kw",
    "colorYellow900": "--color-yellow-900-jipa9u",
    "colorYellow1000": "--color-yellow-1000-zo0nn2",
    "colorPurple400": "--color-purple-400-o7fr4k",
    "colorPurple700": "--color-purple-700-5hcbeu",
    "colorAmber400": "--color-amber-400-z6oddn",
    "colorAmber500": "--color-amber-500-rsho1x",
    "colorAwsSquidInk": "--color-aws-squid-ink-oxiega",
    "colorTransparent": "--color-transparent-i61gs1",
    "colorBlack": "--color-black-cox1hy",
    "colorWhite": "--color-white-p1zlvy",
    "colorChartsRed300": "--color-charts-red-300-2k7eul",
    "colorChartsRed400": "--color-charts-red-400-ssrf2o",
    "colorChartsRed500": "--color-charts-red-500-m14kmu",
    "colorChartsRed600": "--color-charts-red-600-938v3h",
    "colorChartsRed700": "--color-charts-red-700-f6sq8t",
    "colorChartsRed800": "--color-charts-red-800-tzkaad",
    "colorChartsRed900": "--color-charts-red-900-fhg0lh",
    "colorChartsRed1000": "--color-charts-red-1000-9iigzo",
    "colorChartsRed1100": "--color-charts-red-1100-4n7b3z",
    "colorChartsRed1200": "--color-charts-red-1200-ek3cuo",
    "colorChartsOrange300": "--color-charts-orange-300-hqhtmn",
    "colorChartsOrange400": "--color-charts-orange-400-g8c1fc",
    "colorChartsOrange500": "--color-charts-orange-500-j3c2cu",
    "colorChartsOrange600": "--color-charts-orange-600-1ad7o4",
    "colorChartsOrange700": "--color-charts-orange-700-spsf2r",
    "colorChartsOrange800": "--color-charts-orange-800-244d7b",
    "colorChartsOrange900": "--color-charts-orange-900-8omk92",
    "colorChartsOrange1000": "--color-charts-orange-1000-ezq5pz",
    "colorChartsOrange1100": "--color-charts-orange-1100-bhcmg5",
    "colorChartsOrange1200": "--color-charts-orange-1200-exs6jj",
    "colorChartsYellow300": "--color-charts-yellow-300-fpz8o0",
    "colorChartsYellow400": "--color-charts-yellow-400-vxiqrf",
    "colorChartsYellow500": "--color-charts-yellow-500-1qgrtj",
    "colorChartsYellow600": "--color-charts-yellow-600-aweqy2",
    "colorChartsYellow700": "--color-charts-yellow-700-xh0lj9",
    "colorChartsYellow800": "--color-charts-yellow-800-gp4422",
    "colorChartsYellow900": "--color-charts-yellow-900-r6gx3k",
    "colorChartsYellow1000": "--color-charts-yellow-1000-6dnac6",
    "colorChartsYellow1100": "--color-charts-yellow-1100-fqp4sw",
    "colorChartsYellow1200": "--color-charts-yellow-1200-k7kf4w",
    "colorChartsGreen300": "--color-charts-green-300-6766ev",
    "colorChartsGreen400": "--color-charts-green-400-gd41ay",
    "colorChartsGreen500": "--color-charts-green-500-yr18n3",
    "colorChartsGreen600": "--color-charts-green-600-b1gmr0",
    "colorChartsGreen700": "--color-charts-green-700-305sle",
    "colorChartsGreen800": "--color-charts-green-800-rh42zr",
    "colorChartsGreen900": "--color-charts-green-900-2x5smm",
    "colorChartsGreen1000": "--color-charts-green-1000-opphoq",
    "colorChartsGreen1100": "--color-charts-green-1100-o67uzm",
    "colorChartsGreen1200": "--color-charts-green-1200-sw46fc",
    "colorChartsTeal300": "--color-charts-teal-300-2qlyrg",
    "colorChartsTeal400": "--color-charts-teal-400-s8pa77",
    "colorChartsTeal500": "--color-charts-teal-500-8d830b",
    "colorChartsTeal600": "--color-charts-teal-600-772n9t",
    "colorChartsTeal700": "--color-charts-teal-700-29mnwm",
    "colorChartsTeal800": "--color-charts-teal-800-vp41t6",
    "colorChartsTeal900": "--color-charts-teal-900-k020ya",
    "colorChartsTeal1000": "--color-charts-teal-1000-fhpqt3",
    "colorChartsTeal1100": "--color-charts-teal-1100-6w598w",
    "colorChartsTeal1200": "--color-charts-teal-1200-0u78my",
    "colorChartsBlue1300": "--color-charts-blue-1-300-pdza0q",
    "colorChartsBlue1400": "--color-charts-blue-1-400-ajl038",
    "colorChartsBlue1500": "--color-charts-blue-1-500-9s8gor",
    "colorChartsBlue1600": "--color-charts-blue-1-600-7ymb7g",
    "colorChartsBlue1700": "--color-charts-blue-1-700-5qzras",
    "colorChartsBlue1800": "--color-charts-blue-1-800-awczh4",
    "colorChartsBlue1900": "--color-charts-blue-1-900-6wxwzk",
    "colorChartsBlue11000": "--color-charts-blue-1-1000-00005b",
    "colorChartsBlue11100": "--color-charts-blue-1-1100-8nwfwf",
    "colorChartsBlue11200": "--color-charts-blue-1-1200-v60p8b",
    "colorChartsBlue2300": "--color-charts-blue-2-300-g72slq",
    "colorChartsBlue2400": "--color-charts-blue-2-400-he538m",
    "colorChartsBlue2500": "--color-charts-blue-2-500-quctxu",
    "colorChartsBlue2600": "--color-charts-blue-2-600-6qav3j",
    "colorChartsBlue2700": "--color-charts-blue-2-700-sp7t4m",
    "colorChartsBlue2800": "--color-charts-blue-2-800-q01umt",
    "colorChartsBlue2900": "--color-charts-blue-2-900-gog7z2",
    "colorChartsBlue21000": "--color-charts-blue-2-1000-c13nf8",
    "colorChartsBlue21100": "--color-charts-blue-2-1100-ddk6eo",
    "colorChartsBlue21200": "--color-charts-blue-2-1200-gt550t",
    "colorChartsPurple300": "--color-charts-purple-300-85q036",
    "colorChartsPurple400": "--color-charts-purple-400-9axh6r",
    "colorChartsPurple500": "--color-charts-purple-500-rn2jbl",
    "colorChartsPurple600": "--color-charts-purple-600-26s4rg",
    "colorChartsPurple700": "--color-charts-purple-700-tv8cvg",
    "colorChartsPurple800": "--color-charts-purple-800-h61qlx",
    "colorChartsPurple900": "--color-charts-purple-900-am452b",
    "colorChartsPurple1000": "--color-charts-purple-1000-uarqpb",
    "colorChartsPurple1100": "--color-charts-purple-1100-y8ctnd",
    "colorChartsPurple1200": "--color-charts-purple-1200-hr9f40",
    "colorChartsPink300": "--color-charts-pink-300-ewnht7",
    "colorChartsPink400": "--color-charts-pink-400-smjdat",
    "colorChartsPink500": "--color-charts-pink-500-bw864b",
    "colorChartsPink600": "--color-charts-pink-600-2ro14y",
    "colorChartsPink700": "--color-charts-pink-700-ryxvua",
    "colorChartsPink800": "--color-charts-pink-800-tcusf8",
    "colorChartsPink900": "--color-charts-pink-900-kpyne4",
    "colorChartsPink1000": "--color-charts-pink-1000-1soluc",
    "colorChartsPink1100": "--color-charts-pink-1100-ff6g93",
    "colorChartsPink1200": "--color-charts-pink-1200-w9585d",
    "colorChartsStatusCritical": "--color-charts-status-critical-c6brdu",
    "colorChartsStatusHigh": "--color-charts-status-high-18fhg5",
    "colorChartsStatusMedium": "--color-charts-status-medium-3trmy3",
    "colorChartsStatusLow": "--color-charts-status-low-br6wv0",
    "colorChartsStatusPositive": "--color-charts-status-positive-md7eqa",
    "colorChartsStatusInfo": "--color-charts-status-info-yds4x2",
    "colorChartsStatusNeutral": "--color-charts-status-neutral-k2p33t",
    "colorChartsThresholdNegative": "--color-charts-threshold-negative-aad26m",
    "colorChartsThresholdPositive": "--color-charts-threshold-positive-mk2804",
    "colorChartsThresholdInfo": "--color-charts-threshold-info-ijuzzj",
    "colorChartsThresholdNeutral": "--color-charts-threshold-neutral-pd7kh4",
    "colorChartsLineGrid": "--color-charts-line-grid-kjxf3m",
    "colorChartsLineTick": "--color-charts-line-tick-xmcbvk",
    "colorChartsLineAxis": "--color-charts-line-axis-b95ncf",
    "colorChartsPaletteCategorical1": "--color-charts-palette-categorical-1-xu0deg",
    "colorChartsPaletteCategorical2": "--color-charts-palette-categorical-2-ktit09",
    "colorChartsPaletteCategorical3": "--color-charts-palette-categorical-3-g0srj0",
    "colorChartsPaletteCategorical4": "--color-charts-palette-categorical-4-5vauwp",
    "colorChartsPaletteCategorical5": "--color-charts-palette-categorical-5-3v8ery",
    "colorChartsPaletteCategorical6": "--color-charts-palette-categorical-6-ztdd8d",
    "colorChartsPaletteCategorical7": "--color-charts-palette-categorical-7-3j5o6w",
    "colorChartsPaletteCategorical8": "--color-charts-palette-categorical-8-c5r39m",
    "colorChartsPaletteCategorical9": "--color-charts-palette-categorical-9-8n6iuv",
    "colorChartsPaletteCategorical10": "--color-charts-palette-categorical-10-opta0w",
    "colorChartsPaletteCategorical11": "--color-charts-palette-categorical-11-b2r7jc",
    "colorChartsPaletteCategorical12": "--color-charts-palette-categorical-12-b5drtm",
    "colorChartsPaletteCategorical13": "--color-charts-palette-categorical-13-c69xg9",
    "colorChartsPaletteCategorical14": "--color-charts-palette-categorical-14-db19x8",
    "colorChartsPaletteCategorical15": "--color-charts-palette-categorical-15-8z8vjw",
    "colorChartsPaletteCategorical16": "--color-charts-palette-categorical-16-549jkl",
    "colorChartsPaletteCategorical17": "--color-charts-palette-categorical-17-nrio7t",
    "colorChartsPaletteCategorical18": "--color-charts-palette-categorical-18-tm902v",
    "colorChartsPaletteCategorical19": "--color-charts-palette-categorical-19-ujcr86",
    "colorChartsPaletteCategorical20": "--color-charts-palette-categorical-20-h55e4g",
    "colorChartsPaletteCategorical21": "--color-charts-palette-categorical-21-vs0u8l",
    "colorChartsPaletteCategorical22": "--color-charts-palette-categorical-22-6klt3l",
    "colorChartsPaletteCategorical23": "--color-charts-palette-categorical-23-3zpkdt",
    "colorChartsPaletteCategorical24": "--color-charts-palette-categorical-24-z9a4uk",
    "colorChartsPaletteCategorical25": "--color-charts-palette-categorical-25-tgdsk2",
    "colorChartsPaletteCategorical26": "--color-charts-palette-categorical-26-lo8zn9",
    "colorChartsPaletteCategorical27": "--color-charts-palette-categorical-27-bruhsa",
    "colorChartsPaletteCategorical28": "--color-charts-palette-categorical-28-6b00fb",
    "colorChartsPaletteCategorical29": "--color-charts-palette-categorical-29-aurmid",
    "colorChartsPaletteCategorical30": "--color-charts-palette-categorical-30-fjnmd7",
    "colorChartsPaletteCategorical31": "--color-charts-palette-categorical-31-7zcct5",
    "colorChartsPaletteCategorical32": "--color-charts-palette-categorical-32-rrda6y",
    "colorChartsPaletteCategorical33": "--color-charts-palette-categorical-33-2v0mzv",
    "colorChartsPaletteCategorical34": "--color-charts-palette-categorical-34-g9a9q3",
    "colorChartsPaletteCategorical35": "--color-charts-palette-categorical-35-u0w821",
    "colorChartsPaletteCategorical36": "--color-charts-palette-categorical-36-tthuf8",
    "colorChartsPaletteCategorical37": "--color-charts-palette-categorical-37-y588bl",
    "colorChartsPaletteCategorical38": "--color-charts-palette-categorical-38-qdh97u",
    "colorChartsPaletteCategorical39": "--color-charts-palette-categorical-39-yisq6l",
    "colorChartsPaletteCategorical40": "--color-charts-palette-categorical-40-yeer1v",
    "colorChartsPaletteCategorical41": "--color-charts-palette-categorical-41-tu9dxw",
    "colorChartsPaletteCategorical42": "--color-charts-palette-categorical-42-q410kp",
    "colorChartsPaletteCategorical43": "--color-charts-palette-categorical-43-dwew7q",
    "colorChartsPaletteCategorical44": "--color-charts-palette-categorical-44-2thp96",
    "colorChartsPaletteCategorical45": "--color-charts-palette-categorical-45-6kinj6",
    "colorChartsPaletteCategorical46": "--color-charts-palette-categorical-46-iefxfq",
    "colorChartsPaletteCategorical47": "--color-charts-palette-categorical-47-9l9wl2",
    "colorChartsPaletteCategorical48": "--color-charts-palette-categorical-48-5s2n0r",
    "colorChartsPaletteCategorical49": "--color-charts-palette-categorical-49-bub0l1",
    "colorChartsPaletteCategorical50": "--color-charts-palette-categorical-50-utrpu5",
    "colorChartsErrorBarMarker": "--color-charts-error-bar-marker-r10jgv",
    "colorSeverityDarkRed": "--color-severity-dark-red-j8bmoc",
    "colorSeverityRed": "--color-severity-red-wf5w2d",
    "colorSeverityOrange": "--color-severity-orange-rpbcus",
    "colorSeverityYellow": "--color-severity-yellow-4er6zq",
    "colorSeverityGrey": "--color-severity-grey-sp7qo8",
    "colorBackgroundNotificationSeverityCritical": "--color-background-notification-severity-critical-0xl8pp",
    "colorBackgroundNotificationSeverityHigh": "--color-background-notification-severity-high-8nbgdi",
    "colorBackgroundNotificationSeverityMedium": "--color-background-notification-severity-medium-lbljs2",
    "colorBackgroundNotificationSeverityLow": "--color-background-notification-severity-low-giz8b6",
    "colorBackgroundNotificationSeverityNeutral": "--color-background-notification-severity-neutral-hnhgmv",
    "colorTextNotificationSeverityCritical": "--color-text-notification-severity-critical-tv4vw4",
    "colorTextNotificationSeverityHigh": "--color-text-notification-severity-high-t4suvu",
    "colorTextNotificationSeverityMedium": "--color-text-notification-severity-medium-8f60kb",
    "colorTextNotificationSeverityLow": "--color-text-notification-severity-low-gvojhi",
    "colorTextNotificationSeverityNeutral": "--color-text-notification-severity-neutral-ynm2wl",
    "colorGreyOpaque10": "--color-grey-opaque-10-vwfmts",
    "colorGreyOpaque25": "--color-grey-opaque-25-cjy3al",
    "colorGreyOpaque40": "--color-grey-opaque-40-yj2cvz",
    "colorGreyOpaque50": "--color-grey-opaque-50-dlm5ly",
    "colorGreyOpaque70": "--color-grey-opaque-70-p0svy7",
    "colorGreyOpaque80": "--color-grey-opaque-80-1wrh9m",
    "colorGreyOpaque90": "--color-grey-opaque-90-te8til",
    "colorGreyTransparent": "--color-grey-transparent-g4kcvh",
    "colorGreyTransparentHeavy": "--color-grey-transparent-heavy-bu3q4i",
    "colorGreyTransparentLight": "--color-grey-transparent-light-mwvx49",
    "colorBackgroundBadgeIcon": "--color-background-badge-icon-jyxnxa",
    "colorBackgroundButtonLinkActive": "--color-background-button-link-active-5oi2dp",
    "colorBackgroundButtonLinkDefault": "--color-background-button-link-default-o64utz",
    "colorBackgroundButtonLinkDisabled": "--color-background-button-link-disabled-9xznu3",
    "colorBackgroundButtonLinkHover": "--color-background-button-link-hover-lhrs2u",
    "colorBackgroundButtonNormalActive": "--color-background-button-normal-active-5imwxd",
    "colorBackgroundButtonNormalDefault": "--color-background-button-normal-default-7f99mv",
    "colorBackgroundButtonNormalDisabled": "--color-background-button-normal-disabled-hl039l",
    "colorBackgroundButtonNormalHover": "--color-background-button-normal-hover-53op9s",
    "colorBackgroundToggleButtonNormalPressed": "--color-background-toggle-button-normal-pressed-4khex7",
    "colorBackgroundButtonPrimaryActive": "--color-background-button-primary-active-5cqoqt",
    "colorBackgroundButtonPrimaryDefault": "--color-background-button-primary-default-vdt0fu",
    "colorBackgroundButtonPrimaryDisabled": "--color-background-button-primary-disabled-sgo4zo",
    "colorBackgroundButtonPrimaryHover": "--color-background-button-primary-hover-mo85i6",
    "colorBackgroundDirectionButtonActive": "--color-background-direction-button-active-lvo0dy",
    "colorBackgroundDirectionButtonDefault": "--color-background-direction-button-default-bvhbsn",
    "colorBackgroundDirectionButtonDisabled": "--color-background-direction-button-disabled-s9x4zq",
    "colorBackgroundDirectionButtonHover": "--color-background-direction-button-hover-74n5o1",
    "colorTextDirectionButtonDefault": "--color-text-direction-button-default-p88lvb",
    "colorTextDirectionButtonDisabled": "--color-text-direction-button-disabled-2jds36",
    "colorBackgroundCalendarCurrentDate": "--color-background-calendar-current-date-sk0f6i",
    "colorBackgroundCellShaded": "--color-background-cell-shaded-v7o6so",
    "colorBackgroundCodeEditorGutterActiveLineDefault": "--color-background-code-editor-gutter-active-line-default-51v1pv",
    "colorBackgroundCodeEditorGutterActiveLineError": "--color-background-code-editor-gutter-active-line-error-ro2qo1",
    "colorBackgroundCodeEditorGutterDefault": "--color-background-code-editor-gutter-default-15qdwh",
    "colorBackgroundCodeEditorLoading": "--color-background-code-editor-loading-6nwpin",
    "colorBackgroundCodeEditorPaneItemHover": "--color-background-code-editor-pane-item-hover-z6k9mr",
    "colorBackgroundCodeEditorStatusBar": "--color-background-code-editor-status-bar-yjtxod",
    "colorBackgroundCard": "--color-background-card-p5vrq0",
    "colorBackgroundItemCard": "--color-background-item-card-ww2wfv",
    "colorBackgroundContainerContent": "--color-background-container-content-6u8rvp",
    "colorBackgroundContainerHeader": "--color-background-container-header-gs3mbe",
    "colorBackgroundControlChecked": "--color-background-control-checked-ka7kc2",
    "colorBackgroundControlDefault": "--color-background-control-default-4jb21l",
    "colorBackgroundControlDisabled": "--color-background-control-disabled-1f3718",
    "colorBackgroundDropdownItemDefault": "--color-background-dropdown-item-default-qmc033",
    "colorBackgroundDropdownItemDimmed": "--color-background-dropdown-item-dimmed-dhho03",
    "colorBackgroundDropdownItemFilterMatch": "--color-background-dropdown-item-filter-match-49b5vt",
    "colorBackgroundDropdownItemHover": "--color-background-dropdown-item-hover-yunepc",
    "colorBackgroundDropdownItemSelected": "--color-background-dropdown-item-selected-f3v6te",
    "colorBackgroundHomeHeader": "--color-background-home-header-4c9jt4",
    "colorBackgroundInlineCode": "--color-background-inline-code-un8udy",
    "colorBackgroundInputDefault": "--color-background-input-default-ifz5bb",
    "colorBackgroundInputDisabled": "--color-background-input-disabled-dihaja",
    "colorBackgroundItemSelected": "--color-background-item-selected-9gppru",
    "colorBackgroundLayoutMain": "--color-background-layout-main-5ilwcb",
    "colorBackgroundDrawer": "--color-background-drawer-5hs0eh",
    "colorBackgroundDrawerBackdrop": "--color-background-drawer-backdrop-ducxi3",
    "colorBackgroundLayoutMobilePanel": "--color-background-layout-mobile-panel-ed0ava",
    "colorBackgroundLayoutPanelContent": "--color-background-layout-panel-content-xto15e",
    "colorBackgroundLayoutPanelHover": "--color-background-layout-panel-hover-tguulw",
    "colorBackgroundLayoutToolbar": "--color-background-layout-toolbar-y0cu80",
    "colorBackgroundLayoutToggleActive": "--color-background-layout-toggle-active-ap91vm",
    "colorBackgroundLayoutToggleDefault": "--color-background-layout-toggle-default-2hgjdu",
    "colorBackgroundLayoutToggleHover": "--color-background-layout-toggle-hover-0cpm7g",
    "colorBackgroundLayoutToggleSelectedActive": "--color-background-layout-toggle-selected-active-zcl8w3",
    "colorBackgroundLayoutToggleSelectedDefault": "--color-background-layout-toggle-selected-default-izfana",
    "colorBackgroundLayoutToggleSelectedHover": "--color-background-layout-toggle-selected-hover-7953u1",
    "colorBackgroundModalOverlay": "--color-background-modal-overlay-d7uby0",
    "colorBackgroundNotificationBlue": "--color-background-notification-blue-4vnob8",
    "colorBackgroundNotificationGreen": "--color-background-notification-green-2rkyvu",
    "colorBackgroundNotificationGrey": "--color-background-notification-grey-x3vul6",
    "colorBackgroundNotificationRed": "--color-background-notification-red-0487ea",
    "colorBackgroundNotificationYellow": "--color-background-notification-yellow-y6us5r",
    "colorBackgroundNotificationStackBar": "--color-background-notification-stack-bar-qe5n4w",
    "colorBackgroundNotificationStackBarActive": "--color-background-notification-stack-bar-active-a4h9r8",
    "colorBackgroundNotificationStackBarHover": "--color-background-notification-stack-bar-hover-jh82oo",
    "colorBackgroundPopover": "--color-background-popover-e20fy8",
    "colorBackgroundProgressBarValueDefault": "--color-background-progress-bar-value-default-69ydqg",
    "colorBackgroundProgressBarDefault": "--color-background-progress-bar-default-j8kyxd",
    "colorBackgroundSegmentActive": "--color-background-segment-active-1u2ldl",
    "colorBackgroundSegmentDefault": "--color-background-segment-default-b0r494",
    "colorBackgroundSegmentDisabled": "--color-background-segment-disabled-m2a5t7",
    "colorBackgroundSegmentHover": "--color-background-segment-hover-800sl4",
    "colorBackgroundSegmentWrapper": "--color-background-segment-wrapper-5tudmm",
    "colorBackgroundSliderRangeDefault": "--color-background-slider-range-default-3ljdu4",
    "colorBackgroundSliderRangeActive": "--color-background-slider-range-active-vu3lky",
    "colorBackgroundSliderHandleDefault": "--color-background-slider-handle-default-lp5ntg",
    "colorBackgroundSliderHandleActive": "--color-background-slider-handle-active-50ubqb",
    "colorBackgroundSliderTrackDefault": "--color-background-slider-track-default-vk2c9o",
    "colorBackgroundSliderHandleRing": "--color-background-slider-handle-ring-9sfenj",
    "colorBackgroundSliderHandleErrorDefault": "--color-background-slider-handle-error-default-411tqq",
    "colorBackgroundSliderHandleErrorActive": "--color-background-slider-handle-error-active-x65pfh",
    "colorBackgroundSliderHandleWarningDefault": "--color-background-slider-handle-warning-default-or76ej",
    "colorBackgroundSliderHandleWarningActive": "--color-background-slider-handle-warning-active-7o84zp",
    "colorBackgroundSliderRangeErrorDefault": "--color-background-slider-range-error-default-b519qn",
    "colorBackgroundSliderRangeErrorActive": "--color-background-slider-range-error-active-6bo8an",
    "colorBackgroundSliderRangeWarningDefault": "--color-background-slider-range-warning-default-6isqvo",
    "colorBackgroundSliderRangeWarningActive": "--color-background-slider-range-warning-active-dm2pha",
    "colorBackgroundStatusError": "--color-background-status-error-mu3lcw",
    "colorBackgroundStatusInfo": "--color-background-status-info-sfobba",
    "colorBackgroundDialog": "--color-background-dialog-2fj3uu",
    "colorBackgroundStatusSuccess": "--color-background-status-success-h6b8bh",
    "colorBackgroundStatusWarning": "--color-background-status-warning-cv83up",
    "colorBackgroundTableHeader": "--color-background-table-header-hdjxos",
    "colorBackgroundTilesDisabled": "--color-background-tiles-disabled-4ynms7",
    "colorBackgroundToggleCheckedDisabled": "--color-background-toggle-checked-disabled-amxc0a",
    "colorBackgroundToggleDefault": "--color-background-toggle-default-kjlhv0",
    "colorBackgroundAvatarGenAi": "--color-background-avatar-gen-ai-oxp2v6",
    "colorBackgroundAvatarDefault": "--color-background-avatar-default-t427xm",
    "colorTextAvatar": "--color-text-avatar-kuhkoa",
    "colorBackgroundLoadingBarGenAi": "--color-background-loading-bar-gen-ai-tey70i",
    "colorBackgroundChatBubbleOutgoing": "--color-background-chat-bubble-outgoing-ay6nj3",
    "colorBackgroundChatBubbleIncoming": "--color-background-chat-bubble-incoming-j38cew",
    "colorTextChatBubbleOutgoing": "--color-text-chat-bubble-outgoing-f3r63s",
    "colorTextChatBubbleIncoming": "--color-text-chat-bubble-incoming-od0yh8",
    "colorBorderButtonLinkDisabled": "--color-border-button-link-disabled-npwqxa",
    "colorBorderButtonNormalActive": "--color-border-button-normal-active-ru7yhb",
    "colorBorderButtonNormalDefault": "--color-border-button-normal-default-glqfp1",
    "colorBorderToggleButtonNormalPressed": "--color-border-toggle-button-normal-pressed-tq8o41",
    "colorBorderButtonNormalDisabled": "--color-border-button-normal-disabled-pkhetz",
    "colorTextButtonNormalDisabled": "--color-text-button-normal-disabled-05p74s",
    "colorBorderButtonNormalHover": "--color-border-button-normal-hover-6a2tdq",
    "colorTextButtonIconDisabled": "--color-text-button-icon-disabled-nnofkn",
    "colorBorderButtonPrimaryActive": "--color-border-button-primary-active-6jnxoc",
    "colorBorderButtonPrimaryDefault": "--color-border-button-primary-default-45p8u2",
    "colorBorderButtonPrimaryDisabled": "--color-border-button-primary-disabled-b5p1ji",
    "colorBorderButtonPrimaryHover": "--color-border-button-primary-hover-rktx0f",
    "colorTextButtonPrimaryDisabled": "--color-text-button-primary-disabled-q79gms",
    "colorItemSelected": "--color-item-selected-72rnwy",
    "colorBorderCalendarGrid": "--color-border-calendar-grid-67r4w4",
    "colorBorderCalendarGridSelectedFocusRing": "--color-border-calendar-grid-selected-focus-ring-jk1fb0",
    "colorBorderCellShaded": "--color-border-cell-shaded-0ipazf",
    "colorBorderCodeEditorAceActiveLineLightTheme": "--color-border-code-editor-ace-active-line-light-theme-q6hsvt",
    "colorBorderCodeEditorAceActiveLineDarkTheme": "--color-border-code-editor-ace-active-line-dark-theme-v09eti",
    "colorBorderCodeEditorDefault": "--color-border-code-editor-default-2bfcfq",
    "colorBorderCodeEditorPaneItemHover": "--color-border-code-editor-pane-item-hover-wvblek",
    "colorBorderCard": "--color-border-card-3n24fu",
    "colorBorderCardHighlighted": "--color-border-card-highlighted-ygosod",
    "colorBorderItemCard": "--color-border-item-card-fia23i",
    "colorBorderItemCardHighlighted": "--color-border-item-card-highlighted-5l7rko",
    "colorBorderContainerDivider": "--color-border-container-divider-9huz1a",
    "colorBorderContainerTop": "--color-border-container-top-k3vmoz",
    "colorBorderControlChecked": "--color-border-control-checked-bdv28l",
    "colorBorderControlDefault": "--color-border-control-default-sh3548",
    "colorBorderControlDisabled": "--color-border-control-disabled-uj7t08",
    "colorBorderDividerActive": "--color-border-divider-active-biq3j4",
    "colorBorderDividerDefault": "--color-border-divider-default-nr68jt",
    "colorBorderDividerPanelBottom": "--color-border-divider-panel-bottom-bruvuz",
    "colorBorderDividerPanelSide": "--color-border-divider-panel-side-an0w07",
    "colorBorderDividerSecondary": "--color-border-divider-secondary-qoitch",
    "colorBorderDropdownContainer": "--color-border-dropdown-container-cmthq7",
    "colorBorderDropdownGroup": "--color-border-dropdown-group-ylcnh8",
    "colorBorderDropdownItemDefault": "--color-border-dropdown-item-default-kape37",
    "colorBorderDropdownItemHover": "--color-border-dropdown-item-hover-aqfuxq",
    "colorBorderDropdownItemDimmedHover": "--color-border-dropdown-item-dimmed-hover-ga9sch",
    "colorBorderDropdownItemSelected": "--color-border-dropdown-item-selected-dl2ezh",
    "colorBorderDropdownItemTop": "--color-border-dropdown-item-top-gp2d1p",
    "colorBorderEditableCellHover": "--color-border-editable-cell-hover-2hmo55",
    "colorBorderInputDefault": "--color-border-input-default-317xk5",
    "colorBorderInputDisabled": "--color-border-input-disabled-zgnzvk",
    "colorBorderInputFocused": "--color-border-input-focused-4z0pgn",
    "colorBorderItemFocused": "--color-border-item-focused-uk47pl",
    "colorBorderDropdownItemFocused": "--color-border-dropdown-item-focused-zacqlp",
    "colorBorderItemPlaceholder": "--color-border-item-placeholder-x8kbjp",
    "colorBorderItemSelected": "--color-border-item-selected-wl5ttm",
    "colorBorderLayout": "--color-border-layout-ayg8vb",
    "colorBorderNotificationStackBar": "--color-border-notification-stack-bar-aszsse",
    "colorBorderPanelHeader": "--color-border-panel-header-ygztvl",
    "colorBorderPopover": "--color-border-popover-1ye6tz",
    "colorBorderSegmentActive": "--color-border-segment-active-ls9t4n",
    "colorBorderSegmentDefault": "--color-border-segment-default-6ig2mo",
    "colorBorderSegmentDisabled": "--color-border-segment-disabled-fcrbcl",
    "colorBorderSegmentHover": "--color-border-segment-hover-0o9ey3",
    "colorBorderStatusError": "--color-border-status-error-j8acpp",
    "colorBorderStatusInfo": "--color-border-status-info-qf6jok",
    "colorBorderStatusSuccess": "--color-border-status-success-8z5f8u",
    "colorBorderStatusWarning": "--color-border-status-warning-j40pg7",
    "colorBorderDialog": "--color-border-dialog-0rjwug",
    "colorBorderDividerInteractiveDefault": "--color-border-divider-interactive-default-r928dz",
    "colorBorderTabsDivider": "--color-border-tabs-divider-f5t9va",
    "colorBorderTabsShadow": "--color-border-tabs-shadow-ugyo07",
    "colorBorderTabsUnderline": "--color-border-tabs-underline-gudemr",
    "colorBorderTilesDisabled": "--color-border-tiles-disabled-19olbu",
    "colorBorderTutorial": "--color-border-tutorial-zggi80",
    "colorForegroundControlDefault": "--color-foreground-control-default-eto4wy",
    "colorForegroundControlDisabled": "--color-foreground-control-disabled-txi6cf",
    "colorForegroundControlReadOnly": "--color-foreground-control-read-only-7ydvuj",
    "colorShadowDefault": "--color-shadow-default-o7dmmm",
    "colorShadowMedium": "--color-shadow-medium-x7of55",
    "colorShadowSide": "--color-shadow-side-rtsbda",
    "colorStrokeChartLine": "--color-stroke-chart-line-3nsnk6",
    "colorStrokeCodeEditorGutterActiveLineDefault": "--color-stroke-code-editor-gutter-active-line-default-5hrdmu",
    "colorStrokeCodeEditorGutterActiveLineHover": "--color-stroke-code-editor-gutter-active-line-hover-vqrb6s",
    "colorTextAccent": "--color-text-accent-n1kmht",
    "colorTextBodyDefault": "--color-text-body-default-vvtq8u",
    "colorTextBodySecondary": "--color-text-body-secondary-yna5sb",
    "colorTextBreadcrumbCurrent": "--color-text-breadcrumb-current-2mqnkk",
    "colorTextBreadcrumbIcon": "--color-text-breadcrumb-icon-9j48ot",
    "colorTextButtonInlineIconDefault": "--color-text-button-inline-icon-default-sm4ql6",
    "colorTextButtonInlineIconDisabled": "--color-text-button-inline-icon-disabled-82hho0",
    "colorTextButtonInlineIconHover": "--color-text-button-inline-icon-hover-rbyzfc",
    "colorTextButtonNormalActive": "--color-text-button-normal-active-vihsxh",
    "colorTextToggleButtonNormalPressed": "--color-text-toggle-button-normal-pressed-wnx2zl",
    "colorTextButtonNormalDefault": "--color-text-button-normal-default-nzalii",
    "colorTextButtonNormalHover": "--color-text-button-normal-hover-gusgyv",
    "colorTextLinkButtonNormalDefault": "--color-text-link-button-normal-default-srprth",
    "colorTextLinkButtonNormalHover": "--color-text-link-button-normal-hover-jrnyw3",
    "colorTextLinkButtonNormalActive": "--color-text-link-button-normal-active-js9ryu",
    "colorTextButtonLinkActive": "--color-text-button-link-active-dqdjg3",
    "colorTextButtonLinkDefault": "--color-text-button-link-default-vvunrs",
    "colorTextButtonLinkDisabled": "--color-text-button-link-disabled-12wh7a",
    "colorTextButtonLinkHover": "--color-text-button-link-hover-kvrc36",
    "colorTextButtonPrimaryActive": "--color-text-button-primary-active-refmba",
    "colorTextButtonPrimaryDefault": "--color-text-button-primary-default-mwl31m",
    "colorTextButtonPrimaryHover": "--color-text-button-primary-hover-pw12ep",
    "colorTextCalendarDateHover": "--color-text-calendar-date-hover-3fcriv",
    "colorTextCalendarMonth": "--color-text-calendar-month-ea0e93",
    "colorTextCodeEditorGutterActiveLine": "--color-text-code-editor-gutter-active-line-2addhd",
    "colorTextCodeEditorGutterDefault": "--color-text-code-editor-gutter-default-nlshs8",
    "colorTextCodeEditorStatusBarDisabled": "--color-text-code-editor-status-bar-disabled-xxmtlc",
    "colorTextCodeEditorTabButtonError": "--color-text-code-editor-tab-button-error-avwh01",
    "colorTextColumnHeader": "--color-text-column-header-e6urd1",
    "colorTextColumnSortingIcon": "--color-text-column-sorting-icon-fngn77",
    "colorTextControlDisabled": "--color-text-control-disabled-upk9lz",
    "colorTextCounter": "--color-text-counter-bywf75",
    "colorTextDisabled": "--color-text-disabled-rox5hg",
    "colorTextDisabledInlineEdit": "--color-text-disabled-inline-edit-1cbiz8",
    "colorTextDropdownFooter": "--color-text-dropdown-footer-umcot2",
    "colorTextDropdownGroupLabel": "--color-text-dropdown-group-label-2tmyik",
    "colorTextDropdownItemDefault": "--color-text-dropdown-item-default-f1jr9u",
    "colorTextDropdownItemDimmed": "--color-text-dropdown-item-dimmed-tq8vh3",
    "colorTextDropdownItemDisabled": "--color-text-dropdown-item-disabled-8m65hf",
    "colorTextDropdownItemFilterMatch": "--color-text-dropdown-item-filter-match-ebhvct",
    "colorTextDropdownItemHighlighted": "--color-text-dropdown-item-highlighted-yr1px8",
    "colorTextDropdownItemSecondary": "--color-text-dropdown-item-secondary-v12lfh",
    "colorTextDropdownItemSecondaryHover": "--color-text-dropdown-item-secondary-hover-de15wb",
    "colorTextEmpty": "--color-text-empty-tlohug",
    "colorTextExpandableSectionDefault": "--color-text-expandable-section-default-ynw8my",
    "colorTextExpandableSectionHover": "--color-text-expandable-section-hover-ojzwhd",
    "colorTextExpandableSectionNavigationIconDefault": "--color-text-expandable-section-navigation-icon-default-mklu1s",
    "colorTextFormDefault": "--color-text-form-default-47mtz6",
    "colorTextFormLabel": "--color-text-form-label-6sbm75",
    "colorTextFormSecondary": "--color-text-form-secondary-1nm780",
    "colorTextGroupLabel": "--color-text-group-label-a2qc05",
    "colorTextLabelGenAi": "--color-text-label-gen-ai-a2n3od",
    "colorTextHeadingDefault": "--color-text-heading-default-izpp46",
    "colorTextHeadingSecondary": "--color-text-heading-secondary-iwtvf6",
    "colorTextHomeHeaderDefault": "--color-text-home-header-default-morg6i",
    "colorTextHomeHeaderSecondary": "--color-text-home-header-secondary-i4jhp7",
    "colorTextIconCaret": "--color-text-icon-caret-9mqubk",
    "colorTextIconSubtle": "--color-text-icon-subtle-3sgxlr",
    "colorTextInputDisabled": "--color-text-input-disabled-wh1f3y",
    "colorTextInputPlaceholder": "--color-text-input-placeholder-dclg8u",
    "colorTextInputPlaceholderDisabled": "--color-text-input-placeholder-disabled-wg87og",
    "colorTextInteractiveActive": "--color-text-interactive-active-uoe6zi",
    "colorTextInteractiveDefault": "--color-text-interactive-default-ugh9wp",
    "colorTextInteractiveDisabled": "--color-text-interactive-disabled-1bqmrl",
    "colorTextInteractiveHover": "--color-text-interactive-hover-6naf7i",
    "colorTextToggleButtonIconPressed": "--color-text-toggle-button-icon-pressed-detfkz",
    "colorTextInteractiveInvertedDefault": "--color-text-interactive-inverted-default-xlc0d5",
    "colorTextInteractiveInvertedHover": "--color-text-interactive-inverted-hover-65rnp7",
    "colorTextInverted": "--color-text-inverted-4v4dmq",
    "colorTextLabel": "--color-text-label-28gfmc",
    "colorTextKeyValuePairsValue": "--color-text-key-value-pairs-value-pezok9",
    "colorTextLayoutToggle": "--color-text-layout-toggle-1a15s3",
    "colorTextLayoutToggleActive": "--color-text-layout-toggle-active-ifu7qp",
    "colorTextLayoutToggleHover": "--color-text-layout-toggle-hover-9jwdce",
    "colorTextLayoutToggleSelected": "--color-text-layout-toggle-selected-xpximc",
    "colorTextLinkDefault": "--color-text-link-default-hude44",
    "colorTextLinkHover": "--color-text-link-hover-2hfec2",
    "colorTextLinkDecorationDefault": "--color-text-link-decoration-default-0x8fhu",
    "colorTextLinkDecorationHover": "--color-text-link-decoration-hover-kui2t9",
    "colorTextLinkSecondaryDefault": "--color-text-link-secondary-default-4p0gj8",
    "colorTextLinkSecondaryHover": "--color-text-link-secondary-hover-0kzmc4",
    "colorTextLinkInfoDefault": "--color-text-link-info-default-mrmt1i",
    "colorTextLinkInfoHover": "--color-text-link-info-hover-mu3ega",
    "colorTextLinkInvertedHover": "--color-text-link-inverted-hover-ocd3u3",
    "colorTextLinkButtonUnderline": "--color-text-link-button-underline-z4wjnv",
    "colorTextLinkButtonUnderlineHover": "--color-text-link-button-underline-hover-cn3mqh",
    "colorTextNotificationDefault": "--color-text-notification-default-1iey72",
    "colorTextNotificationStackBar": "--color-text-notification-stack-bar-tjj0ek",
    "colorTextNotificationYellow": "--color-text-notification-yellow-vjtdxk",
    "colorTextPaginationPageNumberActiveDisabled": "--color-text-pagination-page-number-active-disabled-gfl43p",
    "colorTextPaginationPageNumberDefault": "--color-text-pagination-page-number-default-74j15c",
    "colorTextSegmentActive": "--color-text-segment-active-hlorbe",
    "colorTextSegmentDefault": "--color-text-segment-default-vi2vn9",
    "colorTextSegmentHover": "--color-text-segment-hover-65a2x8",
    "colorTextSmall": "--color-text-small-m1tr70",
    "colorTextStatusError": "--color-text-status-error-ksqavh",
    "colorTextStatusInactive": "--color-text-status-inactive-gy7337",
    "colorTextStatusInfo": "--color-text-status-info-ue8bd2",
    "colorTextStatusSuccess": "--color-text-status-success-ybmii8",
    "colorTextStatusWarning": "--color-text-status-warning-6meo06",
    "colorTextTopNavigationTitle": "--color-text-top-navigation-title-en0v40",
    "colorTextTutorialHotspotDefault": "--color-text-tutorial-hotspot-default-xfv3ow",
    "colorTextTutorialHotspotHover": "--color-text-tutorial-hotspot-hover-92pxog",
    "colorBoardPlaceholderActive": "--color-board-placeholder-active-x6yfem",
    "colorBoardPlaceholderHover": "--color-board-placeholder-hover-5nov9c",
    "colorDragPlaceholderActive": "--color-drag-placeholder-active-ea1sgp",
    "colorDragPlaceholderHover": "--color-drag-placeholder-hover-qwadna",
    "colorDropzoneBackgroundDefault": "--color-dropzone-background-default-7efhmb",
    "colorDropzoneBackgroundHover": "--color-dropzone-background-hover-mi8rlm",
    "colorDropzoneTextDefault": "--color-dropzone-text-default-djdnme",
    "colorDropzoneTextHover": "--color-dropzone-text-hover-asw3rt",
    "colorDropzoneBorderDefault": "--color-dropzone-border-default-k648ha",
    "colorDropzoneBorderHover": "--color-dropzone-border-hover-otpag5",
    "colorGapGlobalDrawer": "--color-gap-global-drawer-nh699a",
    "colorTreeViewConnectorLine": "--color-tree-view-connector-line-1usxvn",
    "colorBackgroundActionCardDefault": "--color-background-action-card-default-src0mr",
    "colorBackgroundActionCardHover": "--color-background-action-card-hover-doobfp",
    "colorBackgroundActionCardActive": "--color-background-action-card-active-4mj226",
    "colorBorderActionCardDefault": "--color-border-action-card-default-dtywof",
    "colorBorderActionCardHover": "--color-border-action-card-hover-onrya1",
    "colorBorderActionCardActive": "--color-border-action-card-active-ak3vrv",
    "colorBorderActionCardDisabled": "--color-border-action-card-disabled-9xqqxt",
    "colorBackgroundActionCardDisabled": "--color-background-action-card-disabled-71qsdt",
    "colorTextActionCardDisabled": "--color-text-action-card-disabled-htx40i",
    "colorIconActionCardDefault": "--color-icon-action-card-default-anh0vz",
    "colorIconActionCardHover": "--color-icon-action-card-hover-qxq4pp",
    "colorIconActionCardActive": "--color-icon-action-card-active-rhp94s",
    "colorIconActionCardDisabled": "--color-icon-action-card-disabled-wm3kyf",
    "colorBackgroundSkeleton": "--color-background-skeleton-sjxg4n",
    "colorBackgroundSkeletonWave": "--color-background-skeleton-wave-1dy97d",
    "fontBoxValueLargeWeight": "--font-box-value-large-weight-wr00sw",
    "fontButtonLetterSpacing": "--font-button-letter-spacing-ufowe3",
    "fontChartDetailSize": "--font-chart-detail-size-9qr25q",
    "fontDecorationStyleLink": "--font-decoration-style-link-pk2xmp",
    "fontDecorationThicknessLink": "--font-decoration-thickness-link-uesuo7",
    "fontDecorationThicknessLinkDisplayL": "--font-decoration-thickness-link-display-l-6g5fyl",
    "fontDisplayLabelWeight": "--font-display-label-weight-zavpeo",
    "fontExpandableHeadingSize": "--font-expandable-heading-size-0uk059",
    "fontFamilyBase": "--font-family-base-gmnpzl",
    "fontFamilyDisplay": "--font-family-display-a93nj0",
    "fontFamilyHeading": "--font-family-heading-ugphat",
    "fontFamilyMonospace": "--font-family-monospace-q47m7k",
    "fontHeaderH2DescriptionLineHeight": "--font-header-h2-description-line-height-ts2s6o",
    "fontHeaderH2DescriptionSize": "--font-header-h2-description-size-g2wws3",
    "fontLinkButtonLetterSpacing": "--font-link-button-letter-spacing-imtxwq",
    "fontLinkButtonWeight": "--font-link-button-weight-vslyg9",
    "fontPanelHeaderLineHeight": "--font-panel-header-line-height-8xb2qj",
    "fontPanelHeaderSize": "--font-panel-header-size-33h9j8",
    "fontSizeBodyM": "--font-size-body-m-a7nh2n",
    "fontSizeBodyS": "--font-size-body-s-smc8cv",
    "fontSizeDisplayL": "--font-size-display-l-wa6woo",
    "fontSizeFormLabel": "--font-size-form-label-mxiqd7",
    "fontSizeHeadingL": "--font-size-heading-l-vnacx6",
    "fontSizeHeadingM": "--font-size-heading-m-170yiy",
    "fontSizeHeadingS": "--font-size-heading-s-zp08en",
    "fontSizeHeadingXl": "--font-size-heading-xl-wvkbur",
    "fontSizeHeadingXs": "--font-size-heading-xs-j8yzxv",
    "fontSizeKeyValuePairsLabel": "--font-size-key-value-pairs-label-1mmf3j",
    "fontSizeTabs": "--font-size-tabs-eeo215",
    "fontSmoothingMozOsx": "--font-smoothing-moz-osx-hbm0aq",
    "fontSmoothingWebkit": "--font-smoothing-webkit-oemolo",
    "fontWayfindingLinkActiveWeight": "--font-wayfinding-link-active-weight-ny4hup",
    "fontWeightAlertHeader": "--font-weight-alert-header-zg25o1",
    "fontWeightBold": "--font-weight-bold-fo1afg",
    "fontWeightBreadcrumbCurrent": "--font-weight-breadcrumb-current-v39mbh",
    "fontWeightButton": "--font-weight-button-0eg20c",
    "fontWeightDisplayL": "--font-weight-display-l-h5zsi8",
    "fontWeightFlashbarHeader": "--font-weight-flashbar-header-fg5kye",
    "fontWeightFormLabel": "--font-weight-form-label-mrg9ef",
    "fontWeightHeadingL": "--font-weight-heading-l-0t6dwc",
    "fontWeightHeadingM": "--font-weight-heading-m-zf82dr",
    "fontWeightHeadingS": "--font-weight-heading-s-lcx0ai",
    "fontWeightHeadingXl": "--font-weight-heading-xl-u3m4we",
    "fontWeightHeadingXs": "--font-weight-heading-xs-wqqpne",
    "fontWeightHeavy": "--font-weight-heavy-6yh4un",
    "fontWeightKeyValuePairsLabel": "--font-weight-key-value-pairs-label-zdidmd",
    "fontWeightLighter": "--font-weight-lighter-ldkoj5",
    "fontWeightNormal": "--font-weight-normal-cxw1m3",
    "fontWeightTabs": "--font-weight-tabs-ichxzl",
    "fontWeightTabsDisabled": "--font-weight-tabs-disabled-v5r551",
    "letterSpacingBodyS": "--letter-spacing-body-s-gq78ok",
    "letterSpacingDisplayL": "--letter-spacing-display-l-elyyxk",
    "letterSpacingHeadingL": "--letter-spacing-heading-l-5v6ibv",
    "letterSpacingHeadingM": "--letter-spacing-heading-m-29ewnk",
    "letterSpacingHeadingS": "--letter-spacing-heading-s-4st9ep",
    "letterSpacingHeadingXl": "--letter-spacing-heading-xl-ckkb6u",
    "letterSpacingHeadingXs": "--letter-spacing-heading-xs-fgog7a",
    "lineHeightBodyM": "--line-height-body-m-2mh3ke",
    "lineHeightBodyS": "--line-height-body-s-nu5hx1",
    "lineHeightDisplayL": "--line-height-display-l-vwanzp",
    "lineHeightFormLabel": "--line-height-form-label-asu26u",
    "lineHeightHeadingL": "--line-height-heading-l-mg5bx6",
    "lineHeightHeadingM": "--line-height-heading-m-uoaqdh",
    "lineHeightHeadingS": "--line-height-heading-s-hmi4vc",
    "lineHeightHeadingXl": "--line-height-heading-xl-hko6p0",
    "lineHeightHeadingXs": "--line-height-heading-xs-q9j004",
    "lineHeightKeyValuePairsLabel": "--line-height-key-value-pairs-label-x3ofa3",
    "lineHeightTabs": "--line-height-tabs-vpnjo7",
    "borderActiveWidth": "--border-active-width-axzm24",
    "borderCodeEditorStatusDividerWidth": "--border-code-editor-status-divider-width-4we6jf",
    "borderContainerStickyWidth": "--border-container-sticky-width-nri0ix",
    "borderContainerTopWidth": "--border-container-top-width-n1eke6",
    "borderControlFocusRingShadowSpread": "--border-control-focus-ring-shadow-spread-9mjajk",
    "borderControlInvalidFocusRingShadowSpread": "--border-control-invalid-focus-ring-shadow-spread-9jjf96",
    "borderDividerListWidth": "--border-divider-list-width-tdfx1x",
    "borderDividerSectionWidth": "--border-divider-section-width-uwo8my",
    "borderDropdownVirtualOffsetWidth": "--border-dropdown-virtual-offset-width-3wp954",
    "borderInvalidWidth": "--border-invalid-width-3xd6e1",
    "borderItemWidth": "--border-item-width-miijiw",
    "borderLineChartDashArray": "--border-line-chart-dash-array-desefi",
    "borderLineChartLineJoin": "--border-line-chart-line-join-aslwou",
    "borderLineChartWidth": "--border-line-chart-width-tesor1",
    "borderPanelHeaderWidth": "--border-panel-header-width-t1iq1m",
    "borderPanelTopWidth": "--border-panel-top-width-10990j",
    "borderRadiusAlert": "--border-radius-alert-syagf6",
    "borderRadiusBadge": "--border-radius-badge-exolfb",
    "borderRadiusButton": "--border-radius-button-7bgkcs",
    "borderRadiusCalendarDayFocusRing": "--border-radius-calendar-day-focus-ring-xvvbuc",
    "borderRadiusCodeEditor": "--border-radius-code-editor-5palck",
    "borderRadiusCardDefault": "--border-radius-card-default-d8ipr7",
    "borderRadiusCardEmbedded": "--border-radius-card-embedded-fvclp8",
    "borderRadiusItemCardDefault": "--border-radius-item-card-default-pi9u8q",
    "borderRadiusItemCardEmbedded": "--border-radius-item-card-embedded-l0g6e3",
    "borderRadiusContainer": "--border-radius-container-nsfwmm",
    "borderRadiusControlCircularFocusRing": "--border-radius-control-circular-focus-ring-yjhscw",
    "borderRadiusControlDefaultFocusRing": "--border-radius-control-default-focus-ring-1uabki",
    "borderRadiusDropdown": "--border-radius-dropdown-fgc2a1",
    "borderRadiusDropzone": "--border-radius-dropzone-eklq14",
    "borderRadiusFlashbar": "--border-radius-flashbar-pp1ptu",
    "borderRadiusItem": "--border-radius-item-iwaia5",
    "borderRadiusInput": "--border-radius-input-7q0str",
    "borderRadiusPopover": "--border-radius-popover-6fqb5w",
    "borderRadiusTabsFocusRing": "--border-radius-tabs-focus-ring-o4qku1",
    "borderRadiusTiles": "--border-radius-tiles-wm1vgw",
    "borderRadiusToken": "--border-radius-token-ycnemh",
    "borderRadiusChatBubble": "--border-radius-chat-bubble-haafsg",
    "borderRadiusTutorialPanelItem": "--border-radius-tutorial-panel-item-ojaqxg",
    "borderTableStickyWidth": "--border-table-sticky-width-ai31mi",
    "borderLinkFocusRingOutline": "--border-link-focus-ring-outline-1p0hnu",
    "borderLinkFocusRingShadowSpread": "--border-link-focus-ring-shadow-spread-39uvxr",
    "borderWidthCard": "--border-width-card-x24gzt",
    "borderWidthCardSelected": "--border-width-card-selected-01i6br",
    "borderWidthItemCard": "--border-width-item-card-3wmyp3",
    "borderWidthItemCardHighlighted": "--border-width-item-card-highlighted-jay4ll",
    "borderWidthItemSelected": "--border-width-item-selected-yv93vd",
    "borderWidthAlert": "--border-width-alert-tuifgy",
    "borderWidthAlertBlockStart": "--border-width-alert-block-start-5wbfsk",
    "borderWidthAlertBlockEnd": "--border-width-alert-block-end-q8rr42",
    "borderWidthAlertInlineStart": "--border-width-alert-inline-start-gjm6m1",
    "borderWidthAlertInlineEnd": "--border-width-alert-inline-end-9s426v",
    "borderWidthButton": "--border-width-button-jm0qg7",
    "borderWidthDropdown": "--border-width-dropdown-youcay",
    "borderWidthField": "--border-width-field-2xc78x",
    "borderWidthPopover": "--border-width-popover-nflirh",
    "borderWidthToken": "--border-width-token-2ukdpu",
    "borderWidthIconSmall": "--border-width-icon-small-z55i5t",
    "borderWidthIconNormal": "--border-width-icon-normal-9h7vj7",
    "borderWidthIconMedium": "--border-width-icon-medium-b7icqv",
    "borderWidthIconBig": "--border-width-icon-big-ymgy42",
    "borderWidthIconLarge": "--border-width-icon-large-u645rg",
    "borderRadiusActionCardDefault": "--border-radius-action-card-default-ejctkq",
    "borderRadiusActionCardEmbedded": "--border-radius-action-card-embedded-3y65t8",
    "borderWidthActionCardDefault": "--border-width-action-card-default-jy3kut",
    "borderWidthActionCardHover": "--border-width-action-card-hover-02l6fg",
    "borderWidthActionCardActive": "--border-width-action-card-active-pwtgzu",
    "borderWidthActionCardDisabled": "--border-width-action-card-disabled-rdvlbc",
    "borderRadiusSkeleton": "--border-radius-skeleton-9lkvfi",
    "motionDurationExtraFast": "--motion-duration-extra-fast-l4w48j",
    "motionDurationExtraSlow": "--motion-duration-extra-slow-29bqym",
    "motionDurationFast": "--motion-duration-fast-unntf6",
    "motionDurationModerate": "--motion-duration-moderate-c9utmg",
    "motionDurationRefreshOnlyAmbient": "--motion-duration-refresh-only-ambient-sxpcba",
    "motionDurationRefreshOnlyFast": "--motion-duration-refresh-only-fast-zfibh6",
    "motionDurationRefreshOnlyMedium": "--motion-duration-refresh-only-medium-5rbn3k",
    "motionDurationRefreshOnlySlow": "--motion-duration-refresh-only-slow-ugjy90",
    "motionDurationAvatarGenAiGradient": "--motion-duration-avatar-gen-ai-gradient-84si5n",
    "motionDurationAvatarLoadingDots": "--motion-duration-avatar-loading-dots-1xxvis",
    "motionDurationRotate180": "--motion-duration-rotate-180-cxi9g7",
    "motionDurationRotate90": "--motion-duration-rotate-90-lyzb0k",
    "motionDurationShowPaced": "--motion-duration-show-paced-otsjh8",
    "motionDurationShowQuick": "--motion-duration-show-quick-tyvnyw",
    "motionDurationSlow": "--motion-duration-slow-zji5vl",
    "motionDurationTransitionQuick": "--motion-duration-transition-quick-mcm2y0",
    "motionDurationTransitionShowPaced": "--motion-duration-transition-show-paced-t8d1os",
    "motionDurationTransitionShowQuick": "--motion-duration-transition-show-quick-5jnnjz",
    "motionEasingEaseOutQuart": "--motion-easing-ease-out-quart-p9axhm",
    "motionEasingRefreshOnlyA": "--motion-easing-refresh-only-a-ccyqaz",
    "motionEasingRefreshOnlyB": "--motion-easing-refresh-only-b-44kz4o",
    "motionEasingRefreshOnlyC": "--motion-easing-refresh-only-c-cxy2sk",
    "motionEasingRefreshOnlyD": "--motion-easing-refresh-only-d-syj3g1",
    "motionEasingAvatarGenAiGradient": "--motion-easing-avatar-gen-ai-gradient-9fwaak",
    "motionEasingRotate180": "--motion-easing-rotate-180-7a58rc",
    "motionEasingRotate90": "--motion-easing-rotate-90-jhbqg9",
    "motionEasingShowPaced": "--motion-easing-show-paced-ym6eyn",
    "motionEasingShowQuick": "--motion-easing-show-quick-9hlj8q",
    "motionEasingTransitionQuick": "--motion-easing-transition-quick-qxak3i",
    "motionEasingTransitionShowPaced": "--motion-easing-transition-show-paced-x2k7uh",
    "motionEasingTransitionShowQuick": "--motion-easing-transition-show-quick-jz3lia",
    "motionEasingResponsive": "--motion-easing-responsive-hjj3ai",
    "motionEasingSticky": "--motion-easing-sticky-tn072u",
    "motionEasingExpressive": "--motion-easing-expressive-o5jqzg",
    "motionDurationResponsive": "--motion-duration-responsive-mehora",
    "motionDurationExpressive": "--motion-duration-expressive-cbdcwy",
    "motionDurationComplex": "--motion-duration-complex-tbdo30",
    "motionKeyframesFadeIn": "--motion-keyframes-fade-in-0r842q",
    "motionKeyframesFadeOut": "--motion-keyframes-fade-out-g7fgdu",
    "motionKeyframesStatusIconError": "--motion-keyframes-status-icon-error-wkou39",
    "motionKeyframesScalePopup": "--motion-keyframes-scale-popup-9iqcu0",
    "sizeCalendarGridWidth": "--size-calendar-grid-width-hv3136",
    "sizeControl": "--size-control-adm93y",
    "sizeIconBig": "--size-icon-big-7pq9l3",
    "sizeIconLarge": "--size-icon-large-mb6y6y",
    "sizeIconMedium": "--size-icon-medium-uv8xcz",
    "sizeIconNormal": "--size-icon-normal-levt08",
    "sizeTableSelectionHorizontal": "--size-table-selection-horizontal-qqiajd",
    "sizeVerticalInput": "--size-vertical-input-p1d7xx",
    "sizeVerticalPanelIconOffset": "--size-vertical-panel-icon-offset-z959cw",
    "spaceAlertActionLeft": "--space-alert-action-left-4s8zo5",
    "spaceAlertHorizontal": "--space-alert-horizontal-ul364s",
    "spaceAlertMessageRight": "--space-alert-message-right-mrjbnn",
    "spaceAlertVertical": "--space-alert-vertical-dlp5wr",
    "spaceButtonFocusOutlineGutter": "--space-button-focus-outline-gutter-jj138g",
    "spaceButtonHorizontal": "--space-button-horizontal-k0c786",
    "spaceButtonVertical": "--space-button-vertical-xaxp6x",
    "spaceTokenVertical": "--space-token-vertical-m3oh2a",
    "spaceFieldVertical": "--space-field-vertical-vm99qz",
    "spaceButtonIconFocusOutlineGutterVertical": "--space-button-icon-focus-outline-gutter-vertical-r44mtq",
    "spaceButtonIconOnlyHorizontal": "--space-button-icon-only-horizontal-i85hxi",
    "spaceButtonInlineIconFocusOutlineGutter": "--space-button-inline-icon-focus-outline-gutter-zbfgku",
    "spaceButtonModalDismissVertical": "--space-button-modal-dismiss-vertical-vqfxjd",
    "spaceCalendarGridFocusOutlineGutter": "--space-calendar-grid-focus-outline-gutter-vvh43m",
    "spaceCalendarGridSelectedFocusOutlineGutter": "--space-calendar-grid-selected-focus-outline-gutter-dy6gf8",
    "spaceCalendarGridGutter": "--space-calendar-grid-gutter-zojo6r",
    "spaceCardHorizontalDefault": "--space-card-horizontal-default-pihe12",
    "spaceCardHorizontalEmbedded": "--space-card-horizontal-embedded-sasxhu",
    "spaceCardVerticalDefault": "--space-card-vertical-default-e40tif",
    "spaceCardVerticalEmbedded": "--space-card-vertical-embedded-30pnhg",
    "spaceItemCardHorizontalDefault": "--space-item-card-horizontal-default-obq2ks",
    "spaceItemCardHorizontalEmbedded": "--space-item-card-horizontal-embedded-e0vef5",
    "spaceItemCardVerticalDefault": "--space-item-card-vertical-default-ppqfu4",
    "spaceItemCardVerticalEmbedded": "--space-item-card-vertical-embedded-zuozef",
    "spaceCodeEditorStatusFocusOutlineGutter": "--space-code-editor-status-focus-outline-gutter-o87hra",
    "spaceContainerContentTop": "--space-container-content-top-1wtqrc",
    "spaceContainerHeaderTop": "--space-container-header-top-am4vzw",
    "spaceContainerHeaderBottom": "--space-container-header-bottom-2taq8v",
    "spaceContainerHorizontal": "--space-container-horizontal-nqrzyh",
    "spaceContentHeaderPaddingBottom": "--space-content-header-padding-bottom-rvy5xz",
    "spaceDarkHeaderOverlapDistance": "--space-dark-header-overlap-distance-ld45ap",
    "spaceExpandableSectionIconOffsetTop": "--space-expandable-section-icon-offset-top-cntyn8",
    "spaceFieldHorizontal": "--space-field-horizontal-0aq2ch",
    "spaceFieldIconOffset": "--space-field-icon-offset-ikwzwx",
    "spaceFilteringTokenDismissButtonFocusOutlineGutter": "--space-filtering-token-dismiss-button-focus-outline-gutter-1iumy3",
    "spaceFilteringTokenOperationSelectFocusOutlineGutter": "--space-filtering-token-operation-select-focus-outline-gutter-jacx1t",
    "spaceFlashbarActionLeft": "--space-flashbar-action-left-rqk3ap",
    "spaceFlashbarDismissRight": "--space-flashbar-dismiss-right-ckhj91",
    "spaceFlashbarHorizontal": "--space-flashbar-horizontal-l63501",
    "spaceFlashbarVertical": "--space-flashbar-vertical-th71op",
    "spaceGridGutter": "--space-grid-gutter-whc3jp",
    "spaceKeyValueGap": "--space-key-value-gap-9glmqc",
    "spaceLayoutContentBottom": "--space-layout-content-bottom-zeb1g9",
    "spaceLayoutContentHorizontal": "--space-layout-content-horizontal-buc0zz",
    "spaceLayoutToggleDiameter": "--space-layout-toggle-diameter-j2qffw",
    "spaceLayoutTogglePadding": "--space-layout-toggle-padding-chwlhz",
    "spaceModalContentBottom": "--space-modal-content-bottom-nl6ceq",
    "spaceModalHorizontal": "--space-modal-horizontal-y5hnwp",
    "spacePanelContentBottom": "--space-panel-content-bottom-24c6lu",
    "spacePanelContentTop": "--space-panel-content-top-qvd1dr",
    "spacePanelDividerMarginHorizontal": "--space-panel-divider-margin-horizontal-yw31p0",
    "spacePanelHeaderVertical": "--space-panel-header-vertical-ckfgmy",
    "spacePanelNavLeft": "--space-panel-nav-left-wn0n7h",
    "spacePanelSideLeft": "--space-panel-side-left-u1m3s9",
    "spacePanelSideRight": "--space-panel-side-right-8wwirc",
    "spacePanelSplitTop": "--space-panel-split-top-3u4vky",
    "spacePanelSplitBottom": "--space-panel-split-bottom-ir16d7",
    "spaceSegmentedControlFocusOutlineGutter": "--space-segmented-control-focus-outline-gutter-x1ywqb",
    "spaceTabsContentTop": "--space-tabs-content-top-ju6qox",
    "spaceTabsFocusOutlineGutter": "--space-tabs-focus-outline-gutter-eerrg4",
    "spaceTabsVertical": "--space-tabs-vertical-3qxuiu",
    "spaceTableContentBottom": "--space-table-content-bottom-tlfqmq",
    "spaceTableEmbeddedHeaderTop": "--space-table-embedded-header-top-twu628",
    "spaceTableFooterHorizontal": "--space-table-footer-horizontal-l5g495",
    "spaceTableHeaderFocusOutlineGutter": "--space-table-header-focus-outline-gutter-ymwujm",
    "spaceTableHeaderHorizontal": "--space-table-header-horizontal-kb5ww2",
    "spaceTableHeaderToolsBottom": "--space-table-header-tools-bottom-d9u5kf",
    "spaceTableHeaderToolsFullPageBottom": "--space-table-header-tools-full-page-bottom-9m47g6",
    "spaceTableHorizontal": "--space-table-horizontal-suurzj",
    "spaceTreeViewIndentation": "--space-tree-view-indentation-xh9kis",
    "spaceTileGutter": "--space-tile-gutter-bi2bdv",
    "spaceActionCardHorizontalDefault": "--space-action-card-horizontal-default-su1e86",
    "spaceActionCardHorizontalEmbedded": "--space-action-card-horizontal-embedded-pb8pj4",
    "spaceActionCardVerticalDefault": "--space-action-card-vertical-default-zqb3v3",
    "spaceActionCardVerticalEmbedded": "--space-action-card-vertical-embedded-f1rm8a",
    "spaceActionCardDescriptionPaddingTop": "--space-action-card-description-padding-top-qw1sd7",
    "spaceActionCardContentPaddingTop": "--space-action-card-content-padding-top-bew8kj",
    "spaceOptionPaddingVertical": "--space-option-padding-vertical-d2srv9",
    "spaceOptionPaddingHorizontal": "--space-option-padding-horizontal-4taa4b",
    "spaceScaled2xNone": "--space-scaled-2x-none-987dp7",
    "spaceScaled2xXxxs": "--space-scaled-2x-xxxs-reumxj",
    "spaceScaled2xXxs": "--space-scaled-2x-xxs-e79hr1",
    "spaceScaled2xXs": "--space-scaled-2x-xs-bcbsqo",
    "spaceScaled2xS": "--space-scaled-2x-s-yr27d5",
    "spaceScaled2xM": "--space-scaled-2x-m-4euqsk",
    "spaceScaled2xL": "--space-scaled-2x-l-u5ida5",
    "spaceScaled2xXl": "--space-scaled-2x-xl-he48nr",
    "spaceScaled2xXxl": "--space-scaled-2x-xxl-sul5ey",
    "spaceScaled2xXxxl": "--space-scaled-2x-xxxl-bxyvwl",
    "spaceScaledNone": "--space-scaled-none-nfyouv",
    "spaceScaledXxxs": "--space-scaled-xxxs-oo06c7",
    "spaceScaledXxs": "--space-scaled-xxs-pfm1nx",
    "spaceScaledXs": "--space-scaled-xs-xwoogq",
    "spaceScaledS": "--space-scaled-s-8ozaad",
    "spaceScaledM": "--space-scaled-m-m892r9",
    "spaceScaledL": "--space-scaled-l-sej05l",
    "spaceScaledXl": "--space-scaled-xl-dunxp5",
    "spaceScaledXxl": "--space-scaled-xxl-6wgq96",
    "spaceScaledXxxl": "--space-scaled-xxxl-hwoy7j",
    "spaceStaticXxxs": "--space-static-xxxs-yidks1",
    "spaceStaticXxs": "--space-static-xxs-ns94dp",
    "spaceStaticXs": "--space-static-xs-gnm0mz",
    "spaceStaticS": "--space-static-s-t763lu",
    "spaceStaticM": "--space-static-m-m6qboo",
    "spaceStaticL": "--space-static-l-n53k41",
    "spaceStaticXl": "--space-static-xl-4tedi6",
    "spaceStaticXxl": "--space-static-xxl-ifa9j8",
    "spaceStaticXxxl": "--space-static-xxxl-tngnnz",
    "spaceNone": "--space-none-xk6qzf",
    "spaceXxxs": "--space-xxxs-pajhad",
    "spaceXxs": "--space-xxs-hwfkai",
    "spaceXs": "--space-xs-ymlm0b",
    "spaceS": "--space-s-tvghoh",
    "spaceM": "--space-m-dsumyt",
    "spaceL": "--space-l-2ud1p3",
    "spaceXl": "--space-xl-jfy3x4",
    "spaceXxl": "--space-xxl-32srm4",
    "spaceXxxl": "--space-xxxl-aut1u7",
    "shadowCard": "--shadow-card-hmrw4q",
    "shadowItemCard": "--shadow-item-card-282f8w",
    "shadowContainer": "--shadow-container-53ltfv",
    "shadowContainerActive": "--shadow-container-active-ypjjoc",
    "shadowDropdown": "--shadow-dropdown-isf0w4",
    "shadowDropup": "--shadow-dropup-2r02r5",
    "shadowFlashCollapsed": "--shadow-flash-collapsed-b68ip6",
    "shadowFlashSticky": "--shadow-flash-sticky-k69vye",
    "shadowModal": "--shadow-modal-kwgqht",
    "shadowPanel": "--shadow-panel-vk7iea",
    "shadowPanelToggle": "--shadow-panel-toggle-qddz27",
    "shadowPopover": "--shadow-popover-pkane9",
    "shadowSplitBottom": "--shadow-split-bottom-vlyulf",
    "shadowSplitSide": "--shadow-split-side-nyajix",
    "shadowSticky": "--shadow-sticky-lolw8j",
    "shadowStickyEmbedded": "--shadow-sticky-embedded-jmny8n",
    "shadowStickyColumnFirst": "--shadow-sticky-column-first-trcd2o",
    "shadowStickyColumnLast": "--shadow-sticky-column-last-qgh697"
  }
};
