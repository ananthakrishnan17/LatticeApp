// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import { getGlobalFlag } from '@cloudscape-design/component-toolkit/internal';
import { useVisualRefresh } from '../hooks/use-visual-mode';
export function createWidgetizedComponent(Implementation, Skeleton) {
    return (Loader) => {
        return (props => {
            const isRefresh = useVisualRefresh();
            if (isRefresh && getGlobalFlag('appLayoutWidget') && Loader) {
                return React.createElement(Loader, { Skeleton: Skeleton, ...props });
            }
            return React.createElement(Implementation, { ...props });
        });
    };
}
//# sourceMappingURL=index.js.map