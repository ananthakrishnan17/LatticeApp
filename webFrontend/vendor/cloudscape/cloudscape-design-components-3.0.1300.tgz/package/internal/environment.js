export var PACKAGE_SOURCE = "components";
export var PACKAGE_VERSION = "3.0.0 (bc6c9867)";
export var GIT_SHA = "bc6c9867";
export var THEME = "open-source-visual-refresh";
export var SYSTEM = "core";
export var ALWAYS_VISUAL_REFRESH = true;