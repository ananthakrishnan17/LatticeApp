import debounce from '../../debounce';
import { reportRuntimeApiWarning } from '../helpers/metrics';
const updatableProperties = [
    'badge',
    'resizable',
    'defaultSize',
    'orderPriority',
    'defaultActive',
    'onResize',
];
export class DrawersController {
    constructor() {
        this.drawers = [];
        this.drawersRegistrationListener = null;
        this.drawerOpenedListener = null;
        this.drawerClosedListener = null;
        this.drawersUpdateListeners = [];
        this.drawerResizeListener = null;
        this.scheduleUpdate = debounce(() => {
            var _a;
            (_a = this.drawersRegistrationListener) === null || _a === void 0 ? void 0 : _a.call(this, this.drawers);
            this.drawersUpdateListeners.forEach(drawersUpdateListeners => {
                drawersUpdateListeners === null || drawersUpdateListeners === void 0 ? void 0 : drawersUpdateListeners(this.drawers);
            });
        }, 0);
        this.registerDrawer = (config) => {
            if (this.drawers.find(drawer => drawer.id === config.id)) {
                reportRuntimeApiWarning('app-layout-drawers', `drawer with id "${config.id}" is already registered`);
            }
            this.drawers = this.drawers.concat(config);
            this.scheduleUpdate();
        };
        this.updateDrawer = ({ id: drawerId, ...rest }) => {
            var _a;
            const drawerIndex = this.drawers.findIndex(({ id }) => id === drawerId);
            const oldDrawerConfig = (_a = this.drawers) === null || _a === void 0 ? void 0 : _a[drawerIndex];
            if (!oldDrawerConfig) {
                throw new Error(`[AwsUi] [runtime drawers] drawer with id ${drawerId} not found`);
            }
            const drawers = this.drawers.slice();
            const updatedDrawer = { ...oldDrawerConfig };
            for (const key of updatableProperties) {
                if (key in rest) {
                    updatedDrawer[key] = rest[key];
                }
            }
            drawers[drawerIndex] = updatedDrawer;
            this.drawers = drawers;
            this.scheduleUpdate();
        };
        this.onDrawersRegistered = (listener) => {
            if (this.drawersRegistrationListener !== null) {
                reportRuntimeApiWarning('app-layout-drawers', 'multiple app layout instances detected when calling onDrawersRegistered');
            }
            this.drawersRegistrationListener = listener;
            this.scheduleUpdate();
            return () => {
                this.drawersRegistrationListener = null;
                this.drawersUpdateListeners = [];
            };
        };
        this.clearRegisteredDrawersForTesting = () => {
            this.drawers = [];
        };
        this.onDrawerOpened = (listener) => {
            if (this.drawerOpenedListener !== null) {
                reportRuntimeApiWarning('app-layout-drawers', 'multiple app layout instances detected when calling onDrawerOpened');
            }
            this.drawerOpenedListener = listener;
            return () => {
                this.drawerOpenedListener = null;
            };
        };
        this.onDrawerClosed = (listener) => {
            if (this.drawerClosedListener !== null) {
                reportRuntimeApiWarning('app-layout-drawers', 'multiple app layout instances detected when calling onDrawerClosed');
            }
            this.drawerClosedListener = listener;
            return () => {
                this.drawerClosedListener = null;
            };
        };
        this.openDrawer = (drawerId, params) => {
            var _a;
            (_a = this.drawerOpenedListener) === null || _a === void 0 ? void 0 : _a.call(this, drawerId, params);
        };
        this.closeDrawer = (drawerId, params) => {
            var _a;
            (_a = this.drawerClosedListener) === null || _a === void 0 ? void 0 : _a.call(this, drawerId, params);
        };
        this.onDrawersUpdated = (listener) => {
            this.drawersUpdateListeners.push(listener);
            return () => {
                this.drawersUpdateListeners = this.drawersUpdateListeners.filter(item => item !== listener);
            };
        };
        this.onDrawerResize = (listener) => {
            if (this.drawerResizeListener !== null) {
                reportRuntimeApiWarning('app-layout-drawers', 'multiple app layout instances detected when calling onDrawerResize');
            }
            this.drawerResizeListener = listener;
            return () => {
                this.drawerResizeListener = null;
            };
        };
        this.resizeDrawer = (drawerId, size) => {
            var _a;
            (_a = this.drawerResizeListener) === null || _a === void 0 ? void 0 : _a.call(this, drawerId, size);
        };
        this.getDrawersState = () => {
            return this.drawers;
        };
    }
    installPublic(api = {}) {
        var _a, _b, _c, _d, _e, _f;
        (_a = api.registerDrawer) !== null && _a !== void 0 ? _a : (api.registerDrawer = this.registerDrawer);
        (_b = api.updateDrawer) !== null && _b !== void 0 ? _b : (api.updateDrawer = this.updateDrawer);
        (_c = api.openDrawer) !== null && _c !== void 0 ? _c : (api.openDrawer = this.openDrawer);
        (_d = api.closeDrawer) !== null && _d !== void 0 ? _d : (api.closeDrawer = this.closeDrawer);
        (_e = api.resizeDrawer) !== null && _e !== void 0 ? _e : (api.resizeDrawer = this.resizeDrawer);
        (_f = api.clearRegisteredDrawersForTesting) !== null && _f !== void 0 ? _f : (api.clearRegisteredDrawersForTesting = this.clearRegisteredDrawersForTesting);
        return api;
    }
    installInternal(internalApi = {}) {
        var _a, _b, _c, _d, _e, _f;
        (_a = internalApi.onDrawersRegistered) !== null && _a !== void 0 ? _a : (internalApi.onDrawersRegistered = this.onDrawersRegistered);
        (_b = internalApi.onDrawerOpened) !== null && _b !== void 0 ? _b : (internalApi.onDrawerOpened = this.onDrawerOpened);
        (_c = internalApi.onDrawerClosed) !== null && _c !== void 0 ? _c : (internalApi.onDrawerClosed = this.onDrawerClosed);
        (_d = internalApi.onDrawerResize) !== null && _d !== void 0 ? _d : (internalApi.onDrawerResize = this.onDrawerResize);
        (_e = internalApi.onDrawersUpdated) !== null && _e !== void 0 ? _e : (internalApi.onDrawersUpdated = this.onDrawersUpdated);
        (_f = internalApi.getDrawersState) !== null && _f !== void 0 ? _f : (internalApi.getDrawersState = this.getDrawersState);
        return internalApi;
    }
}
//# sourceMappingURL=drawers.js.map