// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { getExternalProps } from '../../utils/external-props';
import { getAppLayoutInitialMessages, getAppLayoutMessageHandler, pushInitialMessage, setInitialMessage } from './core';
/**
 * Registers a new left runtime drawer to app layout
 * @param drawer
 */
export function registerLeftDrawer(drawer) {
    var _a;
    const message = { type: 'registerLeftDrawer', payload: drawer };
    pushInitialMessage(message);
    (_a = getAppLayoutMessageHandler()) === null || _a === void 0 ? void 0 : _a(message);
}
/**
 * Registers a new bottom runtime drawer to app layout
 * @param drawer
 */
export function registerBottomDrawer(drawer) {
    var _a;
    const message = { type: 'registerBottomDrawer', payload: { ...drawer, position: 'bottom' } };
    pushInitialMessage(message);
    (_a = getAppLayoutMessageHandler()) === null || _a === void 0 ? void 0 : _a(message);
}
/**
 * Registers a new feature notifications runtime drawer to app layout
 * @param payload
 */
export function registerFeatureNotifications(payload) {
    var _a;
    const message = {
        type: 'registerFeatureNotifications',
        payload,
    };
    pushInitialMessage(message);
    (_a = getAppLayoutMessageHandler()) === null || _a === void 0 ? void 0 : _a(message);
}
export function registerFeatureNotificationsPublic(payload) {
    registerFeatureNotifications(getExternalProps(payload));
}
export function showFeaturePromptIfPossible() {
    updateDrawer({ type: 'showFeaturePromptIfPossible' });
}
export function clearFeatureNotifications() {
    updateDrawer({ type: 'clearFeatureNotifications' });
}
/**
 * Interact with already registered app layout drawers
 * @param message
 */
export function updateDrawer(message) {
    var _a;
    const initialMessages = getAppLayoutInitialMessages();
    if (message.type === 'updateDrawerConfig') {
        initialMessages.forEach(initialMessage => {
            if (initialMessage.payload.id === message.payload.id) {
                initialMessage.payload = { ...initialMessage.payload, ...message.payload };
            }
        });
    }
    if (message.type === 'clearFeatureNotifications') {
        setInitialMessage(initialMessages.filter(initialMessage => initialMessage.type !== 'registerFeatureNotifications'));
    }
    (_a = getAppLayoutMessageHandler()) === null || _a === void 0 ? void 0 : _a(message);
}
//# sourceMappingURL=index.js.map