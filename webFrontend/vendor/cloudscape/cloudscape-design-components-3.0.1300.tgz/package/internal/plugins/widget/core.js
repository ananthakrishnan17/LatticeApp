// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { reportRuntimeApiWarning } from '../helpers/metrics';
const storageKeyMessageHandler = Symbol.for('awsui-widget-api-message-handler');
const storageKeyInitialMessages = Symbol.for('awsui-widget-api-initial-messages');
const storageKeyReadyDeferCallbacks = Symbol.for('awsui-widget-api-ready-defer');
const oneTimeMessageTypes = ['emit-notification'];
function getWindow() {
    return window;
}
export function getAppLayoutMessageHandler() {
    const win = getWindow();
    return win[storageKeyMessageHandler];
}
export function getAppLayoutInitialMessages() {
    var _a;
    const initialMessages = (_a = getWindow()[storageKeyInitialMessages]) !== null && _a !== void 0 ? _a : [];
    getWindow()[storageKeyInitialMessages] = initialMessages.filter(message => !oneTimeMessageTypes.includes(message.type));
    return initialMessages;
}
export function pushInitialMessage(message) {
    var _a;
    const win = getWindow();
    win[storageKeyInitialMessages] = (_a = win[storageKeyInitialMessages]) !== null && _a !== void 0 ? _a : [];
    win[storageKeyInitialMessages].push(message);
}
export function setInitialMessage(message) {
    const win = getWindow();
    win[storageKeyInitialMessages] = message;
}
export function registerAppLayoutHandler(handler) {
    var _a;
    const win = getWindow();
    if (win[storageKeyMessageHandler]) {
        reportRuntimeApiWarning('AppLayoutWidget', 'Double registration attempt, the old handler will be overridden');
    }
    win[storageKeyMessageHandler] = handler;
    (_a = win[storageKeyReadyDeferCallbacks]) === null || _a === void 0 ? void 0 : _a.forEach(fn => fn());
    win[storageKeyReadyDeferCallbacks] = [];
    return () => {
        win[storageKeyMessageHandler] = undefined;
    };
}
export function clearInitialMessages() {
    getWindow()[storageKeyInitialMessages] = undefined;
}
/**
 * Returns whether there is an app layout present on this page or not
 */
export function isAppLayoutReady() {
    return !!getAppLayoutMessageHandler();
}
/**
 * Returns a promise that resolves once the app layout has loaded
 */
export function whenAppLayoutReady() {
    var _a;
    if (isAppLayoutReady()) {
        return Promise.resolve();
    }
    const win = getWindow();
    win[storageKeyReadyDeferCallbacks] = (_a = win[storageKeyReadyDeferCallbacks]) !== null && _a !== void 0 ? _a : [];
    return new Promise(resolve => { var _a; return (_a = win[storageKeyReadyDeferCallbacks]) === null || _a === void 0 ? void 0 : _a.push(resolve); });
}
//# sourceMappingURL=core.js.map