// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { getExternalProps } from '../internal/utils/external-props';
import InternalNavigableGroup from './internal';
const NavigableGroup = React.forwardRef(({ ...rest }, ref) => {
    const baseProps = getBaseProps(rest);
    const baseComponentProps = useBaseComponent('NavigableGroup');
    const externalProps = getExternalProps(rest);
    return React.createElement(InternalNavigableGroup, { ...baseProps, ...baseComponentProps, ...externalProps, ref: ref });
});
applyDisplayName(NavigableGroup, 'NavigableGroup');
/**
 * @awsuiSystem core
 */
export default NavigableGroup;
//# sourceMappingURL=index.js.map