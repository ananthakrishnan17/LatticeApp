// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalButtonDropdown from './internal';
import { hasCheckboxItems, hasDisabledReasonItems } from './utils/utils';
import analyticsSelectors from './analytics-metadata/styles.css.js';
const ButtonDropdown = React.forwardRef(({ items, variant = 'normal', loading = false, loadingText, disabled = false, disabledReason, expandableGroups = false, expandToViewport = false, ariaLabel, children, onItemClick, onItemFollow, mainAction, fullWidth, nativeMainActionAttributes, nativeTriggerAttributes, renderItem, ...props }, ref) => {
    const baseComponentProps = useBaseComponent('ButtonDropdown', {
        props: { expandToViewport, expandableGroups, variant },
        metadata: {
            mainAction: !!mainAction,
            checkboxItems: hasCheckboxItems(items),
            hasDisabledReason: Boolean(disabledReason),
            hasDisabledReasons: hasDisabledReasonItems(items),
        },
    });
    const baseProps = getBaseProps(props);
    const analyticsComponentMetadata = {
        name: 'awsui.ButtonDropdown',
        label: `.${analyticsSelectors['trigger-label']}`,
        properties: { variant, disabled: `${disabled}` },
    };
    return (React.createElement(InternalButtonDropdown, { ...baseProps, ...baseComponentProps, renderItem: renderItem, ref: ref, items: items, variant: variant, loading: loading, loadingText: loadingText, disabled: disabled, disabledReason: disabledReason, expandableGroups: expandableGroups, expandToViewport: expandToViewport, ariaLabel: ariaLabel, onItemClick: onItemClick, onItemFollow: onItemFollow, mainAction: mainAction, fullWidth: fullWidth, nativeMainActionAttributes: nativeMainActionAttributes, nativeTriggerAttributes: nativeTriggerAttributes, ...getAnalyticsMetadataAttribute({
            component: analyticsComponentMetadata,
        }) }, children));
});
applyDisplayName(ButtonDropdown, 'ButtonDropdown');
export default ButtonDropdown;
//# sourceMappingURL=index.js.map