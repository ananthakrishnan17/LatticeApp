// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import InternalIcon from '../../icon/internal';
import ItemsList from '../items-list';
import styles from './styles.css.js';
const CategoryElement = ({ item, index, onItemActivate, onGroupToggle, targetItem, isHighlighted, isKeyboardHighlight, isExpanded, lastInDropdown, highlightItem, disabled, variant, position, renderItem, }) => {
    var _a;
    const highlighted = isHighlighted(item);
    const groupProps = {
        type: 'group',
        index: index !== null && index !== void 0 ? index : 0,
        option: item,
        disabled: !!disabled,
        highlighted: !!highlighted,
        expanded: true,
        expandDirection: 'vertical',
    };
    const renderResult = (_a = renderItem === null || renderItem === void 0 ? void 0 : renderItem({ item: groupProps })) !== null && _a !== void 0 ? _a : null;
    // Hide the category title element from screen readers because it will be
    // provided as an ARIA label.
    return (React.createElement("li", { className: clsx(styles.category, styles[`variant-${variant}`], disabled && styles.disabled), role: "presentation" },
        item.text && (React.createElement("p", { className: clsx(styles.header, {
                [styles.disabled]: disabled,
                [styles['no-content-styling']]: !!renderResult,
            }), "aria-hidden": "true" }, renderResult ? (renderResult) : (React.createElement("span", { className: styles['header-content'] },
            (item.iconName || item.iconUrl || item.iconSvg) && (React.createElement("span", { className: styles['icon-wrapper'] },
                React.createElement(InternalIcon, { name: item.iconName, url: item.iconUrl, svg: item.iconSvg, alt: item.iconAlt }))),
            React.createElement("span", null, item.text))))),
        React.createElement("ul", { className: styles['items-list-container'], role: "group", "aria-label": item.text, "aria-disabled": disabled }, item.items && (React.createElement(ItemsList, { items: item.items, onItemActivate: onItemActivate, onGroupToggle: onGroupToggle, targetItem: targetItem, isHighlighted: isHighlighted, isKeyboardHighlight: isKeyboardHighlight, isExpanded: isExpanded, lastInDropdown: lastInDropdown, highlightItem: highlightItem, categoryDisabled: disabled, hasCategoryHeader: !!item.text, variant: variant, position: position, renderItem: renderItem, parentProps: groupProps })))));
};
export default CategoryElement;
//# sourceMappingURL=category-element.js.map