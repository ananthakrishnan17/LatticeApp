// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalFileDropzone from './internal';
import { useFilesDragging } from './use-files-dragging';
export { useFilesDragging };
export default function FileDropzone(props) {
    const baseComponentProps = useBaseComponent('FileDropzone');
    return React.createElement(InternalFileDropzone, { ...baseComponentProps, ...props });
}
applyDisplayName(FileDropzone, 'FileDropzone');
//# sourceMappingURL=index.js.map