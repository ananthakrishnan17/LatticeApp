// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { getExternalProps } from '../internal/utils/external-props';
import InternalFileUpload from './internal';
const FileUpload = React.forwardRef(({ multiple, showFileSize, showFileLastModified, showFileThumbnail, ...restProps }, ref) => {
    const baseComponentProps = useBaseComponent('FileUpload', {
        props: { multiple, showFileLastModified, showFileSize, showFileThumbnail, tokenLimit: restProps.tokenLimit },
    });
    const externalProps = getExternalProps(restProps);
    return (React.createElement(InternalFileUpload, { ref: ref, multiple: multiple, showFileSize: showFileSize, showFileLastModified: showFileLastModified, showFileThumbnail: showFileThumbnail, ...externalProps, ...baseComponentProps }));
});
applyDisplayName(FileUpload, 'FileUpload');
export default FileUpload;
//# sourceMappingURL=index.js.map