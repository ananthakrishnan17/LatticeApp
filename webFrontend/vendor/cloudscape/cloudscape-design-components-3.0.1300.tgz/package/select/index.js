// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { getExternalProps } from '../internal/utils/external-props';
import InternalSelect from './internal';
import analyticsSelectors from '../internal/components/button-trigger/analytics-metadata/styles.css.js';
const Select = React.forwardRef(({ options = [], filteringType = 'none', statusType = 'finished', triggerVariant = 'label', renderOption, ...restProps }, ref) => {
    var _a, _b, _c, _d;
    const baseComponentProps = useBaseComponent('Select', {
        props: {
            autoFocus: restProps.autoFocus,
            expandToViewport: restProps.expandToViewport,
            filteringType,
            triggerVariant,
            virtualScroll: restProps.virtualScroll,
            readOnly: restProps.readOnly,
        },
        metadata: {
            hasInlineLabel: Boolean(restProps.inlineLabelText),
            hasDisabledReasons: options.some(option => Boolean(option.disabledReason)),
        },
    });
    const externalProps = getExternalProps(restProps);
    const componentAnalyticsMetadata = {
        name: 'awsui.Select',
        label: `.${analyticsSelectors['button-trigger']}`,
        properties: {
            disabled: `${!!externalProps.disabled}`,
            selectedOptionValue: `${externalProps.selectedOption && externalProps.selectedOption.value ? externalProps.selectedOption.value : null}`,
            // Use label for display if available, fallback to value because that's what gets shown in dropdown when label is not provided
            selectedOption: `${(_d = (_b = (_a = externalProps.selectedOption) === null || _a === void 0 ? void 0 : _a.label) !== null && _b !== void 0 ? _b : (_c = externalProps.selectedOption) === null || _c === void 0 ? void 0 : _c.value) !== null && _d !== void 0 ? _d : null}`,
        },
    };
    return (React.createElement(InternalSelect, { renderOption: renderOption, options: options, filteringType: filteringType, statusType: statusType, triggerVariant: triggerVariant, ...externalProps, ...baseComponentProps, ref: ref, ...getAnalyticsMetadataAttribute({ component: componentAnalyticsMetadata }) }));
});
applyDisplayName(Select, 'Select');
export default Select;
//# sourceMappingURL=index.js.map