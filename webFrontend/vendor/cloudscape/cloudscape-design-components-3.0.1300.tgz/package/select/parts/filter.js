// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import InternalInput from '../../input/internal';
import styles from './styles.css.js';
const Filter = React.forwardRef(({ filteringType, ...filterProps }, ref) => {
    if (filteringType === 'none') {
        return null;
    }
    return (React.createElement(InternalInput, { ref: ref, type: "visualSearch", className: styles.filter, autoComplete: false, disableBrowserAutocorrect: true, invalid: false, __noBorderRadius: true, ...filterProps, nativeInputAttributes: {
            'aria-expanded': true,
            'aria-haspopup': 'listbox',
            role: 'combobox',
            autoCorrect: 'off',
            autoCapitalize: 'off',
            ...filterProps.nativeInputAttributes,
        }, __skipNativeAttributesWarnings: true }));
});
export default Filter;
//# sourceMappingURL=filter.js.map