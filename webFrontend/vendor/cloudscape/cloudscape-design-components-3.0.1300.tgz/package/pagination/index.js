// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalPagination from './internal';
const Pagination = React.forwardRef((props, ref) => {
    const baseComponentProps = useBaseComponent('Pagination', {
        props: { openEnd: props.openEnd },
        metadata: { hasJumpToPage: !!props.jumpToPage },
    });
    return (React.createElement(InternalPagination, { ...props, ...baseComponentProps, ref: ref, ...getAnalyticsMetadataAttribute({
            component: {
                name: 'awsui.Pagination',
                label: { root: 'self' },
                properties: {
                    openEnd: `${!!props.openEnd}`,
                    pagesCount: `${props.pagesCount || ''}`,
                    currentPageIndex: `${props.currentPageIndex}`,
                },
            },
        }) }));
});
applyDisplayName(Pagination, 'Pagination');
export default Pagination;
//# sourceMappingURL=index.js.map