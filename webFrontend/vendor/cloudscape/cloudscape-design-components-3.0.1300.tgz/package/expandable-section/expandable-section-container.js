// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import { getAnalyticsLabelAttribute, getAnalyticsMetadataAttribute, } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import { InternalContainerAsSubstep } from '../container/internal';
import { AnalyticsFunnelSubStep } from '../internal/analytics/components/analytics-funnel';
import { getAnalyticsMetadataProps } from '../internal/base-component';
import analyticsSelectors from './analytics-metadata/styles.css.js';
export const ExpandableSectionContainer = ({ className, children, header, variant, expanded, disableContentPaddings, __internalRootRef, __injectAnalyticsComponentMetadata, ...rest }) => {
    const analyticsMetadata = getAnalyticsMetadataProps(rest);
    const analyticsComponentMetadata = {
        name: 'awsui.ExpandableSection',
        label: { root: 'self' },
        properties: { variant, expanded: `${!!expanded}` },
    };
    const metadataAttribute = __injectAnalyticsComponentMetadata
        ? getAnalyticsMetadataAttribute({ component: analyticsComponentMetadata })
        : {};
    if (variant === 'container' || variant === 'stacked') {
        return (React.createElement(AnalyticsFunnelSubStep, { subStepIdentifier: analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.instanceIdentifier, subStepErrorContext: analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.errorContext },
            React.createElement(InternalContainerAsSubstep, { ...rest, className: className, header: header, variant: variant === 'stacked' ? 'stacked' : 'default', disableContentPaddings: disableContentPaddings || !expanded, disableHeaderPaddings: true, __hiddenContent: !expanded, __internalRootRef: __internalRootRef, ...metadataAttribute }, children)));
    }
    return (React.createElement("div", { className: className, ...rest, ref: __internalRootRef, ...metadataAttribute, ...getAnalyticsLabelAttribute(`.${analyticsSelectors['header-label']}`) },
        header,
        children));
};
//# sourceMappingURL=expandable-section-container.js.map