// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalExpandableSection from './internal';
export default function ExpandableSection({ variant = 'default', ...props }) {
    const analyticsMetadata = getAnalyticsMetadataProps(props);
    const baseComponentProps = useBaseComponent('ExpandableSection', {
        props: {
            disableContentPaddings: props.disableContentPaddings,
            headingTagOverride: props.headingTagOverride,
            variant,
        },
        metadata: {
            hasInstanceIdentifier: Boolean(analyticsMetadata === null || analyticsMetadata === void 0 ? void 0 : analyticsMetadata.instanceIdentifier),
            hasHeaderActions: Boolean(props.headerActions),
        },
    }, analyticsMetadata);
    return (React.createElement(InternalExpandableSection, { variant: variant, ...props, ...baseComponentProps, __injectAnalyticsComponentMetadata: true }));
}
applyDisplayName(ExpandableSection, 'ExpandableSection');
//# sourceMappingURL=index.js.map