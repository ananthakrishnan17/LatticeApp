// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalMultiselect from './internal';
import buttonTriggerAnalyticsSelectors from '../internal/components/button-trigger/analytics-metadata/styles.css.js';
const Multiselect = React.forwardRef(({ options = [], filteringType = 'none', statusType = 'finished', selectedOptions = [], keepOpen = true, hideTokens = false, renderOption, ...restProps }, ref) => {
    const baseComponentProps = useBaseComponent('Multiselect', {
        props: {
            inlineTokens: restProps.inlineTokens,
            autoFocus: restProps.autoFocus,
            expandToViewport: restProps.expandToViewport,
            filteringType,
            hideTokens,
            keepOpen,
            tokenLimit: restProps.tokenLimit,
            virtualScroll: restProps.virtualScroll,
            readOnly: restProps.readOnly,
            enableSelectAll: restProps.enableSelectAll,
        },
        metadata: {
            hasInlineLabel: Boolean(restProps.inlineLabelText),
            hasDisabledReasons: options.some(option => Boolean(option.disabledReason)),
        },
    });
    const componentAnalyticsMetadata = {
        name: 'awsui.Multiselect',
        label: `.${buttonTriggerAnalyticsSelectors['button-trigger']}`,
        properties: {
            disabled: `${!!restProps.disabled}`,
            selectedOptionsCount: `${selectedOptions.length}`,
            selectedOptionsValues: selectedOptions
                .filter(option => option.value !== undefined)
                .map(option => `${option.value}`),
            selectedOptions: selectedOptions
                .filter(option => option.value !== undefined)
                // fallback on value when label's undefined because in the dropdown if there's no label
                // the value will be shown.
                .map(option => { var _a; return `${(_a = option.label) !== null && _a !== void 0 ? _a : option.value}`; }),
        },
    };
    return (React.createElement(InternalMultiselect, { renderOption: renderOption, options: options, filteringType: filteringType, statusType: statusType, selectedOptions: selectedOptions, keepOpen: keepOpen, hideTokens: hideTokens, ...restProps, ...baseComponentProps, ref: ref, ...getAnalyticsMetadataAttribute({ component: componentAnalyticsMetadata }) }));
});
applyDisplayName(Multiselect, 'Multiselect');
export default Multiselect;
//# sourceMappingURL=index.js.map