// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalSpaceBetween from './internal';
export default function SpaceBetween({ direction = 'vertical', ...props }) {
    const baseComponentProps = useBaseComponent('SpaceBetween', {
        props: { alignItems: props.alignItems, direction, size: props.size },
    });
    return React.createElement(InternalSpaceBetween, { direction: direction, ...props, ...baseComponentProps });
}
applyDisplayName(SpaceBetween, 'SpaceBetween');
//# sourceMappingURL=index.js.map