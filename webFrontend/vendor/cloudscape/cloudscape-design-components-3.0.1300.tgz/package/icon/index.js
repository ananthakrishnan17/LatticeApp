// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalIcon from './internal';
export default function Icon({ size = 'normal', variant = 'normal', ...props }) {
    const baseComponentProps = useBaseComponent('Icon', { props: { name: props.name, size, variant } });
    return React.createElement(InternalIcon, { size: size, variant: variant, ...props, ...baseComponentProps });
}
applyDisplayName(Icon, 'Icon');
//# sourceMappingURL=index.js.map