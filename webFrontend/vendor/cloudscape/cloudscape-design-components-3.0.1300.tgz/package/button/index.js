// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { InternalButton } from './internal';
const Button = React.forwardRef(({ children, iconName, iconAlign = 'left', iconUrl, iconSvg, iconAlt, variant = 'normal', loading = false, loadingText, disabled = false, disabledReason, wrapText = true, href, target, rel, external = false, download, formAction = 'submit', ariaLabel, ariaDescribedby, onClick, onFollow, ariaExpanded, ariaHaspopup, ariaControls, fullWidth, form, i18nStrings, style, nativeButtonAttributes, nativeAnchorAttributes, ...props }, ref) => {
    const baseComponentProps = useBaseComponent('Button', {
        props: { formAction, fullWidth, iconAlign, iconName, rel, target, external, variant, wrapText },
        metadata: { hasDisabledReason: Boolean(disabledReason) },
    });
    const baseProps = getBaseProps(props);
    return (React.createElement(InternalButton, { ...baseProps, ...baseComponentProps, ref: ref, iconName: iconName, iconAlign: iconAlign, iconUrl: iconUrl, iconSvg: iconSvg, iconAlt: iconAlt, variant: variant, loading: loading, loadingText: loadingText, disabled: disabled, disabledReason: disabledReason, wrapText: wrapText, href: href, target: target, rel: rel, external: external, download: download, formAction: formAction, ariaLabel: ariaLabel, ariaDescribedby: ariaDescribedby, onClick: onClick, onFollow: onFollow, ariaExpanded: ariaExpanded, ariaHaspopup: ariaHaspopup, ariaControls: ariaControls, fullWidth: fullWidth, form: form, i18nStrings: i18nStrings, style: style, nativeButtonAttributes: nativeButtonAttributes, nativeAnchorAttributes: nativeAnchorAttributes, __injectAnalyticsComponentMetadata: true }, children));
});
applyDisplayName(Button, 'Button');
export default Button;
//# sourceMappingURL=index.js.map