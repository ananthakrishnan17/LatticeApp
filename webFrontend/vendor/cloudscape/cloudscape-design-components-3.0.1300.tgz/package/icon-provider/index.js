// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalIconProvider from './internal';
export { defineIcons } from './define-icons';
/**
 * @awsuiSystem core
 */
export default function IconProvider(props) {
    useBaseComponent('IconProvider');
    return React.createElement(InternalIconProvider, { ...props });
}
applyDisplayName(IconProvider, 'IconProvider');
//# sourceMappingURL=index.js.map