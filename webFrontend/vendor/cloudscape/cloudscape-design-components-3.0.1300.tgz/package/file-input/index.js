// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalFileInput from './internal';
const FileInput = React.forwardRef(({ multiple, variant, ...props }, ref) => {
    const baseComponentProps = useBaseComponent('FileInput', {
        props: {
            multiple,
            variant,
        },
    });
    return (React.createElement(InternalFileInput, { multiple: multiple, variant: variant, ...props, ...baseComponentProps, ref: ref, __injectAnalyticsComponentMetadata: true }));
});
applyDisplayName(FileInput, 'FileInput');
export default FileInput;
//# sourceMappingURL=index.js.map