// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { findUpUntil } from '@cloudscape-design/component-toolkit/dom';
import { fireKeyboardEvent } from '../../internal/events';
import { isHTMLElement } from '../../internal/utils/dom';
import handleKey from '../../internal/utils/handle-key';
import { getOwnerSelection, TOKEN_LENGTHS } from './caret-controller';
import { ElementType } from './constants';
import { createParagraph, createTrailingBreak, findAdjacentToken, findAllParagraphs, getTokenType, insertAfter, isCaretSpotType, isElementEffectivelyEmpty, isReferenceElementType, stripZeroWidthCharacters, } from './dom-utils';
import { getPromptText } from './token-operations';
import { removeTokenRange } from './token-utils';
import { handleDeleteAfterTrigger, handleSpaceInOpenMenu } from './trigger-utils';
import { isBreakTextToken, isBRElement, isTextNode } from './type-guards';
/** Handles all keyboard events for the editable element. */
export function handleEditableKeyDown(event, props) {
    const { editableElement, editableState, caretController, tokens, tokensToText } = props;
    const emitChange = (detail) => {
        props.markTokensAsSent(detail.tokens);
        props.onChange(detail);
    };
    const emitTokenDeletion = (newTokens, caretPos) => {
        const value = tokensToText ? tokensToText(newTokens) : getPromptText(newTokens);
        // Don't mark as sent — selection deletions use preventDefault so the DOM
        // is NOT updated by the browser. The render effect must see these as an
        // external change and re-render the DOM to match the new token state.
        props.onChange({ value, tokens: newTokens });
        if (caretController) {
            caretController.setCapturedPosition(caretPos);
        }
    };
    // Forward to consumer's onKeyDown
    fireKeyboardEvent(props.onKeyDown, event);
    const menuItemsState = props.getMenuItemsState();
    const menuItemsHandlers = props.getMenuItemsHandlers();
    const menuOpen = props.getMenuOpen();
    handleKey(event, {
        onInlineStart: () => handleInlineStart(event, caretController, props.announceTokenOperation),
        onInlineEnd: () => handleInlineEnd(event, caretController, props.announceTokenOperation),
        onShiftInlineStart: () => handleInlineStart(event, caretController, props.announceTokenOperation),
        onShiftInlineEnd: () => handleInlineEnd(event, caretController, props.announceTokenOperation),
        onSelectAll: () => {
            if ((tokens === null || tokens === void 0 ? void 0 : tokens.length) === 0) {
                event.preventDefault();
            }
        },
        onBackspace: () => {
            if (editableElement &&
                handleReferenceTokenDeletion(event, true, editableElement, editableState, props.announceTokenOperation, props.i18nStrings, caretController, tokens, emitTokenDeletion)) {
                return;
            }
            if (!tokens || !editableElement) {
                return;
            }
            if (tokens.length === 0) {
                event.preventDefault();
                return;
            }
            handleBackspaceAtParagraphStart(event, editableElement, tokens, tokensToText, emitChange, caretController);
        },
        onDelete: () => {
            if (editableElement &&
                handleReferenceTokenDeletion(event, false, editableElement, editableState, props.announceTokenOperation, props.i18nStrings, caretController, tokens, emitTokenDeletion)) {
                return;
            }
            if (!tokens || !editableElement) {
                return;
            }
            if (handleDeleteAtParagraphEnd(event, editableElement, tokens, tokensToText, emitChange, caretController)) {
                return;
            }
            handleDeleteAfterTrigger(event, editableElement);
        },
        onShiftEnter: () => {
            var _a;
            if (event.nativeEvent.isComposing || ((_a = props.isComposing) === null || _a === void 0 ? void 0 : _a.call(props))) {
                return;
            }
            event.preventDefault();
            if (caretController === null || caretController === void 0 ? void 0 : caretController.findActiveTrigger()) {
                return;
            }
            if (editableElement) {
                splitParagraphAtCaret(editableElement, caretController);
            }
        },
        onEnter: () => {
            var _a;
            if (event.nativeEvent.isComposing || ((_a = props.isComposing) === null || _a === void 0 ? void 0 : _a.call(props))) {
                return;
            }
            if (menuOpen && menuItemsHandlers) {
                event.preventDefault();
                menuItemsHandlers.selectHighlightedOptionWithKeyboard();
                return;
            }
            handleEnterSubmit(event, props);
        },
        onTab: () => {
            if (menuOpen && menuItemsHandlers && !event.shiftKey) {
                event.preventDefault();
                menuItemsHandlers.selectHighlightedOptionWithKeyboard();
            }
        },
        onSpace: () => {
            if (editableElement && handleSpaceAfterClosedTrigger(event, editableElement, menuOpen, caretController)) {
                return;
            }
            if (menuOpen && menuItemsHandlers && menuItemsState) {
                handleSpaceInOpenMenu(event, {
                    menuItemsState,
                    menuItemsHandlers,
                    getMenuStatusType: props.getMenuStatusType,
                    closeMenu: props.closeMenu,
                    caretController: caretController !== null && caretController !== void 0 ? caretController : undefined,
                    editableElement: editableElement !== null && editableElement !== void 0 ? editableElement : undefined,
                });
            }
        },
        onBlockEnd: () => {
            if (menuOpen && menuItemsHandlers) {
                event.preventDefault();
                menuItemsHandlers.moveHighlightWithKeyboard(1);
            }
        },
        onBlockStart: () => {
            if (menuOpen && menuItemsHandlers) {
                event.preventDefault();
                menuItemsHandlers.moveHighlightWithKeyboard(-1);
            }
        },
        onEscape: () => {
            if (menuOpen) {
                event.preventDefault();
                props.closeMenu();
            }
        },
    });
}
/** Handles Enter key for form submission and onAction. */
function handleEnterSubmit(event, props) {
    var _a, _b, _c;
    if (props.disabled || props.readOnly) {
        event.preventDefault();
        return;
    }
    const currentTarget = event.currentTarget;
    if (!isHTMLElement(currentTarget)) {
        return;
    }
    const form = currentTarget.closest('form');
    if (form && !event.isDefaultPrevented()) {
        form.requestSubmit();
    }
    event.preventDefault();
    const plainText = props.tokensToText ? props.tokensToText((_a = props.tokens) !== null && _a !== void 0 ? _a : []) : getPromptText((_b = props.tokens) !== null && _b !== void 0 ? _b : []);
    if (props.onAction) {
        props.onAction({ value: plainText, tokens: [...((_c = props.tokens) !== null && _c !== void 0 ? _c : [])] });
    }
}
/** Splits the current paragraph at the caret position, creating a new paragraph below. */
export function splitParagraphAtCaret(editableElement, caretController, suppressInputEvent = false) {
    var _a;
    const selection = getOwnerSelection(editableElement);
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return;
    }
    const range = selection.getRangeAt(0);
    const startElement = isHTMLElement(range.startContainer) ? range.startContainer : range.startContainer.parentElement;
    const currentP = startElement ? findUpUntil(startElement, node => node.nodeName === 'P') : null;
    if (!(currentP === null || currentP === void 0 ? void 0 : currentP.parentNode)) {
        return;
    }
    const afterRange = ((_a = editableElement.ownerDocument) !== null && _a !== void 0 ? _a : document).createRange();
    afterRange.setStart(range.startContainer, range.startOffset);
    afterRange.setEndAfter(currentP.lastChild || currentP);
    const afterContent = afterRange.extractContents();
    // Strip trailing breaks from extracted content — they belong only in empty paragraphs
    for (const child of Array.from(afterContent.childNodes)) {
        if (child.nodeName === 'BR') {
            child.remove();
        }
    }
    const newP = createParagraph();
    newP.appendChild(afterContent);
    if (isElementEffectivelyEmpty(newP)) {
        newP.appendChild(createTrailingBreak());
    }
    if (isElementEffectivelyEmpty(currentP)) {
        currentP.appendChild(createTrailingBreak());
    }
    currentP.parentNode.insertBefore(newP, currentP.nextSibling);
    let newCaretPos = null;
    if (caretController) {
        const currentPos = caretController.getPosition();
        newCaretPos = currentPos + TOKEN_LENGTHS.LINE_BREAK;
    }
    if (!suppressInputEvent) {
        editableElement.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (caretController && newCaretPos !== null) {
        caretController.setPosition(newCaretPos);
    }
}
function findTokenElementForDeletion(container, offset, isBackspace) {
    var _a;
    let adjacent = null;
    if (isTextNode(container)) {
        const isAtEdge = isBackspace ? offset === 0 : offset === (((_a = container.textContent) === null || _a === void 0 ? void 0 : _a.length) || 0);
        if (isAtEdge) {
            adjacent = isBackspace ? container.previousSibling : container.nextSibling;
        }
    }
    else if (isHTMLElement(container)) {
        const childIndex = isBackspace ? offset - 1 : offset;
        adjacent = container.childNodes[childIndex];
    }
    if (isHTMLElement(adjacent)) {
        const adjacentType = getTokenType(adjacent);
        if (isReferenceElementType(adjacentType)) {
            return {
                wrapperElement: adjacent,
                targetElement: adjacent,
            };
        }
    }
    return { targetElement: null, wrapperElement: null };
}
function isValidTokenForDeletion(element) {
    if (!element) {
        return false;
    }
    const tokenType = getTokenType(element);
    return isReferenceElementType(tokenType);
}
/** Handles Backspace/Delete when adjacent to a reference token. Returns true if handled. */
export function handleReferenceTokenDeletion(event, isBackspace, editableElement, state, announceTokenOperation, i18nStrings, caretController, tokens, emitChange) {
    var _a, _b;
    const selection = getOwnerSelection(editableElement);
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return false;
    }
    const range = selection.getRangeAt(0);
    if (!range.collapsed) {
        event.preventDefault();
        if (!caretController || !tokens || !emitChange) {
            return false;
        }
        // Map the DOM selection to logical token positions and remove the range
        // from state. The render effect will update the DOM on the next cycle.
        const startPos = caretController.getPosition();
        // Get end position by temporarily collapsing the range to its end
        const tempRange = range.cloneRange();
        tempRange.collapse(false);
        selection.removeAllRanges();
        selection.addRange(tempRange);
        const endPos = caretController.getPosition();
        selection.removeAllRanges();
        selection.addRange(range);
        const rangeStart = Math.min(startPos, endPos);
        const rangeEnd = Math.max(startPos, endPos);
        const newTokens = removeTokenRange(tokens, rangeStart, rangeEnd);
        emitChange(newTokens, rangeStart);
        return true;
    }
    const { targetElement, wrapperElement } = findTokenElementForDeletion(range.startContainer, range.startOffset, isBackspace);
    const tokenElement = targetElement || wrapperElement || null;
    if (!isValidTokenForDeletion(tokenElement)) {
        return false;
    }
    const elementToRemove = (wrapperElement || tokenElement);
    const paragraph = elementToRemove.parentNode;
    if (!paragraph) {
        return false;
    }
    event.preventDefault();
    const tokenLabel = ((_a = tokenElement.textContent) === null || _a === void 0 ? void 0 : _a.trim()) || '';
    if (announceTokenOperation && tokenLabel) {
        const announcement = (_b = i18nStrings === null || i18nStrings === void 0 ? void 0 : i18nStrings.tokenRemovedAriaLabel) === null || _b === void 0 ? void 0 : _b.call(i18nStrings, { label: tokenLabel, value: tokenLabel });
        if (announcement) {
            announceTokenOperation(announcement);
        }
    }
    state.skipNextZeroWidthUpdate = true;
    let newCaretPos = null;
    if (caretController) {
        const currentPos = caretController.getPosition();
        newCaretPos = isBackspace ? Math.max(0, currentPos - TOKEN_LENGTHS.REFERENCE) : currentPos;
    }
    elementToRemove.remove();
    editableElement.dispatchEvent(new Event('input', { bubbles: true }));
    if (caretController && newCaretPos !== null) {
        caretController.setPosition(newCaretPos);
    }
    return true;
}
/** If the caret is inside a reference's caret-spot, normalizes it to the paragraph level. */
function normalizeCaretOutOfReference(container, direction, event, selection) {
    var _a;
    if (!isTextNode(container)) {
        return false;
    }
    const parent = container.parentElement;
    if (!parent || !isCaretSpotType(getTokenType(parent))) {
        return false;
    }
    const wrapper = parent.parentElement;
    if (!wrapper || !isReferenceElementType(getTokenType(wrapper))) {
        return false;
    }
    const paragraph = wrapper.parentElement;
    if (!paragraph) {
        return false;
    }
    const wrapperIndex = Array.from(paragraph.childNodes).indexOf(wrapper);
    const newOffset = direction === 'backward' ? wrapperIndex : wrapperIndex + 1;
    event.preventDefault();
    const newRange = ((_a = paragraph.ownerDocument) !== null && _a !== void 0 ? _a : document).createRange();
    newRange.setStart(paragraph, newOffset);
    newRange.collapse(true);
    selection.removeAllRanges();
    selection.addRange(newRange);
    return true;
}
/** Handles inline-start (backward) arrow key — plain navigation or shift+selection across references. */
export function handleInlineStart(event, caretController, announceTokenOperation) {
    var _a;
    const selection = getOwnerSelection(event.currentTarget);
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return;
    }
    const range = selection.getRangeAt(0);
    if (range.collapsed && normalizeCaretOutOfReference(range.startContainer, 'backward', event, selection)) {
        return;
    }
    if (event.shiftKey) {
        handleShiftArrowAcrossTokens(event, selection, range, 'backward');
        return;
    }
    const { sibling, isReferenceToken } = findAdjacentToken(range.startContainer, range.startOffset, 'backward');
    if (isReferenceToken && sibling) {
        event.preventDefault();
        caretController === null || caretController === void 0 ? void 0 : caretController.moveBackward(TOKEN_LENGTHS.REFERENCE);
        if (announceTokenOperation && isHTMLElement(sibling)) {
            const label = stripZeroWidthCharacters(((_a = sibling.textContent) === null || _a === void 0 ? void 0 : _a.trim()) || '');
            if (label) {
                announceTokenOperation(label);
            }
        }
    }
}
/** Handles inline-end (forward) arrow key — plain navigation or shift+selection across references. */
export function handleInlineEnd(event, caretController, announceTokenOperation) {
    var _a;
    const selection = getOwnerSelection(event.currentTarget);
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return;
    }
    const range = selection.getRangeAt(0);
    if (range.collapsed && normalizeCaretOutOfReference(range.startContainer, 'forward', event, selection)) {
        return;
    }
    if (event.shiftKey) {
        handleShiftArrowAcrossTokens(event, selection, range, 'forward');
        return;
    }
    const { sibling, isReferenceToken } = findAdjacentToken(range.startContainer, range.startOffset, 'forward');
    if (isReferenceToken && sibling) {
        event.preventDefault();
        caretController === null || caretController === void 0 ? void 0 : caretController.moveForward(TOKEN_LENGTHS.REFERENCE);
        if (announceTokenOperation && isHTMLElement(sibling)) {
            const label = stripZeroWidthCharacters(((_a = sibling.textContent) === null || _a === void 0 ? void 0 : _a.trim()) || '');
            if (label) {
                announceTokenOperation(label);
            }
        }
    }
}
/** After the browser handles Shift+Arrow, nudge the focus past any reference it landed inside. */
function handleShiftArrowAcrossTokens(event, selection, range, direction) {
    var _a, _b;
    const isBackward = direction === 'backward';
    // Check if the focus is adjacent to a reference in the arrow direction
    const focusNode = selection.focusNode;
    const focusOff = selection.focusOffset;
    if (!focusNode) {
        return false;
    }
    let adjacentRef = null;
    // If focus is inside a reference (e.g. in a caret-spot), the reference itself is what we skip
    let containingRef = null;
    let node = isTextNode(focusNode) ? focusNode.parentElement : focusNode;
    while (node && isHTMLElement(node) && node !== event.currentTarget) {
        const tokenType = getTokenType(node);
        if (isReferenceElementType(tokenType)) {
            containingRef = node;
            break;
        }
        if (isCaretSpotType(tokenType) && node.parentElement) {
            const parentType = getTokenType(node.parentElement);
            if (isReferenceElementType(parentType)) {
                containingRef = node.parentElement;
                break;
            }
        }
        node = node.parentElement;
    }
    if (containingRef) {
        adjacentRef = containingRef;
    }
    else if (isTextNode(focusNode)) {
        if (isBackward && focusOff === 0) {
            adjacentRef = focusNode.previousSibling;
        }
        else if (!isBackward) {
            const len = ((_a = focusNode.textContent) === null || _a === void 0 ? void 0 : _a.length) || 0;
            // Check at the text boundary — only jump over the reference when focus
            // is at the very end of the text node, not one character before.
            if (focusOff >= len && focusNode.nextSibling) {
                const nextSibling = focusNode.nextSibling;
                if (isHTMLElement(nextSibling) && isReferenceElementType(getTokenType(nextSibling))) {
                    adjacentRef = nextSibling;
                }
            }
        }
        if (!adjacentRef && isBackward && focusOff === 0 && focusNode.previousSibling) {
            const previousSibling = focusNode.previousSibling;
            if (isHTMLElement(previousSibling) && isReferenceElementType(getTokenType(previousSibling))) {
                adjacentRef = previousSibling;
            }
        }
    }
    else if (isHTMLElement(focusNode)) {
        if (isBackward && focusOff > 0) {
            adjacentRef = focusNode.childNodes[focusOff - 1];
        }
        else if (!isBackward && focusOff < focusNode.childNodes.length) {
            adjacentRef = focusNode.childNodes[focusOff];
        }
    }
    if (!adjacentRef || !isHTMLElement(adjacentRef) || !isReferenceElementType(getTokenType(adjacentRef))) {
        return false;
    }
    const parent = adjacentRef.parentNode;
    if (!parent) {
        return false;
    }
    event.preventDefault();
    const index = Array.from(parent.childNodes).indexOf(adjacentRef);
    // Find the actual text node on the far side of the reference to extend into,
    // rather than using paragraph-level offsets which the browser may normalize
    // into the reference's caret-spot internals.
    let targetNode = parent;
    let targetOffset = isBackward ? index : index + 1;
    if (!isBackward) {
        const nextSibling = adjacentRef.nextSibling;
        if (nextSibling && isTextNode(nextSibling)) {
            targetNode = nextSibling;
            targetOffset = 0;
        }
    }
    else {
        const prevSibling = adjacentRef.previousSibling;
        if (prevSibling && isTextNode(prevSibling)) {
            targetNode = prevSibling;
            targetOffset = ((_b = prevSibling.textContent) === null || _b === void 0 ? void 0 : _b.length) || 0;
        }
    }
    // If extending would jump the focus past the anchor (deselecting through a reference),
    // collapse instead of flipping the selection direction.
    if (!range.collapsed && selection.anchorNode) {
        const anchorPos = adjacentRef.compareDocumentPosition(selection.anchorNode);
        const anchorIsAfter = (anchorPos & Node.DOCUMENT_POSITION_FOLLOWING) !== 0 || (anchorPos & Node.DOCUMENT_POSITION_CONTAINED_BY) !== 0;
        const anchorIsBefore = (anchorPos & Node.DOCUMENT_POSITION_PRECEDING) !== 0 || (anchorPos & Node.DOCUMENT_POSITION_CONTAINS) !== 0;
        if ((!isBackward && anchorIsAfter) || (isBackward && anchorIsBefore)) {
            const anchorNode = selection.anchorNode;
            const anchorOffset = selection.anchorOffset;
            selection.collapse(anchorNode, anchorOffset);
            selection.extend(targetNode, targetOffset);
            return true;
        }
    }
    selection.extend(targetNode, targetOffset);
    return true;
}
/** Handles space key after a closed trigger element, inserting the space outside the trigger. */
export function handleSpaceAfterClosedTrigger(event, editableElement, menuOpen, caretController) {
    var _a, _b;
    if (event.key !== ' ' || menuOpen) {
        return false;
    }
    const selection = getOwnerSelection(editableElement);
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return false;
    }
    const range = selection.getRangeAt(0);
    if (!range.collapsed) {
        return false;
    }
    let triggerElement = null;
    let caretAtEnd = false;
    if (isTextNode(range.startContainer)) {
        const parent = range.startContainer.parentElement;
        const parentType = parent ? getTokenType(parent) : null;
        if (parentType === ElementType.Trigger && parent) {
            triggerElement = parent;
            const textLength = ((_a = range.startContainer.textContent) === null || _a === void 0 ? void 0 : _a.length) || 0;
            caretAtEnd = range.startOffset === textLength;
        }
    }
    else if (isHTMLElement(range.startContainer)) {
        const container = range.startContainer;
        if (range.startOffset > 0) {
            const prevNode = container.childNodes[range.startOffset - 1];
            if (isHTMLElement(prevNode) && getTokenType(prevNode) === ElementType.Trigger) {
                triggerElement = prevNode;
                caretAtEnd = true;
            }
        }
    }
    if (!triggerElement || !caretAtEnd) {
        return false;
    }
    const paragraph = triggerElement.parentElement;
    if (!paragraph) {
        return false;
    }
    event.preventDefault();
    if (caretController) {
        caretController.capture();
    }
    const spaceNode = ((_b = triggerElement.ownerDocument) !== null && _b !== void 0 ? _b : document).createTextNode(' ');
    insertAfter(spaceNode, triggerElement);
    editableElement.dispatchEvent(new Event('input', { bubbles: true }));
    if (caretController) {
        caretController.restore(1);
    }
    return true;
}
/** Merges two adjacent paragraphs by removing the break token between them. */
export function mergeParagraphs(params) {
    const { direction, editableElement, tokens, currentParagraphIndex, tokensToText, onChange, caretController } = params;
    const paragraphs = findAllParagraphs(editableElement);
    if (direction === 'backward') {
        if (currentParagraphIndex <= 0) {
            return false;
        }
    }
    else {
        if (currentParagraphIndex >= paragraphs.length - 1) {
            return false;
        }
    }
    const breakIndexToRemove = direction === 'backward' ? currentParagraphIndex : currentParagraphIndex + 1;
    let breakCount = 0;
    let breakRemoved = false;
    const newTokens = tokens.filter(token => {
        if (isBreakTextToken(token)) {
            breakCount++;
            if (breakCount === breakIndexToRemove) {
                breakRemoved = true;
                return false;
            }
        }
        return true;
    });
    if (!breakRemoved) {
        return false;
    }
    const value = tokensToText ? tokensToText(newTokens) : getPromptText(newTokens);
    onChange({ value, tokens: newTokens });
    if (caretController) {
        const currentPos = caretController.getPosition();
        // Backspace: cursor was at start of next paragraph, now needs to move back by the removed break
        // Delete: cursor stays where it is — the next line merges into the current one
        const newCaretPos = direction === 'backward' ? currentPos - TOKEN_LENGTHS.LINE_BREAK : currentPos;
        caretController.setPosition(newCaretPos);
    }
    return true;
}
/** Handles Backspace at the start of a paragraph by merging with the previous one. */
export function handleBackspaceAtParagraphStart(event, editableElement, tokens, tokensToText, onChange, caretController) {
    const selection = getOwnerSelection(editableElement);
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return false;
    }
    const range = selection.getRangeAt(0);
    if (!range.collapsed ||
        range.startOffset !== 0 ||
        !isHTMLElement(range.startContainer) ||
        range.startContainer.nodeName !== 'P') {
        return false;
    }
    const paragraphs = findAllParagraphs(editableElement);
    const currentP = range.startContainer;
    const pIndex = Array.from(paragraphs).indexOf(currentP);
    if (pIndex < 0) {
        return false;
    }
    const merged = mergeParagraphs({
        direction: 'backward',
        editableElement,
        tokens,
        currentParagraphIndex: pIndex,
        tokensToText,
        onChange,
        caretController: caretController,
    });
    if (merged) {
        event.preventDefault();
    }
    return merged;
}
/** Handles Delete at the end of a paragraph by merging with the next one. */
export function handleDeleteAtParagraphEnd(event, editableElement, tokens, tokensToText, onChange, caretController) {
    var _a;
    const selection = getOwnerSelection(editableElement);
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return false;
    }
    const range = selection.getRangeAt(0);
    const container = range.startContainer;
    if (!range.collapsed) {
        return false;
    }
    let isAtEndOfParagraph = false;
    let currentP = null;
    if (isHTMLElement(container) && container.nodeName === 'P') {
        currentP = container;
        const hasOnlyTrailingBR = currentP.childNodes.length === 1 && isBRElement(currentP.firstChild);
        isAtEndOfParagraph = hasOnlyTrailingBR || range.startOffset === currentP.childNodes.length;
    }
    else if (isTextNode(container)) {
        isAtEndOfParagraph = range.startOffset === (((_a = container.textContent) === null || _a === void 0 ? void 0 : _a.length) || 0) && !container.nextSibling;
        let node = container;
        while (node && node.nodeName !== 'P') {
            node = node.parentNode;
        }
        currentP = node;
    }
    if (!isAtEndOfParagraph || !currentP) {
        return false;
    }
    const paragraphs = findAllParagraphs(editableElement);
    const pIndex = Array.from(paragraphs).indexOf(currentP);
    if (pIndex < 0) {
        return false;
    }
    const merged = mergeParagraphs({
        direction: 'forward',
        editableElement,
        tokens,
        currentParagraphIndex: pIndex,
        tokensToText,
        onChange,
        caretController: caretController,
    });
    if (merged) {
        event.preventDefault();
    }
    return merged;
}
/** Handles copy/cut events on the contentEditable element. */
export function handleClipboardEvent(event, editableElement, isCut) {
    const selection = getOwnerSelection(editableElement);
    if (!selection || selection.rangeCount === 0) {
        return;
    }
    const range = selection.getRangeAt(0);
    const fragment = range.cloneContents();
    const paragraphs = findAllParagraphs(fragment);
    const text = paragraphs.length > 0
        ? paragraphs.map(p => stripZeroWidthCharacters(p.textContent || '')).join('\n')
        : stripZeroWidthCharacters(fragment.textContent || '');
    event.clipboardData.setData('text/plain', text);
    event.preventDefault();
    if (isCut) {
        selection.deleteFromDocument();
    }
}
//# sourceMappingURL=event-handlers.js.map