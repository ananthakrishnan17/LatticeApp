// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { getOwnerSelection } from './caret-controller';
import { ElementType, SPECIAL_CHARS } from './constants';
import { insertAfter, stripZeroWidthCharacters } from './dom-utils';
/** Extracts typed text from a caret-spot, moving it to the paragraph level. */
function extractFromSpot(spot, trackCaret) {
    var _a, _b;
    const extraText = stripZeroWidthCharacters(spot.textContent || '');
    if (!extraText) {
        return null;
    }
    let caretWasHere = false;
    if (trackCaret) {
        const selection = getOwnerSelection(spot);
        if ((selection === null || selection === void 0 ? void 0 : selection.rangeCount) && spot.contains(selection.getRangeAt(0).startContainer)) {
            caretWasHere = true;
        }
    }
    const textNode = ((_a = spot.ownerDocument) !== null && _a !== void 0 ? _a : document).createTextNode(extraText);
    const wrapper = spot.parentElement;
    const isBefore = spot.getAttribute('data-type') === ElementType.CaretSpotBefore;
    if (isBefore) {
        (_b = wrapper.parentNode) === null || _b === void 0 ? void 0 : _b.insertBefore(textNode, wrapper);
    }
    else {
        insertAfter(textNode, wrapper);
    }
    spot.textContent = SPECIAL_CHARS.ZERO_WIDTH_CHARACTER;
    return caretWasHere ? textNode : null;
}
/** Extracts typed text from caret spots, moving it to the paragraph level. */
export function extractTextFromCaretSpots(portalContainers, trackCaret) {
    let movedTextNode = null;
    for (const container of portalContainers.values()) {
        const wrapper = container.element.parentElement;
        if (!wrapper) {
            continue;
        }
        for (const child of Array.from(wrapper.children)) {
            const type = child.getAttribute('data-type');
            if (type === ElementType.CaretSpotBefore || type === ElementType.CaretSpotAfter) {
                const result = extractFromSpot(child, trackCaret);
                if (result) {
                    movedTextNode = result;
                }
            }
        }
    }
    return { movedTextNode };
}
//# sourceMappingURL=caret-spot-utils.js.map