// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { isHTMLElement } from '../../internal/utils/dom';
import { ElementType } from './constants';
import { getTokenType, isCaretSpotType, isReferenceElementType } from './dom-utils';
import { isTextNode } from './type-guards';
// Module-level flag: mouse state is inherently global (one mouse per document)
// and must be accessible from the standalone normalizeSelection function.
let isMouseDown = false;
/** Updates the mouse-down tracking flag used to skip selection normalization during drag. */
export function setMouseDown(value) {
    isMouseDown = value;
}
/** Returns whether the mouse is currently pressed. */
export function getMouseDown() {
    return isMouseDown;
}
/**
 * Checks whether a node is inside a reference element's internals or directly
 * on the contentEditable div (not inside a paragraph). These are non-typeable
 * positions where the caret should not rest.
 */
export function isNonTypeablePosition(node) {
    while (node) {
        if (node.nodeName === 'P') {
            return false;
        }
        if (isHTMLElement(node)) {
            if (isReferenceElementType(getTokenType(node))) {
                return true;
            }
            if (node.getAttribute('contenteditable') === 'true') {
                return true;
            }
        }
        node = node.parentNode;
    }
    return false;
}
/**
 * Finds the reference wrapper element that contains the given node, if any.
 * Returns null if the node is not inside a reference element.
 */
export function findContainingReference(node) {
    while (node) {
        if (node.nodeName === 'P') {
            return null;
        }
        if (isHTMLElement(node) && isReferenceElementType(getTokenType(node))) {
            return node;
        }
        node = node.parentNode;
    }
    return null;
}
/**
 * Moves a collapsed caret out of non-typeable positions into the parent paragraph.
 * Handles caret inside reference element internals (caret spots, token container)
 * and caret on the contentEditable div itself (clicking on padding).
 * Some browsers (notably Firefox) may place the caret in these positions on focus
 * or imprecise clicks.
 */
export function normalizeCollapsedCaret(selection) {
    var _a;
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return;
    }
    const range = selection.getRangeAt(0);
    if (!range.collapsed) {
        return;
    }
    const container = range.startContainer;
    // Walk up from the caret position to find a reference wrapper.
    let node = isTextNode(container) ? container.parentElement : container;
    let wrapper = null;
    let caretSpotType = null;
    while (node && isHTMLElement(node)) {
        const tokenType = getTokenType(node);
        if (isCaretSpotType(tokenType)) {
            caretSpotType = tokenType;
        }
        if (isReferenceElementType(tokenType)) {
            wrapper = node;
            break;
        }
        node = node.parentElement;
    }
    if (!wrapper) {
        return;
    }
    const paragraph = wrapper.parentElement;
    if (!paragraph) {
        return;
    }
    const wrapperIndex = Array.from(paragraph.childNodes).indexOf(wrapper);
    // If we know the caret was in the before-spot, position before the wrapper.
    // Otherwise position after it (after-spot, token container, or wrapper itself).
    const newOffset = caretSpotType === ElementType.CaretSpotBefore ? wrapperIndex : wrapperIndex + 1;
    // Guard: skip if the selection is already at the target position.
    if (range.startContainer === paragraph && range.startOffset === newOffset) {
        return;
    }
    const newRange = ((_a = container.ownerDocument) !== null && _a !== void 0 ? _a : document).createRange();
    newRange.setStart(paragraph, newOffset);
    newRange.collapse(true);
    selection.removeAllRanges();
    selection.addRange(newRange);
}
/** Adjusts non-collapsed selection boundaries to exclude caret spot elements. */
export function normalizeSelection(selection, skipCaretSpots = false) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j;
    if (!(selection === null || selection === void 0 ? void 0 : selection.rangeCount)) {
        return;
    }
    const range = selection.getRangeAt(0);
    if (range.collapsed || isMouseDown || skipCaretSpots) {
        return;
    }
    const normalizeBoundary = (container) => {
        if (!isTextNode(container)) {
            return null;
        }
        const parent = container.parentElement;
        if (!parent) {
            return null;
        }
        const parentType = getTokenType(parent);
        if (!isCaretSpotType(parentType)) {
            return null;
        }
        const wrapper = parent.parentElement;
        if (!wrapper || !isReferenceElementType(getTokenType(wrapper))) {
            return null;
        }
        const paragraph = wrapper.parentElement;
        if (!paragraph) {
            return null;
        }
        const wrapperIndex = Array.from(paragraph.childNodes).indexOf(wrapper);
        const newOffset = parentType === ElementType.CaretSpotBefore ? wrapperIndex : wrapperIndex + 1;
        return { container: paragraph, offset: newOffset };
    };
    const normalizedStart = normalizeBoundary(range.startContainer);
    const normalizedEnd = normalizeBoundary(range.endContainer);
    if (!normalizedStart && !normalizedEnd) {
        return;
    }
    const newStartContainer = (_a = normalizedStart === null || normalizedStart === void 0 ? void 0 : normalizedStart.container) !== null && _a !== void 0 ? _a : range.startContainer;
    const newStartOffset = (_b = normalizedStart === null || normalizedStart === void 0 ? void 0 : normalizedStart.offset) !== null && _b !== void 0 ? _b : range.startOffset;
    const newEndContainer = (_c = normalizedEnd === null || normalizedEnd === void 0 ? void 0 : normalizedEnd.container) !== null && _c !== void 0 ? _c : range.endContainer;
    const newEndOffset = (_d = normalizedEnd === null || normalizedEnd === void 0 ? void 0 : normalizedEnd.offset) !== null && _d !== void 0 ? _d : range.endOffset;
    // Guard: skip if the selection already matches the normalized boundaries.
    // Prevents Safari from entering an infinite selectionchange loop in RTL.
    if (range.startContainer === newStartContainer &&
        range.startOffset === newStartOffset &&
        range.endContainer === newEndContainer &&
        range.endOffset === newEndOffset) {
        return;
    }
    // Determine if the selection is backward (focus before anchor in document order).
    // Range always has start <= end, but the user may be selecting in reverse.
    const isBackward = selection.anchorNode === range.endContainer &&
        selection.anchorOffset === range.endOffset &&
        selection.focusNode === range.startContainer &&
        selection.focusOffset === range.startOffset;
    if (isBackward) {
        // Preserve backward direction: collapse to anchor (end), extend to focus (start)
        const anchorContainer = (_e = normalizedEnd === null || normalizedEnd === void 0 ? void 0 : normalizedEnd.container) !== null && _e !== void 0 ? _e : range.endContainer;
        const anchorOffset = (_f = normalizedEnd === null || normalizedEnd === void 0 ? void 0 : normalizedEnd.offset) !== null && _f !== void 0 ? _f : range.endOffset;
        const focusContainer = (_g = normalizedStart === null || normalizedStart === void 0 ? void 0 : normalizedStart.container) !== null && _g !== void 0 ? _g : range.startContainer;
        const focusOffset = (_h = normalizedStart === null || normalizedStart === void 0 ? void 0 : normalizedStart.offset) !== null && _h !== void 0 ? _h : range.startOffset;
        selection.collapse(anchorContainer, anchorOffset);
        selection.extend(focusContainer, focusOffset);
    }
    else {
        const updatedRange = ((_j = range.startContainer.ownerDocument) !== null && _j !== void 0 ? _j : document).createRange();
        updatedRange.setStart(newStartContainer, newStartOffset);
        updatedRange.setEnd(newEndContainer, newEndOffset);
        selection.removeAllRanges();
        selection.addRange(updatedRange);
    }
}
//# sourceMappingURL=caret-utils.js.map