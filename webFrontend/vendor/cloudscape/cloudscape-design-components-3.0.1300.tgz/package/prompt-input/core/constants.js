// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export var ElementType;
(function (ElementType) {
    ElementType["Reference"] = "reference";
    ElementType["Pinned"] = "pinned";
    ElementType["CaretSpotBefore"] = "cursor-spot-before";
    ElementType["CaretSpotAfter"] = "cursor-spot-after";
    ElementType["Trigger"] = "trigger";
    ElementType["TrailingBreak"] = "trailing-break";
})(ElementType || (ElementType = {}));
export const SPECIAL_CHARS = {
    ZERO_WIDTH_CHARACTER: '\u200B',
    NEWLINE: '\n',
};
export const DEFAULT_MAX_ROWS = 3;
export const NEXT_TICK_TIMEOUT = 0;
//# sourceMappingURL=constants.js.map