// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalPromptInput from './internal';
const PromptInput = React.forwardRef(({ autoComplete, autoFocus, disableBrowserAutocorrect, disableActionButton, spellcheck, readOnly, actionButtonIconName, minRows = 1, maxRows = 3, ...props }, ref) => {
    const baseComponentProps = useBaseComponent('PromptInput', {
        props: {
            readOnly,
            autoComplete,
            autoFocus,
            disableBrowserAutocorrect,
            disableActionButton,
            spellcheck,
            actionButtonIconName,
            minRows,
            maxRows,
        },
    });
    return (React.createElement(InternalPromptInput, { readOnly: readOnly, autoComplete: autoComplete, autoFocus: autoFocus, disableBrowserAutocorrect: disableBrowserAutocorrect, disableActionButton: disableActionButton, spellcheck: spellcheck, actionButtonIconName: actionButtonIconName, minRows: minRows, maxRows: maxRows, ...props, ...baseComponentProps, ref: ref }));
});
applyDisplayName(PromptInput, 'PromptInput');
export default PromptInput;
//# sourceMappingURL=index.js.map