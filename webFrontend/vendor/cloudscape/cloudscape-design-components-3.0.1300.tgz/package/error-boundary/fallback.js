// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import IntlMessageFormat from 'intl-messageformat';
import InternalAlert from '../alert/internal';
import InternalButton from '../button/internal';
import { useInternalI18n } from '../i18n/context';
import { getBaseProps } from '../internal/base-component';
import { canUseRefresh, refreshPage } from './utils';
import styles from './styles.css.js';
import testUtilStyles from './test-classes/styles.css.js';
export function ErrorBoundaryFallback({ i18nStrings = {}, renderFallback, ...props }) {
    var _a;
    const baseProps = getBaseProps(props);
    const defaultSlots = {
        header: (React.createElement("div", { className: clsx(styles.header, testUtilStyles.header) },
            React.createElement(DefaultHeaderContent, { i18nStrings: i18nStrings }))),
        description: (React.createElement("div", { className: clsx(styles.description, testUtilStyles.description) },
            React.createElement(DefaultDescriptionContent, { i18nStrings: i18nStrings }))),
        action: canUseRefresh() ? (React.createElement("div", { className: clsx(styles.action, testUtilStyles.action) },
            React.createElement(DefaultActionContent, { i18nStrings: i18nStrings }))) : null,
    };
    return (React.createElement("div", { ...baseProps, className: clsx(baseProps.className, testUtilStyles.fallback) }, (_a = renderFallback === null || renderFallback === void 0 ? void 0 : renderFallback(defaultSlots)) !== null && _a !== void 0 ? _a : (React.createElement(InternalAlert, { type: "error", header: defaultSlots.header, action: defaultSlots.action }, defaultSlots.description))));
}
function DefaultHeaderContent({ i18nStrings }) {
    const i18n = useInternalI18n('error-boundary');
    return React.createElement(React.Fragment, null, i18n('i18nStrings.headerText', i18nStrings === null || i18nStrings === void 0 ? void 0 : i18nStrings.headerText));
}
function DefaultDescriptionContent({ i18nStrings: { descriptionText, components: { Feedback } = {} } = {}, }) {
    const i18n = useInternalI18n('error-boundary');
    // Dependencies for the intl-format function, where the pseudo-tags are declared as functions from parsed chunks.
    const formatArgs = Feedback
        ? {
            hasFeedback: true,
            Feedback: (chunks) => {
                var _a;
                return (React.createElement("span", { className: testUtilStyles['feedback-action'] },
                    React.createElement(Feedback, null, (_a = chunks[0]) !== null && _a !== void 0 ? _a : '')));
            },
        }
        : { hasFeedback: false, Feedback: () => React.createElement(React.Fragment, null) };
    // This ensures that the description string provided via i18nStrings also supports the <Feedback> injection,
    // because the i18n() helper propagates the second argument as is, without applying intl-format to it.
    // We wrap the format with try-catch to avoid intl errors caused by incorrectly referenced components.
    function safeFormat(descriptionText) {
        try {
            return descriptionText ? new IntlMessageFormat(descriptionText).format(formatArgs) : undefined;
        }
        catch {
            return descriptionText;
        }
    }
    const message = i18n('i18nStrings.descriptionText', safeFormat(descriptionText), format => format(formatArgs));
    // When the description includes <Feedback>, then the translated message is represented as an array of strings and
    // React elements that require keys when rendering to avoid React warnings.
    return (React.createElement(React.Fragment, null, Array.isArray(message) ? message.map((chunk, i) => React.createElement(React.Fragment, { key: i }, chunk)) : message));
}
function DefaultActionContent({ i18nStrings }) {
    const i18n = useInternalI18n('error-boundary');
    return (React.createElement(InternalButton, { iconName: "refresh", onClick: refreshPage, className: testUtilStyles['refresh-action'] }, i18n('i18nStrings.refreshActionText', i18nStrings === null || i18nStrings === void 0 ? void 0 : i18nStrings.refreshActionText)));
}
//# sourceMappingURL=fallback.js.map