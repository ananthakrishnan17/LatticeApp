// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { InternalErrorBoundary } from './internal';
function ErrorBoundary({ suppressNested = false, suppressible = false, ...props }) {
    var _a, _b;
    const baseComponentProps = useBaseComponent('ErrorBoundary', {
        props: { suppressNested, suppressible },
        metadata: {
            hasBoundaryId: !!props.errorBoundaryId,
            hasFeedbackAction: !!((_b = (_a = props.i18nStrings) === null || _a === void 0 ? void 0 : _a.components) === null || _b === void 0 ? void 0 : _b.Feedback),
            hasRenderFallback: !!props.renderFallback,
        },
    });
    return (React.createElement(InternalErrorBoundary, { ...baseComponentProps, ...props, suppressNested: suppressNested, suppressible: suppressible }));
}
applyDisplayName(ErrorBoundary, 'ErrorBoundary');
export default ErrorBoundary;
//# sourceMappingURL=index.js.map