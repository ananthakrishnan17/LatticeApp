// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalAttributeEditor from './internal';
const AttributeEditor = React.forwardRef(({ items = [], addButtonVariant = 'normal', isItemRemovable = () => true, hideAddButton, additionalActions, ...props }, ref) => {
    var _a, _b;
    const baseComponentProps = useBaseComponent('AttributeEditor', {
        props: {
            addButtonVariant: addButtonVariant,
        },
        metadata: {
            definitionItems: (_b = (_a = props.definition) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : null,
            hasGridLayout: !!props.gridLayout,
            hasCustomRowActions: !!props.customRowActions,
        },
    });
    return (React.createElement(InternalAttributeEditor, { items: items, isItemRemovable: isItemRemovable, addButtonVariant: addButtonVariant, additionalActions: additionalActions, hideAddButton: hideAddButton, ...props, ...baseComponentProps, ref: ref }));
});
applyDisplayName(AttributeEditor, 'AttributeEditor');
export default AttributeEditor;
//# sourceMappingURL=index.js.map