// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalFileTokenGroup from './internal';
const FileTokenGroup = ({ showFileLastModified, showFileSize, showFileThumbnail, alignment, limit, ...props }) => {
    const baseComponentProps = useBaseComponent('FileTokenGroup', {
        props: {
            showFileLastModified,
            showFileSize,
            showFileThumbnail,
            alignment,
            limit,
        },
    });
    return (React.createElement(InternalFileTokenGroup, { showFileLastModified: showFileLastModified, showFileSize: showFileSize, showFileThumbnail: showFileThumbnail, alignment: alignment, limit: limit, ...props, ...baseComponentProps }));
};
applyDisplayName(FileTokenGroup, 'FileTokenGroup');
export default FileTokenGroup;
//# sourceMappingURL=index.js.map