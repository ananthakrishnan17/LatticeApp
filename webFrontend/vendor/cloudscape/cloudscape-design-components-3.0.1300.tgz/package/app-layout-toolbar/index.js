// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { useMergeRefs, warnOnce } from '@cloudscape-design/component-toolkit/internal';
import { applyDefaults } from '../app-layout/defaults';
import { useAppLayoutPlacement } from '../app-layout/utils/use-app-layout-placement';
import AppLayoutToolbarInternal from '../app-layout/visual-refresh-toolbar';
import { AppLayoutToolbarPublicContext } from '../app-layout/visual-refresh-toolbar/contexts';
import { getBaseProps } from '../internal/base-component';
import useBaseComponent from '../internal/hooks/use-base-component';
import { useControllable } from '../internal/hooks/use-controllable';
import { useMobile } from '../internal/hooks/use-mobile';
import { useVisualRefresh } from '../internal/hooks/use-visual-mode';
import { isDevelopment } from '../internal/is-development';
import { applyDisplayName } from '../internal/utils/apply-display-name';
const AppLayoutToolbar = React.forwardRef(({ contentType = 'default', headerSelector = '#b #h', footerSelector = '#b #f', navigationWidth = 280, toolsWidth = 290, maxContentWidth, minContentWidth, navigationOpen: controlledNavigationOpen, onNavigationChange: controlledOnNavigationChange, analyticsMetadata, ...rest }, ref) => {
    var _a, _b;
    const isRefresh = useVisualRefresh();
    if (!isRefresh) {
        throw new Error(`AppLayoutToolbar component is not supported in the Classic theme. Please switch to the Refresh theme. For more details, refer to the documentation.`);
    }
    if (isDevelopment) {
        if (rest.toolsOpen && rest.toolsHide) {
            warnOnce('AppLayoutToolbar', `You have enabled both the \`toolsOpen\` prop and the \`toolsHide\` prop. This is not supported. Set \`toolsOpen\` to \`false\` when you set \`toolsHide\` to \`true\`.`);
        }
    }
    const { __internalRootRef } = useBaseComponent('AppLayoutToolbar', {
        props: {
            contentType,
            disableContentPaddings: rest.disableContentPaddings,
            navigationWidth,
            navigationHide: rest.navigationHide,
            toolsHide: rest.toolsHide,
            toolsWidth,
            maxContentWidth,
            minContentWidth,
            stickyNotifications: rest.stickyNotifications,
            disableContentHeaderOverlap: rest.disableContentHeaderOverlap,
            navigationTriggerHide: rest.navigationTriggerHide,
        },
        metadata: {
            drawersCount: (_b = (_a = rest.drawers) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : null,
            hasContentHeader: !!rest.contentHeader,
        },
    }, analyticsMetadata);
    const isMobile = useMobile();
    const { navigationOpen: defaultNavigationOpen, ...restDefaults } = applyDefaults(contentType, { maxContentWidth, minContentWidth }, isRefresh);
    const [navigationOpen = false, setNavigationOpen] = useControllable(controlledNavigationOpen, controlledOnNavigationChange, isMobile ? false : defaultNavigationOpen, { componentName: 'AppLayoutToolbar', controlledProp: 'navigationOpen', changeHandler: 'onNavigationChange' });
    const onNavigationChange = (event) => {
        setNavigationOpen(event.detail.open);
        controlledOnNavigationChange === null || controlledOnNavigationChange === void 0 ? void 0 : controlledOnNavigationChange(event);
    };
    const [rootRef, placement] = useAppLayoutPlacement(headerSelector, footerSelector);
    // This re-builds the props including the default values
    const props = {
        contentType,
        navigationWidth,
        toolsWidth,
        navigationOpen,
        onNavigationChange,
        ...restDefaults,
        ...rest,
        placement,
    };
    const baseProps = getBaseProps(rest);
    return (React.createElement(AppLayoutToolbarPublicContext.Provider, { value: true },
        React.createElement("div", { ref: useMergeRefs(__internalRootRef, rootRef), ...baseProps },
            React.createElement(AppLayoutToolbarInternal, { ref: ref, ...props }))));
});
applyDisplayName(AppLayoutToolbar, 'AppLayoutToolbar');
export default AppLayoutToolbar;
//# sourceMappingURL=index.js.map