// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalRadioGroup from './internal';
import analyticsSelectors from './analytics-metadata/styles.css.js';
const RadioGroup = React.forwardRef(({ direction = 'vertical', ...rest }, ref) => {
    const baseComponentProps = useBaseComponent('RadioGroup', {
        props: { readOnly: rest.readOnly, direction: direction !== null && direction !== void 0 ? direction : 'vertical' },
    });
    return (React.createElement(InternalRadioGroup, { ref: ref, direction: direction, ...rest, ...baseComponentProps, ...getAnalyticsMetadataAttribute({
            component: {
                name: 'awsui.RadioGroup',
                label: { root: 'self' },
                properties: {
                    value: `${rest.value}`,
                    valueLabel: `.${analyticsSelectors.selected}`,
                },
            },
        }) }));
});
applyDisplayName(RadioGroup, 'RadioGroup');
export default RadioGroup;
//# sourceMappingURL=index.js.map