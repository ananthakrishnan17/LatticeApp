// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import { InternalSideNavigation } from './internal';
import analyticsSelectors from './analytics-metadata/styles.css.js';
export default function SideNavigation({ items = [], ...props }) {
    const internalProps = useBaseComponent('SideNavigation');
    const componentAnalyticMetadata = {
        name: 'awsui.SideNavigation',
        label: `.${analyticsSelectors['header-link-text']}`,
        properties: {
            activeHref: props.activeHref || '',
        },
    };
    return (React.createElement(InternalSideNavigation, { ...props, ...internalProps, items: items, ...getAnalyticsMetadataAttribute({ component: componentAnalyticMetadata }) }));
}
applyDisplayName(SideNavigation, 'SideNavigation');
//# sourceMappingURL=index.js.map