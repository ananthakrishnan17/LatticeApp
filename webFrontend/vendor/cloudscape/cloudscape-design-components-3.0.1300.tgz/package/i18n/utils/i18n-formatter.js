// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import IntlMessageFormat from 'intl-messageformat';
import { getMatchableLocales } from './locales';
import { normalizeMessages } from './messages';
/**
 * A stateful container for formatting internal strings. Caches formatters
 * where possible; a new instance must be created if locale or messages may
 * have changed.
 */
export class I18nFormatter {
    constructor(locale, messages) {
        // Create a per-render cache of messages and IntlMessageFormat instances.
        // Not memoizing it allows us to reset the cache when the component rerenders
        // with potentially different locale or messages. We expect this component to
        // be placed above AppLayout and therefore rerender very infrequently.
        this._localeFormatterCache = new Map();
        this._locale = locale.toLowerCase();
        this._messages = normalizeMessages([messages]);
    }
    format(namespace, component, key, provided, customHandler) {
        var _a, _b, _c, _d;
        // A general rule in this library is that undefined is basically
        // treated as "not provided". So even if a user explicitly provides an
        // undefined value, it will default to i18n provider values.
        if (provided !== undefined) {
            return provided;
        }
        const cacheKey = `${namespace}.${component}.${key}`;
        let intlMessageFormat;
        const cachedFormatter = this._localeFormatterCache.get(cacheKey);
        if (cachedFormatter) {
            // If an IntlMessageFormat instance was cached for this locale, just use that.
            intlMessageFormat = cachedFormatter;
        }
        else {
            // Widen the locale string (e.g. en-GB -> en) until we find a locale
            // that contains the message we need.
            let message;
            const matchableLocales = getMatchableLocales(this._locale);
            for (const matchableLocale of matchableLocales) {
                message = (_d = (_c = (_b = (_a = this._messages) === null || _a === void 0 ? void 0 : _a[namespace]) === null || _b === void 0 ? void 0 : _b[matchableLocale]) === null || _c === void 0 ? void 0 : _c[component]) === null || _d === void 0 ? void 0 : _d[key];
                if (message !== undefined) {
                    break;
                }
            }
            // If a message wasn't found, exit early.
            if (message === undefined) {
                return provided;
            }
            // Lazily create an IntlMessageFormat object for this key.
            intlMessageFormat = new IntlMessageFormat(message, this._locale);
            this._localeFormatterCache.set(cacheKey, intlMessageFormat);
        }
        if (customHandler) {
            return customHandler(args => intlMessageFormat.format(args));
        }
        // Assuming `ReturnValue extends string` since a customHandler wasn't provided.
        return intlMessageFormat.format();
    }
}
//# sourceMappingURL=i18n-formatter.js.map