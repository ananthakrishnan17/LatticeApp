// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useContext } from 'react';
import { awsuiPluginsInternal } from '../internal/plugins/api';
export const namespace = 'cloudscape-design-components';
const defaultContextValue = {
    locale: null,
    format: (_namespace, _component, _key, provided) => provided,
};
export const InternalI18nContext = awsuiPluginsInternal.sharedReactContexts.createContext(React, 'InternalI18nContext');
export function useLocale() {
    var _a;
    return ((_a = useContext(InternalI18nContext)) !== null && _a !== void 0 ? _a : defaultContextValue).locale;
}
export function useInternalI18n(componentName) {
    var _a;
    const { format } = (_a = useContext(InternalI18nContext)) !== null && _a !== void 0 ? _a : defaultContextValue;
    return (key, provided, customHandler) => {
        return format(namespace, componentName, key, provided, customHandler);
    };
}
//# sourceMappingURL=context.js.map