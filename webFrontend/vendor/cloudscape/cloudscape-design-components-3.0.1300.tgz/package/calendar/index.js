// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalCalendar from './internal';
export default function Calendar({ locale = '', isDateEnabled = () => true, granularity = 'day', ...props }) {
    const baseComponentProps = useBaseComponent('Calendar', {
        props: { granularity },
        metadata: {
            hasDisabledReasons: Boolean(props.dateDisabledReason),
        },
    });
    return (React.createElement(InternalCalendar, { ...props, ...baseComponentProps, locale: locale, isDateEnabled: isDateEnabled, granularity: granularity }));
}
applyDisplayName(Calendar, 'Calendar');
//# sourceMappingURL=index.js.map