// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { forwardRef } from 'react';
import clsx from 'clsx';
import { getAnalyticsMetadataAttribute } from '@cloudscape-design/component-toolkit/internal/analytics-metadata';
import InternalIcon from '../icon/internal';
import { fireNonCancelableEvent } from '../internal/events';
import legacyTestingStyles from '../token-group/styles.css.js';
import styles from './styles.css.js';
import testUtilStyles from './test-classes/styles.css.js';
export default forwardRef(DismissButton);
function DismissButton({ disabled, dismissLabel, onDismiss, readOnly, inline }, ref) {
    const analyticsMetadata = {
        action: 'dismiss',
        detail: {
            label: { root: 'self' },
        },
    };
    return (React.createElement("button", { ref: ref, type: "button", className: clsx(styles['dismiss-button'], legacyTestingStyles['dismiss-button'], testUtilStyles['dismiss-button'], inline && styles['dismiss-button-inline']), "aria-disabled": disabled || readOnly ? true : undefined, onClick: () => {
            if (disabled || readOnly || !onDismiss) {
                return;
            }
            fireNonCancelableEvent(onDismiss);
        }, "aria-label": dismissLabel, ...(disabled || readOnly ? {} : getAnalyticsMetadataAttribute(analyticsMetadata)) },
        React.createElement(InternalIcon, { name: "close" })));
}
//# sourceMappingURL=dismiss-button.js.map