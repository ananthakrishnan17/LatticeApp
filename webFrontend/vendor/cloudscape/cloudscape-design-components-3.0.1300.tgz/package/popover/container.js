// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useLayoutEffect, useRef } from 'react';
import clsx from 'clsx';
import { getLogicalBoundingClientRect, useResizeObserver } from '@cloudscape-design/component-toolkit/internal';
import { useVisualRefresh } from '../internal/hooks/use-visual-mode';
import usePopoverPosition from './use-popover-position.js';
import usePositionObserver from './use-position-observer';
import styles from './styles.css.js';
export default function PopoverContainer({ position, trackRef, getTrack: externalGetTrack, trackKey, triggerClampRef, minVisibleBlockSize, arrow, children, zIndex, renderWithPortal, size, fixedWidth, variant, keepPosition, allowScrollToFit, allowVerticalOverflow, hideOnOverscroll, hoverArea, className, }) {
    const bodyRef = useRef(null);
    const contentRef = useRef(null);
    const popoverRef = useRef(null);
    const arrowRef = useRef(null);
    const isRefresh = useVisualRefresh();
    const getTrack = useRef(() => {
        if (trackRef) {
            return trackRef.current;
        }
        if (externalGetTrack) {
            return externalGetTrack();
        }
        throw new Error('Invariant violation: must provide either trackRef or getTrack.');
    });
    // Updates the position handler.
    const { updatePositionHandler, popoverStyle, internalPosition, positionHandlerRef, isOverscrolling } = usePopoverPosition({
        popoverRef,
        bodyRef,
        arrowRef,
        triggerClampRef,
        getTrack: getTrack.current,
        contentRef,
        allowScrollToFit,
        allowVerticalOverflow,
        preferredPosition: position,
        renderWithPortal,
        keepPosition,
        hideOnOverscroll,
        minVisibleBlockSize,
    });
    // Recalculate position when properties change.
    useLayoutEffect(() => {
        updatePositionHandler();
    }, [updatePositionHandler, trackKey]);
    // Recalculate position when content size changes.
    useResizeObserver(contentRef, () => {
        updatePositionHandler(true);
    });
    // Recalculate position when the DOM changes.
    // istanbul ignore next - tested via integration tests
    usePositionObserver(getTrack.current, trackKey, () => {
        // Do not update position if popover moved offscreen
        const popoverOffset = popoverRef.current && getLogicalBoundingClientRect(popoverRef.current);
        if (!popoverOffset || popoverOffset.insetBlockStart < 0 || popoverOffset.insetBlockEnd > window.innerHeight) {
            return;
        }
        positionHandlerRef.current();
    });
    // Recalculate position on resize or scroll events.
    useLayoutEffect(() => {
        const controller = new AbortController();
        const updatePositionOnResize = () => requestAnimationFrame(() => updatePositionHandler(true));
        const refreshPosition = () => requestAnimationFrame(() => positionHandlerRef.current());
        window.addEventListener('resize', updatePositionOnResize, { signal: controller.signal });
        window.addEventListener('scroll', refreshPosition, { capture: true, signal: controller.signal });
        return () => {
            controller.abort();
        };
    }, [hideOnOverscroll, keepPosition, positionHandlerRef, trackRef, updatePositionHandler]);
    return isOverscrolling ? null : (React.createElement("div", { ref: popoverRef, style: { ...popoverStyle, zIndex }, className: clsx(styles.container, isRefresh && styles.refresh, className) },
        React.createElement("div", { ref: arrowRef, className: clsx(styles[`container-arrow`], styles[`container-arrow-position-${internalPosition}`]), "aria-hidden": true }, arrow(internalPosition)),
        React.createElement("div", { ref: bodyRef, className: clsx(styles['container-body'], styles[`container-body-size-${size}`], {
                [styles['fixed-width']]: fixedWidth,
                [styles[`container-body-variant-${variant}`]]: variant,
            }) }, hoverArea ? (React.createElement("div", { className: styles['hover-area'] },
            React.createElement("div", { ref: contentRef }, children))) : (React.createElement("div", { ref: contentRef }, children)))));
}
//# sourceMappingURL=container.js.map