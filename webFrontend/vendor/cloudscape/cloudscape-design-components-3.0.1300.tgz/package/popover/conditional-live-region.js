// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import InternalLiveRegion from '../live-region/internal';
const ConditionalLiveRegion = ({ condition, children }) => {
    if (condition) {
        return React.createElement(InternalLiveRegion, null, children);
    }
    return React.createElement(React.Fragment, null, children);
};
export default ConditionalLiveRegion;
//# sourceMappingURL=conditional-live-region.js.map