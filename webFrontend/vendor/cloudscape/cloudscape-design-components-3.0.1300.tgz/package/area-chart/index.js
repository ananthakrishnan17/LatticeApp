// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalAreaChart from './internal';
function AreaChart({ height = 500, xScaleType = 'linear', yScaleType = 'linear', statusType = 'finished', detailPopoverSize = 'medium', i18nStrings = {}, ...props }) {
    const baseComponentProps = useBaseComponent('AreaChart', {
        props: {
            detailPopoverSize,
            hideLegend: props.hideLegend,
            hideFilter: props.hideFilter,
            fitHeight: props.fitHeight,
            xScaleType,
            yScaleType,
        },
    });
    return (React.createElement(InternalAreaChart, { height: height, xScaleType: xScaleType, yScaleType: yScaleType, statusType: statusType, detailPopoverSize: detailPopoverSize, i18nStrings: i18nStrings, ...props, ...baseComponentProps }));
}
applyDisplayName(AreaChart, 'AreaChart');
export default AreaChart;
//# sourceMappingURL=index.js.map