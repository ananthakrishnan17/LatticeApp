// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import React from 'react';
import useBaseComponent from '../internal/hooks/use-base-component';
import { applyDisplayName } from '../internal/utils/apply-display-name';
import InternalList from './internal';
export default function List(props) {
    const baseComponentProps = useBaseComponent('List');
    return React.createElement(InternalList, { ...baseComponentProps, ...props });
}
applyDisplayName(List, 'List');
//# sourceMappingURL=index.js.map